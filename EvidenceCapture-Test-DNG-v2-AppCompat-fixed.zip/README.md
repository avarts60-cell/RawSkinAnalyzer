Version: `0.6.0-evidence-dng`

# EvidenceCapture-Test DNG v2

This build captures:
- DNG using Android `DngCreator`
- JPEG
- `metadata.json`

Each capture stores SHA-256 hashes for the DNG and JPEG and writes a separate
integrity section for the metadata file.

Storage:
`Android/data/com.rawskinanalyzer/files/captures/<capture-id>/`

Release state: `RELEASE_UNVERIFIED`

Important: DNG creation depends on a matching RAW image and `TotalCaptureResult`.
