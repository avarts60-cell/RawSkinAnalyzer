# RawSkinAnalyzer Android

Runnable Android implementation starting point for Camera2 runtime inspection.

Build with Android Studio or `./gradlew assembleDebug` after Gradle wrapper setup.

Current release state: RELEASE_UNVERIFIED. This project is not a claim of production or clinical validation.
