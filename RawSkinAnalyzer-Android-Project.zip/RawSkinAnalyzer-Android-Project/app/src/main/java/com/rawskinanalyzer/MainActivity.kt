package com.rawskinanalyzer
import android.Manifest
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
class MainActivity: AppCompatActivity(){
 private lateinit var output:TextView
 private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it) inspect() else output.text="Camera permission denied."}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);output=findViewById(R.id.output);findViewById<Button>(R.id.inspectCamera).setOnClickListener{if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)inspect() else permission.launch(Manifest.permission.CAMERA)}}
 private fun inspect(){val m=getSystemService(CameraManager::class.java);output.text=buildString{appendLine("Camera2 inventory");appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}");appendLine("Android API: ${android.os.Build.VERSION.SDK_INT}");m.cameraIdList.forEach{id->val c=m.getCameraCharacteristics(id);appendLine("Camera $id");appendLine(" facing=${c.get(CameraCharacteristics.LENS_FACING)}");appendLine(" hardware=${c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)}");appendLine(" capabilities=${c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.joinToString(",")}")}}}
}
