# Project Status

## Current truthful status
Overall: STATIC_REVIEW COMPLETE; exact-baseline compilation UNVERIFIED; device verification UNVERIFIED.

The project has a real implementation path from capture through pixel-derived analysis, but it is not yet a validated skin-analysis system.

## What is implemented
- Camera permission and Camera2 activity
- JPEG capture
- RAW image/DNG creation path
- SHA-256 evidence hashes
- JPEG quality analysis
- Three required session steps
- Pixel-derived feature extraction and localized 6x6 pattern mapping
- Multiple heuristic characteristic analyzers
- Final ranked skin profile

## What is not established
- Exact ZIP compilation in the current audit environment
- Unit testing
- Integration testing
- Vivo T3 Ultra/device verification
- Calibration against ground truth
- Accuracy, sensitivity, specificity, or repeatability under controlled conditions
- Reliable face/cheek localization
- Direct measurement of pores, sebum, hydration, acne, tanning, or pigmentation

## Release recommendation
RELEASE_UNVERIFIED. Do not represent the current outputs as clinically validated or objectively measured skin conditions.

## Phase 2 repair status
- Left/right delta defect: REPAIRED (STATIC_REVIEW)
- Analysis completion failure gate: REPAIRED (STATIC_REVIEW)
- Exact compile: UNVERIFIED
- Device verification: UNVERIFIED

## Phase 3 status
Camera capability discovery: IMPLEMENTED (STATIC_REVIEW). RAW availability on target device: UNVERIFIED until runtime. Exact capture selection migration: PENDING COMPILE/DEVICE VALIDATION.

## Phase 4 status
Capture capability requirement: IMPLEMENTED (STATIC_REVIEW). Runtime RAW/JPEG decision now has explicit PASS/BLOCK behavior. Exact capture wiring and target-device operation remain UNVERIFIED.

## Phase 5 status
Skin ROI plausibility gate: IMPLEMENTED (STATIC_REVIEW). Anatomical face/cheek segmentation remains UNVERIFIED and is not claimed.

## Phase 6 status
Scoring policy transparency: IMPLEMENTED (STATIC_REVIEW).
Specialized detector calibration: UNVERIFIED.
Confidence semantics: explicitly marked rule-based/heuristic where reported by the new policy.

## Phase 7 status
Deterministic unit-test source: IMPLEMENTED.
UNIT_TESTED: UNVERIFIED pending successful execution on the exact baseline.

## Score provenance wiring status
Analyzer-to-final-profile registration: IMPLEMENTED AS SOURCE.
Exported JSON provenance: IMPLEMENTED AS SOURCE.
Exact compilation and runtime validation: UNVERIFIED.

## Skin-data state status
Canonical validity reporting: IMPLEMENTED AS SOURCE.
Competing direct status emission: REMOVED where matched.
Exact compile/runtime validation: UNVERIFIED.

## Skin concern interpretation
Concern model and interpreter: IMPLEMENTED AS SOURCE.
Final pipeline wiring/export: PENDING NEXT LAYER.
Medical diagnosis claims: NOT INTRODUCED.

## Skin objective planning
Concern-to-objective planner: IMPLEMENTED AS SOURCE.
Final JSON concern export: IMPLEMENTED AS SOURCE.
Final JSON objective export: IMPLEMENTED AS SOURCE.
Routine/product recommendation: NOT YET IMPLEMENTED.

## Routine strategy
Objective-to-strategy planner: IMPLEMENTED AS SOURCE.
AM/PM framework export: IMPLEMENTED AS SOURCE.
Ingredient selection: NOT YET IMPLEMENTED.
Product selection: NOT YET IMPLEMENTED.

## Ingredient strategy
Abstract category mapping: IMPLEMENTED AS SOURCE.
Specific ingredient and product selection: NOT YET IMPLEMENTED.

## Routine compatibility
Compatibility decision model: IMPLEMENTED AS SOURCE.
AM/PM and alternating/review export: IMPLEMENTED AS SOURCE.
Specific ingredient-level interaction rules: NOT YET IMPLEMENTED.
Concrete routine scheduling: NEXT LAYER.

## Routine scheduling
AM/PM schedule assembly: IMPLEMENTED AS SOURCE.
Alternating night-slot assembly: IMPLEMENTED AS SOURCE.
Specific ingredient frequency and product instructions: NOT YET IMPLEMENTED.
User-context personalization: NOT YET IMPLEMENTED.

## User routine context
Context model and schedule adjustment: IMPLEMENTED AS SOURCE.
Interactive collection of user preferences: NOT YET IMPLEMENTED.
Specific ingredient and product selection: NOT YET IMPLEMENTED.

## Specific ingredient mapping
Named ingredient option mapping: IMPLEMENTED AS SOURCE.
Tolerance-aware optional filtering: IMPLEMENTED AS SOURCE.
Concentration and frequency selection: NOT YET IMPLEMENTED.
Product selection: NOT YET IMPLEMENTED.

## Ingredient use planning
Categorical concentration guidance: IMPLEMENTED AS SOURCE.
Tolerance-aware frequency guidance: IMPLEMENTED AS SOURCE.
Exact percentage and individualized dosing: NOT IMPLEMENTED.
Product selection: NEXT LAYER.

## Product selection architecture
Requirement generation: IMPLEMENTED AS SOURCE.
Candidate model and ranking logic: IMPLEMENTED AS SOURCE.
Real product catalog integration: NOT YET IMPLEMENTED.
Product recommendation output: NOT YET IMPLEMENTED.

## Local product catalog integration
Local catalog adapter: IMPLEMENTED AS SOURCE.
End-to-end requirement-to-candidate ranking: IMPLEMENTED AS SOURCE.
Commercial product database: NOT YET IMPLEMENTED.
Live external catalog integration: NOT YET IMPLEMENTED.

## Commercial product catalog integration
Commercial record model: IMPLEMENTED AS SOURCE.
Validation and normalization adapter: IMPLEMENTED AS SOURCE.
Repository abstraction with local fallback: IMPLEMENTED AS SOURCE.
Live catalog provider/API: NOT YET IMPLEMENTED.
Actual product data population: NOT YET IMPLEMENTED.

## Product recommendation assembly
Structured recommendation records: IMPLEMENTED AS SOURCE.
Concern-to-product explanation: IMPLEMENTED AS SOURCE.
Caution propagation: IMPLEMENTED AS SOURCE.
Recommendation presentation/UI: NOT YET IMPLEMENTED.
Live commercial product data population: NOT YET IMPLEMENTED.

## Final skincare result
Unified end-user result model: IMPLEMENTED AS SOURCE.
AM/PM and alternating routine aggregation: IMPLEMENTED AS SOURCE.
Ingredient and recommendation aggregation: IMPLEMENTED AS SOURCE.
UI rendering: NOT YET IMPLEMENTED.
Live commercial product population: NOT YET IMPLEMENTED.

## Skin progress tracking
Longitudinal snapshot model: IMPLEMENTED AS SOURCE.
Feature-by-feature delta calculation: IMPLEMENTED AS SOURCE.
Improved/stable/worsened classification: IMPLEMENTED AS SOURCE.
Persistent previous-session storage: NOT YET IMPLEMENTED.
Automatic routine adaptation from progress: NOT YET IMPLEMENTED.

## Persistent session architecture
Session record model: IMPLEMENTED AS SOURCE.
Storage interface: IMPLEMENTED AS SOURCE.
Automatic previous-session retrieval: IMPLEMENTED AS SOURCE.
Automatic current-session saving: IMPLEMENTED AS SOURCE.
Current implementation persistence: IN-MEMORY ONLY.
Database-backed storage: NOT YET IMPLEMENTED.

## Routine adaptation
Progress-to-adaptation decision model: IMPLEMENTED AS SOURCE.
Adaptation reasons and affected features: IMPLEMENTED AS SOURCE.
Automatic routine rewriting: NOT YET IMPLEMENTED.
Multi-session trend aggregation: NOT YET IMPLEMENTED.
Persistent database backend: NOT YET IMPLEMENTED.

## Routine adaptation execution
Controlled adaptation executor: IMPLEMENTED AS SOURCE.
Maintain and simplify execution: IMPLEMENTED AS SOURCE.
Automatic intensification: BLOCKED.
Adjustment requiring compatibility/tolerance review: IMPLEMENTED AS SOURCE.
Multi-session trend policy: NOT YET IMPLEMENTED.
Persistent database backend: NOT YET IMPLEMENTED.

## Multi-session trend analysis
Compatible session history retrieval: IMPLEMENTED AS SOURCE.
Three-or-more session trend detection: IMPLEMENTED AS SOURCE.
Up to five recent session analysis: IMPLEMENTED AS SOURCE.
Trend-aware adaptation policy: NEXT LAYER.

## Trend-aware adaptation
Multi-session trend policy: IMPLEMENTED AS SOURCE.
Short-term fallback with insufficient trend data: IMPLEMENTED AS SOURCE.
Sustained improvement reinforcement: IMPLEMENTED AS SOURCE.
Sustained worsening escalation: IMPLEMENTED AS SOURCE.
Trend-aware automatic ingredient substitution: NOT YET IMPLEMENTED.

## Trend-aware routine adjustment generation
Sustained-worsening candidate generation: IMPLEMENTED AS SOURCE.
Existing compatible ingredient-plan matching: IMPLEMENTED AS SOURCE.
Automatic frequency escalation: BLOCKED.
Automatic replacement with new ingredients: NOT YET IMPLEMENTED.
Candidate activation after review: NEXT LAYER.

## Candidate activation and controlled revision
Candidate compatibility lookup: IMPLEMENTED AS SOURCE.
Direct caution gate: IMPLEMENTED AS SOURCE.
Unsupported automatic frequency changes: BLOCKED.
Approved/rejected candidate audit output: IMPLEMENTED AS SOURCE.
Controlled routine revision generation: IMPLEMENTED AS SOURCE.
Persistent database backend: NOT YET IMPLEMENTED.

## Persistent skin session storage
Android persistent session store: IMPLEMENTED AS SOURCE.
Session restoration after app restart: IMPLEMENTED AS SOURCE.
Analysis-version compatibility retention: IMPLEMENTED AS SOURCE.
Encrypted storage: NOT YET IMPLEMENTED.
Room/SQLite backend: OPTIONAL FUTURE BACKEND.

## Session retention and lifecycle
Configurable maximum session retention: IMPLEMENTED AS SOURCE.
Analysis-version retention window: IMPLEMENTED AS SOURCE.
Obsolete-session cleanup: IMPLEMENTED AS SOURCE.
Automatic cleanup trigger: NEXT INTEGRATION STEP.

## Automatic lifecycle integration
Lifecycle execution after session save: IMPLEMENTED AS SOURCE.
Default retention policy application: IMPLEMENTED AS SOURCE.
Custom retention policy support: IMPLEMENTED AS SOURCE.
Manual lifecycle API retained: IMPLEMENTED AS SOURCE.

## Session data integrity and recovery
Per-session structural validation: IMPLEMENTED AS SOURCE.
Score range and finite-value validation: IMPLEMENTED AS SOURCE.
Partial malformed-entry recovery: IMPLEMENTED AS SOURCE.
Whole-storage corruption recovery: IMPLEMENTED AS SOURCE.
Integrity telemetry/reporting: NEXT LAYER.

## Integrity telemetry and recovery reporting
Safe integrity status reporting: IMPLEMENTED AS SOURCE.
Valid/rejected session counts: IMPLEMENTED AS SOURCE.
Recovery-applied indicator: IMPLEMENTED AS SOURCE.
Malformed raw data exposure: BLOCKED.
Persistent telemetry history: NOT YET IMPLEMENTED.

## Integrity-aware trend confidence
Integrity support classification: IMPLEMENTED AS SOURCE.
Confidence downgrade after partial recovery: IMPLEMENTED AS SOURCE.
Trend disabling after recovery failure: IMPLEMENTED AS SOURCE.
Automatic analyzer wiring to persistent-store telemetry: NEXT INTEGRATION STEP.

## Automatic integrity-aware trend pipeline
Persistent-store telemetry consumption: IMPLEMENTED AS SOURCE.
Automatic confidence qualification: IMPLEMENTED AS SOURCE.
Trend withholding after integrity recovery failure: IMPLEMENTED AS SOURCE.
In-memory store compatibility: IMPLEMENTED AS SOURCE.

## Pipeline section status
Persistent multi-session history, retention, recovery, telemetry, and integrity-aware trend confidence: COMPLETE AS SOURCE IMPLEMENTATION.

## Session N+1 audit (forensic inspection + repair)

### What was inspected
Full source tree (`app/src/main`, `app/src/test`), build config (`build.gradle.kts`,
`app/build.gradle.kts`, `settings.gradle.kts`), `build-error.txt`, and prior status docs.
No files were deleted or restarted. No new architecture, categories, or LLM were added.

### Top weaknesses found, ranked by impact on trustworthiness
1. **Unit tests were non-executable, not just unrun.** `SkinRoiValidityTest` calls
   `android.graphics.Bitmap.createBitmap`, `eraseColor`, `getPixel`/`setPixel`, and
   `Color.rgb`. Under plain JUnit with the stock (non-Robolectric) Android stub jar,
   every one of those calls throws `RuntimeException("... not mocked ...")` at test
   runtime — there was no `org.robolectric` dependency, no `@RunWith(RobolectricTestRunner)`,
   and no `unitTests.returnDefaultValues` fallback anywhere in the project. This means
   the prior "Deterministic unit-test source: IMPLEMENTED" claim in this file was true
   only in the sense that the `.kt` file existed — the test would fail immediately on
   first execution, so it provided zero actual verification of `SkinRoiValidator`
   despite being reported as unit-test coverage. This is exactly the "class/file exists
   != functionality verified" failure mode this audit was asked to guard against, and it
   directly undermines confidence in the ROI-validity gate that the rest of the pipeline
   depends on for input trustworthiness.
2. **No compilation is possible in this audit environment.** This sandbox has no Android
   SDK and no network access to Google's/Maven Central's repositories (network egress is
   restricted to a fixed allowlist that does not include `dl.google.com` or
   `repo.maven.apache.org`). `build-error.txt`'s "BUILD SUCCESSFUL" is from a different,
   earlier workspace path and cannot be treated as evidence for this exact ZIP. This
   remains an honest gap, not something fixable from source alone.
3. **The full trend/routine/product-recommendation subsystem (~30 files) is still not
   called from `MainActivity`.** This matches what this file already disclosed
   ("UI rendering: NOT YET IMPLEMENTED", "Final pipeline wiring/export: PENDING NEXT
   LAYER"), so it is not a new finding, but it is reconfirmed here: none of
   `AutomaticIntegrityAwareTrendPipeline`, `MultiSessionTrendAnalyzer`, or
   `TrendAwareRoutineAdaptationPolicy` are referenced anywhere in `MainActivity.kt`. The
   capture → quality → ROI → feature/pattern/characteristic-scoring → final-profile path
   IS wired end-to-end and does run for real per-image pixel data (verified by reading
   `runFullAnalysisPipelineOnce()` and its ~25 stage functions against their analyzer
   implementations).

### What was fixed this session
- Added `org.robolectric:robolectric:4.13` as a `testImplementation` dependency in
  `app/build.gradle.kts`, plus `testOptions.unitTests.isIncludeAndroidResources = true`.
- Annotated `SkinRoiValidityTest` with `@RunWith(RobolectricTestRunner::class)` and
  `@Config(sdk = [34])` so `Bitmap`/`Color` calls resolve to real Robolectric shadows
  instead of throwing at runtime.
- `AnalysisScorePolicyTest` was left unchanged — it does not touch any `android.*` type
  and was already genuinely executable under plain JUnit.

### What could not be verified
- Whether the project now compiles with Robolectric pulled in, since this environment
  cannot reach Maven Central/Google's Maven to resolve `org.robolectric:robolectric:4.13`
  or re-run `assembleDebug`/`testDebugUnitTest`. The dependency coordinate and API usage
  (`RobolectricTestRunner`, `@Config(sdk=...)`) are correct for Robolectric 4.13, but this
  is UNVERIFIED until built with real network/SDK access.
- Device behavior on the Vivo T3 Ultra (camera RAW capability, DNG write success, ROI
  validity thresholds against real skin tones/lighting) remains UNVERIFIED, unchanged
  from prior sessions.
- Whether `testDebugUnitTest` now actually passes end to end — the fix addresses the
  specific, identified cause of failure (missing Robolectric), but was not run.

### Compilation/test status this session
STATIC_REVIEW: COMPLETE. COMPILED: UNVERIFIED (no SDK/network in this environment).
UNIT_TESTED: UNVERIFIED (fix applied but not executed).

### Single highest-priority next task (superseded by the session below — see there)
Run `./gradlew testDebugUnitTest` in an environment with network access to Google's/Maven
Central's repositories to confirm `SkinRoiValidityTest` now actually passes under
Robolectric, then run `./gradlew assembleDebug` against this exact ZIP (not the
`ForensicAudit-Phase7-Test`/`SkinInterpretation-v1-Test` paths referenced in the stale
`build-error.txt`) to get a real, current `BUILD SUCCESSFUL` for this baseline.

## Session N+2: repair broken end-to-end wiring (concern → routine → product → trend)

### Current project phase
Post-audit repair. The capture → quality → ROI → per-image analyzer → final-profile
scoring chain is real and wired (confirmed in the prior session). This session's job was
to find and connect the single highest-priority *remaining* disconnected/broken system on
top of that, per the standing instruction to always verify rather than assume a wired-looking
call actually compiles.

### Logical implementation step completed in this session
`FinalSkinAnalysisProfileAnalyzer.json()` already *attempted* to wire the entire
concern → objective → routine-strategy → ingredient-strategy → compatibility → schedule →
specific-ingredient → use-plan → product-requirement → product-match → recommendation →
final-routine-result → progress-snapshot → multi-session-trend → trend-aware-adaptation →
adjustment-generation → candidate-activation → adaptation-execution chain (roughly 20
previously "IMPLEMENTED AS SOURCE / NOT YET WIRED" files). On inspection this attempt did
not compile. Four real, distinct defects were found and fixed:

1. **`SkinConcernInterpreter.fromFinalProfile`** referenced a nonexistent
   `profile.rankedFindings` property (the real property is `findings`) and called a
   nonexistent `FinalScoreRegistry.get(...)` method. Fixed the property name and added
   `FinalScoreRegistry.get(characteristic): FinalScoreProvenance?` as a minimal, in-pattern
   extension of the existing registry (it already had `register`/`all`/`clear`).
2. **`FinalSkinAnalysisProfile` was missing the per-characteristic score fields** that
   `json()` tried to read (`x.pigmentationScore`, `x.rednessScore`, etc.) to build the
   progress-tracking snapshot, and `json()` also referenced a nonexistent
   `x.finalAnalysisConfidence` (the real field is `analysisConfidence`). Extended the data
   class with the 8 named score fields the analyzer already computes internally
   (`redness.overallRednessScore`, `pigment.pigmentationVariationScore`, `darkMarkScore`,
   `blemish.blemishLikeScore`, `texture.textureIrregularityScore`,
   `texture.poreLikeSignalScore`, `surface.oilinessSignalScore`,
   `surface.drynessRelatedSignalScore`) and populated them in `analyze()`'s return value,
   and fixed the `finalAnalysisConfidence` typo.
3. **Use-before-declaration**: `controlledRoutineRevision` consumed
   `generatedRoutineAdjustment` before that `val` was declared later in the same function
   body. Reordered so `generatedRoutineAdjustment` (and its JSON) is computed first.
4. **Malformed string interpolation**: `strategy.morningFramework.joinToString(",") { ""$it"" }`
   and the same for `eveningFramework` used unescaped, unjoined empty-string literals
   instead of `{ "\"$it\"" }` (the pattern used correctly everywhere else in the same
   file). Fixed both to match the working pattern.

Every other call in this ~20-file chain (`RoutineStrategyPlanner`, `IngredientStrategyPlanner`,
`RoutineCompatibilityPlanner`, `RoutineSchedulePlanner`, `RoutineContextPlanner`,
`SpecificIngredientMapper`, `IngredientUsePlanner`, `ProductSelectionPlanner`,
`ProductCatalogRepository`/`CommercialProductCatalogAdapter`/`LocalProductCatalog`,
`ProductRecommendationAssembler`, `FinalRoutineResultAssembler`, `SkinProgressTracker`,
`SkinSessionRepository`, `MultiSessionTrendAnalyzer`, `TrendAwareRoutineAdaptationPolicy`,
`RoutineAdaptationEngine`, `TrendAwareRoutineAdjustmentGenerator`,
`RoutineAdjustmentCandidateActivator`, `RoutineAdaptationExecutor`) was checked
field-by-field and signature-by-signature against its actual definition and found to
already be structurally consistent — those parts did not need changes.

### Files created or modified
- `app/src/main/java/com/rawskinanalyzer/FinalSkinAnalysisProfileAnalyzer.kt` — added 8
  score fields to `FinalSkinAnalysisProfile`, populated them in `analyze()`, fixed the
  progress-snapshot field source and the `finalAnalysisConfidence` typo, reordered
  `generatedRoutineAdjustment`/`controlledRoutineRevision`, fixed the two malformed
  `joinToString` lambdas.
- `app/src/main/java/com/rawskinanalyzer/SkinConcernInterpreter.kt` — fixed
  `rankedFindings` → `findings`.
- `app/src/main/java/com/rawskinanalyzer/FinalScoreProvenance.kt` — added
  `FinalScoreRegistry.get(characteristic)`.

### Systems that are now connected (structurally — see Testing status)
Concern interpretation → objective planning → routine strategy → ingredient strategy →
routine compatibility → routine schedule → user-context adjustment → specific ingredient
mapping → ingredient use planning → product requirement generation → product catalog
matching → product recommendation → final routine result → progress snapshot comparison
→ multi-session trend → trend-aware adaptation policy → trend-aware adjustment generation
→ candidate activation → adaptation execution → session persistence (in-memory). All of
this is invoked from `FinalSkinAnalysisProfileAnalyzer.json()`, which
`MainActivity.runFinalSkinAnalysisProfile()` already calls and writes to
`final_skin_analysis_profile.json` per session.

### Important systems still disconnected
- No UI renders any of this JSON — it is file output only, same as before.
- `SkinSessionRepository` still defaults to `InMemorySkinSessionStore`; `configure()` is
  never called with `PersistentSkinSessionStore`, so trend/progress data does not survive
  an app restart despite `PersistentSkinSessionStore` existing as source.
- `ProductCatalogRepository.replace(...)` (commercial catalog) is never called, so
  `ProductCatalogRepository.candidates()` always falls back to `LocalProductCatalog`.
- Integrity-aware trend confidence (`SkinSessionRepository.integrityAwareTrendConfidence`,
  `applyIntegrityAwareTrendPipeline`) is not called from this JSON path — the trend result
  it exports is not yet qualified by integrity telemetry.

### Known implementation limitations
- The added score fields on `FinalSkinAnalysisProfile` duplicate information already
  present per-item in `findings` (by design, to avoid a fragile string-match lookup) —
  this is a deliberate, minimal, additive change, not a redesign of the model.
- `json()` remains a very large function that does real work (including a persistence
  side effect via `SkinSessionRepository.save`) inside what reads as a serializer. That
  pre-existing structural issue was not refactored this session, per the instruction to
  avoid unrelated refactors — it's flagged here as a candidate for a future session.

### Testing status
STATIC_REVIEW: COMPLETE for the four defects above and their call sites. COMPILED:
UNVERIFIED — this sandbox has no Android SDK and no network access to Google's/Maven
Central's repositories, so `./gradlew` cannot be run here. No new automated tests were
added for this chain in this session. Everything in this section is a source-level fix
verified by manual signature/field cross-referencing, not a build or test run.

### Exact recommended next implementation step (superseded — see Session N+3 below)
Run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` in an environment with
real network/SDK access to get a first genuine compile of this chain and catch anything
missed by manual review. If it compiles, the next *logical* step is wiring
`SkinSessionRepository.configure(PersistentSkinSessionStore(...))` so multi-session trend
data survives app restarts — this is the smallest change that would make the
already-wired `multi_session_trend` and `skin_progress` JSON sections reflect real
longitudinal data instead of always starting from an empty in-memory history.

## Session N+3: lighting / capture-condition normalization layer

### Current implementation phase
New capability addition on top of the already-wired capture → quality → ROI →
feature/pattern/characteristic-scoring → final-profile chain. This session did not touch
the trend/routine/product subsystem, `PersistentSkinSessionStore` wiring, or any other
area — scope was limited to capture-condition normalization only, per the session
instruction.

### Where normalization enters the pipeline
Two insertion points, both immediately downstream of the existing quality gate
(`ImageQualityAnalyzer`) and both operating only on the already-derived
`analysis_normalized.jpg` copy, never on `capture.dng` / `capture.jpg`:
1. **Per-capture** (`MainActivity.finishEvidence` → `recordCaptureConditionForStep`): runs
   once per FRONT/LEFT_CHEEK/RIGHT_CHEEK capture, immediately after
   `analysis_normalized.jpg` is written and only if that write succeeded.
2. **Per-session** (`MainActivity.runFullAnalysisPipelineOnce` → new first stage
   `runCaptureConditionConsistency()`, before `runSessionFeatureExtraction()`): runs once
   all three views exist, comparing conditions across the full session before any
   feature/pattern/scoring stage runs.

### Normalization components implemented
- `CaptureConditionProfileAnalyzer` (new) — read-only. Samples the derived analysis copy
  and computes mean luma, per-channel (R/G/B) means, gray-world `rgRatio`/`bgRatio`, a
  `colorCastMagnitude`, dynamic range, an `illuminantEstimate`
  (NEUTRAL / LIKELY_WARM_OR_ORANGE_SHIFTED / LIKELY_COOL_OR_BLUE_SHIFTED), a clamped
  `suggestedExposureGain` (target mid-gray / measured luma, clamped to [0.75, 1.35]), and
  structured warnings (`LOW_LIGHT`, `OVEREXPOSED`, `LOW_DYNAMIC_RANGE`,
  `MODERATE_COLOR_CAST`, `STRONG_COLOR_CAST`). This is the structural representation of
  capture conditions — computing it never modifies any pixel.
- `ThreeViewCaptureConditionAnalyzer` (new) — compares the three per-view profiles from a
  session: luma spread, color-cast spread, gain spread, left/right luma and color-cast
  deltas, an overall `consistency` classification
  (HIGH_CAPTURE_CONDITION_CONSISTENCY / MODERATE_CAPTURE_CONDITION_VARIATION /
  MAJOR_CAPTURE_CONDITION_INCONSISTENCY), and structured cross-view warnings
  (`MAJOR_LIGHTING_MISMATCH_ACROSS_VIEWS`, `MODERATE_LIGHTING_MISMATCH_ACROSS_VIEWS`,
  `MAJOR_COLOR_CAST_MISMATCH_ACROSS_VIEWS`, `MODERATE_COLOR_CAST_MISMATCH_ACROSS_VIEWS`,
  `LEFT_RIGHT_LIGHTING_MISMATCH`, `SESSION_LIGHTING_RELIABILITY_REDUCED`). This is the
  three-view capture-condition difference representation.
- `CaptureConditionNormalizer` (new) — the only place any pixel value is changed. Writes a
  **separate, additional** file, `analysis_lighting_normalized.jpg`, applying a single
  uniform brightness gain (the clamped `suggestedExposureGain`, applied equally to R/G/B —
  no per-channel color grading, no smoothing, no blur, no blemish/texture alteration) to a
  copy of `analysis_normalized.jpg`. It is skipped entirely (no file written) when the
  gain is within 0.06 of 1.0, so well-lit captures are left untouched. It never overwrites
  `analysis_normalized.jpg` or any evidence file.

### Existing components reused
`ImageQualityAnalyzer` (unchanged) still gates and produces `analysis_normalized.jpg`
exactly as before; the new layer only reads that file and the existing `add()` /
`recordAnalysisFailure()` / `latestNormalized()` MainActivity helpers, following the same
per-stage try/catch and stage-failure-recording pattern used by every other analyzer in
`runFullAnalysisPipelineOnce()`.

### What data remains original
`capture.dng`, `capture.jpg`, their SHA-256 hashes, and `metadata.json` are untouched —
nothing in this session reads or writes those files. `analysis_normalized.jpg` (already
consumed by every existing downstream analyzer) is also untouched by this session; the new
exposure-leveled file is additional, not a replacement.

### What warnings can be produced
Per-view: `LOW_LIGHT`, `OVEREXPOSED`, `LOW_DYNAMIC_RANGE`, `MODERATE_COLOR_CAST`,
`STRONG_COLOR_CAST`. Session-level (three-view): `MAJOR_LIGHTING_MISMATCH_ACROSS_VIEWS`,
`MODERATE_LIGHTING_MISMATCH_ACROSS_VIEWS`, `MAJOR_COLOR_CAST_MISMATCH_ACROSS_VIEWS`,
`MODERATE_COLOR_CAST_MISMATCH_ACROSS_VIEWS`, `LEFT_RIGHT_LIGHTING_MISMATCH`,
`SESSION_LIGHTING_RELIABILITY_REDUCED`. All are written to
`{front,left_cheek,right_cheek}_capture_condition.json` and `capture_condition_session.json`
in the session root, and to the per-capture `capture_condition.json` in each step's
evidence directory, and surfaced in the on-screen log via `add(...)`.

### What remains incomplete in this implementation step
- The exposure-leveled derived copy (`analysis_lighting_normalized.jpg`) is written but
  **not yet consumed** by any feature/tone/redness/pigmentation analyzer — all of those
  still read `analysis_normalized.jpg` via `latestNormalized()`, unchanged. Deliberately
  not wired this session: swapping a brightness-adjusted image into color/tone-sensitive
  analyzers needs its own careful review (to confirm it measurably improves cross-view
  comparability rather than just adding a second, differently-biased input) rather than
  being folded into this session as a side effect.
- `capture_condition_session.json` is not yet read by `SkinDataQualityProfileAnalyzer` or
  `AnalysisConfidenceScorer` to downgrade quality/confidence when lighting is
  inconsistent — it is currently informational output only, not yet a scoring input.
- No device/runtime verification (no SDK/network in this sandbox — same standing
  limitation as prior sessions). `ThreeViewCaptureConditionAnalyzerTest` (new, plain JUnit,
  no `android.*` dependency) is source-verified by manual trace of all four cases but not
  executed here.
- `CaptureConditionProfileAnalyzer` itself (the per-image analyzer) has no dedicated unit
  test yet — it depends on `android.graphics.BitmapFactory`/`Bitmap`, so a real test would
  need the same Robolectric setup as `SkinRoiValidityTest`.

### Exact recommended next implementation step
Run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` in an environment with real
network/SDK access to get a first genuine compile+test pass of this session's three new
files plus the existing Robolectric fix. If that passes, the next logical step is deciding
(with real test captures under mismatched lighting) whether `analysis_lighting_normalized.jpg`
should replace `analysis_normalized.jpg` as the input to `ToneColorFeatureAnalyzer` /
`RednessAnalysisAnalyzer` / `PigmentationTanningAnalyzer`, or whether those analyzers should
instead just consume `capture_condition_session.json` as a confidence qualifier — that
choice should not be made without being able to actually compare outputs on real images.

## Session N+4: Batch 1 — core analysis calibration foundation

### Current implementation phase
New architectural layer inserted into the already-wired capture → quality → ROI →
feature/pattern → normalization → characteristic-scoring → final-profile chain. No
existing system was rebuilt or replaced; this session added one new file and made five
small, behavior-preserving edits to existing analyzers plus one MainActivity wiring
addition, per the standing instruction to continue only from unfinished work.

### What existed before this session
`SkinFeatureQuantificationAnalyzer`, `ToneColorFeatureAnalyzer`,
`TextureCharacterizationAnalyzer`, and `LocalizedFeatureAnalyzer` already performed real
NORMALIZATION — scaling raw pixel-derived measurements onto a common 0-100 axis. Five
downstream analyzers (`RednessAnalysisAnalyzer`, `PigmentationTanningAnalyzer`,
`BlemishFeatureAnalyzer`, `TexturePoreFeatureAnalyzer`, `SurfaceConditionAnalyzer`) each
combined those normalized signals into a single characteristic score using a hardcoded
weighted-sum formula inlined in that file. That combination step is calibration, but it
was invisible as a pipeline stage: five different files, five different undocumented
weight sets, no single place to inspect or audit them, and no provenance analogous to
what `FinalScoreProvenance`/`FinalScoreRegistry` already provide one stage later.

### What was added this session
- **`SkinScoreCalibration.kt`** (new) — a single object exposing one named function per
  characteristic (`redness`, `pigmentationVariation`, `blemishLike`,
  `textureIrregularity`, `poreLike`, `surfaceOiliness`, `surfaceDryness`). Each function
  takes the same normalized inputs the prior inline formula used, applies the *same*
  weights (verified line-by-line against the formulas being replaced), and returns a
  `CalibratedComponent` recording every named input, its weight, and its contribution —
  not just the final number.
- **`CalibrationRegistry`** (in the same file) — clear-per-session, register-on-compute,
  read-back registry mirroring the existing `FinalScoreRegistry` pattern one stage
  earlier, so the calibration stage is inspectable the same way final-score provenance
  already is.
- **`MainActivity.reportCalibrationProvenance()`** (new) — writes
  `calibration_provenance.json` per session (all `CalibratedComponent`s with their input
  breakdown) and logs a human-readable per-characteristic breakdown, called immediately
  after `runFinalSkinAnalysisProfile()` builds the final profile and before
  `reportFinalScoreProvenance()`. `CalibrationRegistry.clear()` was added alongside the
  existing `FinalScoreRegistry.clear()` in `beginFinalScoreProvenance()`.

### Files modified and exact nature of each change
- `RednessAnalysisAnalyzer.kt` — replaced inline
  `(q.localizedRedness*0.55 + withinVariation*2.0 + elevated*0.25)` with a call to
  `SkinScoreCalibration.redness(...).calibratedScore`. Same three inputs, same three
  weights, same clamp — output is numerically identical.
- `PigmentationTanningAnalyzer.kt` — replaced inline
  `(q.toneVariation*0.55 + withinVariation*1.5 + tone.darkAreaScore*0.20 + darkerPercent*0.10)`
  with `SkinScoreCalibration.pigmentationVariation(...).calibratedScore`. Same four
  inputs/weights, output unchanged.
- `BlemishFeatureAnalyzer.kt` — replaced inline
  `(candidatePercent*0.55 + localized.hotspotDensity*0.20 + repeatedBonus + q.localizedRedness*0.10)`
  with `SkinScoreCalibration.blemishLike(...).calibratedScore`. `repeatedBonus` is passed
  with calibration weight `1.0` because it was already a pre-scaled bonus (0/8/18/30) in
  the original formula, not a normalized-then-weighted signal — documented explicitly in
  the new function's doc comment so a future reader doesn't "fix" it into a double-weight.
- `TexturePoreFeatureAnalyzer.kt` — replaced both inline `textureScore` and `poreScore`
  formulas with `SkinScoreCalibration.textureIrregularity(...)` and
  `SkinScoreCalibration.poreLike(...)`. Same inputs/weights for both, outputs unchanged.
- `SurfaceConditionAnalyzer.kt` — replaced inline `oil`/`dry` formulas with
  `SkinScoreCalibration.surfaceOiliness(...)` and `SkinScoreCalibration.surfaceDryness(...)`.
  Same inputs/weights for both, outputs unchanged.
- `MainActivity.kt` — added `CalibrationRegistry.clear()` to `beginFinalScoreProvenance()`,
  added `reportCalibrationProvenance()`, and called it from `runFinalSkinAnalysisProfile()`.

### What was deliberately not changed
- No calibration weight was retuned. This session is an extraction/centralization of
  existing behavior into an inspectable stage, not a re-calibration against any ground
  truth — there is still no ground-truth data to calibrate against (see "What is not
  established" at the top of this file).
- `SkinCharacteristicScoringAnalyzer` (the separate, earlier scoring path wired directly
  in `MainActivity.runSkinCharacteristicScoring()`, distinct from the five analyzers
  above that actually feed `FinalSkinAnalysisProfileAnalyzer`) was left untouched. It has
  its own independent weighted combinations (e.g. `q.toneVariation*0.65 + tone.darkAreaScore*0.35`
  for its pigmentation figure) that do not match the final-profile path's weights one for
  one. Folding it into the same calibration object was judged to be a larger, separate
  architectural decision (would either change its output values or require a second,
  differently-weighted calibration function per characteristic) and was left as a
  candidate for a future session rather than bundled into this one.
- `AnalysisConfidenceScorer` and `AnalysisScorePolicy` (the CONFIDENCE stage) were not
  changed — this session's scope was strictly the NORMALIZATION → CALIBRATION →
  CHARACTERISTIC SCORE boundary.

### Testing / compilation status
STATIC_REVIEW: COMPLETE — every replaced formula was checked term-by-term against its
replacement to confirm identical inputs, weights, and clamping, so no output value
should change. COMPILED: UNVERIFIED, same standing limitation as every prior session —
this sandbox has no Android SDK and no network access to Google's/Maven Central's
repositories, so `./gradlew` cannot be run here. No new unit test was added for
`SkinScoreCalibration` in this session.

### Exact recommended next implementation step
Run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` in an environment with
real network/SDK access to confirm this session's refactor compiles and that existing
behavior is unchanged. If it compiles, the next logical Batch 1 step is either (a) adding
a dedicated `SkinScoreCalibrationTest` (plain JUnit, no `android.*` dependency, so it does
not need Robolectric) asserting each calibration function reproduces the exact values the
old inline formulas produced for known inputs, or (b) deciding whether
`SkinCharacteristicScoringAnalyzer`'s separate, differently-weighted formulas should be
migrated onto the same `SkinScoreCalibration` object or explicitly documented as an
intentionally distinct scoring path.

## Session N+5: Batch 2 — feature-specific calibration and validation framework

### Current implementation phase
New pipeline stage inserted immediately after Batch 1's CALIBRATION stage, per the target
architecture (`CHARACTERISTIC ANALYZER -> FEATURE-SPECIFIC CALIBRATION -> 0-100 SCORE ->
CONFIDENCE -> FUSION -> FINAL PROFILE`). No existing analyzer, calibration weight, or
scoring formula was changed. Scope was limited to Batch 2's stated objective — making the
existing calibration stage validatable and preparing it for real (future, ground-truth)
validation — not a re-calibration and not a new characteristic.

### What existed before this session
`SkinScoreCalibration.kt` (Batch 1) recorded every calibration input, weight, and
contribution per characteristic via `CalibrationRegistry`, but recorded them uncritically —
nothing checked whether an input was in a plausible range for the weight it was being
multiplied by, whether the recorded `calibratedScore` actually matched its own recorded
inputs, or whether a value was silently clamped from a much larger raw sum. Batch 1's own
doc comment flagged this directly: "not clinical calibration... there is still no
ground-truth data to calibrate against."

### What was added this session
- **`FeatureCalibrationValidation.kt`** (new) —
  - `FeatureCalibrationBounds`: one documented plausibility bound per distinct input name
    actually produced across all seven `SkinScoreCalibration` functions (17 inputs — see
    file for the full list), each traced back to the exact upstream analyzer expression
    that produces it. Percent-shaped and explicitly-clamped inputs (e.g.
    `elevated_redness_area_percent`, `localized_redness_normalized`) are marked
    `HARD_GUARANTEED` to [0,100]; the four `std(...)`-derived "variation" inputs (raw pixel
    luma/redness/texture units, never clamped upstream) are marked `SOFT_PLAUSIBILITY` with
    a documented working-range ceiling instead of a mathematical one.
  - `FeatureCalibrationValidator`: checks each `CalibratedComponent` for (1) non-finite
    input or score values, (2) inputs outside their documented bound — `ERROR` for a broken
    `HARD_GUARANTEED` bound, `WARNING` for a `SOFT_PLAUSIBILITY` one, (3) an input with no
    bound defined yet (`INFO`, does not fail validation — a deliberate escape hatch so a
    future new calibration input doesn't silently start failing everything), (4) the
    recorded `calibratedScore` recomputed from the component's own recorded inputs and
    compared for consistency (`SCORE_INPUT_SUM_MISMATCH`, `ERROR`), and (5) a raw
    (pre-clamp) weighted sum over 100 flagged as `INFO` so a score sitting at the 100 clamp
    boundary is visibly distinguishable from one that reached 100 "naturally."
  - `MainActivity.reportCalibrationValidation()` (new) — writes
    `calibration_validation.json` per session (all results with their findings) and logs a
    per-characteristic valid/invalid line plus each finding, called immediately after
    `reportCalibrationProvenance()` and before `reportFinalScoreProvenance()` in
    `runFinalSkinAnalysisProfile()`. No existing function was modified beyond this one call
    insertion.
  - `FeatureCalibrationValidatorTest.kt` (new, plain JUnit, no `android.*` dependency —
    does not need Robolectric) — 8 tests covering: a real, plausible `redness` component
    passing clean; a `HARD_GUARANTEED` violation producing `ERROR`/`invalid=false`; a
    `SOFT_PLAUSIBILITY` violation producing `WARNING` while remaining `valid=true`; a
    non-finite input; a hand-constructed score/input mismatch; a raw-sum-clamped case
    producing `INFO` only; an unbounded input name producing `INFO` only; and a coverage
    test that calls all seven real `SkinScoreCalibration` functions and asserts every
    input name they currently emit has a bound in `FeatureCalibrationBounds` (so adding a
    new named input without updating the bounds table fails this test immediately).

### Explicitly not a gate
Findings are reported, not enforced — no pipeline stage's output is withheld, altered, or
blocked because of a validation finding, matching Batch 1's non-blocking precedent
(`AnalysisScorePolicy`, `SkinRoiValidator`) where those already gate; this new stage does
not add a new gate. `valid=false` on a component is visible in
`calibration_validation.json` and the on-screen log, not enforced anywhere else yet — see
"Exact recommended next implementation step" below for the natural place to change that.

### What was deliberately not changed
- No `SkinScoreCalibration` weight was retuned and no bound was reverse-engineered from
  "what score would I like" — every bound in `FeatureCalibrationBounds` was derived by
  reading the exact upstream expression that produces that input, documented per-entry.
- `SkinCharacteristicScoringAnalyzer`'s separate, differently-weighted scoring path
  (flagged as a still-open question at the end of the Batch 1 session log above) was left
  untouched again this session — it does not go through `SkinScoreCalibration` at all, so
  it is out of scope for a validator that operates on `CalibratedComponent`.
- `AnalysisConfidenceScorer` / `AnalysisScorePolicy` (the CONFIDENCE stage) were not
  changed — this session's scope was strictly the CALIBRATION -> validation boundary
  shown in the target architecture, one stage before CONFIDENCE.
- The four `SOFT_PLAUSIBILITY` ceilings (60/60/60/80 for the three texture/redness
  `std(...)`-based inputs and the one luma-based input) are documented plausibility
  estimates, not measured from real device captures — this sandbox has no device or image
  corpus to measure an empirical distribution from. They should be revisited once real
  capture data exists; that data is also the prerequisite for the actual ground-truth
  ("ARE these scores skin conditions") validation this framework is explicitly not.

### Testing / compilation status
STATIC_REVIEW: COMPLETE — every bound was traced to its exact producing expression, and
`FeatureCalibrationValidatorTest` was hand-traced against the validator logic for all 8
cases. COMPILED: UNVERIFIED, same standing limitation as every prior session — this
sandbox has no Android SDK and no network access to Google's/Maven Central's repositories,
so `./gradlew` cannot be run here. `FeatureCalibrationValidatorTest` does not depend on
`android.*`, so (like `AnalysisScorePolicyTest`) it should not need the Robolectric setup
added earlier in this file's history, but that is also unexecuted/unverified here.

### Exact recommended next implementation step
Run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` in an environment with real
network/SDK access to get a genuine compile+test pass of this session's two new files. If
that passes, the next logical Batch 2 step is deciding — with real test captures, not
synthetic ones — whether `calibration_validation.json`'s per-component `valid` flag should
start qualifying `AnalysisConfidenceScorer`'s CONFIDENCE stage output (e.g. downgrading
confidence when a characteristic's calibration failed validation this session), the same
way `capture_condition_session.json` was flagged as a future confidence input in the
Session N+3 log above but not yet wired as one.

## Session N+6: Batch 3 — Routine and Recommendation Intelligence Calibration (objective-strength slice)

### Current batch
Batch 3 — Routine and Recommendation Intelligence Calibration. This session implements one
coherent, fully-connected slice of it (Step 2 + Step 3 of the batch plan: recommendation
input confidence + objective strength calibration), per the batch's own stopping rule: stop
at a clean architectural boundary rather than partially touch every step.

### Batch 1 / Batch 2 state discovered during inspection
Both confirmed present and structurally intact (no code missing or reverted from the
uploaded ZIP): `SkinScoreCalibration`/`CalibrationRegistry` (Batch 1) and
`FeatureCalibrationValidation`/`FeatureCalibrationValidator` (Batch 2) are unchanged and are
not touched by this session. `COMPILED: UNVERIFIED` for both remains the accurate status —
no SDK/network access exists in this environment, same standing limitation noted in every
prior session.

### Existing Brain 2 architecture discovered (Step 1 audit)
The full chain named in the batch's `target_flow` already exists and is already wired
end-to-end inside `FinalSkinAnalysisProfileAnalyzer.json()`:
`FinalSkinAnalysisProfile.findings` (score+level+priority+confidence per characteristic,
already produced by Batch 1/2) -> `SkinConcernInterpreter.fromFinalProfile` ->
`SkinObjectivePlanner.plan` -> `RoutineStrategyPlanner` -> `IngredientStrategyPlanner` ->
`RoutineCompatibilityPlanner` -> `RoutineSchedulePlanner` -> `RoutineContextPlanner` ->
`SpecificIngredientMapper` -> `IngredientUsePlanner` -> `ProductSelectionPlanner` ->
`ProductCatalogRepository` -> `ProductRecommendationAssembler` -> `FinalRoutineResultAssembler`
-> `SkinProgressTracker` / `SkinSessionRepository` -> `MultiSessionTrendAnalyzer` ->
`TrendAwareRoutineAdaptationPolicy` -> `TrendAwareRoutineAdjustmentGenerator` ->
`RoutineAdjustmentCandidateActivator` -> `RoutineAdaptationExecutor`. This is a real,
connected production flow, not disconnected scaffolding — the prior session logs' concern
about disconnected Brain 2 components was accurate as of the sessions that raised it, but by
this session everything in the batch's `target_flow` list is already reachable from
`MainActivity.runFinalSkinAnalysisProfile()`.

The concrete, specific gap found (not a general "it's disconnected" observation, but a
traced, exact break): every per-characteristic analyzer already computes a `confidence`
value (HIGH/MODERATE/LOW) and `FinalSkinFinding.confidence` already carries it, but
`SkinConcernInterpreter.fromFinalProfile()` dropped that field at the exact point it built
`SkinConcern` (no `confidence` field existed on that data class), and
`SkinObjectivePlanner.plan()` derived `SkinObjectiveType` from `concern.score` alone via a
hardcoded threshold ladder that never referenced confidence, priority-based dampening, or
the session-level `analysisConfidence`. This is precisely the batch's Step 3 target: "High
score with weak confidence should remain conservative" / "Low-confidence findings must not
automatically produce aggressive routine changes" / "Secondary findings should not
overwhelm the primary objective" were all stated requirements with no corresponding code.

No other duplicated rule or dead/unreferenced Brain 2 file was found during this audit —
every planner/analyzer file listed in `existing_systems_to_inspect` is called from the one
production chain above; there is no parallel or shadow recommendation path.

### What was implemented this session
- **`RecommendationCalibration.kt`** (new) — `ObjectiveStrengthPolicy`
  (`VERSION = "OBJECTIVE_STRENGTH_POLICY_V1"`, following the same versioned-policy-object
  pattern as `AnalysisScorePolicy`/`SkinScoreCalibration`, per Step 12's instruction to reuse
  existing version infrastructure rather than invent a new one). `calibrate(score,
  findingConfidence, sessionAnalysisConfidence, priority)` computes a score-based base tier
  (same four-tier threshold ladder previously inlined in `SkinObjectivePlanner`, unchanged),
  then applies three independent, explicitly-named caps and keeps whichever binds tightest:
  - `findingConfidenceCap` — HIGH allows the full score-based tier; MODERATE caps at
    `SUPPORT_BALANCE`; LOW (or anything unrecognized, treated conservatively) caps at
    `MAINTAIN_CURRENT_STATE`. A low-confidence finding can never alone justify
    `IMPROVE_VISIBLE_APPEARANCE`.
  - `sessionConfidenceCap` — the whole-session `analysisConfidence` (minimum across every
    analyzer this run, already computed by `FinalSkinAnalysisProfileAnalyzer.minConfidence`)
    caps every objective this session produces, independent of that finding's own
    confidence — this is the "analysis limitations propagate into recommendation
    conservatism" requirement, using the limitation signal that is actually connected today
    (see "What was deliberately not done" below for the one not yet connected).
  - `priorityCap` — only priority 1 and 2 (primary/secondary) may reach
    `IMPROVE_VISIBLE_APPEARANCE`; priority 3+ is capped at `SUPPORT_BALANCE` regardless of
    score or confidence, directly implementing "secondary findings should not overwhelm the
    primary objective."
  Returns `CalibratedObjectiveStrength(objectiveType, scoreBasedTier, wasCapped, reason)`
  where `reason` names every binding cap by value (e.g.
  `finding_confidence=LOW; session_confidence=MODERATE`) — deterministic, structural
  explainability (Step 11) with no LLM involved, generated directly from the decision data.
- **`SkinConcernInterpreter.kt`** (modified) — added `confidence: String` to `SkinConcern`,
  populated from `finding.confidence` in `fromFinalProfile`. This is the one-line fix for the
  exact drop point identified in the audit above.
- **`SkinObjectivePlanner.kt`** (modified) — `plan()` now takes a required
  `sessionAnalysisConfidence: String` parameter (required, not defaulted, so a caller cannot
  silently skip session-level conservatism) and calls `ObjectiveStrengthPolicy.calibrate`
  instead of the inline threshold ladder. Added `strengthReason: String` to `SkinObjective`,
  kept separate from the existing `rationale` field (which explains the evidence
  source/topic, not the strength decision) so both remain independently readable.
- **`FinalSkinAnalysisProfileAnalyzer.kt`** (modified) — updated the two call sites:
  `SkinObjectivePlanner.plan(concerns, x.analysisConfidence)` (was `plan(concerns)`), and
  added `confidence` to the exported `skin_concerns` JSON and `strength_reason` to the
  exported `skin_objectives` JSON. Added top-level
  `"recommendation_calibration_version":"${ObjectiveStrengthPolicy.VERSION}"` to the final
  JSON, alongside the existing `analysis_confidence` field, so historical routine output
  remains attributable to the policy version that produced it (Step 12).
- **`ObjectiveStrengthPolicyTest.kt`** (new, plain JUnit, no `android.*` dependency) — 7
  tests: full-strength case with no cap; each of the three caps triggered individually and
  verified in the returned reason text; multiple simultaneous caps all reported; confirmation
  that caps only ever reduce, never escalate, a score-based tier; and that priority 1/2 are
  not priority-capped.

### Critical separation preserved
No change in this session writes to `FinalSkinAnalysisProfile`, any `CalibratedComponent`,
or any per-characteristic analyzer — `ObjectiveStrengthPolicy.calibrate` is a pure function
of already-computed score/confidence/priority values and returns a new value consumed only
by `SkinObjectivePlanner`. `VISUAL_ANALYSIS_SCORE != CONFIDENCE != PRIORITY != OBJECTIVE`
holds exactly as before; this session only changed how `OBJECTIVE` is derived from the other
three, not their own values.

### Status per definition-of-done category
- Objective calibration: IMPLEMENTED AS SOURCE AND CONNECTED to the production
  `FinalSkinAnalysisProfileAnalyzer.json()` call path (not just present as an unused class).
- Evidence-selection status: UNCHANGED this session — `SpecificIngredientMapper` /
  `IngredientUsePlanner` still use their existing static per-concern ingredient tables from
  Batch-2-and-earlier sessions; Step 4 (evidence-aware candidate selection) was not started.
- Compatibility integration: UNCHANGED — `RoutineCompatibilityPlanner`'s existing
  keyword-based rules (`EXFOLIAT`/`STRONG` substring checks) were audited but not modified;
  Step 6 was not started.
- Tolerance integration: UNCHANGED — no per-ingredient tolerance state machine
  (UNKNOWN/INTRODUCING/TOLERATED/CAUTION/PAUSED) exists anywhere in the project; the closest
  existing concept is the static per-option `caution: String?` field and the user-level
  `TolerancePreference` (CAUTIOUS/BALANCED/FLEXIBLE), neither of which is a persisted,
  per-ingredient state. Step 7 was not started — this is the next natural piece of work (see
  below), not something this session began and left incomplete.
- Routine intensity / morning-evening calibration: UNCHANGED — Steps 5 and 8 not started.
- Trend-aware adaptation: UNCHANGED — the existing `MultiSessionTrendAnalyzer` /
  `TrendAwareRoutineAdaptationPolicy` chain (built in an earlier session) already implements
  most of Step 9's stated requirements (noisy-single-session dampening via the 3-of-5-session
  `MultiSessionTrendAnalyzer` threshold logic, trend-confidence-gated escalation). Not
  modified this session. The one Step 9 requirement it does not yet implement — "capture-
  quality problems should not be interpreted as treatment failure" — remains open; see below.
- Recommendation explainability: PARTIALLY IMPLEMENTED — `strengthReason` covers objective
  strength decisions specifically (this session). Compatibility, tolerance, and routine-
  adaptation decisions already had some reason/explanation fields from earlier sessions
  (`RoutineCompatibilityDecision.reason`, `RoutineAdaptationResult.reasons`,
  `ActivatedAdjustmentCandidate.reason`) that were not touched or extended this session.
- Recommendation versioning: IMPLEMENTED for this session's new policy
  (`ObjectiveStrengthPolicy.VERSION`, exported in the final JSON). No other Brain 2 stage
  carries a version marker yet.

### What was deliberately not done this session
- `AnalysisConfidenceScorer` (a richer confidence model with a numeric score and a
  `factors: List<String>` list of specific limitations like `EVIDENCE_INCOMPLETE` /
  `QUALITY_REVIEW`) exists in the project but is not currently plumbed into
  `FinalSkinAnalysisProfileAnalyzer` at all — it is used elsewhere in `MainActivity`'s
  pre-analysis gating, not in the profile/recommendation chain. This session's
  `sessionConfidenceCap` uses the simpler `analysisConfidence` string
  (HIGH/MODERATE/LOW) that already flows through `FinalSkinAnalysisProfile`, not the richer
  factor list, to stay within a bounded, already-connected slice rather than start a second,
  larger wiring project (connecting `AnalysisConfidenceScorer` into the profile chain) in the
  same session. Flagged explicitly as the next logical step, not silently skipped.
- Steps 4-10 of the batch plan (evidence-aware candidate selection, compatibility/conflict
  calibration, tolerance-state introduction logic, routine-intensity selection, morning/
  evening calibration refinement, and the "capture quality != treatment failure" trend
  requirement) were not started, per the batch's own stopping rule to stop at a clean
  boundary rather than partially touch many steps in one session.
- No existing planner's *output shape* for compatibility/tolerance/schedule/product stages
  was changed — only `SkinConcern`, `SkinObjective`, and their one call site were touched,
  so every downstream stage (`RoutineStrategyPlanner` onward) continues to receive the same
  `List<SkinObjective>` shape it did before, just with better-calibrated `objectiveType`
  values and a new `strengthReason` field it doesn't need to read.

### Testing / compilation status
STATIC_REVIEW: COMPLETE — every cap rule in `ObjectiveStrengthPolicy` was hand-traced
against `ObjectiveStrengthPolicyTest`'s 7 cases, and the one call-site change in
`FinalSkinAnalysisProfileAnalyzer.kt` was checked for signature consistency with the new
required `SkinObjectivePlanner.plan(concerns, sessionAnalysisConfidence)` parameter; no other
file in the project constructs `SkinConcern`/`SkinObjective`/calls
`SkinObjectivePlanner.plan` outside the two files modified here (confirmed by search).
COMPILED: UNVERIFIED — same standing limitation as every prior session, no Android SDK or
Maven/Google Maven network access in this sandbox.

### Exact next logical implementation step
Run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` with real SDK/network access
to get a genuine compile+test pass of this session's changes. If that passes, the next
Batch 3 step to take (per the batch's own `priority_order`) is Step 7, tolerance-aware
introduction logic: introduce the five states named in the batch spec
(UNKNOWN/INTRODUCING/TOLERATED/CAUTION/PAUSED) as an explicit per-ingredient state — there is
currently no existing state to reuse for this, so this would be new, not a rename/duplicate
of anything present — and wire it into `SpecificIngredientMapper`/`IngredientUsePlanner` so
introduction guidance depends on real per-ingredient tolerance history rather than only the
static per-option `caution` field and the session-only `TolerancePreference`.

## Session N+7: Batch 3A — Evidence-Aware Candidate Selection

### Current batch
Batch 3A — Evidence-Aware Candidate Selection only, per this session's handoff. Batch 3B
(compatibility/conflict calibration, tolerance-state architecture, routine-intensity
calibration, morning/evening refinement, trend-aware adaptation nuance) was explicitly out of
scope and was not started.

### Step 1 audit — what was found before writing any code
- **No ingredient "evidence database" exists anywhere in this project.** Searched every file;
  the only evidence-shaped entities are `FinalScoreProvenance`/`FinalScoreRegistry`, which
  record *pipeline* provenance (which analyzer/stage produced a score), not clinical evidence
  for an ingredient's effectiveness. There is no evidence-strength field, no citation, no
  percentage-effectiveness figure anywhere in the codebase (consistent with
  `KNOWN_LIMITATIONS.md`/this file's own "no medical diagnosis claims" stance). The batch spec
  assumed such a database might already exist and said to reuse it if present, and to never
  fabricate one if not — this session did the latter.
- **The only existing structured signal close to "evidence" is `IngredientSelectionRole`**
  (PRIMARY/SUPPORTIVE/OPTIONAL) on `SpecificIngredientOption`, already produced by
  `SpecificIngredientMapper` from earlier sessions. OPTIONAL-role ingredients already carry an
  explicit compatibility/tolerance caution string (e.g. Azelaic acid for TONE_PIGMENTATION);
  this session treats that role as the reusable structural signal, per "reuse existing evidence
  data... do not fabricate evidence."
- **Concrete break found in Step 2 (trace production flow):** the calibrated
  `SkinObjectiveType` (Batch 3's own `ObjectiveStrengthPolicy` output, carried on
  `SkinObjective`) dead-ended at `RoutineStrategyPlanner`. `RoutineTarget` only recorded an
  index-based `RoutineTargetRole` (PRIMARY/SECONDARY/MAINTENANCE by *list position*, not by
  calibrated strength) and a display `objective: String` title — the real
  `SkinObjectiveType`/`strengthReason` were dropped at that exact conversion point and never
  reached `IngredientStrategyPlanner`, `SpecificIngredientMapper`, or any candidate-selection
  point. This meant objective strength, despite being correctly calibrated one session earlier,
  could not have influenced candidate selection even if a selection policy existed — the wiring
  itself was missing, not just the policy.

### What was implemented this session
- **`RoutineStrategyPlanner.kt`** (modified) — added `objectiveType: SkinObjectiveType` and
  `strengthReason: String` to `RoutineTarget`, populated directly from `objective.objectiveType`
  / `objective.strengthReason`. The existing `role: RoutineTargetRole` field is unchanged (still
  index-based; still used for morning/evening text) — both fields now coexist rather than one
  replacing the other.
- **`IngredientStrategyPlanner.kt`** (modified) — added the same two fields to
  `IngredientStrategyItem`, forwarded from `RoutineTarget` at the one call site inside `plan()`.
- **`SpecificIngredientMapper.kt`** (modified) — added the same two fields to
  `SpecificIngredientOption`, forwarded from `IngredientStrategyItem` inside the private
  `option()` helper. No selection logic inside `SpecificIngredientMapper.map()` itself was
  changed — it still generates the same candidate set per concern category; only the two new
  fields ride along.
- **`EvidenceAwareCandidateSelection.kt`** (new) — `EvidenceAwareCandidateSelectionPolicy`
  (`VERSION = "EVIDENCE_AWARE_CANDIDATE_SELECTION_POLICY_V1"`, same versioned-policy-object
  pattern as `AnalysisScorePolicy`/`SkinScoreCalibration`/`ObjectiveStrengthPolicy`).
  `select(options, concerns)` maps each `SpecificIngredientOption` to a
  `CandidateSelectionDecision` deterministically:
  - Objective strength tiers (MONITOR=0 weakest .. IMPROVE_VISIBLE_APPEARANCE=3 strongest) and
    ingredient-role tiers (OPTIONAL=1 weakest .. PRIMARY=3 strongest) are compared via
    `requiredRoleTier(objTier) = 4 - objTier`: a weaker objective requires a stronger/safer
    role to be selected (MAINTAIN_CURRENT_STATE requires PRIMARY only; SUPPORT_BALANCE allows
    PRIMARY+SUPPORTIVE; IMPROVE_VISIBLE_APPEARANCE allows all three including OPTIONAL).
    MONITOR (`objTier=0`) requires an impossible role tier of 4, so nothing is ever selected —
    handled as an explicit `DEFERRED`/`INSUFFICIENT_INFORMATION` case rather than falling
    through the general formula, so its reason is legible on its own.
  - `evidenceStrength` is one of `STRUCTURED_PRIMARY_ROLE_MATCH` /
    `STRUCTURED_SUPPORTIVE_ROLE_MATCH` / `STRUCTURED_OPTIONAL_ROLE_REVIEW_REQUIRED` — deliberately
    labeled STRUCTURED_*, never a clinical/percentage claim, since role is the only real
    structured signal available (see Step 1 audit above).
  - `selectionReason` uses exactly the reason vocabulary named in this batch's spec:
    `TARGETS_PRIMARY_OBJECTIVE` / `TARGETS_SECONDARY_OBJECTIVE` (by concern priority),
    `SUPPORTED_BY_EVIDENCE` (added only for PRIMARY/SUPPORTIVE selections, never OPTIONAL, since
    OPTIONAL's own structural evidence tier is the weakest even when selected),
    `LIMITED_BY_CONFIDENCE` (when the concern's own `confidence` is LOW),
    `LIMITED_BY_LOW_EVIDENCE` (an OPTIONAL-role candidate whose evidence tier itself is the
    limiting factor), `LIMITED_BY_OBJECTIVE_STRENGTH` (default limiting case), and
    `INSUFFICIENT_INFORMATION` (MONITOR objective).
  - Does not recompute or re-apply any confidence cap — `option.objectiveType` already reflects
    every cap `ObjectiveStrengthPolicy.calibrate` applied upstream; this function only reports
    the concern's own `confidence` value alongside the decision for explainability, per the
    instruction not to duplicate the already-completed policy's logic.
  - Missing concern data (should not normally happen — options are only ever generated from
    items derived from the same concerns list) defaults to `confidence = "LOW"` rather than
    silently assuming HIGH, per "preserve unknown or missing evidence explicitly."
- **`FinalSkinAnalysisProfileAnalyzer.kt`** (modified) — this is the actual production-flow
  connection, not just a new unused class:
  - `EvidenceAwareCandidateSelectionPolicy.select(specificIngredients, concerns)` is called
    immediately after `SpecificIngredientMapper.map()`.
  - Only candidates with `selectionStatus == SELECTED` are passed to
    `IngredientUsePlanner.plan(...)` — previously *all* generated candidates went straight to
    use-planning regardless of objective strength. This is the real behavior change the batch
    asked for ("low-strength objectives must not silently become high-strength
    recommendations"): a weak (MAINTAIN_CURRENT_STATE) objective for a concern now only carries
    its PRIMARY-role ingredient into the routine/product pipeline, not its SUPPORTIVE/OPTIONAL
    options; a MONITOR objective carries none through.
  - Exported `objective_type` on each `specific_ingredient_options` JSON entry, and added a new
    top-level `evidence_aware_candidate_selection` JSON section (`policy_version` +
    `decisions[]`, one entry per candidate this session considered, including non-selected ones)
    so DEFERRED/LIMITED candidates remain visible in the output even though they don't reach
    use-planning — nothing is silently dropped from the audit trail.
- **`EvidenceAwareCandidateSelectionPolicyTest.kt`** (new, plain JUnit, no `android.*`
  dependency) — 9 tests: PRIMARY selected under top-tier objective; OPTIONAL limited under a
  weak objective; OPTIONAL selected under a top-tier objective; only PRIMARY qualifies under
  MAINTAIN_CURRENT_STATE (three roles checked together); MONITOR defers every role
  unconditionally; LOW concern confidence produces `LIMITED_BY_CONFIDENCE` even when the role
  would otherwise have been limited for a different reason; secondary-priority concerns are
  tagged `TARGETS_SECONDARY_OBJECTIVE`; missing concern data defaults to conservative LOW
  confidence; every decision carries the policy version.

### What was deliberately not changed
- No previously-completed Batch 3 work (`RecommendationCalibration.kt`,
  `ObjectiveStrengthPolicy`, `SkinConcernInterpreter.kt`'s confidence carry-forward) was
  modified. `ObjectiveStrengthPolicy`'s tier ordering is duplicated as a small local
  `objectiveTier()` function inside `EvidenceAwareCandidateSelection.kt` rather than exposing or
  editing the private `OBJECTIVE_TIER_ORDER` list in `RecommendationCalibration.kt`, to avoid
  touching that file at all.
- `RoutineCompatibilityPlanner`, `RoutineSchedulePlanner`, `ProductSelectionPlanner`,
  `ProductRecommendationAssembler` — none of these were modified. `RoutineCompatibilityPlanner`
  still runs on the full (unfiltered) `ingredientStrategy` list (category-level, not
  candidate-level), which is correct: compatibility/alternating-schedule rules are a Batch 3B
  concern and operate one stage earlier than candidate selection, on ingredient *categories*
  rather than named ingredients — filtering there was out of scope and would have been the
  wrong layer to filter at.
- No evidence level, citation, or effectiveness percentage was invented anywhere in this
  session's code or its doc comments.
- Tolerance-state architecture (Step 7, flagged as next in the prior session's log) was not
  started — that remains Batch 3B/3C's Step 7, unchanged from before this session.

### Testing / compilation status — this is a genuine change from every prior session
Every prior session in this file reported `COMPILED: UNVERIFIED` because this sandbox had no
Android SDK and no network access to Google's/Maven Central's repositories. That standing
limitation for a *full Gradle Android build* is still true and unchanged. However, this session
also discovered a second, more specific problem behind some of that prior "unverified" status:
the `kotlinc` available via `apt` in this sandbox is 1.3.31, while this project's
`build.gradle.kts` pins `org.jetbrains.kotlin.android` to `2.0.21` — 1.3.31 is missing stdlib
functions this codebase already used before this session (`sumOf`, `maxOrNull`/`minOrNull`,
`buildList`), so a naive compile attempt with the apt compiler produces dozens of spurious
"unresolved reference" errors that are toolchain-version artifacts, not real bugs. This session
fetched the exact matching compiler
(`https://github.com/JetBrains/kotlin/releases/download/v2.0.21/kotlin-compiler-2.0.21.zip` —
`github.com`/`release-assets.githubusercontent.com` are within this sandbox's allowed egress
list, unlike Google's/Maven Central's Android artifact hosts) and used it directly (no Gradle,
no Android Gradle Plugin, no Android SDK — genuinely not the same as a real `assembleDebug`).

With that compiler, every non-Android-dependent `.kt` file in `app/src/main` (61 of 74 files —
the 13 excluded all directly import `android.*`: `MainActivity.kt`, `ImageQualityAnalyzer.kt`,
`ImageFeatureExtractor.kt`, `LocalizedPatternMapper.kt`, `LocalizedVariationAnalyzer.kt`,
`SkinRegionAnalyzer.kt`, `SkinRoiValidity.kt`, `SkinFeatureInterpreter.kt`,
`CaptureConditionProfileAnalyzer.kt`, `CaptureConditionNormalizer.kt`,
`CameraCapabilitySelector.kt`, `CaptureCapabilityGate.kt`, `PersistentSkinSessionStore.kt`) was
compiled together with all 6 plain-JUnit test files, using three small local stub
definitions (`PatternMapCell`, `CaptureConditionProfile`, `SkinInterpretation`,
`PersistentSkinSessionStore.lastIntegrityTelemetry` — copied field-for-field from the real,
excluded files, used only to satisfy the compiler in this slice, not part of the real project)
for the handful of types those 61 files reference from the 13 excluded files. **This compiled
with zero errors on the first clean attempt after the stubs were added.** All 33 JUnit tests in
this slice — including this session's new 9 — were then actually executed (not just compiled)
against the matching `kotlin-stdlib.jar` from the same 2.0.21 distribution: **`OK (33 tests)`,
zero failures.** This is the first session in this project's history with a real, executed
green test run rather than a manual/static trace, for the plain-JVM (non-Android) portion of
the codebase. It is still not equivalent to `./gradlew testDebugUnitTest`/`assembleDebug` — the
13 Android-dependent files, the Android Gradle Plugin, resource merging, manifest processing,
and the two Robolectric-dependent tests (`SkinRoiValidityTest`,
`FeatureCalibrationValidatorTest`'s `android.*`-free tests were included and passed, but
`SkinRoiValidityTest` itself needs Robolectric/Android stubs beyond this slice's scope and was
not run) remain genuinely UNVERIFIED, for the same standing reason (no Android SDK, no
Google/Maven Central egress) as every prior session.

### Exact recommended next implementation step
1. Run `./gradlew assembleDebug` and `./gradlew testDebugUnitTest` in an environment with real
   Android SDK + Google/Maven Central network access to get the first genuine full-project
   build, now that the plain-JVM slice has an actual passing test run behind it rather than
   only static review.
2. If that passes, Batch 3A's own scope is complete; the next Batch 3B step (per the standing
   `priority_order` noted in the prior session's log) is Step 7, tolerance-state introduction —
   unchanged recommendation from before this session, since Batch 3A did not touch that area.
