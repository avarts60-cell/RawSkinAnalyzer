plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rawskinanalyzer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rawskinanalyzer"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.6.0-evidence-dng"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    testOptions {
        unitTests {
            // Required for Robolectric: without this, android.jar's checked stubs
            // (e.g. Bitmap.createBitmap) throw "not mocked" at test runtime instead
            // of running real Robolectric shadows. Tests referencing android.graphics
            // types are non-functional without this + the Robolectric runner below.
            isIncludeAndroidResources = true
        }
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    // Added: SkinRoiValidityTest exercises android.graphics.Bitmap/Color, which are
    // unmocked stubs under plain JUnit and throw RuntimeException("not mocked") for
    // every call. Without Robolectric these tests cannot pass; they were previously
    // present as source but not actually executable.
    testImplementation("org.robolectric:robolectric:4.13")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
