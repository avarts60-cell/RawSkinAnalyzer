package com.rawskinanalyzer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PersistentSkinSessionStore(context: Context) : SkinSessionStore {
    private val preferences =
        context.getSharedPreferences("raw_skin_analysis_sessions", Context.MODE_PRIVATE)

    @Volatile
    var lastIntegrityTelemetry: SkinSessionIntegrityTelemetry =
        SkinSessionIntegrityTelemetry(
            status = SkinSessionIntegrityStatus.SESSION_DATA_VALID,
            validSessionCount = 0,
            rejectedEntryCount = 0,
            recoveryApplied = false,
            safeHistoryAvailable = false
        )
        private set

    override fun save(session: StoredSkinSession) {
        val sessions = loadAll().toMutableList()
        sessions.removeAll { it.sessionId == session.sessionId }
        sessions += session
        preferences.edit().putString(KEY_SESSIONS, serialize(sessions)).apply()
    }

    override fun latest(): StoredSkinSession? =
        loadAll().maxByOrNull { it.createdAtEpochMillis }

    override fun history(): List<StoredSkinSession> =
        loadAll().sortedBy { it.createdAtEpochMillis }

    override fun replaceAll(sessions: List<StoredSkinSession>) {
        preferences.edit().putString(KEY_SESSIONS, serialize(sessions)).apply()
    }

    private fun loadAll(): List<StoredSkinSession> {
        val raw = preferences.getString(KEY_SESSIONS, null) ?: return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: run {
            preferences.edit().remove(KEY_SESSIONS).apply()
            val recovery = SkinSessionRecoveryResult(
                validSessions = emptyList(),
                rejectedEntries = 1,
                recoveryStatus = "SESSION_DATA_RECOVERY_FAILED"
            )
            lastIntegrityTelemetry =
                SkinSessionIntegrityTelemetryReporter.from(recovery)
            return emptyList()
        }

        var malformedEntries = 0
        val parsed = buildList {
            for (index in 0 until array.length()) {
                runCatching { parse(array.getJSONObject(index)) }
                    .onSuccess { add(it) }
                    .onFailure { malformedEntries++ }
            }
        }

        val recovery = SkinSessionIntegrityValidator.recover(parsed, malformedEntries)

        if (recovery.rejectedEntries > 0) {
            preferences.edit()
                .putString(KEY_SESSIONS, serialize(recovery.validSessions))
                .apply()
        }

        lastIntegrityTelemetry =
            SkinSessionIntegrityTelemetryReporter.from(recovery)

        return recovery.validSessions
    }

    private fun serialize(sessions: List<StoredSkinSession>): String {
        val array = JSONArray()
        sessions.forEach { session ->
            array.put(JSONObject().apply {
                put("session_id", session.sessionId)
                put("created_at_epoch_millis", session.createdAtEpochMillis)
                put("analysis_version", session.analysisVersion)
                put("snapshot", snapshotJson(session.snapshot))
            })
        }
        return array.toString()
    }

    private fun parse(json: JSONObject): StoredSkinSession =
        StoredSkinSession(
            sessionId = json.getString("session_id"),
            createdAtEpochMillis = json.getLong("created_at_epoch_millis"),
            analysisVersion = json.getString("analysis_version"),
            snapshot = parseSnapshot(json.getJSONObject("snapshot"))
        )

    private fun snapshotJson(s: SkinProgressSnapshot): JSONObject = JSONObject().apply {
        put("pigmentation", s.pigmentationScore)
        put("dark_mark", s.darkMarkScore)
        put("blemish", s.blemishLikeScore)
        put("redness", s.rednessScore)
        put("pore", s.poreLikeScore)
        put("shine", s.shineScore)
        put("texture", s.textureScore)
        put("dryness", s.drynessScore)
    }

    private fun parseSnapshot(j: JSONObject): SkinProgressSnapshot =
        SkinProgressSnapshot(
            pigmentationScore = j.getDouble("pigmentation"),
            darkMarkScore = j.getDouble("dark_mark"),
            blemishLikeScore = j.getDouble("blemish"),
            rednessScore = j.getDouble("redness"),
            poreLikeScore = j.getDouble("pore"),
            shineScore = j.getDouble("shine"),
            textureScore = j.getDouble("texture"),
            drynessScore = j.getDouble("dryness")
        )

    private companion object { const val KEY_SESSIONS = "sessions" }
}
