package com.rawskinanalyzer

enum class RoutineCompatibilityAction {
    INCLUDE,
    ALTERNATE,
    SEPARATE_SESSION,
    REVIEW_REQUIRED
}

data class RoutineCompatibilityDecision(
    val ingredientCategory: String,
    val routinePhase: String,
    val action: RoutineCompatibilityAction,
    val reason: String
)

data class RoutineAssembly(
    val morning: List<RoutineCompatibilityDecision>,
    val evening: List<RoutineCompatibilityDecision>,
    val alternating: List<RoutineCompatibilityDecision>
)

object RoutineCompatibilityPlanner {
    fun plan(items: List<IngredientStrategyItem>): RoutineAssembly {
        val decisions = items.map { item ->
            val action = when {
                item.role == IngredientRole.CAUTION ->
                    RoutineCompatibilityAction.REVIEW_REQUIRED
                item.ingredientCategory.contains("EXFOLIAT", ignoreCase = true) ->
                    RoutineCompatibilityAction.ALTERNATE
                item.ingredientCategory.contains("STRONG", ignoreCase = true) ->
                    RoutineCompatibilityAction.SEPARATE_SESSION
                else ->
                    RoutineCompatibilityAction.INCLUDE
            }
            RoutineCompatibilityDecision(
                ingredientCategory = item.ingredientCategory,
                routinePhase = item.routinePhase,
                action = action,
                reason = reasonFor(item, action)
            )
        }

        return RoutineAssembly(
            morning = decisions.filter {
                it.routinePhase == "AM" || it.routinePhase == "AM_OR_PM"
            },
            evening = decisions.filter {
                it.routinePhase == "PM" || it.routinePhase == "AM_OR_PM"
            },
            alternating = decisions.filter {
                it.action == RoutineCompatibilityAction.ALTERNATE ||
                it.action == RoutineCompatibilityAction.SEPARATE_SESSION ||
                it.action == RoutineCompatibilityAction.REVIEW_REQUIRED
            }
        )
    }

    private fun reasonFor(
        item: IngredientStrategyItem,
        action: RoutineCompatibilityAction
    ): String = when (action) {
        RoutineCompatibilityAction.INCLUDE ->
            "Category may be considered for its assigned routine phase within this strategy framework."
        RoutineCompatibilityAction.ALTERNATE ->
            "Category should not be automatically stacked; use an alternating schedule rule."
        RoutineCompatibilityAction.SEPARATE_SESSION ->
            "Category should be placed in a separate routine session rather than automatically combined."
        RoutineCompatibilityAction.REVIEW_REQUIRED ->
            "Marked as caution by the ingredient strategy and requires compatibility review before routine inclusion."
    }
}
