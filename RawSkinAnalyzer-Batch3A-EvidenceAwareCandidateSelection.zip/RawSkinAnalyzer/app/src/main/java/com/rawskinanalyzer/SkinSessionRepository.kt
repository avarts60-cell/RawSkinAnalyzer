package com.rawskinanalyzer

data class StoredSkinSession(
    val sessionId: String,
    val createdAtEpochMillis: Long,
    val analysisVersion: String,
    val snapshot: SkinProgressSnapshot
)

interface SkinSessionStore {
    fun save(session: StoredSkinSession)
    fun latestCompatible(currentAnalysisVersion: String): StoredSkinSession?
    fun history(): List<StoredSkinSession>
    fun replaceAll(sessions: List<StoredSkinSession>)
}

class InMemorySkinSessionStore : SkinSessionStore {
    private val sessions = mutableListOf<StoredSkinSession>()

    override fun save(session: StoredSkinSession) {
        sessions.removeAll { it.sessionId == session.sessionId }
        sessions += session
        sessions.sortBy { it.createdAtEpochMillis }
    }

    override fun latestCompatible(currentAnalysisVersion: String): StoredSkinSession? =
        sessions
            .filter { it.analysisVersion == currentAnalysisVersion }
            .maxByOrNull { it.createdAtEpochMillis }

    override fun history(): List<StoredSkinSession> =
        sessions.sortedByDescending { it.createdAtEpochMillis }

    override fun replaceAll(sessions: List<StoredSkinSession>) {
        this.sessions.clear()
        this.sessions.addAll(sessions)
    }
}

object SkinSessionRepository {
    private var store: SkinSessionStore = InMemorySkinSessionStore()

    fun configure(newStore: SkinSessionStore) {
        store = newStore
    }

    fun previousSnapshot(analysisVersion: String): SkinProgressSnapshot? =
        store.latestCompatible(analysisVersion)?.snapshot

    fun save(
        sessionId: String,
        createdAtEpochMillis: Long,
        analysisVersion: String,
        snapshot: SkinProgressSnapshot,
        retentionPolicy: SkinSessionRetentionPolicy = SkinSessionRetentionPolicy()
    ): SkinSessionLifecycleResult {
        store.save(
            StoredSkinSession(
                sessionId = sessionId,
                createdAtEpochMillis = createdAtEpochMillis,
                analysisVersion = analysisVersion,
                snapshot = snapshot
            )
        )
        return applyLifecyclePolicy(retentionPolicy)
    }

    fun history(): List<StoredSkinSession> = store.history()

    fun compatibleHistory(analysisVersion: String): List<SkinProgressSnapshot> =
        store.history().filter { it.analysisVersion == analysisVersion }
            .sortedBy { it.createdAtEpochMillis }.map { it.snapshot }

    fun applyLifecyclePolicy(policy: SkinSessionRetentionPolicy = SkinSessionRetentionPolicy()): SkinSessionLifecycleResult {
        val result = SkinSessionLifecycleManager.apply(store.history(), policy)
        store.replaceAll(result.retained)
        return result
    }

    fun integrityAwareTrendConfidence(
        telemetry: SkinSessionIntegrityTelemetry,
        existingConfidence: String
    ): IntegrityAwareTrendConfidenceResult =
        IntegrityAwareTrendConfidencePolicy.evaluate(telemetry, existingConfidence)

    fun <T> applyIntegrityAwareTrendPipeline(
        trendResult: T?,
        existingConfidence: String
    ): AutomaticIntegrityAwareTrendOutput<T> =
        AutomaticIntegrityAwareTrendPipeline.apply(
            trendResult = trendResult,
            existingConfidence = existingConfidence,
            telemetry = AutomaticIntegrityAwareTrendPipeline.telemetryFrom(store)
        )

}
