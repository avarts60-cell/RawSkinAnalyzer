# RawSkinAnalyzer Camera2 Audit — Phase 15.73

Diagnostic Android project. It inventories Camera2 characteristics and reports capability names plus JPEG, YUV and RAW output sizes and sensor/control ranges.

This is an engineering diagnostic, not a clinical analyzer and not a release-pass claim.

Build with `./gradlew assembleDebug` in Android Studio/Gradle.
