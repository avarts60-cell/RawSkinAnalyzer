plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.rawskinanalyzer"
    compileSdk=35
    defaultConfig {
        applicationId="com.rawskinanalyzer"
        minSdk=26
        targetSdk=35
        versionCode=2
        versionName="0.2.0-camera-audit"
        testInstrumentationRunner="androidx.test.runner.AndroidJUnitRunner"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
}
