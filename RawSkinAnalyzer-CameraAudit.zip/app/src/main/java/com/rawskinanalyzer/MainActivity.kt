package com.rawskinanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.util.Range
import android.util.Size
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) audit() else output.text = "Camera permission denied." }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        findViewById<Button>(R.id.run).setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) audit()
            else permission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun <T> values(a: Array<T>?): String =
        a?.joinToString(", ") ?: "UNAVAILABLE"

    private fun sizes(s: Array<Size>?): String =
        s?.joinToString(", ") { "${it.width}x${it.height}" } ?: "UNAVAILABLE"

    private fun intRange(r: Range<Int>?): String =
        r?.let { "${it.lower}..${it.upper}" } ?: "UNAVAILABLE"

    private fun floatRange(r: Range<Float>?): String =
        r?.let { "${it.lower}..${it.upper}" } ?: "UNAVAILABLE"

    private fun capName(v: Int): String = when (v) {
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE -> "BACKWARD_COMPATIBLE"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR -> "MANUAL_SENSOR"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING -> "MANUAL_POST_PROCESSING"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW -> "RAW"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_READ_SENSOR_SETTINGS -> "READ_SENSOR_SETTINGS"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BURST_CAPTURE -> "BURST_CAPTURE"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_YUV_REPROCESSING -> "YUV_REPROCESSING"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_DEPTH_OUTPUT -> "DEPTH_OUTPUT"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO -> "HIGH_SPEED_VIDEO"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_PRIVATE_REPROCESSING -> "PRIVATE_REPROCESSING"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MOTION_TRACKING -> "MOTION_TRACKING"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA -> "LOGICAL_MULTI_CAMERA"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME -> "MONOCHROME"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_SECURE_IMAGE_DATA -> "SECURE_IMAGE_DATA"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_SYSTEM_CAMERA -> "SYSTEM_CAMERA"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_OFFLINE_PROCESSING -> "OFFLINE_PROCESSING"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_ULTRA_HIGH_RESOLUTION_SENSOR -> "ULTRA_HIGH_RESOLUTION_SENSOR"
        CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_REMOSAIC_REPROCESSING -> "REMOSAIC_REPROCESSING"
        else -> "UNKNOWN($v)"
    }

    private fun audit() {
        val manager = getSystemService(CameraManager::class.java)
        val out = StringBuilder()
        out.appendLine("RawSkinAnalyzer Camera2 Audit")
        out.appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        out.appendLine("Android API: ${Build.VERSION.SDK_INT}")
        out.appendLine("Camera count: ${manager.cameraIdList.size}")
        out.appendLine()

        manager.cameraIdList.forEach { id ->
            val c = manager.getCameraCharacteristics(id)
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            out.appendLine("===== CAMERA $id =====")
            out.appendLine("Facing: ${when(c.get(CameraCharacteristics.LENS_FACING)) {
                CameraCharacteristics.LENS_FACING_BACK -> "BACK"
                CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
                CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
                else -> "UNKNOWN"
            }}")
            out.appendLine("Hardware level: ${c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)}")
            out.appendLine("Capabilities: ${caps?.joinToString(", ") { capName(it) } ?: "UNAVAILABLE"}")
            out.appendLine("JPEG sizes: ${sizes(map?.getOutputSizes(android.graphics.ImageFormat.JPEG))}")
            out.appendLine("YUV_420_888 sizes: ${sizes(map?.getOutputSizes(android.graphics.ImageFormat.YUV_420_888))}")
            out.appendLine("RAW_SENSOR sizes: ${sizes(map?.getOutputSizes(android.graphics.ImageFormat.RAW_SENSOR))}")
            out.appendLine("Active array: ${c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)}")
            out.appendLine("Pixel array: ${c.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE)}")
            out.appendLine("ISO range: ${intRange(c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE))}")
            out.appendLine("Exposure ns: ${intRange(c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE))}")
            out.appendLine("Focus distance: ${floatRange(c.get(CameraCharacteristics.LENS_INFO_FOCUS_DISTANCE_RANGE))}")
            out.appendLine("Focal lengths: ${values(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS))}")
            out.appendLine("Sensor orientation: ${c.get(CameraCharacteristics.SENSOR_ORIENTATION)}")
            out.appendLine("AF modes: ${values(c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES))}")
            out.appendLine("AE modes: ${values(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_MODES))}")
            out.appendLine("AWB modes: ${values(c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES))}")
            out.appendLine("OIS modes: ${values(c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION))}")
            out.appendLine("Video stabilization: ${values(c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES))}")
            out.appendLine("FPS ranges: ${values(c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES))}")
            out.appendLine()
        }
        output.text = out.toString()
    }
}
