package com.rawskinanalyzer
import org.junit.Assert.assertEquals
import org.junit.Test
class ReleaseStateTest {
    @Test fun initialReleaseStateIsUnverified() {
        assertEquals("RELEASE_UNVERIFIED", "RELEASE_UNVERIFIED")
    }
}
