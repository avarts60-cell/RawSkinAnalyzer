# RawSkinAnalyzer Controlled Capture

Phase 15.74 engineering capture prototype.

Features:
- Back/front Camera2 selection
- Live preview
- 3-second capture countdown
- RAW_SENSOR + JPEG still capture
- Capture metadata reporting
- Basic exposure quality flagging
- Runtime evidence only

This project is not a clinical device and remains RELEASE_UNVERIFIED.
