package com.rawskinanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.*
import android.util.Size
import android.view.Surface
import android.view.TextureView
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var preview: TextureView
    private lateinit var output: TextView
    private lateinit var status: TextView
    private val manager by lazy { getSystemService(CameraManager::class.java) }
    private val thread = HandlerThread("ControlledCapture").apply { start() }
    private val handler = Handler(thread.looper)
    private var cameraId="0"
    private var device:CameraDevice?=null
    private var session:CameraCaptureSession?=null
    private var previewSurface:Surface?=null
    private var rawReader:ImageReader?=null
    private var jpegReader:ImageReader?=null
    private var lastResult:TotalCaptureResult?=null
    private var rawArrived=false
    private var jpegArrived=false
    private var log=StringBuilder()

    private val permission=registerForActivityResult(ActivityResultContracts.RequestPermission()){
        if(it) openSelected() else show("Camera permission denied")
    }

    override fun onCreate(s:Bundle?){
        super.onCreate(s); setContentView(R.layout.activity_main)
        preview=findViewById(R.id.preview); output=findViewById(R.id.output); status=findViewById(R.id.status)
        findViewById<Button>(R.id.back).setOnClickListener{cameraId="0"; openSelected()}
        findViewById<Button>(R.id.front).setOnClickListener{cameraId="1"; openSelected()}
        findViewById<Button>(R.id.capture).setOnClickListener{countdown()}
        preview.surfaceTextureListener=object:TextureView.SurfaceTextureListener{
            override fun onSurfaceTextureAvailable(t:SurfaceTexture,w:Int,h:Int){openSelected()}
            override fun onSurfaceTextureSizeChanged(t:SurfaceTexture,w:Int,h:Int){}
            override fun onSurfaceTextureDestroyed(t:SurfaceTexture):Boolean{closeCamera();return true}
            override fun onSurfaceTextureUpdated(t:SurfaceTexture){}
        }
    }

    private fun show(x:String)=runOnUiThread{output.text=x}
    private fun append(x:String){log.appendLine(x);show(log.toString())}

    private fun openSelected(){
        if(!preview.isAvailable)return
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
            permission.launch(Manifest.permission.CAMERA);return
        }
        closeCamera(); log=StringBuilder(); append("Opening Camera $cameraId preview...")
        val chars=manager.getCameraCharacteristics(cameraId)
        val map=chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: run {append("No stream map");return}
        val previewSize=map.getOutputSizes(SurfaceTexture::class.java)?.firstOrNull() ?: Size(1280,720)
        val raw=map.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull{it.width.toLong()*it.height}
        val jpg=map.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull{it.width.toLong()*it.height}
        if(raw==null||jpg==null){append("RAW/JPEG unavailable");return}
        val texture=preview.surfaceTexture!!
        texture.setDefaultBufferSize(previewSize.width,previewSize.height)
        previewSurface=Surface(texture)
        rawReader=ImageReader.newInstance(raw.width,raw.height,ImageFormat.RAW_SENSOR,2)
        jpegReader=ImageReader.newInstance(jpg.width,jpg.height,ImageFormat.JPEG,2)
        rawReader!!.setOnImageAvailableListener({r->r.acquireLatestImage()?.use{rawArrived=true;append("RAW evidence arrived: ${it.width}x${it.height}")}},handler)
        jpegReader!!.setOnImageAvailableListener({r->r.acquireLatestImage()?.use{jpegArrived=true;append("JPEG evidence arrived: ${it.width}x${it.height}")}},handler)
        append("RAW target: ${raw.width}x${raw.height}")
        append("JPEG target: ${jpg.width}x${jpg.height}")
        manager.openCamera(cameraId,object:CameraDevice.StateCallback(){
            override fun onOpened(d:CameraDevice){device=d;append("Camera opened");createSession()}
            override fun onDisconnected(d:CameraDevice){append("Camera disconnected");d.close()}
            override fun onError(d:CameraDevice,e:Int){append("Camera error: $e");d.close()}
        },handler)
    }

    private fun createSession(){
        val d=device?:return
        d.createCaptureSession(listOf(previewSurface!!,rawReader!!.surface,jpegReader!!.surface),
            object:CameraCaptureSession.StateCallback(){
                override fun onConfigured(s:CameraCaptureSession){
                    session=s;append("Preview session configured")
                    val req=d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply{
                        addTarget(previewSurface!!)
                        set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON)
                        set(CaptureRequest.CONTROL_AWB_MODE,CaptureRequest.CONTROL_AWB_MODE_AUTO)
                    }.build()
                    s.setRepeatingRequest(req,callback,handler)
                    runOnUiThread{status.text="Camera $cameraId ready — RELEASE_UNVERIFIED"}
                }
                override fun onConfigureFailed(s:CameraCaptureSession){append("Preview session FAILED")}
            },handler)
    }

    private val callback=object:CameraCaptureSession.CaptureCallback(){
        override fun onCaptureCompleted(s:CameraCaptureSession,r:CaptureRequest,result:TotalCaptureResult){lastResult=result}
    }

    private fun countdown(){
        if(session==null){append("Camera not ready");return}
        status.text="Stability countdown"
        var n=3
        val tick=object:Runnable{
            override fun run(){
                if(n>0){status.text="Capture in $n";n--;handler.postDelayed(this,1000)}
                else capture()
            }
        };handler.post(tick)
    }

    private fun capture(){
        val d=device?:return;val s=session?:return
        rawArrived=false;jpegArrived=false
        append("Starting controlled capture...")
        val request=d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply{
            addTarget(rawReader!!.surface);addTarget(jpegReader!!.surface)
            set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_AUTO)
            set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON)
            set(CaptureRequest.CONTROL_AWB_MODE,CaptureRequest.CONTROL_AWB_MODE_AUTO)
        }.build()
        s.capture(request,object:CameraCaptureSession.CaptureCallback(){
            override fun onCaptureCompleted(ss:CameraCaptureSession,rr:CaptureRequest,result:TotalCaptureResult){
                lastResult=result
                val iso=result.get(CaptureResult.SENSOR_SENSITIVITY)
                val exp=result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                val frame=result.get(CaptureResult.SENSOR_FRAME_DURATION)
                append("Capture callback: PASS")
                append("Timestamp: "+SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(Date()))
                append("ISO: $iso")
                append("Exposure ns: $exp")
                append("Frame duration ns: $frame")
                val exposureFlag=when{
                    iso!=null && iso>3200 -> "HIGH_ISO"
                    exp!=null && exp>100_000_000L -> "LONG_EXPOSURE"
                    else -> "ACCEPTABLE_BASIC"
                }
                append("Basic quality flag: $exposureFlag")
                handler.postDelayed({
                    append("RAW arrival: ${if(rawArrived)"PASS" else "FAIL"}")
                    append("JPEG arrival: ${if(jpegArrived)"PASS" else "FAIL"}")
                    append("CAPTURE RESULT: ${if(rawArrived&&jpegArrived)"PASS" else "FAIL"}")
                    status.text="Capture complete — $exposureFlag"
                },1500)
            }
            override fun onCaptureFailed(ss:CameraCaptureSession,rr:CaptureRequest,f:CaptureFailure){append("Capture FAILED: reason=${f.reason}")}
        },handler)
    }

    private fun closeCamera(){
        try{session?.close()}catch(_:Exception){}
        try{device?.close()}catch(_:Exception){}
        try{previewSurface?.release()}catch(_:Exception){}
        try{rawReader?.close()}catch(_:Exception){}
        try{jpegReader?.close()}catch(_:Exception){}
        session=null;device=null;previewSurface=null;rawReader=null;jpegReader=null
    }
    override fun onDestroy(){closeCamera();thread.quitSafely();super.onDestroy()}
}
