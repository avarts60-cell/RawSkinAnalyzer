plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.rawskinanalyzer"; compileSdk=35
 defaultConfig { applicationId="com.rawskinanalyzer"; minSdk=26; targetSdk=35; versionCode=5; versionName="0.5.0" } }
dependencies { implementation("androidx.appcompat:appcompat:1.7.0"); implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.activity:activity-ktx:1.10.0") }
