package com.rawskinanalyzer
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.*
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity:AppCompatActivity(){
 lateinit var preview:TextureView; lateinit var out:TextView; lateinit var status:TextView
 val cm by lazy{getSystemService(CameraManager::class.java)}; val ht=HandlerThread("cam").apply{start()}; val h=Handler(ht.looper)
 var id="0"; var dev:CameraDevice?=null; var ses:CameraCaptureSession?=null; var ps:Surface?=null; var rr:ImageReader?=null; var jr:ImageReader?=null
 var dir:File?=null; var rf:File?=null; var jf:File?=null; val raw=AtomicBoolean(false); val jpg=AtomicBoolean(false); var result:TotalCaptureResult?=null; val log=StringBuilder()
 val perm=registerForActivityResult(ActivityResultContracts.RequestPermission()){if(it)open() else add("Permission denied")}
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);preview=findViewById(R.id.preview);out=findViewById(R.id.output);status=findViewById(R.id.status)
 findViewById<Button>(R.id.back).setOnClickListener{id="0";open()};findViewById<Button>(R.id.front).setOnClickListener{id="1";open()};findViewById<Button>(R.id.capture).setOnClickListener{capture()}
 preview.surfaceTextureListener=object:TextureView.SurfaceTextureListener{override fun onSurfaceTextureAvailable(t:SurfaceTexture,w:Int,h:Int){open()};override fun onSurfaceTextureSizeChanged(t:SurfaceTexture,w:Int,h:Int){};override fun onSurfaceTextureDestroyed(t:SurfaceTexture)=true;override fun onSurfaceTextureUpdated(t:SurfaceTexture){}}}
 fun add(s:String){log.appendLine(s);runOnUiThread{out.text=log.toString()}}
 fun open(){if(!preview.isAvailable)return;if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){perm.launch(Manifest.permission.CAMERA);return};try{dev?.close();log.clear();val c=cm.getCameraCharacteristics(id);val m=c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?:return;val r=m.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull{it.width*it.height}?:return;val j=m.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull{it.width*it.height}?:return;val p=m.getOutputSizes(SurfaceTexture::class.java)!!.first();preview.surfaceTexture!!.setDefaultBufferSize(p.width,p.height);ps=Surface(preview.surfaceTexture);rr=ImageReader.newInstance(r.width,r.height,ImageFormat.RAW_SENSOR,2);jr=ImageReader.newInstance(j.width,j.height,ImageFormat.JPEG,2);add("Camera $id ready target RAW ${r.width}x${r.height} JPEG ${j.width}x${j.height}")
 rr!!.setOnImageAvailableListener({x->x.acquireNextImage()?.use{save(it,true)}},h);jr!!.setOnImageAvailableListener({x->x.acquireNextImage()?.use{save(it,false)}},h)
 cm.openCamera(id,object:CameraDevice.StateCallback(){override fun onOpened(d:CameraDevice){dev=d;session()};override fun onDisconnected(d:CameraDevice){d.close()};override fun onError(d:CameraDevice,e:Int){add("Camera error $e");d.close()}},h)}catch(e:Exception){add("Open error ${e.message}")}}
 fun session(){val d=dev?:return;d.createCaptureSession(listOf(ps!!,rr!!.surface,jr!!.surface),object:CameraCaptureSession.StateCallback(){override fun onConfigured(s:CameraCaptureSession){ses=s;val q=d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply{addTarget(ps!!);set(CaptureRequest.CONTROL_AF_MODE,CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON)}.build();s.setRepeatingRequest(q,object:CameraCaptureSession.CaptureCallback(){override fun onCaptureCompleted(a:CameraCaptureSession,b:CaptureRequest,r:TotalCaptureResult){status.text="Camera $id | ISO ${r.get(CaptureResult.SENSOR_SENSITIVITY)} | ${r.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.div(1e6)} ms"}},h);add("Preview session PASS")};override fun onConfigureFailed(s:CameraCaptureSession){add("Session FAIL")}},h)}
 fun capture(){val d=dev?:return;val s=ses?:return;raw.set(false);jpg.set(false);val cid="CAP_"+SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(Date());dir=File(getExternalFilesDir(null),"captures/$cid").apply{mkdirs()};rf=File(dir,"capture.raw");jf=File(dir,"capture.jpg");add("CAPTURE ID: $cid");val q=d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply{addTarget(rr!!.surface);addTarget(jr!!.surface);set(CaptureRequest.CONTROL_AE_MODE,CaptureRequest.CONTROL_AE_MODE_ON)}.build();s.capture(q,object:CameraCaptureSession.CaptureCallback(){override fun onCaptureCompleted(a:CameraCaptureSession,b:CaptureRequest,r:TotalCaptureResult){result=r;add("Capture callback PASS");h.postDelayed({finish(cid)},2000)};override fun onCaptureFailed(a:CameraCaptureSession,b:CaptureRequest,f:CaptureFailure){add("Capture FAIL ${f.reason}")}},h)}
 fun save(i:Image,isRaw:Boolean){val f=if(isRaw)rf else jf?:return;try{FileOutputStream(f).use{o->for(p in i.planes){val b=p.buffer;val x=ByteArray(b.remaining());b.get(x);o.write(x)}};if(isRaw){raw.set(true);add("RAW bytes saved ${f.length()}")}else{jpg.set(true);add("JPEG saved ${f.length()}")}}catch(e:Exception){add("Save error ${e.message}")}}
 fun finish(cid:String){val d=dir?:return;val r=result;val iso=r?.get(CaptureResult.SENSOR_SENSITIVITY);val exp=r?.get(CaptureResult.SENSOR_EXPOSURE_TIME);val ae=r?.get(CaptureResult.CONTROL_AE_STATE);val q=when{ae==CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED->"LOW_LIGHT_WARNING";iso!=null&&iso>8000->"HIGH_NOISE_RISK";iso!=null&&iso>3200->"ELEVATED_NOISE_RISK";else->"NO_BASIC_WARNING"};val meta=File(d,"metadata.txt");meta.writeText("CAPTURE_ID=$cid\nCAMERA_ID=$id\nRAW_SAVED=${raw.get()}\nJPEG_SAVED=${jpg.get()}\nISO=$iso\nEXPOSURE_NS=$exp\nAE_STATE=$ae\nQUALITY_CLASS=$q\nRAW_SHA256=${rf?.takeIf{it.exists()}?.let{hash(it)}}\nJPEG_SHA256=${jf?.takeIf{it.exists()}?.let{hash(it)}}\nRELEASE_STATE=RELEASE_UNVERIFIED\n");add("Metadata saved");add("Quality: $q");add("EVIDENCE RESULT: ${if(raw.get()&&jpg.get())"PASS" else "FAIL"}");status.text="Evidence saved | $q"}
 fun hash(f:File):String{val m=MessageDigest.getInstance("SHA-256");f.inputStream().use{input->val b=ByteArray(8192);while(true){val n=input.read(b);if(n<0)break;m.update(b,0,n)}};return m.digest().joinToString(""){"%02x".format(it)}}
 override fun onDestroy(){dev?.close();ses?.close();rr?.close();jr?.close();ht.quitSafely();super.onDestroy()}
}