# Test Status

## Exact audit baseline
| Validation | Status |
|---|---|
| STATIC_REVIEW | COMPLETE |
| COMPILED | UNVERIFIED |
| UNIT_TESTED | NOT PRESENT / UNVERIFIED |
| INTEGRATION_TESTED | UNVERIFIED |
| DEVICE_VERIFIED | UNVERIFIED |

## Existing evidence
`build-error.txt` records `BUILD SUCCESSFUL` after `assembleDebug`, but references:
`/workspaces/RawSkinAnalyzer/SkinInterpretation-v1-Test/...`
Therefore it is retained as historical evidence only and not promoted to COMPILED for the exact audit ZIP.

## Missing tests
No `src/test` or `src/androidTest` files were found in the audit ZIP.

## Minimum test plan
1. Unit tests for quality thresholds and each score formula.
2. Unit tests for empty/partial/three-view data.
3. Regression test for left/right delta defect.
4. Integration tests proving a failed stage prevents final readiness.
5. Camera capability tests for RAW availability and DNG creation.
6. Controlled-image repeatability tests under exposure, white-balance, and compression variation.
7. Device verification on the target Vivo T3 Ultra after camera mapping is capability-based.

## Phase 4 required regression tests
- RAW-capable rear camera -> allow capture.
- Rear camera without RAW -> block when requireRaw=true.
- No compatible rear camera -> block.
- Verify the selected camera ID is the ID used by the low-level capture session after integration testing.

## Phase 6 required tests
- Boundary tests immediately below/at/above score bands.
- Tests confirming heuristic policy metadata is emitted.
- Regression tests ensuring objective selection does not interpret rule-based confidence as a probability.
- Calibration dataset tests before any threshold is promoted beyond heuristic status.

## Phase 7 added tests
- `AnalysisScorePolicyTest`: low/moderate/high boundaries and failure-driven invalid confidence.
- `SkinRoiValidityTest`: insufficient mask, broad mask, plausible mask.
Status: NOT EXECUTED in the current environment.
