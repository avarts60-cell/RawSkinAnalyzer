package com.rawskinanalyzer

import kotlin.math.abs
import kotlin.math.max

data class CrossViewPatternSummary(
    val matchedCells:Int,
    val repeatedRedCells:Int,
    val repeatedDarkCells:Int,
    val repeatedTextureCells:Int,
    val consistencyScore:Double,
    val notes:List<String>
)

object CrossViewPatternAnalyzer {
    fun compare(
        front:List<PatternCell>, left:List<PatternCell>, right:List<PatternCell>
    ):CrossViewPatternSummary{
        fun signature(a:List<PatternCell>)=a.associateBy{it.row*10+it.col}
        val f=signature(front);val l=signature(left);val r=signature(right)
        val keys=f.keys.intersect(l.keys).intersect(r.keys)
        var red=0;var dark=0;var texture=0
        for(k in keys){
            val cells=listOfNotNull(f[k],l[k],r[k])
            val redVals=cells.map{it.redness};val darkVals=cells.map{it.darkPercent};val texVals=cells.map{it.texture}
            val redSpread=redVals.maxOrNull()!!-redVals.minOrNull()!!
            val darkSpread=darkVals.maxOrNull()!!-darkVals.minOrNull()!!
            val texSpread=texVals.maxOrNull()!!-texVals.minOrNull()!!
            if(redSpread<12)red++
            if(darkSpread<18)dark++
            if(texSpread<22)texture++
        }
        val total=max(1,keys.size)
        val score=(red+dark+texture)/(total*3.0)*100.0
        val notes=mutableListOf<String>()
        when {
            score>=80 -> notes+="HIGH_REPEATED_PATTERN_CONSISTENCY"
            score>=60 -> notes+="MODERATE_REPEATED_PATTERN_CONSISTENCY"
            else -> notes+="LOW_REPEATED_PATTERN_CONSISTENCY"
        }
        return CrossViewPatternSummary(keys.size,red,dark,texture,score,notes)
    }
    fun json(x:CrossViewPatternSummary) =
        """{"matched_cells":${x.matchedCells},"repeated_red_cells":${x.repeatedRedCells},"repeated_dark_cells":${x.repeatedDarkCells},"repeated_texture_cells":${x.repeatedTextureCells},"consistency_score":${x.consistencyScore},"notes":[${x.notes.joinToString(","){"\"$it\""}}],"medical_diagnosis":false}"""
}
