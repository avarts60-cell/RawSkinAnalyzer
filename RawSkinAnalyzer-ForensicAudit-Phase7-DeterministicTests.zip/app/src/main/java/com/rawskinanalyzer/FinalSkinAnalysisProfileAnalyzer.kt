package com.rawskinanalyzer

data class FinalSkinFinding(
    val characteristic:String,
    val score:Double,
    val level:String,
    val priority:Int,
    val evidence:String,
    val confidence:String
)

data class FinalSkinAnalysisProfile(
    val findings:List<FinalSkinFinding>,
    val primaryFinding:String,
    val secondaryFinding:String,
    val overallProfile:String,
    val analysisConfidence:String
)

object FinalSkinAnalysisProfileAnalyzer {
    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_SIGNAL"
        score>=30.0 -> "MODERATE_SIGNAL"
        score>=12.0 -> "LOW_SIGNAL"
        else -> "MINIMAL_SIGNAL"
    }

    private fun minConfidence(vararg values:String)=when {
        values.any { it=="LOW" } -> "LOW"
        values.all { it=="HIGH" } -> "HIGH"
        else -> "MODERATE"
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):FinalSkinAnalysisProfile {
        val redness=RednessAnalysisAnalyzer.analyze(front,left,right)
        val pigment=PigmentationTanningAnalyzer.analyze(front,left,right)
        val blemish=BlemishFeatureAnalyzer.analyze(front,left,right)
        val texture=TexturePoreFeatureAnalyzer.analyze(front,left,right)
        val surface=SurfaceConditionAnalyzer.analyze(front,left,right)

        val darkMarkScore=when(pigment.localizedDarkMarkSignal) {
            "HIGH_LOCALIZED_DARK_MARK_SIGNAL" -> 75.0
            "MODERATE_LOCALIZED_DARK_MARK_SIGNAL" -> 45.0
            "LOW_LOCALIZED_DARK_MARK_SIGNAL" -> 20.0
            else -> 5.0
        }

        val raw=listOf(
            FinalSkinFinding("REDNESS",redness.overallRednessScore,level(redness.overallRednessScore),0,
                "${redness.distribution}; ${redness.crossViewConsistency}",redness.confidence),
            FinalSkinFinding("PIGMENTATION_OR_TONE_VARIATION",pigment.pigmentationVariationScore,level(pigment.pigmentationVariationScore),0,
                pigment.broadToneShiftSignal,pigment.confidence),
            FinalSkinFinding("DARK_MARK_SIGNAL",darkMarkScore,level(darkMarkScore),0,
                pigment.localizedDarkMarkSignal,pigment.confidence),
            FinalSkinFinding("BLEMISH_LIKE_FEATURES",blemish.blemishLikeScore,level(blemish.blemishLikeScore),0,
                "${blemish.distribution}; ${blemish.repetition}",blemish.confidence),
            FinalSkinFinding("TEXTURE_IRREGULARITY",texture.textureIrregularityScore,level(texture.textureIrregularityScore),0,
                "${texture.distribution}; ${texture.crossViewConsistency}",texture.confidence),
            FinalSkinFinding("PORE_LIKE_FEATURES",texture.poreLikeSignalScore,level(texture.poreLikeSignalScore),0,
                texture.distribution,texture.confidence),
            FinalSkinFinding("SURFACE_SHINE_SIGNAL",surface.oilinessSignalScore,level(surface.oilinessSignalScore),0,
                surface.dominantSurfaceSignal,surface.confidence),
            FinalSkinFinding("DRYNESS_RELATED_SURFACE_SIGNAL",surface.drynessRelatedSignalScore,level(surface.drynessRelatedSignalScore),0,
                surface.dominantSurfaceSignal,surface.confidence)
        ).sortedByDescending { it.score }

        val ranked=raw.mapIndexed { i,f -> f.copy(priority=i+1) }
        val significant=ranked.count { it.score>=12.0 }
        val overall=when {
            significant>=4 -> "MULTI_CHARACTERISTIC_VISIBLE_SKIN_PROFILE"
            significant>=2 -> "MULTI_FACTOR_VISIBLE_SKIN_PROFILE"
            significant==1 -> "SINGLE_DOMINANT_VISIBLE_SKIN_CHARACTERISTIC"
            else -> "LIMITED_STRONG_VISIBLE_SKIN_SIGNAL"
        }

        return FinalSkinAnalysisProfile(
            ranked,
            ranked.firstOrNull()?.characteristic ?: "INSUFFICIENT_DATA",
            ranked.getOrNull(1)?.characteristic ?: "NONE",
            overall,
            minConfidence(
                redness.confidence,pigment.confidence,blemish.confidence,
                texture.confidence,surface.confidence
            )
        )
    }

    fun json(x:FinalSkinAnalysisProfile):String {
        val findings=x.findings.joinToString(","){f ->
            """{"characteristic":"${f.characteristic}","score":${f.score},"level":"${f.level}","priority":${f.priority},"evidence":"${f.evidence}","confidence":"${f.confidence}"}"""
        }
        return """{"findings":[$findings],"primary_finding":"${x.primaryFinding}","secondary_finding":"${x.secondaryFinding}","overall_profile":"${x.overallProfile}","analysis_confidence":"${x.analysisConfidence}","method":"final_skin_analysis_profile_v1","medical_diagnosis":false}"""
    }
}
