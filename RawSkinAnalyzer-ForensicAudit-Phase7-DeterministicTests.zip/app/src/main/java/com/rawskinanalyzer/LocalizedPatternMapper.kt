package com.rawskinanalyzer

import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.abs
import kotlin.math.max

data class PatternMapCell(
    val row:Int,
    val col:Int,
    val samples:Int,
    val skinPercent:Double,
    val meanLuma:Double,
    val redness:Double,
    val texture:Double,
    val darkPercent:Double
)

object LocalizedPatternMapper {
    fun map(file:File, grid:Int=6):List<PatternMapCell> {
        val b=BitmapFactory.decodeFile(file.absolutePath)
            ?: throw IllegalArgumentException("Cannot decode normalized image")
        val out=mutableListOf<PatternMapCell>()
        for(row in 0 until grid) for(col in 0 until grid) {
            val x0=col*b.width/grid; val x1=(col+1)*b.width/grid
            val y0=row*b.height/grid; val y1=(row+1)*b.height/grid
            val step=max(1,max(x1-x0,y1-y0)/48)
            var total=0; var skin=0; var lumaSum=0.0; var redSum=0.0
            var dark=0; var textureSum=0.0; var textureN=0
            for(y in y0 until y1 step step) for(x in x0 until x1 step step) {
                val p=b.getPixel(x,y)
                val r=(p shr 16 and 255).toDouble()
                val g=(p shr 8 and 255).toDouble()
                val bl=(p and 255).toDouble()
                val mx=maxOf(r,g,bl); val mn=minOf(r,g,bl)
                total++
                val isSkin=r>45 && g>20 && bl>10 && mx-mn>12 && r>=g && r>=bl && r-g>4
                if(isSkin) {
                    skin++
                    val lum=.2126*r+.7152*g+.0722*bl
                    lumaSum+=lum
                    redSum+=r-g
                    if(lum<55) dark++
                    if(x>=x0+step) {
                        val q=b.getPixel(x-step,y)
                        val qr=(q shr 16 and 255).toDouble()
                        val qg=(q shr 8 and 255).toDouble()
                        val qb=(q and 255).toDouble()
                        val qLum=.2126*qr+.7152*qg+.0722*qb
                        textureSum+=abs(lum-qLum)
                        textureN++
                    }
                }
            }
            val denom=max(1,skin).toDouble()
            out+=PatternMapCell(
                row,col,total,
                skin*100.0/max(1,total),
                lumaSum/denom,
                redSum/denom,
                if(textureN==0) 0.0 else textureSum/textureN,
                dark*100.0/denom
            )
        }
        b.recycle()
        return out
    }

    fun json(cells:List<PatternMapCell>):String =
        """{"grid_rows":6,"grid_cols":6,"cells":[${cells.joinToString(","){
            """{"row":${it.row},"col":${it.col},"samples":${it.samples},"skin_percent":${it.skinPercent},"mean_luma":${it.meanLuma},"redness":${it.redness},"texture":${it.texture},"dark_percent":${it.darkPercent}}"""
        }}],"method":"localized_pattern_mapping_v1","medical_diagnosis":false}"""
}
