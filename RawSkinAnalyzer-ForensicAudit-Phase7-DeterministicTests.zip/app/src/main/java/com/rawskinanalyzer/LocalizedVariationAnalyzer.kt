package com.rawskinanalyzer

import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.abs
import kotlin.math.max

data class LocalizedVariationResult(
    val sampledPixels:Int,
    val regions:Int,
    val rednessRange:Double,
    val lumaRange:Double,
    val textureRange:Double,
    val elevatedRedRegions:Int,
    val darkerRegions:Int,
    val observations:List<String>
)

object LocalizedVariationAnalyzer {
    fun analyze(file:File): LocalizedVariationResult {
        val b=BitmapFactory.decodeFile(file.absolutePath) ?: throw IllegalArgumentException("Cannot decode normalized image")
        val grid=6
        val reds=ArrayList<Double>(); val lumas=ArrayList<Double>(); val textures=ArrayList<Double>()
        var sampled=0
        for (gy in 0 until grid) for (gx in 0 until grid) {
            val x0=gx*b.width/grid; val x1=(gx+1)*b.width/grid
            val y0=gy*b.height/grid; val y1=(gy+1)*b.height/grid
            val step=max(1,max(x1-x0,y1-y0)/64)
            var n=0; var sr=0.0; var sg=0.0; var sl=0.0; var st=0.0; var tn=0
            for(y in y0 until y1 step step) for(x in x0 until x1 step step) {
                val p=b.getPixel(x,y); val r=(p shr 16 and 255).toDouble(); val g=(p shr 8 and 255).toDouble(); val bl=(p and 255).toDouble()
                val mx=maxOf(r,g,bl); val mn=minOf(r,g,bl)
                if(r>45 && g>20 && bl>10 && mx-mn>12 && r>=g && r>=bl && r-g>4) {
                    val lum=.2126*r+.7152*g+.0722*bl
                    n++; sampled++; sr+=r; sg+=g; sl+=lum
                    if(x>=x0+step){ val q=b.getPixel(x-step,y); val ql=.2126*((q shr 16 and 255))+.7152*((q shr 8 and 255))+.0722*(q and 255); st+=abs(lum-ql); tn++ }
                }
            }
            if(n>=8){ reds.add((sr-sg)/n); lumas.add(sl/n); textures.add(if(tn==0)0.0 else st/tn) }
        }
        b.recycle()
        fun range(v:List<Double>)=if(v.isEmpty())0.0 else v.maxOrNull()!!-v.minOrNull()!!
        val rm=if(reds.isEmpty())0.0 else reds.average(); val lm=if(lumas.isEmpty())0.0 else lumas.average()
        val redHi=reds.count{it>rm+8.0}; val dark=lumas.count{it<lm-15.0}
        val obs=mutableListOf<String>()
        if(range(reds)>18) obs.add("HIGH_LOCALIZED_REDNESS_VARIATION")
        if(range(lumas)>35) obs.add("HIGH_LOCALIZED_TONE_VARIATION")
        if(range(textures)>20) obs.add("HIGH_LOCALIZED_TEXTURE_VARIATION")
        if(obs.isEmpty()) obs.add("NO_ELEVATED_LOCALIZED_VARIATION_BY_CURRENT_THRESHOLDS")
        return LocalizedVariationResult(sampled,reds.size,range(reds),range(lumas),range(textures),redHi,dark,obs)
    }
    fun json(r:LocalizedVariationResult)="""{"sampled_pixels":${r.sampledPixels},"regions":${r.regions},"redness_range":${r.rednessRange},"luma_range":${r.lumaRange},"texture_range":${r.textureRange},"elevated_red_regions":${r.elevatedRedRegions},"darker_regions":${r.darkerRegions},"observations":[${r.observations.joinToString(","){"\"$it\""}}],"method":"localized_grid_variation_v1","medical_diagnosis":false}"""
}
