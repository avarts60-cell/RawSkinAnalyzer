package com.rawskinanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.DngCreator
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var preview: TextureView
    private lateinit var output: TextView
    private lateinit var status: TextView
    private val cameraManager by lazy { getSystemService(CameraManager::class.java) }
    private val cameraThread = HandlerThread("RawSkinCamera").apply { start() }
    private val cameraHandler = Handler(cameraThread.looper)

    private var cameraId = "0"
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var rawReader: ImageReader? = null
    private var jpegReader: ImageReader? = null

    private var captureId = ""
    private var captureDir: File? = null
    private var dngFile: File? = null
    private var jpegFile: File? = null
    private var captureResult: TotalCaptureResult? = null
    private var rawImage: Image? = null
    private var dngWritten = AtomicBoolean(false)
    private var jpegWritten = AtomicBoolean(false)
    private var captureCallbackReceived = AtomicBoolean(false)
    private var finishing = AtomicBoolean(false)
    private val log = StringBuilder()
    private enum class SessionStep(val folder:String, val label:String) {
        FRONT("front","FRONT FACE"), LEFT_CHEEK("left_cheek","LEFT CHEEK"), RIGHT_CHEEK("right_cheek","RIGHT CHEEK")
    }
    private var sessionId = ""
    private var sessionRoot: File? = null
    private var currentStep = SessionStep.FRONT
    private val completedSteps = linkedSetOf<SessionStep>()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) openCamera() else add("CAMERA PERMISSION: DENIED")
        }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sessionId = "SESSION_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        sessionRoot = File(getExternalFilesDir(null), "sessions/$sessionId").apply { mkdirs() }
        preview = findViewById(R.id.preview)
        output = findViewById(R.id.output)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.back).setOnClickListener { cameraId = "0"; openCamera() }
        findViewById<Button>(R.id.front).setOnClickListener { cameraId = "1"; openCamera() }
        findViewById<Button>(R.id.capture).setOnClickListener { captureEvidence() }
        findViewById<Button>(R.id.frontStep).setOnClickListener { selectStep(SessionStep.FRONT) }
        findViewById<Button>(R.id.leftCheekStep).setOnClickListener { selectStep(SessionStep.LEFT_CHEEK) }
        findViewById<Button>(R.id.rightCheekStep).setOnClickListener { selectStep(SessionStep.RIGHT_CHEEK) }

        preview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) = openCamera()
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean { closeCamera(); return true }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
    }

    private fun selectStep(step: SessionStep) {
        currentStep = step
        log.clear()
        add("THREE-PHOTO SESSION")
        add("SESSION ID: $sessionId")
        add("CURRENT STEP: ${step.label}")
        add("PROTOCOL: FRONT → LEFT CHEEK → RIGHT CHEEK")
        status.text = "CURRENT STEP: ${step.label}"
    }

    private fun latestNormalized(step: SessionStep): File? = File(sessionRoot, step.folder).walkTopDown().filter { it.isFile && it.name == "analysis_normalized.jpg" }.maxByOrNull { it.lastModified() }
    private fun runSessionFeatureExtraction() {
        try {
            val fs=SessionStep.values().associateWith { latestNormalized(it) ?: throw IllegalStateException("Missing ${it.label}") }
            val ft=fs.mapValues { ImageFeatureExtractor.extract(it.value) }
            val names=mapOf(SessionStep.FRONT to "front_features.json",SessionStep.LEFT_CHEEK to "left_cheek_features.json",SessionStep.RIGHT_CHEEK to "right_cheek_features.json")
            for ((step,v) in ft) { File(sessionRoot!!,names[step]!!).writeText(ImageFeatureExtractor.json(v)); add("${step.label} FEATURES: SAVED") }
            val l=ft[SessionStep.LEFT_CHEEK]!!; val r=ft[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"session_analysis.json").writeText("""{"session_id":"$sessionId","left_right_luma_delta":${kotlin.math.abs(l.meanLuma-r.meanLuma)},"left_right_redness_delta":${kotlin.math.abs(l.rednessIndex-r.rednessIndex)},"left_right_texture_delta":${kotlin.math.abs(l.textureScore-r.textureScore)},"analysis_data_ready":true}""")
            add("SESSION COMPARISON: COMPLETE"); add("ANALYSIS DATA READY")
        } catch(e:Exception){ recordAnalysisFailure("FEATURE EXTRACTION", e) }
    }

    private fun runSkinRegionAnalysis() {
        try {
            val steps=SessionStep.values()
            val results=linkedMapOf<SessionStep,SkinRegionResult>()
            for(step in steps){
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=SkinRegionAnalyzer.analyze(file); results[step]=r
                val name=when(step){
                    SessionStep.FRONT -> "front_skin_region.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_skin_region.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_skin_region.json"
                }
                File(sessionRoot!!,name).writeText(SkinRegionAnalyzer.json(r))
                add("${step.label} SKIN REGION: SAVED")
            }
            val l=results[SessionStep.LEFT_CHEEK]!!; val r=results[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"skin_region_session.json").writeText("""{"session_id":"$sessionId","left_skin_percent":${l.skinPercent},"right_skin_percent":${r.skinPercent},"left_right_redness_delta":${kotlin.math.abs(l.redness-r.redness)},"left_right_texture_delta":${kotlin.math.abs(l.texture-r.texture)},"skin_region_analysis_ready":true}""")
            add("SKIN REGION COMPARISON: COMPLETE")
            add("SKIN REGION ANALYSIS READY")
        } catch(e:Exception){ recordAnalysisFailure("SKIN REGION", e) }
    }

    private fun runSkinFeatureInterpretation() {
        try {
            val results=linkedMapOf<SessionStep,SkinInterpretation>()
            for(step in SessionStep.values()){
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=SkinFeatureInterpreter.analyze(file); results[step]=r
                val name=when(step){
                    SessionStep.FRONT -> "front_skin_interpretation.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_skin_interpretation.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_skin_interpretation.json"
                }
                File(sessionRoot!!,name).writeText(SkinFeatureInterpreter.json(r))
                add("${step.label} SKIN PATTERNS: SAVED")
            }
            val l=results[SessionStep.LEFT_CHEEK]!!; val r=results[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"skin_interpretation_session.json").writeText("""{"session_id":"$sessionId","left_right_redness_mean_delta":${kotlin.math.abs(l.rednessMean-r.rednessMean)},"left_right_tone_variation_delta":${kotlin.math.abs(l.toneStd-r.toneStd)},"left_right_texture_variation_delta":${kotlin.math.abs(l.textureVariation-r.textureVariation)},"interpretation_ready":true,"medical_diagnosis":false}""")
            add("SKIN PATTERN COMPARISON: COMPLETE")
            add("SKIN FEATURE INTERPRETATION READY")
        } catch(e:Exception){ recordAnalysisFailure("SKIN INTERPRETATION", e) }
    }

    private var analysisRunning = false
    private var analysisCompletedForSession: String? = null
    private var analysisStageFailures = mutableListOf<String>()

    private fun resetAnalysisStateForNewSession() {
        analysisRunning = false
        analysisCompletedForSession = null
    }

    private fun runFullAnalysisPipelineOnce() {
        reportHeuristicAnalysisPolicy()
        if (!validateSkinRoiInputs()) return
        reportCameraCapabilities()
        analysisStageFailures.clear()
        val currentSession = sessionId ?: return
        if (analysisRunning || analysisCompletedForSession == currentSession) {
            add("ANALYSIS PIPELINE: ALREADY HANDLED FOR CURRENT SESSION")
            return
        }
        analysisRunning = true
        try {
            runSessionFeatureExtraction()
            runSkinRegionAnalysis()
            runSkinFeatureInterpretation()
            runLocalizedVariationAnalysis()
            runThreeViewConsistencyAnalysis()
            runLocalizedPatternMapping()
            runPatternHotspotDetection()
            runCrossViewHotspotComparison()
            runCrossViewSpatialAgreement()
            runSessionPatternConfidence()
            runPatternEvidenceSummary()
            runPatternStabilityAnalysis()
            runPatternRepeatabilityAnalysis()
            runPatternSignalRanking()
            runPatternSignalClustering()
            runSkinDataQualityProfile()
            runMultiViewSkinDataFusion()
            runSkinFeatureQuantification()
            runToneColorFeatureAnalysis()
            runTextureCharacterization()
            runLocalizedFeatureAnalysis()
            runMultiViewSkinFeatureFusion()
            runSkinCharacteristicScoring()
            runRednessAnalysis()
            runPigmentationTanningAnalysis()
            runBlemishFeatureAnalysis()
            runTexturePoreFeatureAnalysis()
            runSurfaceConditionAnalysis()
            runFinalSkinAnalysisProfile()
            if (analysisStageFailures.isNotEmpty()) {
                add("ANALYSIS RESULT: FAILED_STAGES=${analysisStageFailures.joinToString(",")}")
                add("SESSION NOT READY FOR FINAL ANALYSIS")
                return
            }
            analysisCompletedForSession = currentSession
            add("SESSION READY FOR ANALYSIS")
        } finally {
            analysisRunning = false
        }
    }

    private fun runLocalizedVariationAnalysis() {
        try {
            for(step in SessionStep.values()) {
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=LocalizedVariationAnalyzer.analyze(file)
                val name=when(step){
                    SessionStep.FRONT -> "front_localized_variation.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_localized_variation.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_localized_variation.json"
                }
                File(sessionRoot!!,name).writeText(LocalizedVariationAnalyzer.json(r))
                add("${step.label} LOCALIZED VARIATION: SAVED")
            }
            add("LOCALIZED VARIATION ANALYSIS: COMPLETE")
        } catch(e:Exception){ recordAnalysisFailure("LOCALIZED VARIATION", e) }
    }

    private fun runThreeViewConsistencyAnalysis() {
        try {
            val f=SkinFeatureInterpreter.analyze(latestNormalized(SessionStep.FRONT) ?: throw IllegalStateException("Missing FRONT"))
            val l=SkinFeatureInterpreter.analyze(latestNormalized(SessionStep.LEFT_CHEEK) ?: throw IllegalStateException("Missing LEFT"))
            val r=SkinFeatureInterpreter.analyze(latestNormalized(SessionStep.RIGHT_CHEEK) ?: throw IllegalStateException("Missing RIGHT"))
            val result=ThreeViewConsistencyAnalyzer.analyze(f,l,r)
            File(sessionRoot!!,"three_view_consistency.json").writeText(ThreeViewConsistencyAnalyzer.json(result))
            add("THREE-VIEW CONSISTENCY: ${result.consistency}")
            add("THREE-VIEW CONSISTENCY ANALYSIS: COMPLETE")
        } catch(e:Exception){ recordAnalysisFailure("THREE-VIEW CONSISTENCY", e) }
    }

    private fun runLocalizedPatternMapping() {
        try {
            val steps = SessionStep.values()
            for (step in steps) {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val cells = LocalizedPatternMapper.map(image)
                val name = when (step) {
                    SessionStep.FRONT -> "front_pattern_map.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_pattern_map.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_pattern_map.json"
                }
                File(sessionRoot!!, name).writeText(LocalizedPatternMapper.json(cells))
                when (step) {
                    SessionStep.FRONT -> add("FRONT FACE PATTERN MAP: SAVED")
                    SessionStep.LEFT_CHEEK -> add("LEFT CHEEK PATTERN MAP: SAVED")
                    SessionStep.RIGHT_CHEEK -> add("RIGHT CHEEK PATTERN MAP: SAVED")
                }
            }
            add("LOCALIZED PATTERN MAPPING: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("LOCALIZED PATTERN MAPPING", e)
        }
    }

    private fun runPatternHotspotDetection() {
        try {
            for (step in SessionStep.values()) {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val cells = LocalizedPatternMapper.map(image)
                val hotspots = PatternHotspotAnalyzer.analyze(cells)
                val name = when (step) {
                    SessionStep.FRONT -> "front_pattern_hotspots.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_pattern_hotspots.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_pattern_hotspots.json"
                }
                File(sessionRoot!!, name).writeText(PatternHotspotAnalyzer.json(hotspots))
                when (step) {
                    SessionStep.FRONT -> add("FRONT FACE PATTERN HOTSPOTS: SAVED count=${hotspots.size}")
                    SessionStep.LEFT_CHEEK -> add("LEFT CHEEK PATTERN HOTSPOTS: SAVED count=${hotspots.size}")
                    SessionStep.RIGHT_CHEEK -> add("RIGHT CHEEK PATTERN HOTSPOTS: SAVED count=${hotspots.size}")
                }
            }
            add("PATTERN HOTSPOT DETECTION: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN HOTSPOT DETECTION", e)
        }
    }

    private fun runCrossViewHotspotComparison() {
        add("CROSS-VIEW HOTSPOT COMPARISON: STARTED")
        try {
            fun hotspotsFor(step: SessionStep): List<PatternHotspot> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return PatternHotspotAnalyzer.analyze(LocalizedPatternMapper.map(image))
            }
            val result = CrossViewHotspotComparator.compare(
                hotspotsFor(SessionStep.FRONT),
                hotspotsFor(SessionStep.LEFT_CHEEK),
                hotspotsFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "cross_view_hotspot_comparison.json")
                .writeText(CrossViewHotspotComparator.json(result))
            add("CROSS-VIEW HOTSPOT COMPARISON: COMPLETE")
            add("CROSS-VIEW HOTSPOT RESULT: ${result.result}")
        } catch (e: Exception) {
            recordAnalysisFailure("CROSS-VIEW HOTSPOT COMPARISON", e)
        }
    }

    private fun runCrossViewSpatialAgreement() {
        add("CROSS-VIEW SPATIAL AGREEMENT: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = CrossViewSpatialAgreementAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "cross_view_spatial_agreement.json")
                .writeText(CrossViewSpatialAgreementAnalyzer.json(result))
            add("CROSS-VIEW SPATIAL AGREEMENT: COMPLETE")
            add("SPATIAL AGREEMENT RESULT: ${result.result}")
        } catch (e: Exception) {
            recordAnalysisFailure("CROSS-VIEW SPATIAL AGREEMENT", e)
        }
    }

    private fun runSessionPatternConfidence() {
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val front = mapFor(SessionStep.FRONT)
            val left = mapFor(SessionStep.LEFT_CHEEK)
            val right = mapFor(SessionStep.RIGHT_CHEEK)
            val spatial = CrossViewSpatialAgreementAnalyzer.analyze(front, left, right)
            val result = SessionPatternConfidenceAnalyzer.analyze(front, left, right, spatial)
            File(sessionRoot!!, "session_pattern_confidence.json")
                .writeText(SessionPatternConfidenceAnalyzer.json(result))
            add("PATTERN CONFIDENCE: ${result.level}")
            add("CONFIDENCE SCORE: ${"%.1f".format(java.util.Locale.US, result.score)}/100")
            add("SESSION PATTERN CONFIDENCE: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("SESSION PATTERN CONFIDENCE", e)
        }
    }

    private fun runPatternEvidenceSummary() {
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val front = mapFor(SessionStep.FRONT)
            val left = mapFor(SessionStep.LEFT_CHEEK)
            val right = mapFor(SessionStep.RIGHT_CHEEK)
            val spatial = CrossViewSpatialAgreementAnalyzer.analyze(front, left, right)
            val confidence = SessionPatternConfidenceAnalyzer.analyze(front, left, right, spatial)
            val summary = PatternEvidenceSummaryAnalyzer.analyze(
                front, left, right, spatial, confidence
            )
            File(sessionRoot!!, "pattern_evidence_summary.json")
                .writeText(PatternEvidenceSummaryAnalyzer.json(summary))
            add("PATTERN EVIDENCE SUMMARY: COMPLETE")
            add("EVIDENCE STATUS: ${summary.status}")
            add("PATTERN SIGNAL: ${summary.signal}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN EVIDENCE SUMMARY", e)
        }
    }

    private fun runPatternStabilityAnalysis() {
        add("PATTERN STABILITY ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternStabilityAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_stability_analysis.json")
                .writeText(PatternStabilityAnalyzer.json(result))
            add("PATTERN STABILITY ANALYSIS: COMPLETE")
            add("PATTERN STABILITY RESULT: ${result.result}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN STABILITY ANALYSIS", e)
        }
    }

    private fun runPatternRepeatabilityAnalysis() {
        add("PATTERN REPEATABILITY ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternRepeatabilityAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_repeatability_analysis.json")
                .writeText(PatternRepeatabilityAnalyzer.json(result))
            add("PATTERN REPEATABILITY ANALYSIS: COMPLETE")
            add("PATTERN REPEATABILITY RESULT: ${result.result}")
            add("REPEATABILITY SCORE: ${"%.1f".format(java.util.Locale.US, result.score)}/100")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN REPEATABILITY ANALYSIS", e)
        }
    }

    private fun runPatternSignalRanking() {
        add("PATTERN SIGNAL RANKING: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternSignalRankingAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_signal_ranking.json")
                .writeText(PatternSignalRankingAnalyzer.json(result))
            add("PATTERN SIGNAL RANKING: COMPLETE")
            add("TOP SIGNALS: ${result.signals.size}")
            add("HIGHEST SUPPORT: ${result.topClassification}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN SIGNAL RANKING", e)
        }
    }

    private fun runPatternSignalClustering() {
        add("PATTERN SIGNAL CLUSTERING: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternSignalClusteringAnalyzer.analyze(
                mapFor(SessionStep.FRONT), mapFor(SessionStep.LEFT_CHEEK), mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_signal_clusters.json")
                .writeText(PatternSignalClusteringAnalyzer.json(result))
            add("PATTERN SIGNAL CLUSTERING: COMPLETE")
            add("PATTERN CLUSTERS: ${result.clusters.size}")
            add("STRONGEST CLUSTER: ${result.clusters.firstOrNull()?.classification ?: "NONE"}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN SIGNAL CLUSTERING", e)
        }
    }

    private fun runSkinDataQualityProfile() {
        add("SKIN DATA QUALITY PROFILE: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=SkinDataQualityProfileAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"skin_data_quality_profile.json")
                .writeText(SkinDataQualityProfileAnalyzer.json(result))
            add("SKIN DATA QUALITY PROFILE: COMPLETE")
            result.views.forEach { add("${it.view} DATA: ${if(it.usable) "USABLE" else "LIMITED"} (${String.format(java.util.Locale.US,"%.1f",it.score)})") }
            add("SKIN DATA STATUS: ${result.overallStatus}")
        } catch(e:Exception) {
            recordAnalysisFailure("SKIN DATA QUALITY PROFILE", e)
        }
    }

    private fun runMultiViewSkinDataFusion() {
        add("MULTI-VIEW SKIN DATA FUSION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=MultiViewSkinDataFusionAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"multi_view_skin_data.json")
                .writeText(MultiViewSkinDataFusionAnalyzer.json(result))
            add("MULTI-VIEW SKIN DATA FUSION: COMPLETE")
            add("USABLE SKIN VIEWS: ${result.usableViews}/3")
            add("CROSS-VIEW SUPPORT: ${result.crossViewSupport}")
            add("SKIN DATA FUSION STATUS: ${result.overallStatus}")
        } catch(e:Exception) {
            recordAnalysisFailure("MULTI-VIEW SKIN DATA FUSION", e)
        }
    }

    private fun runSkinFeatureQuantification() {
        add("SKIN FEATURE QUANTIFICATION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=SkinFeatureQuantificationAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"skin_feature_quantification.json")
                .writeText(SkinFeatureQuantificationAnalyzer.json(result))
            add("SKIN FEATURE QUANTIFICATION: COMPLETE")
            add("TONE VARIATION: ${String.format(java.util.Locale.US,"%.1f",result.toneVariation)}")
            add("LOCALIZED REDNESS: ${String.format(java.util.Locale.US,"%.1f",result.localizedRedness)}")
            add("TEXTURE VARIATION: ${String.format(java.util.Locale.US,"%.1f",result.textureVariation)}")
            add("SKIN FEATURE CONFIDENCE: ${result.confidence}")
        } catch(e:Exception) {
            recordAnalysisFailure("SKIN FEATURE QUANTIFICATION", e)
        }
    }

    private fun runToneColorFeatureAnalysis() {
        add("TONE AND COLOR FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=ToneColorFeatureAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"tone_color_feature_analysis.json")
                .writeText(ToneColorFeatureAnalyzer.json(result))
            add("TONE AND COLOR FEATURE ANALYSIS: COMPLETE")
            add("TONE CHARACTERISTIC: ${result.toneUniformity}")
            add("REDNESS SIGNAL: ${result.rednessSignal}")
            add("DARK AREA SIGNAL: ${result.darkAreaSignal}")
            add("TONE/COLOR PROFILE: ${result.overallToneColorCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("TONE AND COLOR FEATURE ANALYSIS", e)
        }
    }

    private fun runTextureCharacterization() {
        add("TEXTURE CHARACTERIZATION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=TextureCharacterizationAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"texture_characterization.json")
                .writeText(TextureCharacterizationAnalyzer.json(result))
            add("TEXTURE CHARACTERIZATION: COMPLETE")
            add("OVERALL TEXTURE: ${result.overallTexture}")
            add("LOCALIZED TEXTURE: ${result.localizedTextureSignal}")
            add("TEXTURE DISTRIBUTION: ${result.textureDistribution}")
            add("TEXTURE PROFILE: ${result.dominantTextureCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("TEXTURE CHARACTERIZATION", e)
        }
    }

    private fun runLocalizedFeatureAnalysis() {
        add("LOCALIZED FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=LocalizedFeatureAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"localized_feature_analysis.json")
                .writeText(LocalizedFeatureAnalyzer.json(result))
            add("LOCALIZED FEATURE ANALYSIS: COMPLETE")
            add("LOCALIZED HOTSPOTS: ${result.totalHotspots}")
            add("FEATURE CONCENTRATION: ${result.concentration}")
            add("FEATURE DISTRIBUTION: ${result.distribution}")
            add("LOCALIZED FEATURE PROFILE: ${result.dominantLocalizedCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("LOCALIZED FEATURE ANALYSIS", e)
        }
    }

    private fun runMultiViewSkinFeatureFusion() {
        add("MULTI-VIEW SKIN FEATURE FUSION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=MultiViewSkinFeatureFusionAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"multi_view_skin_feature_profile.json")
                .writeText(MultiViewSkinFeatureFusionAnalyzer.json(result))
            add("MULTI-VIEW SKIN FEATURE FUSION: COMPLETE")
            add("DOMINANT FEATURE DOMAIN: ${result.dominantFeatureDomain}")
            add("SECONDARY FEATURE DOMAIN: ${result.secondaryFeatureDomain}")
            add("OVERALL FEATURE SIGNAL: ${result.overallFeatureSignal}")
            add("SKIN FEATURE FUSION CONFIDENCE: ${result.confidence}")
        } catch(e:Exception) {
            recordAnalysisFailure("MULTI-VIEW SKIN FEATURE FUSION", e)
        }
    }

    private fun runSkinCharacteristicScoring() {
        add("SKIN CHARACTERISTIC SCORING: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=SkinCharacteristicScoringAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"skin_characteristic_scores.json")
                .writeText(SkinCharacteristicScoringAnalyzer.json(result))
            add("SKIN CHARACTERISTIC SCORING: COMPLETE")
            result.scores.forEach {
                add("${it.characteristic}: ${String.format(java.util.Locale.US,"%.1f",it.score)} (${it.level})")
            }
            add("PRIMARY CHARACTERISTIC: ${result.primaryCharacteristic}")
            add("SECONDARY CHARACTERISTIC: ${result.secondaryCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("SKIN CHARACTERISTIC SCORING", e)
        }
    }

    private fun runRednessAnalysis() {
        add("REDNESS ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=RednessAnalysisAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"redness_analysis.json")
                .writeText(RednessAnalysisAnalyzer.json(result))
            add("REDNESS ANALYSIS: COMPLETE")
            add("REDNESS SCORE: ${String.format(java.util.Locale.US,"%.1f",result.overallRednessScore)}")
            add("REDNESS LEVEL: ${result.rednessLevel}")
            add("REDNESS DISTRIBUTION: ${result.distribution}")
            add("REDNESS CROSS-VIEW: ${result.crossViewConsistency}")
        } catch(e:Exception) {
            recordAnalysisFailure("REDNESS ANALYSIS", e)
        }
    }

    private fun runPigmentationTanningAnalysis() {
        add("PIGMENTATION AND TANNING ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=PigmentationTanningAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"pigmentation_tanning_analysis.json")
                .writeText(PigmentationTanningAnalyzer.json(result))
            add("PIGMENTATION AND TANNING ANALYSIS: COMPLETE")
            add("PIGMENTATION SCORE: ${String.format(java.util.Locale.US,"%.1f",result.pigmentationVariationScore)}")
            add("PIGMENTATION LEVEL: ${result.pigmentationLevel}")
            add("BROAD TONE SHIFT: ${result.broadToneShiftSignal}")
            add("LOCALIZED DARK MARKS: ${result.localizedDarkMarkSignal}")
            add("PIGMENTATION CROSS-VIEW: ${result.crossViewConsistency}")
        } catch(e:Exception) {
            recordAnalysisFailure("PIGMENTATION AND TANNING ANALYSIS", e)
        }
    }

    private fun runBlemishFeatureAnalysis() {
        add("BLEMISH-LIKE FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=BlemishFeatureAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"blemish_like_feature_analysis.json")
                .writeText(BlemishFeatureAnalyzer.json(result))
            add("BLEMISH-LIKE FEATURE ANALYSIS: COMPLETE")
            add("BLEMISH-LIKE SCORE: ${String.format(java.util.Locale.US,"%.1f",result.blemishLikeScore)}")
            add("BLEMISH-LIKE LEVEL: ${result.blemishLikeLevel}")
            add("BLEMISH DISTRIBUTION: ${result.distribution}")
            add("BLEMISH CROSS-VIEW: ${result.crossViewSupport}")
        } catch(e:Exception) {
            recordAnalysisFailure("BLEMISH-LIKE FEATURE ANALYSIS", e)
        }
    }

    private fun runTexturePoreFeatureAnalysis() {
        add("TEXTURE AND PORE FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=TexturePoreFeatureAnalyzer.analyze(mapFor(SessionStep.FRONT),mapFor(SessionStep.LEFT_CHEEK),mapFor(SessionStep.RIGHT_CHEEK))
            File(sessionRoot!!,"texture_pore_feature_analysis.json").writeText(TexturePoreFeatureAnalyzer.json(result))
            add("TEXTURE AND PORE FEATURE ANALYSIS: COMPLETE")
            add("TEXTURE IRREGULARITY SCORE: ${String.format(java.util.Locale.US,"%.1f",result.textureIrregularityScore)}")
            add("TEXTURE LEVEL: ${result.textureLevel}")
            add("PORE-LIKE SIGNAL SCORE: ${String.format(java.util.Locale.US,"%.1f",result.poreLikeSignalScore)}")
            add("PORE-LIKE LEVEL: ${result.poreLikeLevel}")
            add("TEXTURE CROSS-VIEW: ${result.crossViewConsistency}")
        } catch(e:Exception) {
            recordAnalysisFailure("TEXTURE AND PORE FEATURE ANALYSIS", e)
        }
    }

    private fun runSurfaceConditionAnalysis() {
        add("SURFACE OILINESS AND DRYNESS SIGNAL ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=SurfaceConditionAnalyzer.analyze(
                mapFor(SessionStep.FRONT),mapFor(SessionStep.LEFT_CHEEK),mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"surface_condition_analysis.json").writeText(SurfaceConditionAnalyzer.json(result))
            add("SURFACE OILINESS AND DRYNESS SIGNAL ANALYSIS: COMPLETE")
            add("SURFACE SHINE SCORE: ${String.format(java.util.Locale.US,"%.1f",result.oilinessSignalScore)}")
            add("SURFACE SHINE LEVEL: ${result.oilinessLevel}")
            add("DRYNESS-RELATED SCORE: ${String.format(java.util.Locale.US,"%.1f",result.drynessRelatedSignalScore)}")
            add("DRYNESS-RELATED LEVEL: ${result.drynessRelatedLevel}")
            add("DOMINANT SURFACE SIGNAL: ${result.dominantSurfaceSignal}")
        } catch(e:Exception) {
            recordAnalysisFailure("SURFACE OILINESS AND DRYNESS SIGNAL ANALYSIS", e)
        }
    }

    private fun runFinalSkinAnalysisProfile() {
        add("FINAL SKIN ANALYSIS PROFILE: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=FinalSkinAnalysisProfileAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"final_skin_analysis_profile.json")
                .writeText(FinalSkinAnalysisProfileAnalyzer.json(result))
            add("FINAL SKIN ANALYSIS PROFILE: COMPLETE")
            result.findings.forEach {
                add("PRIORITY ${it.priority}: ${it.characteristic} — ${String.format(java.util.Locale.US,"%.1f",it.score)} (${it.level})")
            }
            add("PRIMARY SKIN FINDING: ${result.primaryFinding}")
            add("SECONDARY SKIN FINDING: ${result.secondaryFinding}")
            add("OVERALL SKIN PROFILE: ${result.overallProfile}")
            add("FINAL ANALYSIS CONFIDENCE: ${result.analysisConfidence}")
        } catch(e:Exception) {
            recordAnalysisFailure("FINAL SKIN ANALYSIS PROFILE", e)
        }
    }

    private fun recordAnalysisFailure(stage: String, error: Exception) {
        analysisStageFailures.add(stage)
        add("$stage ERROR: ${error.javaClass.simpleName}: ${error.message}")
    }

    private fun reportHeuristicAnalysisPolicy() {
        add("ANALYSIS SCORE POLICY: ${AnalysisScorePolicy.VERSION}")
        add("ANALYSIS SCORE STATUS: HEURISTIC_AND_UNCALIBRATED")
        add("ANALYSIS CONFIDENCE STATUS: RULE_BASED_NOT_STATISTICALLY_CALIBRATED")
    }

    private fun validateSkinRoiInputs(): Boolean {
        val steps=listOf(SessionStep.FRONT, SessionStep.LEFT_CHEEK, SessionStep.RIGHT_CHEEK)
        var allValid=true
        steps.forEach { step ->
            try {
                val image=latestNormalized(step)
                if(image==null) {
                    add("SKIN ROI ${step.label}: MISSING_NORMALIZED_IMAGE")
                    allValid=false
                } else {
                    val result=SkinRoiValidator.validate(image) { pixel ->
                        SkinRegionAnalyzer.isSkinColor(pixel)
                    }
                    add("SKIN ROI ${step.label}: ${result.reason}; overall=${String.format(java.util.Locale.US,"%.3f",result.overallSkinFraction)} central=${String.format(java.util.Locale.US,"%.3f",result.centralSkinFraction)}")
                    if(!result.valid) allValid=false
                }
            } catch(e: Exception) {
                add("SKIN ROI ${step.label} ERROR: ${e.javaClass.simpleName}: ${e.message}")
                allValid=false
            }
        }
        if(!allValid) add("ANALYSIS BLOCKED: SKIN ROI VALIDITY FAILED")
        return allValid
    }

    private fun validateCaptureCapabilities(): Boolean {
        return try {
            val decision=CaptureCapabilityGate.resolveRear(this, requireRaw = true)
            add("CAPTURE CAPABILITY: ${decision.reason}; camera=${decision.cameraId}; jpeg=${decision.jpegAllowed}; rawRequired=${decision.rawRequired}; raw=${decision.rawAllowed}")
            if (!decision.jpegAllowed || (decision.rawRequired && !decision.rawAllowed)) {
                add("CAPTURE BLOCKED: REQUIRED CAMERA CAPABILITY UNAVAILABLE")
                false
            } else true
        } catch (e: Exception) {
            add("CAPTURE CAPABILITY ERROR: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    private fun reportCameraCapabilities() {
        try {
            val cameras=CameraCapabilitySelector.inventory(this)
            add("CAMERA CAPABILITY INVENTORY: ${cameras.size} CAMERA(S)")
            cameras.forEach {
                add("CAMERA id=${it.cameraId} facing=${it.lensFacing} raw=${it.supportsRaw} compatible=${it.supportsBackwardCompatible} level=${it.hardwareLevel}")
            }
            val rear=CameraCapabilitySelector.select(this, android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK)
            add("CAMERA REAR SELECTION: ${rear.reason}; raw=${rear.rawCapable}; id=${rear.selected?.cameraId}")
        } catch (e: Exception) {
            recordAnalysisFailure("CAMERA CAPABILITY VALIDATION", e)
        }
    }

    private fun add(message: String) {
        log.appendLine(message)
        runOnUiThread { output.text = log.toString() }
    }

    private fun openCamera() {
        if (!validateCaptureCapabilities()) return
        if (!preview.isAvailable) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        closeCamera()
        log.clear()
        try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: run { add("STREAM MAP: MISSING"); return }
            val rawSize = map.getOutputSizes(ImageFormat.RAW_SENSOR)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: run { add("RAW_SENSOR: UNAVAILABLE"); return }
            val jpegSize = map.getOutputSizes(ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: run { add("JPEG: UNAVAILABLE"); return }
            val previewSize = map.getOutputSizes(SurfaceTexture::class.java)?.firstOrNull()
                ?: run { add("PREVIEW: UNAVAILABLE"); return }

            preview.surfaceTexture!!.setDefaultBufferSize(previewSize.width, previewSize.height)
            previewSurface = Surface(preview.surfaceTexture)
            rawReader = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 2)
            jpegReader = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 2)

            rawReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireNextImage() ?: return@setOnImageAvailableListener
                handleRawImage(image)
            }, cameraHandler)

            jpegReader!!.setOnImageAvailableListener({ reader ->
                reader.acquireNextImage()?.use { image -> saveJpeg(image) }
            }, cameraHandler)

            add("Camera $cameraId")
            add("DNG target: ${rawSize.width}x${rawSize.height}")
            add("JPEG target: ${jpegSize.width}x${jpegSize.height}")

            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    createSession()
                }
                override fun onDisconnected(camera: CameraDevice) {
                    add("CAMERA: DISCONNECTED")
                    camera.close()
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    add("CAMERA ERROR: $error")
                    camera.close()
                }
            }, cameraHandler)
        } catch (e: Exception) {
            recordAnalysisFailure("OPEN", e)
        }
    }

    private fun createSession() {
        val d = device ?: return
        d.createCaptureSession(
            listOf(previewSurface!!, rawReader!!.surface, jpegReader!!.surface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    val request = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                        addTarget(previewSurface!!)
                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                        set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
                    }.build()
                    s.setRepeatingRequest(request, object : CameraCaptureSession.CaptureCallback() {
                        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                            val iso = result.get(CaptureResult.SENSOR_SENSITIVITY)
                            val exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                            runOnUiThread {
                                status.text = "Camera $cameraId | ISO ${iso ?: "?"} | ${exp?.div(1_000_000.0) ?: "?"} ms"
                            }
                        }
                    }, cameraHandler)
                    add("PREVIEW SESSION: PASS")
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    add("PREVIEW SESSION: FAIL")
                }
            }, cameraHandler
        )
    }

    private fun captureEvidence() {
        val d = device ?: run { add("CAPTURE: CAMERA NOT READY"); return }
        val s = session ?: run { add("CAPTURE: SESSION NOT READY"); return }

        log.clear()
        captureId = "CAP_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        captureDir = File(sessionRoot ?: getExternalFilesDir(null), "${currentStep.folder}/$captureId").apply { mkdirs() }
        dngFile = File(captureDir, "capture.dng")
        jpegFile = File(captureDir, "capture.jpg")
        captureResult = null
        rawImage?.close()
        rawImage = null
        dngWritten.set(false)
        jpegWritten.set(false)
        captureCallbackReceived.set(false)
        finishing.set(false)

        add("THREE-PHOTO SESSION")
        add("SESSION ID: $sessionId")
        add("SESSION STEP: ${currentStep.label}")
        add("CAPTURE ID: $captureId")
        add("CAMERA: $cameraId")
        add("DNG: capture.dng")
        add("JPEG: capture.jpg")

        try {
            val request = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(rawReader!!.surface)
                addTarget(jpegReader!!.surface)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            }.build()

            s.capture(request, object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    captureResult = result
                    captureCallbackReceived.set(true)
                    add("CAPTURE CALLBACK: PASS")
                    tryWriteDng()
                    scheduleFinish()
                }

                override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                    add("CAPTURE CALLBACK: FAIL reason=${failure.reason}")
                    scheduleFinish()
                }
            }, cameraHandler)
        } catch (e: Exception) {
            recordAnalysisFailure("CAPTURE", e)
        }
    }

    private fun handleRawImage(image: Image) {
        if (captureDir == null) {
            image.close()
            return
        }
        rawImage?.close()
        rawImage = image
        add("RAW IMAGE: ARRIVED ${image.width}x${image.height}")
        tryWriteDng()
    }

    private fun tryWriteDng() {
        val image = rawImage ?: return
        val result = captureResult ?: return
        val file = dngFile ?: return
        if (dngWritten.get()) return
        try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            DngCreator(chars, result).use { creator ->
                FileOutputStream(file).use { stream ->
                    creator.writeImage(stream, image)
                }
            }
            dngWritten.set(file.exists() && file.length() > 0)
            add("DNG: ${if (dngWritten.get()) "SAVED" else "FAIL"} bytes=${file.length()}")
        } catch (e: Exception) {
            recordAnalysisFailure("DNG WRITE", e)
        } finally {
            image.close()
            rawImage = null
        }
    }

    private fun saveJpeg(image: Image) {
        val file = jpegFile ?: return
        try {
            FileOutputStream(file).use { stream ->
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                stream.write(bytes)
            }
            jpegWritten.set(file.exists() && file.length() > 0)
            add("JPEG: ${if (jpegWritten.get()) "SAVED" else "FAIL"} bytes=${file.length()}")
        } catch (e: Exception) {
            recordAnalysisFailure("JPEG WRITE", e)
        }
    }

    private fun scheduleFinish() {
        cameraHandler.removeCallbacksAndMessages("finish")
        cameraHandler.postDelayed({ finishEvidence() }, 2500)
    }

    private fun finishEvidence() {
        if (!finishing.compareAndSet(false, true)) return
        tryWriteDng()

        val dir = captureDir ?: return
        val result = captureResult
        val iso = result?.get(CaptureResult.SENSOR_SENSITIVITY)
        val exposure = result?.get(CaptureResult.SENSOR_EXPOSURE_TIME)
        val frame = result?.get(CaptureResult.SENSOR_FRAME_DURATION)
        val af = result?.get(CaptureResult.CONTROL_AF_STATE)
        val ae = result?.get(CaptureResult.CONTROL_AE_STATE)
        val awb = result?.get(CaptureResult.CONTROL_AWB_STATE)

        val quality = when {
            ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED -> "LOW_LIGHT_WARNING"
            iso != null && iso > 8000 -> "HIGH_NOISE_RISK"
            iso != null && iso > 3200 -> "ELEVATED_NOISE_RISK"
            else -> "NO_BASIC_WARNING"
        }

        val dng = dngFile
        val jpg = jpegFile
        val metadata = File(dir, "metadata.json")

        val dngHash = dng?.takeIf { it.exists() && it.length() > 0 }?.let { sha256(it) }
        val jpgHash = jpg?.takeIf { it.exists() && it.length() > 0 }?.let { sha256(it) }

        metadata.writeText("""
{
  "capture_id": "$captureId",
  "camera_id": "$cameraId",
  "timestamp_epoch_ms": ${System.currentTimeMillis()},
  "release_state": "RELEASE_UNVERIFIED",
  "artifacts": {
    "dng": {"name": "capture.dng", "saved": ${dngWritten.get()}, "bytes": ${dng?.length() ?: 0}, "sha256": ${json(dngHash)}},
    "jpeg": {"name": "capture.jpg", "saved": ${jpegWritten.get()}, "bytes": ${jpg?.length() ?: 0}, "sha256": ${json(jpgHash)}}
  },
  "capture": {
    "callback_pass": ${captureCallbackReceived.get()},
    "iso": ${iso ?: "null"},
    "exposure_ns": ${exposure ?: "null"},
    "frame_duration_ns": ${frame ?: "null"},
    "focus_state": ${af ?: "null"},
    "ae_state": ${ae ?: "null"},
    "awb_state": ${awb ?: "null"}
  },
  "quality_class": "$quality"
}
""".trimIndent())

        val metadataHash = sha256(metadata)

        val analysisPass = try {
            val sourceJpeg = jpg ?: throw IllegalStateException("JPEG missing")
            val report = ImageQualityAnalyzer.analyze(sourceJpeg)
            val normalized = File(dir, "analysis_normalized.jpg")
            val normalizedSaved = if (report.pass) {
                ImageQualityAnalyzer.writeNormalizedCopy(sourceJpeg, normalized)
            } else false

            add("ANALYSIS SIZE: ${report.width}x${report.height}")
            add("MEAN LUMA: ${"%.2f".format(java.util.Locale.US, report.meanLuma)}")
            add("CONTRAST: ${"%.2f".format(java.util.Locale.US, report.contrast)}")
            add("DARK CLIP %: ${"%.2f".format(java.util.Locale.US, report.darkClipPercent)}")
            add("BRIGHT CLIP %: ${"%.2f".format(java.util.Locale.US, report.brightClipPercent)}")
            add("DETAIL SCORE: ${"%.2f".format(java.util.Locale.US, report.detailScore)}")
            add("PROCESSING WARNINGS: ${if (report.warnings.isEmpty()) "NONE" else report.warnings.joinToString(",")}")
            add("NORMALIZED IMAGE: ${if (normalizedSaved) "SAVED" else "NOT_SAVED"}")
            add("ANALYSIS INPUT: ${if (report.pass && normalizedSaved) "PASS" else "FAIL"}")
            report.pass && normalizedSaved
        } catch (e: Exception) {
            recordAnalysisFailure("ANALYSIS", e)
            false
        }

        val pass = dngWritten.get() && jpegWritten.get() && captureCallbackReceived.get()

        add("METADATA: SAVED")
        add("DNG SHA-256: ${dngHash ?: "UNAVAILABLE"}")
        add("JPEG SHA-256: ${jpgHash ?: "UNAVAILABLE"}")
        add("METADATA SHA-256: $metadataHash")
        add("QUALITY: $quality")
        add("EVIDENCE RESULT: ${if (pass) "PASS" else "FAIL"}")
        if (pass && analysisPass) {
            completedSteps.add(currentStep)
            add("SESSION STEP RESULT: PASS (${currentStep.label})")
            if (completedSteps.size == 3) {
                File(sessionRoot!!, "session_manifest.json").writeText("{\"session_id\":\"$sessionId\",\"required_steps\":[\"FRONT\",\"LEFT_CHEEK\",\"RIGHT_CHEEK\"],\"session_ready_for_analysis\":true}")
                add("SESSION COMPLETE: 3/3")
                runFullAnalysisPipelineOnce()
                runOnUiThread { status.text = "SESSION READY FOR ANALYSIS" }
            } else {
                val next = SessionStep.values().first { it !in completedSteps }
                currentStep = next
                add("NEXT REQUIRED STEP: ${next.label}")
                runOnUiThread { status.text = "NEXT: ${next.label}" }
            }
        } else {
            add("SESSION STEP RESULT: RETAKE REQUIRED (${currentStep.label})")
            runOnUiThread { status.text = "RETAKE: ${currentStep.label}" }
        }

        runOnUiThread {
            status.text = if (pass) "Evidence PASS | $quality" else "Evidence FAIL"
        }
    }

    private fun json(value: String?): String = value?.let { "\"$it\"" } ?: "null"

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun closeCamera() {
        try { rawImage?.close() } catch (_: Exception) {}
        rawImage = null
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { previewSurface?.release() } catch (_: Exception) {}
        try { rawReader?.close() } catch (_: Exception) {}
        try { jpegReader?.close() } catch (_: Exception) {}
        session = null; device = null; previewSurface = null; rawReader = null; jpegReader = null
    }

    override fun onDestroy() {
        closeCamera()
        cameraThread.quitSafely()
        super.onDestroy()
    }
}
