package com.rawskinanalyzer

data class SkinCharacteristicScore(
    val characteristic:String,
    val score:Double,
    val level:String,
    val evidence:String
)

data class SkinCharacteristicScoringResult(
    val scores:List<SkinCharacteristicScore>,
    val primaryCharacteristic:String,
    val secondaryCharacteristic:String,
    val confidence:String
)

object SkinCharacteristicScoringAnalyzer {
    private fun clamp(v:Double)=v.coerceIn(0.0,100.0)

    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_SIGNAL"
        score>=30.0 -> "MODERATE_SIGNAL"
        score>=12.0 -> "LOW_SIGNAL"
        else -> "MINIMAL_SIGNAL"
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):SkinCharacteristicScoringResult {
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val tone=ToneColorFeatureAnalyzer.analyze(front,left,right)
        val texture=TextureCharacterizationAnalyzer.analyze(front,left,right)
        val localized=LocalizedFeatureAnalyzer.analyze(front,left,right)

        val redness=clamp(tone.rednessScore)
        val pigmentation=clamp(q.toneVariation*0.65 + tone.darkAreaScore*0.35)
        val darkMarks=clamp(q.darkFeatureConcentration*0.75 + localized.hotspotDensity*0.25)
        val texturePores=clamp(texture.textureVariationScore*0.75 + texture.highTextureCellPercent*0.25)
        val blemishLike=clamp(localized.hotspotDensity*0.5 +
            when(localized.repeatedFeatureSignal) {
                "HIGH_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 40.0
                "MODERATE_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 25.0
                "LOW_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 10.0
                else -> 0.0
            }*0.5)

        val scores=listOf(
            SkinCharacteristicScore("REDNESS",redness,level(redness),"localized_redness_score"),
            SkinCharacteristicScore("TONE_PIGMENTATION_VARIATION",pigmentation,level(pigmentation),"tone_variation_and_dark_area_signal"),
            SkinCharacteristicScore("DARK_MARK_SIGNAL",darkMarks,level(darkMarks),"dark_area_and_localized_feature_signal"),
            SkinCharacteristicScore("TEXTURE_PORE_SIGNAL",texturePores,level(texturePores),"texture_variation_and_high_texture_density"),
            SkinCharacteristicScore("BLEMISH_LIKE_LOCALIZED_SIGNAL",blemishLike,level(blemishLike),"hotspot_density_and_repeat_signal")
        ).sortedByDescending { it.score }

        return SkinCharacteristicScoringResult(
            scores,
            scores.first().characteristic,
            scores.getOrElse(1){scores.first()}.characteristic,
            q.confidence
        )
    }

    fun json(x:SkinCharacteristicScoringResult):String {
        val values=x.scores.joinToString(","){s ->
            """{"characteristic":"${s.characteristic}","score":${s.score},"level":"${s.level}","evidence":"${s.evidence}"}"""
        }
        return """{"scores":[$values],"primary_characteristic":"${x.primaryCharacteristic}","secondary_characteristic":"${x.secondaryCharacteristic}","confidence":"${x.confidence}","method":"skin_characteristic_scoring_v1","medical_diagnosis":false}"""
    }
}
