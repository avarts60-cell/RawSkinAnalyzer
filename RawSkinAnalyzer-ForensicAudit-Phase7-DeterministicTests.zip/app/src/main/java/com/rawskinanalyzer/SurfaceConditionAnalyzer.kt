package com.rawskinanalyzer

data class SurfaceConditionViewResult(
    val view:String,
    val skinCells:Int,
    val meanLuma:Double,
    val highlightPercent:Double,
    val textureVariation:Double,
    val roughAreaPercent:Double
)

data class SurfaceConditionResult(
    val oilinessSignalScore:Double,
    val oilinessLevel:String,
    val drynessRelatedSignalScore:Double,
    val drynessRelatedLevel:String,
    val dominantSurfaceSignal:String,
    val distribution:String,
    val crossViewConsistency:String,
    val confidence:String,
    val views:List<SurfaceConditionViewResult>
)

object SurfaceConditionAnalyzer {
    private fun std(v:List<Double>):Double {
        if(v.isEmpty()) return 0.0
        val m=v.average()
        return kotlin.math.sqrt(v.sumOf{(it-m)*(it-m)}/v.size)
    }
    private fun level(score:Double, kind:String)=when {
        score>=60.0 -> "HIGH_VISIBLE_${kind}_SIGNAL"
        score>=30.0 -> "MODERATE_VISIBLE_${kind}_SIGNAL"
        score>=12.0 -> "LOW_VISIBLE_${kind}_SIGNAL"
        else -> "MINIMAL_VISIBLE_${kind}_SIGNAL"
    }
    private fun view(name:String,cells:List<PatternMapCell>):SurfaceConditionViewResult {
        val skin=cells.filter{it.skinPercent>=10.0}
        if(skin.isEmpty()) return SurfaceConditionViewResult(name,0,0.0,0.0,0.0,0.0)
        val luma=skin.map{it.meanLuma}
        val texture=skin.map{it.texture}
        val lm=luma.average()
        val ls=std(luma)
        val tm=texture.average()
        val ts=std(texture)
        val highlights=luma.count{it>=lm+ls*0.75}*100.0/luma.size
        val rough=skin.count{it.texture>=tm+ts*0.75 && it.meanLuma<=lm}*100.0/skin.size
        return SurfaceConditionViewResult(name,skin.size,lm,highlights,ts,rough)
    }
    fun analyze(front:List<PatternMapCell>,left:List<PatternMapCell>,right:List<PatternMapCell>):SurfaceConditionResult {
        val views=listOf(view("FRONT_FACE",front),view("LEFT_CHEEK",left),view("RIGHT_CHEEK",right)).filter{it.skinCells>0}
        if(views.isEmpty()) return SurfaceConditionResult(0.0,"INSUFFICIENT_DATA",0.0,"INSUFFICIENT_DATA","INSUFFICIENT_DATA","INSUFFICIENT_DATA","INSUFFICIENT_DATA","LOW",emptyList())
        val highlight=views.map{it.highlightPercent}.average()
        val rough=views.map{it.roughAreaPercent}.average()
        val tex=views.map{it.textureVariation}.average()
        val oil=(highlight*0.75 + tex*0.25).coerceIn(0.0,100.0)
        val dry=(rough*0.70 + tex*0.50).coerceIn(0.0,100.0)
        val dominant=when {
            oil>=dry+8.0 -> "SURFACE_SHINE_DOMINANT"
            dry>=oil+8.0 -> "DRYNESS_RELATED_TEXTURE_DOMINANT"
            oil>=12.0 || dry>=12.0 -> "MIXED_SURFACE_SIGNAL"
            else -> "LIMITED_SURFACE_CONDITION_SIGNAL"
        }
        val active=views.count{it.highlightPercent>=10.0 || it.roughAreaPercent>=10.0}
        val distribution=when {
            active>=3 -> "MULTI_VIEW_SURFACE_SIGNAL"
            active==2 -> "TWO_VIEW_SURFACE_SIGNAL"
            active==1 -> "LOCALIZED_SURFACE_SIGNAL"
            else -> "LIMITED_SURFACE_SIGNAL"
        }
        val spread=std(views.map{it.meanLuma})
        val consistency=when {
            views.size<2 -> "SINGLE_VIEW_SURFACE_SIGNAL"
            spread<=6.0 -> "HIGH_CROSS_VIEW_SURFACE_CONSISTENCY"
            spread<=14.0 -> "MODERATE_CROSS_VIEW_SURFACE_CONSISTENCY"
            else -> "LOW_CROSS_VIEW_SURFACE_CONSISTENCY"
        }
        val confidence=when {
            views.size==3 && consistency=="HIGH_CROSS_VIEW_SURFACE_CONSISTENCY" -> "HIGH"
            views.size>=2 -> "MODERATE"
            else -> "LOW"
        }
        return SurfaceConditionResult(oil,level(oil,"SURFACE_SHINE"),dry,level(dry,"DRYNESS_RELATED"),dominant,distribution,consistency,confidence,views)
    }
    fun json(x:SurfaceConditionResult):String {
        val views=x.views.joinToString(","){v->"""{"view":"${v.view}","skin_cells":${v.skinCells},"mean_luma":${v.meanLuma},"highlight_percent":${v.highlightPercent},"texture_variation":${v.textureVariation},"rough_area_percent":${v.roughAreaPercent}}"""}
        return """{"oiliness_signal_score":${x.oilinessSignalScore},"oiliness_level":"${x.oilinessLevel}","dryness_related_signal_score":${x.drynessRelatedSignalScore},"dryness_related_level":"${x.drynessRelatedLevel}","dominant_surface_signal":"${x.dominantSurfaceSignal}","distribution":"${x.distribution}","cross_view_consistency":"${x.crossViewConsistency}","confidence":"${x.confidence}","views":[$views],"method":"surface_condition_analysis_v1","medical_diagnosis":false}"""
    }
}
