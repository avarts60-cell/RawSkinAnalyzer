package com.rawskinanalyzer

import android.graphics.Bitmap
import android.graphics.Color
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SkinRoiValidityTest {
    @Test fun insufficientMaskFails() {
        val b=Bitmap.createBitmap(40,40,Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.BLACK)
        val r=SkinRoiValidator.validate(b) { false }
        assertFalse(r.valid)
        assertEquals("INSUFFICIENT_SKIN_SIGNAL", r.reason)
    }

    @Test fun broadMaskFails() {
        val b=Bitmap.createBitmap(40,40,Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.WHITE)
        val r=SkinRoiValidator.validate(b) { true }
        assertFalse(r.valid)
        assertEquals("MASK_TOO_BROAD", r.reason)
    }

    @Test fun plausibleMaskPasses() {
        val b=Bitmap.createBitmap(40,40,Bitmap.Config.ARGB_8888)
        b.eraseColor(Color.BLACK)
        for(y in 8..31) for(x in 8..31) b.setPixel(x,y,Color.rgb(210,160,130))
        val r=SkinRoiValidator.validate(b) { Color.red(it) > 100 && Color.green(it) > 80 }
        assertTrue(r.valid)
        assertEquals("ROI_PLAUSIBILITY_PASS", r.reason)
    }
}
