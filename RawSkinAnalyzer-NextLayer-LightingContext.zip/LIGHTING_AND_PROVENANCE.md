# Lighting and Score Provenance

## Purpose
Current feature scores are image-derived and may be sensitive to capture illumination. Indoor results should therefore be interpreted as session-specific signals unless capture conditions are standardized.

## What this layer adds
- Explicit capture-context interpretation status.
- A final interpretation qualifier when lighting context is unknown or potentially risky.
- Separation between capture-context metadata and skin-feature scores.

## What this layer does not claim
- It does not identify the actual light source automatically.
- It does not correct pigmentation, redness, tanning, or dark-mark scores.
- It does not make indoor and daylight scores directly comparable.
- It does not provide clinical calibration.

## Next data objective
Create explicit score provenance so every final finding records its source stage, source score, transformation, and reason for selection.
