# RawSkinAnalyzer Forensic Project Audit

## Audit baseline
- Source: RawSkinAnalyzer-FinalSkinAnalysisProfile-v1(1).zip
- Audit method: STATIC_REVIEW
- Prior build log present: COMPILED for a project identified in build-error.txt as `SkinInterpretation-v1-Test`; this does not prove this exact ZIP was compiled.
- Device verification: UNVERIFIED

## Executive findings
1. The project contains a real Android Camera2 RAW/JPEG capture path and real JPEG pixel analysis.
2. The analysis pipeline is executable by call order in MainActivity, but individual stage failures are swallowed and later stages still run.
3. Skin detection is a simple RGB heuristic, not face/landmark segmentation.
4. Several specialized detectors use real pixel-derived inputs but combine them with arbitrary weights and thresholds that are not calibrated or validated.
5. A concrete defect exists in skin_region_session.json: both left/right deltas subtract the right result from itself, forcing both deltas to 0.
6. The build log reports a successful compilation, but its path/version naming differs from this ZIP; exact-baseline compilation remains UNVERIFIED.
7. No test sources were found in this ZIP.

## Truth matrix
| Component | Status | Notes |
|---|---|---|
| Camera2 preview/capture | IMPLEMENTED BUT UNVERIFIED | Real Android Camera2 APIs are present |
| RAW/DNG persistence | IMPLEMENTED BUT UNVERIFIED | Depends on camera capability and matching result/image |
| JPEG quality metrics | STATIC_REVIEW | Real sampled pixels; thresholds uncalibrated |
| Normalized analysis image | STATIC_REVIEW | Resize/recompress only, not illumination normalization |
| Skin-region mask | HEURISTIC IMPLEMENTATION | RGB rules; no face localization |
| Localized pattern map | STATIC_REVIEW | Real pixels aggregated into 6x6 grid |
| Redness score | HEURISTIC IMPLEMENTATION | RGB-derived inputs with arbitrary scaling/thresholds |
| Pigmentation/tanning score | HEURISTIC IMPLEMENTATION | Luma variation is not a validated pigmentation/tanning measure |
| Blemish-like score | HEURISTIC IMPLEMENTATION | Arbitrary weights/bonuses and hotspot thresholds |
| Texture score | HEURISTIC IMPLEMENTATION | Neighbor luma difference, not calibrated skin texture |
| Pore-like score | TECHNICALLY WEAK / HEURISTIC | Coarse 6x6 cells cannot establish pores reliably |
| Oiliness/dryness signals | TECHNICALLY WEAK / HEURISTIC | Relative highlights/texture are not direct sebum/hydration measures |
| Final profile | IMPLEMENTED BUT UNVALIDATED | Ranking of upstream heuristic scores |
| Confidence labels | HEURISTIC IMPLEMENTATION | Rule-based, not statistically calibrated |
| Session readiness | IMPLEMENTED WITH CONTROL-FLOW RISK | Stage exceptions do not block later readiness |
| Skin objective selection | NOT PRESENT IN THIS BASELINE | This ZIP ends at FinalSkinAnalysisProfile |

## Confirmed defect
`runSkinRegionAnalysis()` writes:
`abs(l.redness-r.redness)` and `abs(l.texture-r.texture)`.
Both are always zero. They should compare left with right.

## Required repair priorities
1. Fix the forced-zero left/right deltas.
2. Introduce explicit stage result objects and dependency gating; a failed stage must not silently permit final readiness.
3. Separate capture/evidence readiness from analysis validity.
4. Replace hard-coded camera IDs with capability-based camera selection and verify RAW support.
5. Add face/skin ROI localization before characteristic scoring.
6. Mark or remove unsupported clinical-style labels until calibration data exists.
7. Add deterministic unit tests for every formula and threshold plus integration tests for pipeline gating.

## Phase 2 repairs
- Repaired self-subtraction patterns in left/right redness and texture delta calculations.
- Added analysis-stage failure recording and a completion gate: if recorded stage failures exist, the session is not marked ready for final analysis.
- Validation status: STATIC_REVIEW only; exact compilation/device validation remains required.

## Phase 3 camera/capture audit
- Added capability inventory using CameraManager and REQUEST_AVAILABLE_CAPABILITIES.
- Added explicit rear-camera selection result that prefers RAW-capable backward-compatible cameras.
- Existing capture wiring was not blindly rewritten because exact current callback/ID wiring requires compile/device validation; this phase exposes capability truth without falsely claiming device support.

## Phase 4 capture capability gate
- Added CaptureCapabilityGate with an explicit rear-camera decision requiring RAW capability for the current evidence workflow.
- Added runtime blocking when JPEG or required RAW capability is unavailable.
- Camera ID resolution is capability-based at the new gate; existing low-level capture wiring still requires exact compile/device validation before claiming complete migration.

## Phase 5 segmentation/ROI validity repair
- Added SkinRoiValidator to quantify overall and central mask coverage using the existing skin classifier.
- Invalid, excessively broad, or centrally insufficient masks now block downstream analysis.
- This is a validity gate around the existing heuristic mask, not a replacement face segmentation model.

## Phase 6 scoring-policy repair
- Added `AnalysisScorePolicy` as an explicit central registry for generic score bands and objective threshold.
- Policy documentation states that thresholds are engineering heuristics and not clinically/statistically calibrated.
- Pipeline now logs heuristic and uncalibrated score status.
- Existing detector-specific constants remain subject to future calibration work; this phase does not falsely relabel them as validated.

## Phase 7 deterministic tests
- Added JUnit regression tests for score-policy boundaries and invalid confidence when failures exist.
- Added deterministic bitmap tests for insufficient, overly broad, and plausible ROI masks.
- These tests are added to source but have not been executed in this environment; status remains STATIC_REVIEW until a Gradle test run succeeds.

## Score interpretation layer
A capture-context qualifier was added without modifying existing skin scores. This prevents the pipeline from implying that image-derived pigmentation/redness findings are automatically invariant across indoor and daylight conditions.
