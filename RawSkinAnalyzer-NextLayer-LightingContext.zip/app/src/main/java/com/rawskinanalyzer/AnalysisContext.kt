package com.rawskinanalyzer

/**
 * Capture-context metadata for interpreting image-derived skin signals.
 * This does not estimate clinical skin state and does not modify feature scores.
 */
enum class LightingContext {
    UNKNOWN,
    INDOOR_ARTIFICIAL,
    INDOOR_NATURAL,
    OUTDOOR_SHADE,
    OUTDOOR_DAYLIGHT,
    MIXED_LIGHT
}

data class AnalysisContext(
    val lighting: LightingContext,
    val meanLuma: Double?,
    val contrast: Double?,
    val brightClipPercent: Double?,
    val darkClipPercent: Double?,
    val contextQuality: String
)

object AnalysisContextInterpreter {
    fun interpret(
        meanLuma: Double?,
        contrast: Double?,
        brightClipPercent: Double?,
        darkClipPercent: Double?
    ): AnalysisContext {
        val quality = when {
            meanLuma == null || contrast == null -> "CONTEXT_UNKNOWN"
            darkClipPercent != null && darkClipPercent > 5.0 -> "LOW_LIGHT_RISK"
            brightClipPercent != null && brightClipPercent > 5.0 -> "OVEREXPOSURE_RISK"
            meanLuma < 85.0 -> "DIM_CAPTURE_CONTEXT"
            meanLuma > 210.0 -> "VERY_BRIGHT_CAPTURE_CONTEXT"
            else -> "USABLE_CAPTURE_CONTEXT"
        }
        return AnalysisContext(
            lighting = LightingContext.UNKNOWN,
            meanLuma = meanLuma,
            contrast = contrast,
            brightClipPercent = brightClipPercent,
            darkClipPercent = darkClipPercent,
            contextQuality = quality
        )
    }

    fun interpretationQualifier(context: AnalysisContext): String = when (context.contextQuality) {
        "LOW_LIGHT_RISK", "DIM_CAPTURE_CONTEXT" ->
            "IMAGE_DERIVED_SIGNALS_MAY_BE_LIGHTING_SENSITIVE"
        "OVEREXPOSURE_RISK", "VERY_BRIGHT_CAPTURE_CONTEXT" ->
            "IMAGE_DERIVED_SIGNALS_MAY_BE_HIGHLIGHT_SENSITIVE"
        "USABLE_CAPTURE_CONTEXT" ->
            "CAPTURE_CONTEXT_USABLE_NOT_LIGHTING_STANDARDIZED"
        else ->
            "CAPTURE_CONTEXT_UNKNOWN"
    }
}
