# RawSkinAnalyzer RAW Capture Test

Runtime Camera2 diagnostic for:
- Camera 0 RAW + JPEG capture
- Camera 1 RAW + JPEG capture
- Session configuration
- Image arrival
- Reported ISO, exposure and frame duration

A test PASS validates only that runtime capture path. It does not establish RELEASE_PASS.
