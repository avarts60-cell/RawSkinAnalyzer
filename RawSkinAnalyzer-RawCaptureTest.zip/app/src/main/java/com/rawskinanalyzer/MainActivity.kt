package com.rawskinanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var output: TextView
    private var pendingId: String? = null

    private val permission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) pendingId?.let { runTest(it) }
        else show("Camera permission denied")
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        output = findViewById(R.id.output)
        findViewById<Button>(R.id.back).setOnClickListener { requestTest("0") }
        findViewById<Button>(R.id.front).setOnClickListener { requestTest("1") }
    }

    private fun requestTest(id: String) {
        pendingId = id
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) runTest(id)
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun show(text: String) = runOnUiThread { output.text = text }

    private fun runTest(id: String) {
        show("Starting Camera $id runtime capture test...")
        val thread = HandlerThread("RawCaptureTest").apply { start() }
        val handler = Handler(thread.looper)
        val log = StringBuilder()
        val rawArrived = AtomicBoolean(false)
        val jpegArrived = AtomicBoolean(false)
        val manager = getSystemService(CameraManager::class.java)

        try {
            val chars = manager.getCameraCharacteristics(id)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: throw IllegalStateException("No stream configuration map")

            val raw = map.getOutputSizes(ImageFormat.RAW_SENSOR)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: throw IllegalStateException("RAW_SENSOR unavailable")

            val jpeg = map.getOutputSizes(ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: throw IllegalStateException("JPEG unavailable")

            log.appendLine("Camera: $id")
            log.appendLine("RAW: ${raw.width}x${raw.height}")
            log.appendLine("JPEG: ${jpeg.width}x${jpeg.height}")
            log.appendLine("Opening camera...")

            val rawReader = ImageReader.newInstance(raw.width, raw.height, ImageFormat.RAW_SENSOR, 2)
            val jpegReader = ImageReader.newInstance(jpeg.width, jpeg.height, ImageFormat.JPEG, 2)

            rawReader.setOnImageAvailableListener({ reader ->
                reader.acquireLatestImage()?.use {
                    rawArrived.set(true)
                    log.appendLine("RAW image arrived: ${it.width}x${it.height}")
                }
            }, handler)

            jpegReader.setOnImageAvailableListener({ reader ->
                reader.acquireLatestImage()?.use {
                    jpegArrived.set(true)
                    log.appendLine("JPEG image arrived: ${it.width}x${it.height}")
                }
            }, handler)

            manager.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    log.appendLine("Camera opened")
                    device.createCaptureSession(
                        listOf(rawReader.surface, jpegReader.surface),
                        object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(session: CameraCaptureSession) {
                                log.appendLine("Session configured: PASS")
                                try {
                                    val request = device.createCaptureRequest(
                                        CameraDevice.TEMPLATE_STILL_CAPTURE
                                    ).apply {
                                        addTarget(rawReader.surface)
                                        addTarget(jpegReader.surface)
                                        set(CaptureRequest.CONTROL_AF_MODE,
                                            CaptureRequest.CONTROL_AF_MODE_AUTO)
                                        set(CaptureRequest.CONTROL_AE_MODE,
                                            CaptureRequest.CONTROL_AE_MODE_ON)
                                    }.build()

                                    session.capture(request,
                                        object : CameraCaptureSession.CaptureCallback() {
                                            override fun onCaptureCompleted(
                                                session: CameraCaptureSession,
                                                request: CaptureRequest,
                                                result: TotalCaptureResult
                                            ) {
                                                log.appendLine("Capture callback: PASS")
                                                log.appendLine("Reported ISO: ${result.get(CaptureResult.SENSOR_SENSITIVITY)}")
                                                log.appendLine("Reported exposure ns: ${result.get(CaptureResult.SENSOR_EXPOSURE_TIME)}")
                                                log.appendLine("Reported frame duration ns: ${result.get(CaptureResult.SENSOR_FRAME_DURATION)}")
                                                handler.postDelayed({
                                                    log.appendLine("RAW arrival: ${if (rawArrived.get()) "PASS" else "FAIL"}")
                                                    log.appendLine("JPEG arrival: ${if (jpegArrived.get()) "PASS" else "FAIL"}")
                                                    log.appendLine("OVERALL: ${if (rawArrived.get() && jpegArrived.get()) "PASS" else "FAIL"}")
                                                    show(log.toString())
                                                    session.close()
                                                    device.close()
                                                    rawReader.close()
                                                    jpegReader.close()
                                                    thread.quitSafely()
                                                }, 2000)
                                            }

                                            override fun onCaptureFailed(
                                                session: CameraCaptureSession,
                                                request: CaptureRequest,
                                                failure: CaptureFailure
                                            ) {
                                                log.appendLine("Capture callback: FAIL reason=${failure.reason}")
                                                show(log.toString())
                                            }
                                        }, handler
                                    )
                                } catch (e: Exception) {
                                    log.appendLine("Capture setup FAIL: ${e.javaClass.simpleName}: ${e.message}")
                                    show(log.toString())
                                }
                            }

                            override fun onConfigureFailed(session: CameraCaptureSession) {
                                log.appendLine("Session configuration: FAIL")
                                show(log.toString())
                            }
                        }, handler
                    )
                }

                override fun onDisconnected(device: CameraDevice) {
                    log.appendLine("Camera disconnected")
                    device.close()
                    show(log.toString())
                }

                override fun onError(device: CameraDevice, error: Int) {
                    log.appendLine("Camera error: $error")
                    device.close()
                    show(log.toString())
                }
            }, handler)
        } catch (e: Exception) {
            log.appendLine("TEST FAIL: ${e.javaClass.simpleName}: ${e.message}")
            show(log.toString())
            thread.quitSafely()
        }
    }
}
