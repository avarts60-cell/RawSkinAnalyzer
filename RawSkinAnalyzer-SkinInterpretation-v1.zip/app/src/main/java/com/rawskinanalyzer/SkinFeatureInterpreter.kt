package com.rawskinanalyzer

import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class SkinInterpretation(
    val skinPixels:Int,
    val rednessMean:Double,
    val rednessStd:Double,
    val localizedRedPercent:Double,
    val darkSpotPercent:Double,
    val toneStd:Double,
    val textureVariation:Double,
    val observations:List<String>
)

object SkinFeatureInterpreter {
    fun analyze(file:File):SkinInterpretation {
        val b=BitmapFactory.decodeFile(file.absolutePath) ?: throw IllegalArgumentException("Cannot decode normalized image")
        val step=max(1,max(b.width,b.height)/512)
        val values=ArrayList<Double>()
        val lumas=ArrayList<Double>()
        val texture=ArrayList<Double>()
        for(y in 0 until b.height step step) for(x in 0 until b.width step step) {
            val p=b.getPixel(x,y)
            val r=(p shr 16 and 255).toDouble(); val g=(p shr 8 and 255).toDouble(); val bl=(p and 255).toDouble()
            val mx=maxOf(r,g,bl); val mn=minOf(r,g,bl)
            val skin=r>45 && g>20 && bl>10 && mx-mn>12 && r>=g && r>=bl && r-g>4
            if(skin){
                val redness=r-g
                val l=.2126*r+.7152*g+.0722*bl
                values.add(redness); lumas.add(l)
                if(x>=step){
                    val q=b.getPixel(x-step,y)
                    val qr=(q shr 16 and 255).toDouble();val qg=(q shr 8 and 255).toDouble();val qb=(q and 255).toDouble()
                    val ql=.2126*qr+.7152*qg+.0722*qb
                    texture.add(abs(l-ql))
                }
            }
        }
        b.recycle()
        val n=max(1,values.size)
        val rm=values.sum()/n
        val rs=kotlin.math.sqrt(values.sumOf{(it-rm)*(it-rm)}/n)
        val lm=lumas.sum()/n
        val ls=kotlin.math.sqrt(lumas.sumOf{(it-lm)*(it-lm)}/n)
        val localized=values.count{it>rm+max(10.0,rs) }*100.0/n
        val dark=lumas.count{it<lm-max(18.0,ls)}*100.0/n
        val tm=if(texture.isEmpty())0.0 else texture.sum()/texture.size
        val ts=if(texture.isEmpty())0.0 else kotlin.math.sqrt(texture.sumOf{(it-tm)*(it-tm)}/texture.size)
        val obs=mutableListOf<String>()
        if(localized>8.0) obs.add("ELEVATED_LOCALIZED_REDNESS")
        if(dark>8.0) obs.add("ELEVATED_DARKER_AREA_CONCENTRATION")
        if(ls>30.0) obs.add("HIGH_TONE_VARIATION")
        if(ts>25.0) obs.add("HIGH_TEXTURE_VARIATION")
        if(obs.isEmpty()) obs.add("NO_ELEVATED_PATTERN_BY_CURRENT_THRESHOLDS")
        return SkinInterpretation(values.size,rm,rs,localized,dark,ls,ts,obs)
    }
    fun json(r:SkinInterpretation):String="""{"skin_pixels":${r.skinPixels},"redness_mean":${r.rednessMean},"redness_std":${r.rednessStd},"localized_red_percent":${r.localizedRedPercent},"dark_spot_percent":${r.darkSpotPercent},"tone_std":${r.toneStd},"texture_variation":${r.textureVariation},"observations":[${r.observations.joinToString(","){"\\"$it\\""}}],"method":"skin_feature_interpretation_v1","medical_diagnosis":false}"""
}