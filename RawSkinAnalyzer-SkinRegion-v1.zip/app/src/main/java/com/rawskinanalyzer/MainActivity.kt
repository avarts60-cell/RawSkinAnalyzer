package com.rawskinanalyzer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.DngCreator
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var preview: TextureView
    private lateinit var output: TextView
    private lateinit var status: TextView
    private val cameraManager by lazy { getSystemService(CameraManager::class.java) }
    private val cameraThread = HandlerThread("RawSkinCamera").apply { start() }
    private val cameraHandler = Handler(cameraThread.looper)

    private var cameraId = "0"
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var rawReader: ImageReader? = null
    private var jpegReader: ImageReader? = null

    private var captureId = ""
    private var captureDir: File? = null
    private var dngFile: File? = null
    private var jpegFile: File? = null
    private var captureResult: TotalCaptureResult? = null
    private var rawImage: Image? = null
    private var dngWritten = AtomicBoolean(false)
    private var jpegWritten = AtomicBoolean(false)
    private var captureCallbackReceived = AtomicBoolean(false)
    private var finishing = AtomicBoolean(false)
    private val log = StringBuilder()
    private enum class SessionStep(val folder:String, val label:String) {
        FRONT("front","FRONT FACE"), LEFT_CHEEK("left_cheek","LEFT CHEEK"), RIGHT_CHEEK("right_cheek","RIGHT CHEEK")
    }
    private var sessionId = ""
    private var sessionRoot: File? = null
    private var currentStep = SessionStep.FRONT
    private val completedSteps = linkedSetOf<SessionStep>()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) openCamera() else add("CAMERA PERMISSION: DENIED")
        }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        sessionId = "SESSION_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        sessionRoot = File(getExternalFilesDir(null), "sessions/$sessionId").apply { mkdirs() }
        preview = findViewById(R.id.preview)
        output = findViewById(R.id.output)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.back).setOnClickListener { cameraId = "0"; openCamera() }
        findViewById<Button>(R.id.front).setOnClickListener { cameraId = "1"; openCamera() }
        findViewById<Button>(R.id.capture).setOnClickListener { captureEvidence() }
        findViewById<Button>(R.id.frontStep).setOnClickListener { selectStep(SessionStep.FRONT) }
        findViewById<Button>(R.id.leftCheekStep).setOnClickListener { selectStep(SessionStep.LEFT_CHEEK) }
        findViewById<Button>(R.id.rightCheekStep).setOnClickListener { selectStep(SessionStep.RIGHT_CHEEK) }

        preview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) = openCamera()
            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean { closeCamera(); return true }
            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
        }
    }

    private fun selectStep(step: SessionStep) {
        currentStep = step
        log.clear()
        add("THREE-PHOTO SESSION")
        add("SESSION ID: $sessionId")
        add("CURRENT STEP: ${step.label}")
        add("PROTOCOL: FRONT → LEFT CHEEK → RIGHT CHEEK")
        status.text = "CURRENT STEP: ${step.label}"
    }

    private fun latestNormalized(step: SessionStep): File? = File(sessionRoot, step.folder).walkTopDown().filter { it.isFile && it.name == "analysis_normalized.jpg" }.maxByOrNull { it.lastModified() }
    private fun runSessionFeatureExtraction() {
        try {
            val fs=SessionStep.values().associateWith { latestNormalized(it) ?: throw IllegalStateException("Missing ${it.label}") }
            val ft=fs.mapValues { ImageFeatureExtractor.extract(it.value) }
            val names=mapOf(SessionStep.FRONT to "front_features.json",SessionStep.LEFT_CHEEK to "left_cheek_features.json",SessionStep.RIGHT_CHEEK to "right_cheek_features.json")
            for ((step,v) in ft) { File(sessionRoot!!,names[step]!!).writeText(ImageFeatureExtractor.json(v)); add("${step.label} FEATURES: SAVED") }
            val l=ft[SessionStep.LEFT_CHEEK]!!; val r=ft[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"session_analysis.json").writeText("""{"session_id":"$sessionId","left_right_luma_delta":${kotlin.math.abs(l.meanLuma-r.meanLuma)},"left_right_redness_delta":${kotlin.math.abs(l.rednessIndex-r.rednessIndex)},"left_right_texture_delta":${kotlin.math.abs(l.textureScore-r.textureScore)},"analysis_data_ready":true}""")
            add("SESSION COMPARISON: COMPLETE"); add("ANALYSIS DATA READY")
        } catch(e:Exception){ add("FEATURE EXTRACTION ERROR: ${e.javaClass.simpleName}: ${e.message}") }
    }

    private fun runSkinRegionAnalysis() {
        try {
            val steps=SessionStep.values()
            val results=linkedMapOf<SessionStep,SkinRegionResult>()
            for(step in steps){
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=SkinRegionAnalyzer.analyze(file); results[step]=r
                val name=when(step){
                    SessionStep.FRONT -> "front_skin_region.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_skin_region.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_skin_region.json"
                }
                File(sessionRoot!!,name).writeText(SkinRegionAnalyzer.json(r))
                add("${step.label} SKIN REGION: SAVED")
            }
            val l=results[SessionStep.LEFT_CHEEK]!!; val r=results[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"skin_region_session.json").writeText("""{"session_id":"$sessionId","left_skin_percent":${l.skinPercent},"right_skin_percent":${r.skinPercent},"left_right_redness_delta":${kotlin.math.abs(l.redness-r.redness)},"left_right_texture_delta":${kotlin.math.abs(l.texture-r.texture)},"skin_region_analysis_ready":true}""")
            add("SKIN REGION COMPARISON: COMPLETE")
            add("SKIN REGION ANALYSIS READY")
        } catch(e:Exception){ add("SKIN REGION ERROR: ${e.javaClass.simpleName}: ${e.message}") }
    }

    private fun add(message: String) {
        log.appendLine(message)
        runOnUiThread { output.text = log.toString() }
    }

    private fun openCamera() {
        if (!preview.isAvailable) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        closeCamera()
        log.clear()
        try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: run { add("STREAM MAP: MISSING"); return }
            val rawSize = map.getOutputSizes(ImageFormat.RAW_SENSOR)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: run { add("RAW_SENSOR: UNAVAILABLE"); return }
            val jpegSize = map.getOutputSizes(ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: run { add("JPEG: UNAVAILABLE"); return }
            val previewSize = map.getOutputSizes(SurfaceTexture::class.java)?.firstOrNull()
                ?: run { add("PREVIEW: UNAVAILABLE"); return }

            preview.surfaceTexture!!.setDefaultBufferSize(previewSize.width, previewSize.height)
            previewSurface = Surface(preview.surfaceTexture)
            rawReader = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 2)
            jpegReader = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 2)

            rawReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireNextImage() ?: return@setOnImageAvailableListener
                handleRawImage(image)
            }, cameraHandler)

            jpegReader!!.setOnImageAvailableListener({ reader ->
                reader.acquireNextImage()?.use { image -> saveJpeg(image) }
            }, cameraHandler)

            add("Camera $cameraId")
            add("DNG target: ${rawSize.width}x${rawSize.height}")
            add("JPEG target: ${jpegSize.width}x${jpegSize.height}")

            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    createSession()
                }
                override fun onDisconnected(camera: CameraDevice) {
                    add("CAMERA: DISCONNECTED")
                    camera.close()
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    add("CAMERA ERROR: $error")
                    camera.close()
                }
            }, cameraHandler)
        } catch (e: Exception) {
            add("OPEN ERROR: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun createSession() {
        val d = device ?: return
        d.createCaptureSession(
            listOf(previewSurface!!, rawReader!!.surface, jpegReader!!.surface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    val request = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                        addTarget(previewSurface!!)
                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                        set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
                    }.build()
                    s.setRepeatingRequest(request, object : CameraCaptureSession.CaptureCallback() {
                        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                            val iso = result.get(CaptureResult.SENSOR_SENSITIVITY)
                            val exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                            runOnUiThread {
                                status.text = "Camera $cameraId | ISO ${iso ?: "?"} | ${exp?.div(1_000_000.0) ?: "?"} ms"
                            }
                        }
                    }, cameraHandler)
                    add("PREVIEW SESSION: PASS")
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    add("PREVIEW SESSION: FAIL")
                }
            }, cameraHandler
        )
    }

    private fun captureEvidence() {
        val d = device ?: run { add("CAPTURE: CAMERA NOT READY"); return }
        val s = session ?: run { add("CAPTURE: SESSION NOT READY"); return }

        log.clear()
        captureId = "CAP_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        captureDir = File(sessionRoot ?: getExternalFilesDir(null), "${currentStep.folder}/$captureId").apply { mkdirs() }
        dngFile = File(captureDir, "capture.dng")
        jpegFile = File(captureDir, "capture.jpg")
        captureResult = null
        rawImage?.close()
        rawImage = null
        dngWritten.set(false)
        jpegWritten.set(false)
        captureCallbackReceived.set(false)
        finishing.set(false)

        add("THREE-PHOTO SESSION")
        add("SESSION ID: $sessionId")
        add("SESSION STEP: ${currentStep.label}")
        add("CAPTURE ID: $captureId")
        add("CAMERA: $cameraId")
        add("DNG: capture.dng")
        add("JPEG: capture.jpg")

        try {
            val request = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(rawReader!!.surface)
                addTarget(jpegReader!!.surface)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            }.build()

            s.capture(request, object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    captureResult = result
                    captureCallbackReceived.set(true)
                    add("CAPTURE CALLBACK: PASS")
                    tryWriteDng()
                    scheduleFinish()
                }

                override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                    add("CAPTURE CALLBACK: FAIL reason=${failure.reason}")
                    scheduleFinish()
                }
            }, cameraHandler)
        } catch (e: Exception) {
            add("CAPTURE ERROR: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun handleRawImage(image: Image) {
        if (captureDir == null) {
            image.close()
            return
        }
        rawImage?.close()
        rawImage = image
        add("RAW IMAGE: ARRIVED ${image.width}x${image.height}")
        tryWriteDng()
    }

    private fun tryWriteDng() {
        val image = rawImage ?: return
        val result = captureResult ?: return
        val file = dngFile ?: return
        if (dngWritten.get()) return
        try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            DngCreator(chars, result).use { creator ->
                FileOutputStream(file).use { stream ->
                    creator.writeImage(stream, image)
                }
            }
            dngWritten.set(file.exists() && file.length() > 0)
            add("DNG: ${if (dngWritten.get()) "SAVED" else "FAIL"} bytes=${file.length()}")
        } catch (e: Exception) {
            add("DNG WRITE ERROR: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            image.close()
            rawImage = null
        }
    }

    private fun saveJpeg(image: Image) {
        val file = jpegFile ?: return
        try {
            FileOutputStream(file).use { stream ->
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                stream.write(bytes)
            }
            jpegWritten.set(file.exists() && file.length() > 0)
            add("JPEG: ${if (jpegWritten.get()) "SAVED" else "FAIL"} bytes=${file.length()}")
        } catch (e: Exception) {
            add("JPEG WRITE ERROR: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    private fun scheduleFinish() {
        cameraHandler.removeCallbacksAndMessages("finish")
        cameraHandler.postDelayed({ finishEvidence() }, 2500)
    }

    private fun finishEvidence() {
        if (!finishing.compareAndSet(false, true)) return
        tryWriteDng()

        val dir = captureDir ?: return
        val result = captureResult
        val iso = result?.get(CaptureResult.SENSOR_SENSITIVITY)
        val exposure = result?.get(CaptureResult.SENSOR_EXPOSURE_TIME)
        val frame = result?.get(CaptureResult.SENSOR_FRAME_DURATION)
        val af = result?.get(CaptureResult.CONTROL_AF_STATE)
        val ae = result?.get(CaptureResult.CONTROL_AE_STATE)
        val awb = result?.get(CaptureResult.CONTROL_AWB_STATE)

        val quality = when {
            ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED -> "LOW_LIGHT_WARNING"
            iso != null && iso > 8000 -> "HIGH_NOISE_RISK"
            iso != null && iso > 3200 -> "ELEVATED_NOISE_RISK"
            else -> "NO_BASIC_WARNING"
        }

        val dng = dngFile
        val jpg = jpegFile
        val metadata = File(dir, "metadata.json")

        val dngHash = dng?.takeIf { it.exists() && it.length() > 0 }?.let { sha256(it) }
        val jpgHash = jpg?.takeIf { it.exists() && it.length() > 0 }?.let { sha256(it) }

        metadata.writeText("""
{
  "capture_id": "$captureId",
  "camera_id": "$cameraId",
  "timestamp_epoch_ms": ${System.currentTimeMillis()},
  "release_state": "RELEASE_UNVERIFIED",
  "artifacts": {
    "dng": {"name": "capture.dng", "saved": ${dngWritten.get()}, "bytes": ${dng?.length() ?: 0}, "sha256": ${json(dngHash)}},
    "jpeg": {"name": "capture.jpg", "saved": ${jpegWritten.get()}, "bytes": ${jpg?.length() ?: 0}, "sha256": ${json(jpgHash)}}
  },
  "capture": {
    "callback_pass": ${captureCallbackReceived.get()},
    "iso": ${iso ?: "null"},
    "exposure_ns": ${exposure ?: "null"},
    "frame_duration_ns": ${frame ?: "null"},
    "focus_state": ${af ?: "null"},
    "ae_state": ${ae ?: "null"},
    "awb_state": ${awb ?: "null"}
  },
  "quality_class": "$quality"
}
""".trimIndent())

        val metadataHash = sha256(metadata)

        val analysisPass = try {
            val sourceJpeg = jpg ?: throw IllegalStateException("JPEG missing")
            val report = ImageQualityAnalyzer.analyze(sourceJpeg)
            val normalized = File(dir, "analysis_normalized.jpg")
            val normalizedSaved = if (report.pass) {
                ImageQualityAnalyzer.writeNormalizedCopy(sourceJpeg, normalized)
            } else false

            add("ANALYSIS SIZE: ${report.width}x${report.height}")
            add("MEAN LUMA: ${"%.2f".format(java.util.Locale.US, report.meanLuma)}")
            add("CONTRAST: ${"%.2f".format(java.util.Locale.US, report.contrast)}")
            add("DARK CLIP %: ${"%.2f".format(java.util.Locale.US, report.darkClipPercent)}")
            add("BRIGHT CLIP %: ${"%.2f".format(java.util.Locale.US, report.brightClipPercent)}")
            add("DETAIL SCORE: ${"%.2f".format(java.util.Locale.US, report.detailScore)}")
            add("PROCESSING WARNINGS: ${if (report.warnings.isEmpty()) "NONE" else report.warnings.joinToString(",")}")
            add("NORMALIZED IMAGE: ${if (normalizedSaved) "SAVED" else "NOT_SAVED"}")
            add("ANALYSIS INPUT: ${if (report.pass && normalizedSaved) "PASS" else "FAIL"}")
            report.pass && normalizedSaved
        } catch (e: Exception) {
            add("ANALYSIS ERROR: ${e.javaClass.simpleName}: ${e.message}")
            false
        }

        val pass = dngWritten.get() && jpegWritten.get() && captureCallbackReceived.get()

        add("METADATA: SAVED")
        add("DNG SHA-256: ${dngHash ?: "UNAVAILABLE"}")
        add("JPEG SHA-256: ${jpgHash ?: "UNAVAILABLE"}")
        add("METADATA SHA-256: $metadataHash")
        add("QUALITY: $quality")
        add("EVIDENCE RESULT: ${if (pass) "PASS" else "FAIL"}")
        if (pass && analysisPass) {
            completedSteps.add(currentStep)
            add("SESSION STEP RESULT: PASS (${currentStep.label})")
            if (completedSteps.size == 3) {
                File(sessionRoot!!, "session_manifest.json").writeText("{\"session_id\":\"$sessionId\",\"required_steps\":[\"FRONT\",\"LEFT_CHEEK\",\"RIGHT_CHEEK\"],\"session_ready_for_analysis\":true}")
                add("SESSION COMPLETE: 3/3")
                runSessionFeatureExtraction()
                runSkinRegionAnalysis()
                add("SESSION READY FOR ANALYSIS")
                runOnUiThread { status.text = "SESSION READY FOR ANALYSIS" }
            } else {
                val next = SessionStep.values().first { it !in completedSteps }
                currentStep = next
                add("NEXT REQUIRED STEP: ${next.label}")
                runOnUiThread { status.text = "NEXT: ${next.label}" }
            }
        } else {
            add("SESSION STEP RESULT: RETAKE REQUIRED (${currentStep.label})")
            runOnUiThread { status.text = "RETAKE: ${currentStep.label}" }
        }

        runOnUiThread {
            status.text = if (pass) "Evidence PASS | $quality" else "Evidence FAIL"
        }
    }

    private fun json(value: String?): String = value?.let { "\"$it\"" } ?: "null"

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun closeCamera() {
        try { rawImage?.close() } catch (_: Exception) {}
        rawImage = null
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { previewSurface?.release() } catch (_: Exception) {}
        try { rawReader?.close() } catch (_: Exception) {}
        try { jpegReader?.close() } catch (_: Exception) {}
        session = null; device = null; previewSurface = null; rawReader = null; jpegReader = null
    }

    override fun onDestroy() {
        closeCamera()
        cameraThread.quitSafely()
        super.onDestroy()
    }
}
