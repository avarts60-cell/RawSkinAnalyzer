# Architecture

## Capture path
UI step selection -> camera open -> Camera2 capture request -> JPEG ImageReader + RAW ImageReader -> TotalCaptureResult -> JPEG save / DNG creation -> metadata + hashes.

## Session gate
`finishEvidence()` requires DNG, JPEG, callback, and JPEG quality pass before adding a view to the three-photo session.

## Analysis path
Normalized JPEG
-> ImageFeatureExtractor / SkinRegionAnalyzer / SkinFeatureInterpreter
-> LocalizedVariationAnalyzer
-> ThreeViewConsistencyAnalyzer
-> LocalizedPatternMapper
-> hotspot/spatial/stability/repeatability stages
-> multi-view fusion and quantification
-> tone/texture/localized feature scoring
-> redness / pigmentation / blemish / texture-pore / surface condition
-> FinalSkinAnalysisProfile.

## Important architectural limitation
Most analysis stages recompute pattern maps directly from the normalized JPEG rather than consuming persisted artifacts. Artifact files are therefore evidence outputs, not authoritative inputs to downstream computation.

## Failure handling concern
Most `run...()` methods catch exceptions locally and only log them. `runFullAnalysisPipelineOnce()` continues to later stages and then marks the session analysis complete. This can create a final profile after upstream failures unless downstream code itself fails due to missing input.
