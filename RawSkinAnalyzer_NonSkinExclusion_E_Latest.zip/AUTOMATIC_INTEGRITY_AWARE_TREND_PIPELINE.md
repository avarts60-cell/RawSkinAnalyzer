# Automatic Integrity-Aware Trend Pipeline

The repository now provides automatic integrity-aware trend processing.

Flow:
1. Session history is loaded.
2. Persistent storage validates and recovers history.
3. The store exposes safe integrity telemetry.
4. A multi-session trend result is passed to the automatic pipeline.
5. Integrity-aware confidence is applied.
6. If safe multi-session history is unavailable, the trend result is withheld.

The pipeline does not modify underlying skin scores.
