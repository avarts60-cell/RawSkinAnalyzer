# Commercial Product Catalog Integration

This layer adds a normalized commercial-product boundary.

Input model:
- product ID
- brand
- product name
- ingredient names
- product attributes
- supported routine phases
- catalog source
- optional verification timestamp

Processing:
1. validate required fields
2. normalize valid records into ProductCandidate
3. use the existing ProductSelectionPlanner ranking engine
4. fall back to the local generic catalog when no commercial records are loaded

No live commercial products are embedded. External or curated catalog data can be loaded through ProductCatalogRepository.replace().
