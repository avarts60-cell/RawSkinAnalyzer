# Final Skincare Result Assembly

This layer assembles the complete pipeline into a single structured output.

It combines:
- primary and secondary findings
- prioritized concerns
- AM routine
- PM routine
- alternating plan
- ingredient-use plan
- accepted product recommendations
- propagated cautions

The assembler does not modify analysis scores, concern ranking, compatibility decisions, ingredient mapping, or product ranking. It is a final presentation boundary over the existing pipeline.
