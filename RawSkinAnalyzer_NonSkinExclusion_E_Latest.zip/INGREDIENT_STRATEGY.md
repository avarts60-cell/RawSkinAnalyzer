# Ingredient Strategy
Maps routine targets to PRIMARY_OPTION, SUPPORTIVE_OPTION, and CAUTION categories. Specific ingredients, concentrations, frequencies, contraindications, and products are not selected.
