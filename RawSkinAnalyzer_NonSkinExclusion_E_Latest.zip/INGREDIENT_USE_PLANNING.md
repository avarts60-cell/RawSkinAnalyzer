# Ingredient Concentration and Frequency Planning

This layer adds structured concentration and frequency guidance labels to named ingredient options.

The planner uses:
- ingredient name
- concern
- routine phase
- tolerance preference
- active-intensity preference
- caution metadata

Guidance is intentionally categorical and conservative. It does not prescribe an exact percentage, dose, treatment course, or replace product labeling and individualized professional advice.
