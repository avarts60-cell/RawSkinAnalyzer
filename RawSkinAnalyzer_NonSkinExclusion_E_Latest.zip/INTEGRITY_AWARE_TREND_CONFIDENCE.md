# Integrity-Aware Trend Confidence

This layer qualifies multi-session trend confidence using session integrity telemetry.

- Valid history: `FULL` support and existing confidence retained.
- Partially recovered history: `QUALIFIED` support and confidence downgraded one level.
- Recovery failure: `LIMITED` support, `LOW` confidence, and multi-session trend conclusions disabled.

Underlying skin scores are not changed. This layer only controls how strongly historical trends are trusted.
