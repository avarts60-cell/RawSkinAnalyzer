# Known Limitations

- RGB skin masks use fixed thresholds and can include hair, lips, background, shadows, or exclude valid skin.
- No face detector, landmarks, cheek ROI, pose validation, distance control, or illumination standardization is present.
- `analysis_normalized.jpg` is resized/recompressed; it is not photometrically normalized.
- Quality `detailScore` is an average sampled luma difference and is not a validated blur metric.
- Camera IDs are selected by literal strings in the UI, so logical camera mapping is device-dependent.
- Specialized scores use uncalibrated constants including weights such as 0.55/0.20/1.5 and thresholds such as 12/30/60.
- Confidence labels are rule-based rather than probability or validated uncertainty estimates.
- The pore-like and surface-condition labels exceed what the coarse image features can currently establish.
- Cross-view consistency compares summary statistics; the same anatomical location is not geometrically aligned.
- The baseline contains no test source tree.
- A prior build log shows compilation success for a differently named/path baseline, not proof for this exact ZIP.

## Camera capability limitation
Capability inventory now reports RAW support at runtime, but this audit ZIP has not been compiled or run on the target device; runtime values remain unverified.

## Phase 5 limitation
The ROI validator measures plausibility of the existing heuristic skin mask; it does not detect facial landmarks or guarantee that the analyzed central region is anatomically skin.

## Phase 6 limitation
Centralization of policy metadata does not validate the existing detector-specific weights, thresholds, or formulas. Detector outputs remain heuristic until calibration and repeatability testing are completed.
