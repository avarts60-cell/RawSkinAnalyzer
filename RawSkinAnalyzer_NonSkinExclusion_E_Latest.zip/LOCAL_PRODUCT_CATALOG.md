# Local Product Catalog Integration

This layer provides a catalog adapter compatible with ProductCandidate and ProductSelectionPlanner.

Current catalog entries are generic ingredient-category candidates rather than commercial products. This validates the end-to-end integration:

ingredient use plan
→ product requirement
→ catalog candidate
→ deterministic ranking
→ accepted candidate

A future commercial catalog can replace LocalProductCatalog while preserving the ranking interface.
