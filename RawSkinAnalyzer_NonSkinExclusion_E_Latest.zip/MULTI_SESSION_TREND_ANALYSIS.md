# Multi-Session Trend Analysis

This layer analyzes up to five compatible skin sessions. At least three sessions are required for a trend result.

Per-feature outputs include historical values, average delta, and:
- SUSTAINED_IMPROVEMENT
- STABLE_TREND
- SUSTAINED_WORSENING
- MIXED_TREND

The result remains downstream from measured skin analysis and does not alter original session scores.
