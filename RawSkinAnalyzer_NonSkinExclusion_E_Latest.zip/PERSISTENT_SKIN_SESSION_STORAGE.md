# Persistent Skin Session Storage

This layer adds `PersistentSkinSessionStore`, backed by Android SharedPreferences.

Stored data:
- session ID
- creation timestamp
- analysis version
- fused progress snapshot scores

Sessions are serialized as JSON and restored after application restart.

Compatibility filtering remains in `SkinSessionRepository`, so multi-session trend analysis continues to use only sessions with the matching analysis version.

The `SkinSessionStore` abstraction remains unchanged, allowing a future Room/SQLite implementation without changing repository consumers.
