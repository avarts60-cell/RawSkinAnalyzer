# Product Recommendation Assembly

This layer converts accepted product matches into structured recommendation records.

Each recommendation preserves:
- linked skin concern
- target ingredient
- routine phase
- deterministic match score
- ranking reasons
- recommendation status
- explanation
- caution metadata

The recommendation assembler does not independently alter ranking or create products. It only explains and structures accepted matches produced by the existing product selection engine.
