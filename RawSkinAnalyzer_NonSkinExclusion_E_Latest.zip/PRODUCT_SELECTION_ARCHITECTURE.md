# Product Selection Architecture

The product layer separates planning from catalog data.

It defines:
- product requirements
- required attributes
- exclusion attributes
- candidate model
- deterministic match scoring
- acceptance threshold

No real products are embedded in this layer. A future catalog or external product source can provide ProductCandidate records to the ranking function.
