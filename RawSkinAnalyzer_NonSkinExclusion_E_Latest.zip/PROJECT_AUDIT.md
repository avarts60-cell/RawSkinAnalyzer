# RawSkinAnalyzer Forensic Project Audit

## Audit baseline
- Source: RawSkinAnalyzer-FinalSkinAnalysisProfile-v1(1).zip
- Audit method: STATIC_REVIEW
- Prior build log present: COMPILED for a project identified in build-error.txt as `SkinInterpretation-v1-Test`; this does not prove this exact ZIP was compiled.
- Device verification: UNVERIFIED

## Executive findings
1. The project contains a real Android Camera2 RAW/JPEG capture path and real JPEG pixel analysis.
2. The analysis pipeline is executable by call order in MainActivity, but individual stage failures are swallowed and later stages still run.
3. Skin detection is a simple RGB heuristic, not face/landmark segmentation.
4. Several specialized detectors use real pixel-derived inputs but combine them with arbitrary weights and thresholds that are not calibrated or validated.
5. A concrete defect exists in skin_region_session.json: both left/right deltas subtract the right result from itself, forcing both deltas to 0.
6. The build log reports a successful compilation, but its path/version naming differs from this ZIP; exact-baseline compilation remains UNVERIFIED.
7. No test sources were found in this ZIP.

## Truth matrix
| Component | Status | Notes |
|---|---|---|
| Camera2 preview/capture | IMPLEMENTED BUT UNVERIFIED | Real Android Camera2 APIs are present |
| RAW/DNG persistence | IMPLEMENTED BUT UNVERIFIED | Depends on camera capability and matching result/image |
| JPEG quality metrics | STATIC_REVIEW | Real sampled pixels; thresholds uncalibrated |
| Normalized analysis image | STATIC_REVIEW | Resize/recompress only, not illumination normalization |
| Skin-region mask | HEURISTIC IMPLEMENTATION | RGB rules; no face localization |
| Localized pattern map | STATIC_REVIEW | Real pixels aggregated into 6x6 grid |
| Redness score | HEURISTIC IMPLEMENTATION | RGB-derived inputs with arbitrary scaling/thresholds |
| Pigmentation/tanning score | HEURISTIC IMPLEMENTATION | Luma variation is not a validated pigmentation/tanning measure |
| Blemish-like score | HEURISTIC IMPLEMENTATION | Arbitrary weights/bonuses and hotspot thresholds |
| Texture score | HEURISTIC IMPLEMENTATION | Neighbor luma difference, not calibrated skin texture |
| Pore-like score | TECHNICALLY WEAK / HEURISTIC | Coarse 6x6 cells cannot establish pores reliably |
| Oiliness/dryness signals | TECHNICALLY WEAK / HEURISTIC | Relative highlights/texture are not direct sebum/hydration measures |
| Final profile | IMPLEMENTED BUT UNVALIDATED | Ranking of upstream heuristic scores |
| Confidence labels | HEURISTIC IMPLEMENTATION | Rule-based, not statistically calibrated |
| Session readiness | IMPLEMENTED WITH CONTROL-FLOW RISK | Stage exceptions do not block later readiness |
| Skin objective selection | NOT PRESENT IN THIS BASELINE | This ZIP ends at FinalSkinAnalysisProfile |

## Confirmed defect
`runSkinRegionAnalysis()` writes:
`abs(l.redness-r.redness)` and `abs(l.texture-r.texture)`.
Both are always zero. They should compare left with right.

## Required repair priorities
1. Fix the forced-zero left/right deltas.
2. Introduce explicit stage result objects and dependency gating; a failed stage must not silently permit final readiness.
3. Separate capture/evidence readiness from analysis validity.
4. Replace hard-coded camera IDs with capability-based camera selection and verify RAW support.
5. Add face/skin ROI localization before characteristic scoring.
6. Mark or remove unsupported clinical-style labels until calibration data exists.
7. Add deterministic unit tests for every formula and threshold plus integration tests for pipeline gating.

## Phase 2 repairs
- Repaired self-subtraction patterns in left/right redness and texture delta calculations.
- Added analysis-stage failure recording and a completion gate: if recorded stage failures exist, the session is not marked ready for final analysis.
- Validation status: STATIC_REVIEW only; exact compilation/device validation remains required.

## Phase 3 camera/capture audit
- Added capability inventory using CameraManager and REQUEST_AVAILABLE_CAPABILITIES.
- Added explicit rear-camera selection result that prefers RAW-capable backward-compatible cameras.
- Existing capture wiring was not blindly rewritten because exact current callback/ID wiring requires compile/device validation; this phase exposes capability truth without falsely claiming device support.

## Phase 4 capture capability gate
- Added CaptureCapabilityGate with an explicit rear-camera decision requiring RAW capability for the current evidence workflow.
- Added runtime blocking when JPEG or required RAW capability is unavailable.
- Camera ID resolution is capability-based at the new gate; existing low-level capture wiring still requires exact compile/device validation before claiming complete migration.

## Phase 5 segmentation/ROI validity repair
- Added SkinRoiValidator to quantify overall and central mask coverage using the existing skin classifier.
- Invalid, excessively broad, or centrally insufficient masks now block downstream analysis.
- This is a validity gate around the existing heuristic mask, not a replacement face segmentation model.

## Phase 6 scoring-policy repair
- Added `AnalysisScorePolicy` as an explicit central registry for generic score bands and objective threshold.
- Policy documentation states that thresholds are engineering heuristics and not clinically/statistically calibrated.
- Pipeline now logs heuristic and uncalibrated score status.
- Existing detector-specific constants remain subject to future calibration work; this phase does not falsely relabel them as validated.

## Phase 7 deterministic tests
- Added JUnit regression tests for score-policy boundaries and invalid confidence when failures exist.
- Added deterministic bitmap tests for insufficient, overly broad, and plausible ROI masks.
- These tests are added to source but have not been executed in this environment; status remains STATIC_REVIEW until a Gradle test run succeeds.

## Score provenance wiring
FinalSkinAnalysisProfileAnalyzer now registers all eight authoritative final scores before ranking.
The exported final profile includes `score_provenance`.
Dark-mark scoring is explicitly documented as a categorical mapping from the dedicated pigmentation analyzer's localized-dark-mark signal rather than a silent reuse of the earlier characteristic score.

## Authoritative skin-data state repair
- Removed direct contradictory `INSUFFICIENT_SKIN_DATA` emission where it bypassed canonical state resolution.
- Canonical status is now emitted from `SkinDataStateResolver` using the usable-view count.
- PASS/PARTIAL/FAIL is the authoritative eligibility state; FAIL emits an explicit analysis block.

## Skin concern interpretation layer
Added a structured non-diagnostic concern model that maps authoritative final characteristics into skincare-relevant appearance categories while retaining score, priority, level, and provenance source.

## Skin objective bridge
The final profile export now derives structured skin concerns and prioritized appearance-focused objectives from authoritative final findings. Objectives preserve provenance and remain explicitly non-diagnostic.

## Routine strategy bridge
Added a structured strategy planner that converts ordered objectives into primary, secondary, and maintenance targets plus a generic AM/PM framework. No product or treatment claims are introduced at this layer.

## Ingredient strategy bridge
Added primary, supportive, and caution planning categories with compatibility review before future routine assembly.

## Routine compatibility layer
Added explicit include, alternate, separate-session, and review-required decisions between abstract ingredient strategy and future routine scheduling. The planner prevents automatic inclusion of every planned category in the same session.

## Routine scheduling layer
Added category-level AM/PM routine assembly and alternating night-slot scheduling from compatibility decisions. Review-required items are not automatically scheduled.

## User-context constraint layer
Added context-aware filtering and simplification after schedule generation. Image-derived scores and priorities remain unchanged; only routine assembly is constrained.

## Specific ingredient mapping layer
Added named ingredient options derived from structured concerns while retaining routine phase, source category, selection role, and caution metadata. This remains an option layer rather than a prescription or product recommendation engine.

## Ingredient use planning layer
Added categorical strength, introduction, and frequency planning derived from named ingredient options and user tolerance constraints. Exact concentrations and dosing are deliberately not generated.

## Product selection architecture layer
Added a deterministic boundary between ingredient-use planning and future product data. Product candidates can be matched and ranked without altering skin findings or ingredient plans.

## Local product catalog layer
Added a normalized local catalog and connected it to the existing ProductCandidate and deterministic ranking pipeline. Current entries are generic catalog candidates, not commercial product recommendations.

## Commercial catalog integration layer
Added CommercialProductRecord validation, normalization into ProductCandidate, and a repository boundary that switches between commercial records and the existing local fallback catalog without changing ranking logic.

## Recommendation assembly layer
Added a dedicated explanation boundary after product ranking. Accepted matches are now converted into concern-linked, ingredient-linked, phase-aware recommendation records without changing ranking decisions.

## Final skincare result layer
Added a final aggregation boundary that combines findings, routine scheduling, ingredient-use guidance, accepted product recommendations, and cautions without modifying upstream analysis or ranking logic.

## Progress tracking layer
Added a longitudinal comparison boundary using normalized core appearance scores. A first session explicitly reports insufficient comparison data rather than inventing progress. Future sessions can supply a compatible previous snapshot.

## Session storage layer
Added a storage abstraction between analysis and longitudinal history. The current implementation retrieves the latest compatible snapshot before saving the new session, allowing SkinProgressTracker to perform automatic comparisons while preserving replaceability of the storage backend.

## Routine adaptation layer
Added a downstream decision engine that converts longitudinal feature changes into maintain, review, or adjustment states. It preserves the separation between measured analysis data and adaptation policy.

## Routine adaptation execution layer
Added an execution boundary after adaptation decisions. The system can preserve or simplify a routine automatically, while potential adjustment is explicitly held for compatibility and tolerance review rather than directly intensifying treatment.

## Multi-session trend layer
Added longitudinal trend analysis across compatible historical snapshots, allowing sustained patterns to be distinguished from a single session-to-session change.

## Trend-aware adaptation layer
Added a policy boundary that gives sustained multi-session patterns greater influence than a single comparison while preserving conservative review behavior and downstream execution safeguards.

## Trend-aware adjustment generation layer
Added a controlled candidate-generation boundary for sustained worsening. The layer proposes only existing, uncautioned ingredient plans and explicitly blocks automatic frequency escalation or direct activation.

## Candidate activation layer
Added explicit approval and rejection gates between trend-aware adjustment generation and routine revision. Only candidates backed by an existing uncautioned ingredient plan can enter the controlled revised routine, and no automatic frequency escalation is permitted.

## Persistent session storage layer
Replaced the architecture's in-memory-only limitation with a SharedPreferences-backed implementation capable of restoring session history after application restart while preserving the existing SkinSessionStore abstraction.

## Persistent session lifecycle layer
Added retention limits and analysis-version lifecycle pruning while preserving the compatible-history contract used by trend analysis.

## Automatic lifecycle integration layer
Session persistence now automatically applies the configured retention policy immediately after a completed snapshot is saved, preventing uncontrolled historical accumulation without requiring a separate application-layer call.

## Session data integrity and recovery layer
Added defensive validation and recovery during persistent session loading. Individual malformed entries no longer invalidate otherwise usable history, and recovered valid history is written back to persistent storage.

## Integrity telemetry layer
Added a safe telemetry abstraction for session recovery outcomes. Persistence now exposes recovery state and aggregate counts without retaining or exporting malformed raw session content.

## Integrity-aware trend confidence layer
Added an explicit boundary between data integrity and skin findings. Historical corruption can now qualify or disable multi-session trend confidence without altering underlying skin characteristic scores.

## Automatic integrity-aware trend integration
Added a repository-level bridge that automatically reads session integrity telemetry and applies confidence qualification to multi-session trend results. Recovery failure now prevents unsupported historical trend conclusions while leaving current skin analysis scores unchanged.
