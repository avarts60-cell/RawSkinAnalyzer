# Routine Adaptation from Longitudinal Progress

This layer interprets longitudinal comparison output without changing the underlying skin-analysis scores.

Possible actions:
- MAINTAIN_CURRENT_ROUTINE
- SIMPLIFY_ROUTINE
- REVIEW_AND_MONITOR
- CONSIDER_ROUTINE_ADJUSTMENT

The engine evaluates improved, stable, and worsened feature counts plus comparison confidence.

A first session or incompatible comparison produces REVIEW_AND_MONITOR with INSUFFICIENT_LONGITUDINAL_DATA rather than an unsupported adjustment.

The current implementation provides an adaptation decision layer only. It does not automatically rewrite the routine schedule or product plan.
