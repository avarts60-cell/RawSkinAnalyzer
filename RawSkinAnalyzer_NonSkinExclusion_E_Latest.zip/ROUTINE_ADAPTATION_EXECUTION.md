# Routine Adaptation Execution

This layer converts a routine adaptation decision into a controlled output plan.

Rules:
- MAINTAIN_CURRENT_ROUTINE preserves the existing plan.
- SIMPLIFY_ROUTINE may remove one alternating step when available.
- REVIEW_AND_MONITOR does not automatically intensify the routine.
- CONSIDER_ROUTINE_ADJUSTMENT requires compatibility and tolerance review before an automatic change.

The executor does not change measured skin-analysis scores, concern priorities, or product ranking.
