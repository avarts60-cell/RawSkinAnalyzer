# Routine Adjustment Candidate Activation

This layer activates generated adjustment candidates through explicit gates.

A candidate is rejected when:
- no matching ingredient-use plan exists
- a direct caution exists
- the requested automatic frequency differs from the controlled review state

Approved candidates retain the existing ingredient plan and are represented in a controlled alternating-plan revision. The layer does not automatically increase frequency or introduce a new ingredient.

The output preserves both approved and rejected candidates with reasons.
