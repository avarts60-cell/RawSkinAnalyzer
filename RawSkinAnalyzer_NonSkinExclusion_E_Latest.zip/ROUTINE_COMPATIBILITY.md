# Routine Compatibility and Assembly

The compatibility layer evaluates ingredient-strategy categories before routine inclusion.

Actions:
- INCLUDE: may be considered in its assigned phase.
- ALTERNATE: do not automatically stack; use an alternating schedule.
- SEPARATE_SESSION: keep out of the same automatic routine session.
- REVIEW_REQUIRED: caution category requiring compatibility review.

This is a structural safety layer. It does not establish medical contraindications, exact concentrations, individualized treatment schedules, or product-specific compatibility.
