# Routine Scheduling and Assembly

This layer converts compatible category-level decisions into:
- AM compatible support steps
- PM base support steps
- alternating or separate-session PM slots
- a simple weekly pattern

Schedule labels are structural:
- DAILY_OR_AS_NEEDED
- NIGHT_SLOT_n

They are not individualized medical dosing or product-use instructions. Specific ingredient frequency and product selection require later compatibility, tolerance, and user-context layers.
