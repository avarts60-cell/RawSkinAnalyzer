# Routine Strategy Planner

The strategy layer ranks objective-derived concerns into:
- PRIMARY
- SECONDARY
- MAINTENANCE

Current framework:
Morning:
1. Gentle cleansing as needed
2. Objective-compatible support step
3. Moisturizing support as needed
4. Daytime photoprotection

Evening:
1. Gentle cleansing
2. Objective-targeted support step
3. Moisturizing support

This layer does not yet select ingredients, concentrations, products, frequency, or individualized contraindications.
