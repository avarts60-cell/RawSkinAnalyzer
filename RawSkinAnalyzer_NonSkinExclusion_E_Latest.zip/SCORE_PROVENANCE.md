# Final Score Provenance
Each final characteristic must record characteristic, finalScore, sourceStage, sourceScore, replacedScore when applicable, and selectionReason.
Canonical skin data: 3/3=PASS/FULL_MULTI_VIEW_SKIN_DATA; 2/3=PARTIAL; 0-1/3=FAIL/INSUFFICIENT_SKIN_DATA.

## Implemented final sources
REDNESS -> RednessAnalysisAnalyzer
PIGMENTATION_OR_TONE_VARIATION -> PigmentationTanningAnalyzer
DARK_MARK_SIGNAL -> PigmentationTanningAnalyzer.localizedDarkMarkSignal categorical mapping
BLEMISH_LIKE_FEATURES -> BlemishFeatureAnalyzer
TEXTURE_IRREGULARITY -> TexturePoreFeatureAnalyzer
PORE_LIKE_FEATURES -> TexturePoreFeatureAnalyzer
SURFACE_SHINE_SIGNAL -> SurfaceConditionAnalyzer
DRYNESS_RELATED_SURFACE_SIGNAL -> SurfaceConditionAnalyzer
