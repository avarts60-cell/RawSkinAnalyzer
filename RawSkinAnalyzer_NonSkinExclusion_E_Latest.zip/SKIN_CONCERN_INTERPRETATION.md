# Skin Concern Interpretation

This layer converts final image-derived findings into non-diagnostic concern categories.

It distinguishes:
- TONE_PIGMENTATION
- DARK_MARKS
- BLEMISH_LIKE_APPEARANCE
- REDNESS_APPEARANCE
- PORE_TEXTURE_APPEARANCE
- SURFACE_SHINE
- DRYNESS_APPEARANCE

These categories describe visible image signals and are not medical diagnoses. They are the input for a later skincare-objective layer.
