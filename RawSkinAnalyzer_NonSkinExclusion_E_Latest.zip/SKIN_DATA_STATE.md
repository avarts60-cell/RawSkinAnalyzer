# Canonical Skin Data State

Exactly one authoritative state should be emitted per completed fusion:

- PASS: all required views usable.
- PARTIAL: enough views for partial analysis.
- FAIL: insufficient usable views; final analysis is blocked.

`SKIN DATA STATUS` must be derived from this state and must not be independently emitted by earlier stages.
