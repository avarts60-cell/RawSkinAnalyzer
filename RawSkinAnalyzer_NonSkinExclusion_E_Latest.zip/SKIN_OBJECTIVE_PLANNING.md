# Skin Objective Planning

The objective layer converts ordered non-diagnostic skin concerns into practical appearance-focused objectives.

Current objective types:
- IMPROVE_VISIBLE_APPEARANCE
- SUPPORT_BALANCE
- MAINTAIN_CURRENT_STATE
- MONITOR

Score bands are current engineering policy and remain heuristic. Objectives retain concern priority and evidence provenance.

This layer does not select products, active ingredients, routines, treatment frequency, or medical interventions.
