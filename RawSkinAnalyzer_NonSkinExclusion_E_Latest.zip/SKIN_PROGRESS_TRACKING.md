# Skin Progress Tracking

This layer establishes a longitudinal comparison model.

Each session can be represented as a SkinProgressSnapshot containing the same core appearance scores used by the analysis pipeline.

Comparison output includes:
- previous score
- current score
- delta
- IMPROVED / STABLE / WORSENED direction
- overall direction
- comparison confidence

The current pipeline exports INSUFFICIENT_COMPARISON_DATA until a previous compatible snapshot is supplied. The tracker does not alter the current session's analysis scores.
