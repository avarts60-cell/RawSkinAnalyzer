# Skin Session Data Integrity and Recovery

Persistent session history is now validated during loading.

Validation requires:
- non-empty session ID
- positive creation timestamp
- non-empty analysis version
- all progress scores finite and within 0.0 to 100.0

Malformed JSON entries are skipped individually. Valid entries are retained and the cleaned history is persisted back to storage.

If the complete stored JSON cannot be parsed, the invalid persisted value is removed and an empty safe history is returned.
