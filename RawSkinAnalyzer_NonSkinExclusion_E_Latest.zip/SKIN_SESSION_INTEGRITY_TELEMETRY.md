# Skin Session Integrity Telemetry

The persistence layer now produces a safe integrity summary after history loading.

Reported fields:
- integrity status
- valid session count
- rejected entry count
- whether recovery was applied
- whether safe history remains available

Raw malformed JSON and rejected session contents are never included in telemetry.

Possible statuses:
- `SESSION_DATA_VALID`
- `SESSION_DATA_PARTIALLY_RECOVERED`
- `SESSION_DATA_RECOVERY_FAILED`
