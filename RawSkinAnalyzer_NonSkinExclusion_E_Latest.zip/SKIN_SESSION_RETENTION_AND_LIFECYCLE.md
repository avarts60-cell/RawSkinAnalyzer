# Skin Session Retention and Lifecycle

Defaults: retain at most 30 sessions and the two most recent analysis versions. `applyLifecyclePolicy()` prunes obsolete history and persists the retained set. Compatible trend history remains version-filtered.
