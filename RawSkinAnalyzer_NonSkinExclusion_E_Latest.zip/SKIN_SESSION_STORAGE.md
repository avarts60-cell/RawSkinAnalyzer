# Skin Session Storage and Previous-Session Retrieval

This layer introduces a storage abstraction for longitudinal skin analysis.

Components:
- StoredSkinSession: immutable session record
- SkinSessionStore: storage interface
- InMemorySkinSessionStore: current default implementation
- SkinSessionRepository: application boundary

Flow:
1. retrieve the latest compatible previous snapshot
2. compare it with the current snapshot
3. export progress results
4. save the current session

Compatibility is currently based on analysis-version equality. A persistent database implementation can replace InMemorySkinSessionStore through SkinSessionRepository.configure().
