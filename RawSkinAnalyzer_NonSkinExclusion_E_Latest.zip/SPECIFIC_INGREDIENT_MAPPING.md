# Specific Ingredient Mapping

This layer maps image-derived appearance concerns to named cosmetic ingredient options.

Each option retains:
- concern
- selection role
- routine phase
- source strategy category
- caution text where applicable

Current implementation provides options only. It does not select concentration, product, exact frequency, or medical treatment. Cautious tolerance preference removes OPTIONAL choices automatically.
