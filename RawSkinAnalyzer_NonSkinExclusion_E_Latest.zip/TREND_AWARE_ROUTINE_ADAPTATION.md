# Trend-Aware Routine Adaptation

This layer combines:
- current-versus-previous progress
- multi-session trend analysis
- existing adaptation policy

Policy:
- insufficient trend data preserves the existing short-term decision
- two or more sustained worsening features can escalate to CONSIDER_ROUTINE_ADJUSTMENT
- two or more sustained improving features, with no sustained worsening, can reinforce MAINTAIN_CURRENT_ROUTINE
- mixed trends remain under review

The policy does not alter measured skin-analysis scores. Potential adjustment remains subject to downstream compatibility and tolerance review.
