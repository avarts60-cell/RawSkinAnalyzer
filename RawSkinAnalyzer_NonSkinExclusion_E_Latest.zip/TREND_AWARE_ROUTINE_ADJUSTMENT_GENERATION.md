# Trend-Aware Routine Adjustment Generation

This layer generates controlled adjustment candidates only when:
- the trend-aware adaptation decision is CONSIDER_ROUTINE_ADJUSTMENT
- sustained worsening features exist
- an existing ingredient-use plan matches the affected concern
- the plan does not carry a direct caution

Generated candidates retain the existing ingredient target and do not automatically escalate frequency. Activation remains subject to compatibility and tolerance review.

If no eligible candidate exists, the system returns REVIEW_REQUIRED_NO_CANDIDATE.
