# User Routine Context

Adds structured routine constraints without changing image-derived findings. Current controls cover complexity, tolerance preference, active-intensity preference, optional time limits, and excluded categories. Defaults preserve the existing pipeline behavior.
