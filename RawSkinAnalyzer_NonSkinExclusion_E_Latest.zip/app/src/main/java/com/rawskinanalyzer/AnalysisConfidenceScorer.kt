package com.rawskinanalyzer

data class AnalysisConfidence(val score:Double,val level:String,val factors:List<String>)

object AnalysisConfidenceScorer {
    fun score(
        qualityPass:Boolean,
        evidencePass:Boolean,
        skinCoverage:Double,
        detailScore:Double,
        consistencyScore:Double
    ):AnalysisConfidence{
        var score=0.0; val factors=mutableListOf<String>()
        if(evidencePass){score+=25;factors+="EVIDENCE_COMPLETE"} else factors+="EVIDENCE_INCOMPLETE"
        if(qualityPass){score+=20;factors+="QUALITY_PASS"} else factors+="QUALITY_REVIEW"
        val cov=when{skinCoverage>=35->25.0;skinCoverage>=20->18.0;skinCoverage>=10->10.0;else->0.0}
        score+=cov;factors+="SKIN_COVERAGE_${cov.toInt()}"
        val det=when{detailScore>=8->20.0;detailScore>=4->15.0;detailScore>=2->10.0;else->0.0}
        score+=det;factors+="DETAIL_${det.toInt()}"
        val cons=when{consistencyScore>=80->10.0;consistencyScore>=60->7.0;consistencyScore>=40->4.0;else->0.0}
        score+=cons;factors+="CROSS_VIEW_${cons.toInt()}"
        val level=when{score>=85->"HIGH";score>=65->"MODERATE";score>=45->"LOW";else->"INSUFFICIENT"}
        return AnalysisConfidence(score,level,factors)
    }
    fun json(x:AnalysisConfidence) =
        """{"score":${x.score},"level":"${x.level}","factors":[${x.factors.joinToString(","){"\"$it\""}}],"medical_diagnosis":false}"""
}
