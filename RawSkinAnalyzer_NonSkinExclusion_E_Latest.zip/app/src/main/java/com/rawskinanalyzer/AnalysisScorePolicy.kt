package com.rawskinanalyzer

/**
 * Central registry for heuristic score policy.
 *
 * IMPORTANT: These constants are engineering thresholds, not clinically calibrated
 * measurements or probabilities. Any feature using them must expose heuristic status.
 */
object AnalysisScorePolicy {
    const val VERSION = "HEURISTIC_POLICY_V1"
    const val OBJECTIVE_SELECTION_MIN_SCORE = 12.0
    const val LEVEL_LOW = 30.0
    const val LEVEL_HIGH = 60.0

    fun level(score: Double): String = when {
        score >= LEVEL_HIGH -> "HIGH_VISIBLE_SIGNAL"
        score >= LEVEL_LOW -> "MODERATE_VISIBLE_SIGNAL"
        else -> "LOW_VISIBLE_SIGNAL"
    }

    fun evidenceConfidence(
        threeViewConsistency: String?,
        roiValid: Boolean,
        upstreamFailures: Int
    ): String = when {
        upstreamFailures > 0 -> "INVALID"
        !roiValid -> "INSUFFICIENT_INPUT_VALIDITY"
        threeViewConsistency == "HIGH_CROSS_VIEW_CONSISTENCY" -> "HIGHER_HEURISTIC_CONFIDENCE"
        threeViewConsistency != null -> "MODERATE_HEURISTIC_CONFIDENCE"
        else -> "LIMITED_HEURISTIC_CONFIDENCE"
    }
}
