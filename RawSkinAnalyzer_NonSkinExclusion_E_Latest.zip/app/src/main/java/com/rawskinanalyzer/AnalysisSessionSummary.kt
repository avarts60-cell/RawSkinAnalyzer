package com.rawskinanalyzer

data class AnalysisSessionDecision(
    val sessionId:String,
    val readiness:String,
    val confidence:AnalysisConfidence,
    val consistency:CrossViewPatternSummary,
    val observations:List<String>
)

object AnalysisSessionSummary {
    fun decide(
        sessionId:String,
        evidencePass:Boolean,
        featureComplete:Boolean,
        skinRegionComplete:Boolean,
        patternComplete:Boolean,
        confidence:AnalysisConfidence,
        consistency:CrossViewPatternSummary
    ):AnalysisSessionDecision{
        val ok=evidencePass&&featureComplete&&skinRegionComplete&&patternComplete&&confidence.level!="INSUFFICIENT"
        val obs=if(ok) listOf("ANALYSIS_PREREQUISITES_COMPLETE","MEASUREMENTS_READY_FOR_REVIEW")
                 else listOf("ANALYSIS_PREREQUISITES_INCOMPLETE")
        return AnalysisSessionDecision(sessionId,if(ok)"READY_FOR_REVIEW" else "NOT_READY",confidence,consistency,obs)
    }
    fun json(x:AnalysisSessionDecision) =
        """{"session_id":"${x.sessionId}","readiness":"${x.readiness}","confidence":${AnalysisConfidenceScorer.json(x.confidence)},"consistency":${CrossViewPatternAnalyzer.json(x.consistency)},"observations":[${x.observations.joinToString(","){"\"$it\""}}],"medical_diagnosis":false}"""
}
