package com.rawskinanalyzer

/**
 * AnatomicalRegionMapper
 *
 * Turns a [FaceGeometryResult] (ML Kit contours/landmarks, see FaceGeometryAnalyzer) into the
 * eight anatomical regions this batch's handoff requires, plus the landmark-based non-skin
 * exclusion regions (eyes, eyebrows, lips, an approximate lower-nose/nostril band). Everything
 * here is derived geometrically from contour points ML Kit actually returned — per the
 * handoff's own rule ("derive additional boundaries geometrically... rather than pretending
 * unsupported landmarks exist"), no region is invented when its source contour is missing;
 * that region is simply absent from the result with the reason recorded, not force-guessed
 * from a generic face template.
 *
 * All polygons are returned in the SAME coordinate space as the input [FaceGeometryResult]'s
 * contour points were built in — i.e. normalized-image coordinates by default. Every point
 * also carries its own original-capture-coordinate value (computed once by FaceGeometryAnalyzer
 * using the normalized->original scale factor), so no region here needs a second scale estimate
 * — see `pointAt` below, which reuses that exact same per-geometry scale.
 *
 * Region approximations and their honest limitations, stated once here rather than repeated
 * per region:
 *  - FOREHEAD: ML Kit's FACE contour approximates the visible face oval; it does not track a
 *    hairline. The forehead region is therefore the portion of the face bounding box ABOVE the
 *    eyebrow-top contour line, clipped to the FACE contour's own left/right extent at that
 *    height — a geometric approximation, not a hairline-aware boundary.
 *  - LEFT_CHEEK / RIGHT_CHEEK: ML Kit's own LEFT_CHEEK/RIGHT_CHEEK contour is a small localized
 *    cluster (not a full region outline). This mapper expands it into a quadrilateral bounded
 *    by the cheek contour's centroid, the eye-bottom height, the nose side, and the mouth
 *    corner on that side — the classic "cheek triangle" between eye, nose, and mouth, built
 *    only from points ML Kit actually returned.
 *  - NOSE: bounding quad of NOSE_BRIDGE + NOSE_BOTTOM contour points. No further sub-division.
 *  - CHIN: the central third (by x-extent) of the FACE contour's lowest arc, below the
 *    lower-lip contour.
 *  - JAW: the two outer thirds of that same lowest arc, extended up to cheek height — CHIN and
 *    JAW are allowed to share their boundary edge (anatomically contiguous), which is the one
 *    deliberate, documented region overlap this mapper produces, per the handoff's "allow
 *    regions to overlap only where technically justified" rule.
 *  - UNDER_EYE_LEFT / UNDER_EYE_RIGHT: a thin band between the eye contour's bottom edge and
 *    the cheek region's top edge on that side. This is the region most sensitive to missing
 *    contour data (needs both EYE and CHEEK); it is simply omitted, not guessed, when either
 *    is missing.
 *  - Nostril exclusion is an approximate lower-center band of the NOSE polygon (ML Kit has no
 *    per-nostril landmark) — documented as approximate, consistent with the handoff's
 *    "do not pretend landmark geometry can solve [things it cannot]" instruction applied to
 *    the exclusion side as well as the region side.
 */

enum class AnatomicalRegion { FOREHEAD, LEFT_CHEEK, RIGHT_CHEEK, NOSE, CHIN, JAW, UNDER_EYE_LEFT, UNDER_EYE_RIGHT }
enum class NonSkinExclusionCategory { OUTSIDE_FACE, EYES, EYEBROWS, LIPS, NOSTRILS_APPROXIMATE, HAIR_OR_STUBBLE }

data class RegionPolygon(
    val region: AnatomicalRegion,
    val points: List<GeometryPoint>,
    /** Confidence this region's boundary is geometrically sound, independent of skin-color evidence. Never fabricated — see class doc. */
    val confidence: Double
)

data class ExclusionPolygon(
    val category: NonSkinExclusionCategory,
    val points: List<GeometryPoint>,
    val reason: String
)

data class RegionSet(
    val regions: List<RegionPolygon>,
    val exclusions: List<ExclusionPolygon>,
    val skippedRegions: List<Pair<AnatomicalRegion, String>>
) {
    fun region(r: AnatomicalRegion): RegionPolygon? = regions.firstOrNull { it.region == r }
}

object AnatomicalRegionMapper {
    const val VERSION = "anatomical_region_mapper_v1"

    /** Every region built here comes from a derived/approximated contour set (see class doc) — this is the shared confidence ceiling. */
    private const val REGION_APPROXIMATION_CONFIDENCE = 0.7

    private fun nx(p: GeometryPoint) = p.normalizedX
    private fun ny(p: GeometryPoint) = p.normalizedY
    private fun minX(pts: List<GeometryPoint>) = pts.minOf { nx(it) }
    private fun maxX(pts: List<GeometryPoint>) = pts.maxOf { nx(it) }
    private fun minY(pts: List<GeometryPoint>) = pts.minOf { ny(it) }
    private fun maxY(pts: List<GeometryPoint>) = pts.maxOf { ny(it) }
    private fun quad(a: GeometryPoint, b: GeometryPoint, c: GeometryPoint, d: GeometryPoint) = listOf(a, b, c, d)

    private fun pointAt(px: Float, py: Float, geom: FaceGeometryResult): GeometryPoint {
        val scaleAvailable = geom.originalScaleAvailable && geom.originalImageWidth != null && geom.originalImageHeight != null
        val ox = if (scaleAvailable) px * (geom.originalImageWidth!!.toFloat() / geom.normalizedImageWidth.toFloat()) else null
        val oy = if (scaleAvailable) py * (geom.originalImageHeight!!.toFloat() / geom.normalizedImageHeight.toFloat()) else null
        return GeometryPoint(px, py, ox, oy)
    }

    fun map(geom: FaceGeometryResult): RegionSet {
        val regions = mutableListOf<RegionPolygon>()
        val exclusions = mutableListOf<ExclusionPolygon>()
        val skipped = mutableListOf<Pair<AnatomicalRegion, String>>()

        if (!geom.faceDetected || geom.bounds == null) {
            AnatomicalRegion.values().forEach { skipped += it to "NO_FACE_GEOMETRY" }
            return RegionSet(emptyList(), emptyList(), skipped)
        }

        val faceOutline = geom.contour(FaceLandmarkGroup.FACE_OUTLINE)
        val leftEye = geom.contour(FaceLandmarkGroup.LEFT_EYE)
        val rightEye = geom.contour(FaceLandmarkGroup.RIGHT_EYE)
        val leftBrow = geom.contour(FaceLandmarkGroup.LEFT_EYEBROW)
        val rightBrow = geom.contour(FaceLandmarkGroup.RIGHT_EYEBROW)
        val nose = geom.contour(FaceLandmarkGroup.NOSE)
        val mouth = geom.contour(FaceLandmarkGroup.MOUTH)
        val leftCheek = geom.contour(FaceLandmarkGroup.LEFT_CHEEK)
        val rightCheek = geom.contour(FaceLandmarkGroup.RIGHT_CHEEK)

        // --- Outside-face exclusion: everything outside the FACE contour's own bounding box ---
        if (faceOutline.isNotEmpty()) {
            val fLeft = minX(faceOutline); val fRight = maxX(faceOutline)
            val fTop = minY(faceOutline); val fBottom = maxY(faceOutline)
            exclusions += ExclusionPolygon(
                NonSkinExclusionCategory.OUTSIDE_FACE,
                quad(
                    pointAt(fLeft, fTop, geom), pointAt(fRight, fTop, geom),
                    pointAt(fRight, fBottom, geom), pointAt(fLeft, fBottom, geom)
                ),
                "FACE_OUTLINE_BOUNDING_BOX"
            )
        }

        // --- FOREHEAD: face bbox above eyebrow-top line, clipped to face outline x-extent ---
        if (faceOutline.isNotEmpty() && (leftBrow.isNotEmpty() || rightBrow.isNotEmpty())) {
            val browTopY = (leftBrow + rightBrow).minOfOrNull { ny(it) }
            val fLeft = minX(faceOutline); val fRight = maxX(faceOutline); val fTop = minY(faceOutline)
            if (browTopY != null && browTopY > fTop) {
                regions += RegionPolygon(
                    AnatomicalRegion.FOREHEAD,
                    quad(
                        pointAt(fLeft, fTop, geom), pointAt(fRight, fTop, geom),
                        pointAt(fRight, browTopY, geom), pointAt(fLeft, browTopY, geom)
                    ),
                    REGION_APPROXIMATION_CONFIDENCE * geom.geometryConfidence
                )
            } else skipped += AnatomicalRegion.FOREHEAD to "EYEBROW_ABOVE_FACE_TOP_INVALID_GEOMETRY"
        } else skipped += AnatomicalRegion.FOREHEAD to "MISSING_FACE_OUTLINE_OR_EYEBROW_CONTOUR"

        // --- EYEBROWS / EYES exclusion ---
        if (leftBrow.isNotEmpty()) exclusions += ExclusionPolygon(NonSkinExclusionCategory.EYEBROWS, leftBrow, "LEFT_EYEBROW_CONTOUR")
        if (rightBrow.isNotEmpty()) exclusions += ExclusionPolygon(NonSkinExclusionCategory.EYEBROWS, rightBrow, "RIGHT_EYEBROW_CONTOUR")
        if (leftEye.isNotEmpty()) exclusions += ExclusionPolygon(NonSkinExclusionCategory.EYES, leftEye, "LEFT_EYE_CONTOUR")
        if (rightEye.isNotEmpty()) exclusions += ExclusionPolygon(NonSkinExclusionCategory.EYES, rightEye, "RIGHT_EYE_CONTOUR")

        // --- LIPS exclusion ---
        if (mouth.isNotEmpty()) exclusions += ExclusionPolygon(NonSkinExclusionCategory.LIPS, mouth, "LIP_CONTOURS_COMBINED")

        // --- NOSE region + approximate nostril exclusion ---
        if (nose.isNotEmpty()) {
            val nLeft = minX(nose); val nRight = maxX(nose); val nTop = minY(nose); val nBottom = maxY(nose)
            regions += RegionPolygon(
                AnatomicalRegion.NOSE,
                quad(
                    pointAt(nLeft, nTop, geom), pointAt(nRight, nTop, geom),
                    pointAt(nRight, nBottom, geom), pointAt(nLeft, nBottom, geom)
                ),
                REGION_APPROXIMATION_CONFIDENCE * geom.geometryConfidence
            )
            // Nostril approximation: lower quarter of the nose polygon by height, center 70% by width.
            // ML Kit provides no per-nostril landmark; this is a documented coarse approximation only.
            val bandTop = nBottom - (nBottom - nTop) * 0.25f
            val bandLeft = nLeft + (nRight - nLeft) * 0.15f
            val bandRight = nRight - (nRight - nLeft) * 0.15f
            exclusions += ExclusionPolygon(
                NonSkinExclusionCategory.NOSTRILS_APPROXIMATE,
                quad(
                    pointAt(bandLeft, bandTop, geom), pointAt(bandRight, bandTop, geom),
                    pointAt(bandRight, nBottom, geom), pointAt(bandLeft, nBottom, geom)
                ),
                "APPROXIMATE_LOWER_NOSE_BAND_NO_PER_NOSTRIL_LANDMARK"
            )
        } else {
            skipped += AnatomicalRegion.NOSE to "MISSING_NOSE_CONTOUR"
        }

        // --- CHEEKS: quad between cheek-contour centroid, eye-bottom, nose side, mouth corner ---
        fun cheekRegion(cheekContour: List<GeometryPoint>, eyeContour: List<GeometryPoint>, region: AnatomicalRegion): RegionPolygon? {
            if (cheekContour.isEmpty() || eyeContour.isEmpty() || nose.isEmpty() || mouth.isEmpty()) return null
            val cx = cheekContour.map { nx(it) }.average().toFloat()
            val cy = cheekContour.map { ny(it) }.average().toFloat()
            val eyeBottomY = eyeContour.maxOf { ny(it) }
            val noseSideX = if (region == AnatomicalRegion.LEFT_CHEEK) minX(nose) else maxX(nose)
            val mouthCornerX = if (region == AnatomicalRegion.LEFT_CHEEK) mouth.maxOf { nx(it) } else mouth.minOf { nx(it) }
            val mouthY = mouth.map { ny(it) }.average().toFloat()
            return RegionPolygon(
                region,
                quad(
                    pointAt(cx, eyeBottomY, geom),
                    pointAt(noseSideX, cy, geom),
                    pointAt(mouthCornerX, mouthY, geom),
                    pointAt(cx, cy + (mouthY - cy) * 0.5f, geom)
                ),
                REGION_APPROXIMATION_CONFIDENCE * geom.geometryConfidence
            )
        }
        cheekRegion(leftCheek, leftEye, AnatomicalRegion.LEFT_CHEEK)?.let { regions += it }
            ?: run { skipped += AnatomicalRegion.LEFT_CHEEK to "MISSING_LEFT_CHEEK_OR_SUPPORTING_CONTOUR" }
        cheekRegion(rightCheek, rightEye, AnatomicalRegion.RIGHT_CHEEK)?.let { regions += it }
            ?: run { skipped += AnatomicalRegion.RIGHT_CHEEK to "MISSING_RIGHT_CHEEK_OR_SUPPORTING_CONTOUR" }

        // --- CHIN + JAW: lower arc of FACE contour, split into center third (chin) / outer thirds (jaw) ---
        if (faceOutline.isNotEmpty() && mouth.isNotEmpty()) {
            val lowerLipY = mouth.maxOf { ny(it) }
            val lowerArc = faceOutline.filter { ny(it) > lowerLipY }
            if (lowerArc.size >= 3) {
                val arcLeft = minX(lowerArc); val arcRight = maxX(lowerArc); val arcBottom = maxY(lowerArc)
                val thirdWidth = (arcRight - arcLeft) / 3f
                val centerLeft = arcLeft + thirdWidth
                val centerRight = arcRight - thirdWidth
                regions += RegionPolygon(
                    AnatomicalRegion.CHIN,
                    quad(
                        pointAt(centerLeft, lowerLipY, geom), pointAt(centerRight, lowerLipY, geom),
                        pointAt(centerRight, arcBottom, geom), pointAt(centerLeft, arcBottom, geom)
                    ),
                    REGION_APPROXIMATION_CONFIDENCE * geom.geometryConfidence
                )
                val cheekTopY = (leftCheek + rightCheek).minOfOrNull { ny(it) } ?: lowerLipY
                regions += RegionPolygon(
                    AnatomicalRegion.JAW,
                    listOf(
                        pointAt(arcLeft, cheekTopY, geom), pointAt(centerLeft, cheekTopY, geom),
                        pointAt(centerLeft, arcBottom, geom), pointAt(arcLeft, arcBottom, geom),
                        pointAt(centerRight, arcBottom, geom), pointAt(centerRight, cheekTopY, geom),
                        pointAt(arcRight, cheekTopY, geom), pointAt(arcRight, arcBottom, geom)
                    ),
                    REGION_APPROXIMATION_CONFIDENCE * geom.geometryConfidence
                )
            } else {
                skipped += AnatomicalRegion.CHIN to "INSUFFICIENT_LOWER_FACE_OUTLINE_POINTS"
                skipped += AnatomicalRegion.JAW to "INSUFFICIENT_LOWER_FACE_OUTLINE_POINTS"
            }
        } else {
            skipped += AnatomicalRegion.CHIN to "MISSING_FACE_OUTLINE_OR_MOUTH_CONTOUR"
            skipped += AnatomicalRegion.JAW to "MISSING_FACE_OUTLINE_OR_MOUTH_CONTOUR"
        }

        // --- UNDER_EYE_LEFT / UNDER_EYE_RIGHT: thin band between eye-bottom and cheek-top on that side ---
        fun underEye(eyeContour: List<GeometryPoint>, cheekRegionPolygon: RegionPolygon?, region: AnatomicalRegion): RegionPolygon? {
            if (eyeContour.isEmpty() || cheekRegionPolygon == null) return null
            val eLeft = minX(eyeContour); val eRight = maxX(eyeContour); val eBottom = maxY(eyeContour)
            val cheekTop = cheekRegionPolygon.points.minOf { ny(it) }
            if (cheekTop <= eBottom) return null
            return RegionPolygon(
                region,
                quad(
                    pointAt(eLeft, eBottom, geom), pointAt(eRight, eBottom, geom),
                    pointAt(eRight, cheekTop, geom), pointAt(eLeft, cheekTop, geom)
                ),
                REGION_APPROXIMATION_CONFIDENCE * geom.geometryConfidence * 0.9 // thinnest, most approximate region
            )
        }
        underEye(leftEye, regions.firstOrNull { it.region == AnatomicalRegion.LEFT_CHEEK }, AnatomicalRegion.UNDER_EYE_LEFT)?.let { regions += it }
            ?: run { skipped += AnatomicalRegion.UNDER_EYE_LEFT to "MISSING_LEFT_EYE_CONTOUR_OR_LEFT_CHEEK_REGION" }
        underEye(rightEye, regions.firstOrNull { it.region == AnatomicalRegion.RIGHT_CHEEK }, AnatomicalRegion.UNDER_EYE_RIGHT)?.let { regions += it }
            ?: run { skipped += AnatomicalRegion.UNDER_EYE_RIGHT to "MISSING_RIGHT_EYE_CONTOUR_OR_RIGHT_CHEEK_REGION" }

        return RegionSet(regions, exclusions, skipped)
    }

    fun json(set: RegionSet): String {
        fun gp(p: GeometryPoint) = """{"nx":${p.normalizedX},"ny":${p.normalizedY},"ox":${p.originalX ?: "null"},"oy":${p.originalY ?: "null"}}"""
        val regionsJson = set.regions.joinToString(",") { r ->
            """{"region":"${r.region}","confidence":${r.confidence},"points":[${r.points.joinToString(",") { gp(it) }}]}"""
        }
        val exclusionsJson = set.exclusions.joinToString(",") { e ->
            """{"category":"${e.category}","reason":"${e.reason}","points":[${e.points.joinToString(",") { gp(it) }}]}"""
        }
        val skippedJson = set.skippedRegions.joinToString(",") { (r, reason) -> """{"region":"$r","reason":"$reason"}""" }
        return """{"method":"$VERSION","regions":[$regionsJson],"exclusions":[$exclusionsJson],"skipped_regions":[$skippedJson]}"""
    }
}
