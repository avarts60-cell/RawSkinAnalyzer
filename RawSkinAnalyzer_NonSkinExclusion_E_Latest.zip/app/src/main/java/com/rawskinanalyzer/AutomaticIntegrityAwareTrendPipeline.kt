package com.rawskinanalyzer

data class AutomaticIntegrityAwareTrendOutput<T>(
    val trendResult: T?,
    val integrityConfidence: IntegrityAwareTrendConfidenceResult,
    val integrityTelemetry: SkinSessionIntegrityTelemetry
)

object AutomaticIntegrityAwareTrendPipeline {

    fun <T> apply(
        trendResult: T?,
        existingConfidence: String,
        telemetry: SkinSessionIntegrityTelemetry
    ): AutomaticIntegrityAwareTrendOutput<T> {
        val confidence = IntegrityAwareTrendConfidencePolicy.evaluate(
            telemetry = telemetry,
            existingConfidence = existingConfidence
        )

        return AutomaticIntegrityAwareTrendOutput(
            trendResult = if (confidence.multiSessionTrendAllowed) trendResult else null,
            integrityConfidence = confidence,
            integrityTelemetry = telemetry
        )
    }

    fun telemetryFrom(store: SkinSessionStore): SkinSessionIntegrityTelemetry =
        when (store) {
            is PersistentSkinSessionStore -> store.lastIntegrityTelemetry
            else -> SkinSessionIntegrityTelemetry(
                status = SkinSessionIntegrityStatus.SESSION_DATA_VALID,
                validSessionCount = store.history().size,
                rejectedEntryCount = 0,
                recoveryApplied = false,
                safeHistoryAvailable = store.history().isNotEmpty()
            )
        }
}
