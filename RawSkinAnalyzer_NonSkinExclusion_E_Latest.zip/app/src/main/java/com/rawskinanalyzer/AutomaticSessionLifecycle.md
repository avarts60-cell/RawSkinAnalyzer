# Automatic Session Lifecycle Integration

Session saving now automatically invokes the configured retention policy.

Flow:
1. Save the completed analysis snapshot.
2. Apply analysis-version retention.
3. Apply maximum-session retention.
4. Persist the retained session set.
5. Return the lifecycle result.

A custom `SkinSessionRetentionPolicy` can be passed to `SkinSessionRepository.save()`.
