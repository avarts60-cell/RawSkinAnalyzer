package com.rawskinanalyzer

data class BlemishViewResult(
    val view:String,
    val skinCells:Int,
    val hotspotCount:Int,
    val candidatePercent:Double,
    val meanCandidateRedness:Double,
    val meanCandidateTexture:Double
)

data class BlemishFeatureAnalysisResult(
    val blemishLikeScore:Double,
    val blemishLikeLevel:String,
    val candidateCount:Int,
    val distribution:String,
    val repetition:String,
    val crossViewSupport:String,
    val confidence:String,
    val views:List<BlemishViewResult>
)

object BlemishFeatureAnalyzer {
    private fun std(values:List<Double>):Double {
        if(values.isEmpty()) return 0.0
        val mean=values.average()
        return kotlin.math.sqrt(values.sumOf { (it-mean)*(it-mean) }/values.size)
    }

    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_VISIBLE_BLEMISH_LIKE_SIGNAL"
        score>=30.0 -> "MODERATE_VISIBLE_BLEMISH_LIKE_SIGNAL"
        score>=12.0 -> "LOW_VISIBLE_BLEMISH_LIKE_SIGNAL"
        else -> "MINIMAL_VISIBLE_BLEMISH_LIKE_SIGNAL"
    }

    private fun analyzeView(name:String,cells:List<PatternMapCell>):BlemishViewResult {
        val skin=cells.filter { it.skinPercent>=10.0 }
        if(skin.isEmpty()) return BlemishViewResult(name,0,0,0.0,0.0,0.0)

        val redMean=skin.map { it.redness }.average()
        val redStd=std(skin.map { it.redness })
        val texMean=skin.map { it.texture }.average()
        val texStd=std(skin.map { it.texture })

        val candidates=skin.filter {
            it.redness >= redMean + redStd*0.5 &&
            it.texture >= texMean + texStd*0.25
        }
        val hotspots=PatternHotspotAnalyzer.analyze(cells)
        return BlemishViewResult(
            name,skin.size,hotspots.size,
            candidates.size*100.0/skin.size,
            if(candidates.isEmpty()) 0.0 else candidates.map { it.redness }.average(),
            if(candidates.isEmpty()) 0.0 else candidates.map { it.texture }.average()
        )
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):BlemishFeatureAnalysisResult {
        val localized=LocalizedFeatureAnalyzer.analyze(front,left,right)
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val views=listOf(
            analyzeView("FRONT_FACE",front),
            analyzeView("LEFT_CHEEK",left),
            analyzeView("RIGHT_CHEEK",right)
        ).filter { it.skinCells>0 }

        if(views.isEmpty()) return BlemishFeatureAnalysisResult(
            0.0,"INSUFFICIENT_BLEMISH_FEATURE_DATA",0,"INSUFFICIENT_DATA",
            "INSUFFICIENT_DATA","INSUFFICIENT_DATA","LOW",emptyList()
        )

        val candidatePercent=views.map { it.candidatePercent }.average()
        val hotspots=views.sumOf { it.hotspotCount }
        val repeatedBonus=when(localized.repeatedFeatureSignal) {
            "HIGH_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 30.0
            "MODERATE_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 18.0
            "LOW_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 8.0
            else -> 0.0
        }

        val score=SkinScoreCalibration.blemishLike(
            candidatePercent=candidatePercent,
            hotspotDensity=localized.hotspotDensity,
            repeatedFeatureBonus=repeatedBonus,
            localizedRedness=q.localizedRedness
        ).calibratedScore

        val activeViews=views.count { it.candidatePercent>=8.0 || it.hotspotCount>=2 }
        val distribution=when {
            activeViews>=3 -> "MULTI_VIEW_BLEMISH_LIKE_DISTRIBUTION"
            activeViews==2 -> "TWO_VIEW_BLEMISH_LIKE_DISTRIBUTION"
            activeViews==1 -> "LOCALIZED_BLEMISH_LIKE_DISTRIBUTION"
            else -> "LIMITED_BLEMISH_LIKE_DISTRIBUTION"
        }

        val repetition=when {
            hotspots>=8 || localized.repeatedFeatureSignal=="HIGH_REPEATED_LOCALIZED_FEATURE_SIGNAL" ->
                "HIGH_REPEATED_BLEMISH_LIKE_SIGNAL"
            hotspots>=3 || localized.repeatedFeatureSignal=="MODERATE_REPEATED_LOCALIZED_FEATURE_SIGNAL" ->
                "MODERATE_REPEATED_BLEMISH_LIKE_SIGNAL"
            hotspots>0 -> "LOW_REPEATED_BLEMISH_LIKE_SIGNAL"
            else -> "NO_STRONG_REPEATED_BLEMISH_LIKE_SIGNAL"
        }

        val support=when {
            activeViews>=3 -> "HIGH_CROSS_VIEW_BLEMISH_SUPPORT"
            activeViews==2 -> "MODERATE_CROSS_VIEW_BLEMISH_SUPPORT"
            activeViews==1 -> "LIMITED_CROSS_VIEW_BLEMISH_SUPPORT"
            else -> "NO_CROSS_VIEW_BLEMISH_SUPPORT"
        }

        val confidence=when {
            views.size==3 && activeViews>=2 && q.confidence=="HIGH" -> "HIGH"
            views.size>=2 -> "MODERATE"
            else -> "LOW"
        }

        return BlemishFeatureAnalysisResult(
            score,level(score),hotspots,distribution,repetition,support,confidence,views
        )
    }

    fun json(x:BlemishFeatureAnalysisResult):String {
        val views=x.views.joinToString(","){v ->
            """{"view":"${v.view}","skin_cells":${v.skinCells},"hotspot_count":${v.hotspotCount},"candidate_percent":${v.candidatePercent},"mean_candidate_redness":${v.meanCandidateRedness},"mean_candidate_texture":${v.meanCandidateTexture}}"""
        }
        return """{"blemish_like_score":${x.blemishLikeScore},"blemish_like_level":"${x.blemishLikeLevel}","candidate_count":${x.candidateCount},"distribution":"${x.distribution}","repetition":"${x.repetition}","cross_view_support":"${x.crossViewSupport}","confidence":"${x.confidence}","views":[$views],"method":"blemish_like_feature_analysis_v1","medical_diagnosis":false}"""
    }
}
