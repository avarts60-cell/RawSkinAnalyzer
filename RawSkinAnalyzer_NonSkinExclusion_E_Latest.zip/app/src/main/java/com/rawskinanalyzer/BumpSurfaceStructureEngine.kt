package com.rawskinanalyzer

import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * BumpSurfaceStructureEngine
 *
 * Batch 4D-F2, step_1 (P0). Dedicated bump-like / surface-structure evidence, built on the SAME
 * [SignalGrid] / [ConnectedComponentExtractor] architecture every other structural detector in
 * this project already uses (`FeatureCandidateDetectors`, `ShineDetectionEngine`) — no new tile
 * decode path, no new candidate model family beyond the [BumpCandidate] wrapper the same
 * dedicated-detection-pass rationale [ShineCandidate] already established.
 *
 * A bump/raised-structure reads, under the directional lighting a phone-camera capture has, as a
 * small compact area carrying its OWN internal highlight-to-shadow gradient (brighter on the
 * side facing the light, darker on the falloff side) rather than a uniform patch of either
 * darkness (a dark-mark/pigmentation candidate) or brightness (a shine candidate). That
 * highlight/shadow RELATIONSHIP — step_1's own listed signal — is exactly what distinguishes a
 * true 3D surface irregularity from either of those two flatter cases, and is exactly what this
 * engine measures instead of re-scoring darkness or brightness alone:
 *
 *  - local brightness profile / shadow-highlight relationship: [internalReliefContrast] — the
 *    actual luma split between the brighter and darker halves of the candidate's own cells
 *    (median-split, not a single global threshold), so a REAL internal gradient is required, not
 *    just "some bright cells and some dark cells anywhere in the tile".
 *  - gradient configuration / edge structure: elevated [SignalGrid.gradientMagnitude], plus
 *    [FeatureOrientationEngine]'s structure-tensor coherence reused here as "how consistently the
 *    relief gradient points in one direction across the shape" (a genuine raised structure has a
 *    single dominant relief axis; isotropic micro-texture noise does not).
 *  - shape: [GridComponent.circularity]/[GridComponent.elongation] — a bump is compact-to-oval,
 *    not a thin line (which is `FeatureCandidateDetectors`' hair/stubble territory) and not
 *    diffusely irregular.
 *  - surrounding skin: the same [VisualFeatureCandidateEngine.skinSupportFor] weighting every
 *    other structural candidate in this project already goes through.
 *  - "highlights are not automatically interpreted as bumps" (this step's own integration
 *    requirement): [ShineDetectionEngine.shineMask] is computed over the SAME grid and a
 *    candidate whose own cells are mostly inside that mask (a flat, uniformly bright/desaturated
 *    patch with no internal relief split of its own) is suppressed, not promoted — see
 *    [shineOverlapFraction] and its use in [confidenceFor]. A SMALL partial shine overlap (a
 *    highlight sitting at one edge of a real relief gradient, which is physically what a bump's
 *    apex highlight looks like) is treated as mild corroborating evidence instead.
 */
object BumpSurfaceStructureEngine {
    const val VERSION = "bump_surface_structure_engine_v1"

    private const val VARIANCE_ELEVATION_MULTIPLIER = 1.3
    private const val GRADIENT_STD_MULTIPLIER = 0.9
    private const val MIN_COMPONENT_AREA_CELLS = 2

    private fun clamp01(v: Double) = max(0.0, min(1.0, v))

    private fun maxComponentArea(totalCells: Int) = max(MIN_COMPONENT_AREA_CELLS + 1, (totalCells * 0.3).toInt())

    /** A candidate cell for surface relief: textured (variance-elevated) AND edge-bearing
     * (gradient-elevated), while excluding cells already far into either extreme darkness (dark
     * mark / pigmentation territory) or extreme red shift (redness territory) — this keeps this
     * detector's mask from overlapping wholesale with `FeatureCandidateDetectors`' own dark/redness
     * cells, consistent with this project's "don't create duplicate classifiers" rule; some overlap
     * at the margins is expected and resolved downstream via shared candidate IDs never colliding
     * (bump candidates carry their own `_bump` id suffix) rather than by a false claim of exclusivity. */
    fun structureMask(grid: SignalGrid): Array<BooleanArray> {
        val meanVariance = run {
            var s = 0.0; var n = 0
            for (r in 0 until grid.rows) for (c in 0 until grid.cols) { s += grid.localVariance[r][c]; n++ }
            if (n > 0) s / n else 0.0
        }
        val darkThreshold = grid.regionMeanLuma - 1.4 * grid.regionLumaStdDev
        val gradientThreshold = grid.regionLumaStdDev * GRADIENT_STD_MULTIPLIER
        val mask = Array(grid.rows) { BooleanArray(grid.cols) }
        for (r in 0 until grid.rows) {
            for (c in 0 until grid.cols) {
                val isTextured = grid.localVariance[r][c] > meanVariance * VARIANCE_ELEVATION_MULTIPLIER
                val hasEdge = grid.gradientMagnitude[r][c] > gradientThreshold
                val notDeeplyDark = grid.luma[r][c] > darkThreshold
                val notRedShifted = grid.cr[r][c] < grid.regionMeanCr + 10.0
                mask[r][c] = isTextured && hasEdge && notDeeplyDark && notRedShifted
            }
        }
        return mask
    }

    fun components(grid: SignalGrid): List<GridComponent> {
        val mask = structureMask(grid)
        val total = grid.rows * grid.cols
        return ConnectedComponentExtractor.extract(mask, grid.rows, grid.cols, MIN_COMPONENT_AREA_CELLS, maxComponentArea(total))
    }

    private fun boundingBoxOriginal(grid: SignalGrid, comp: GridComponent): IntArray {
        val topLeft = grid.cellToOriginalBox(comp.minRow, comp.minCol)
        val bottomRight = grid.cellToOriginalBox(comp.maxRow, comp.maxCol)
        val x = topLeft[0]; val y = topLeft[1]
        val width = max(1, bottomRight[2] - topLeft[0])
        val height = max(1, bottomRight[3] - topLeft[1])
        return intArrayOf(x, y, width, height)
    }

    /** Median-split internal relief contrast: sorts the component's own cell luma values, splits
     * at the median, and returns (bright-half mean - dark-half mean) normalized by the region's
     * own luma std-dev. This is a real per-candidate measurement, not a fixed global threshold. */
    private fun internalReliefContrast(grid: SignalGrid, comp: GridComponent): Double {
        val lumas = comp.cells.map { (r, c) -> grid.luma[r][c] }.sorted()
        if (lumas.size < 2) return 0.0
        val mid = lumas.size / 2
        val darkHalf = lumas.subList(0, mid)
        val brightHalf = lumas.subList(mid, lumas.size)
        val darkMean = darkHalf.average()
        val brightMean = brightHalf.average()
        val denom = if (grid.regionLumaStdDev > 0.01) grid.regionLumaStdDev * 2.5 else 25.0
        return clamp01((brightMean - darkMean) / denom)
    }

    private fun shineOverlapFraction(comp: GridComponent, shineMask: Array<BooleanArray>): Double {
        if (comp.cells.isEmpty()) return 0.0
        var inShine = 0
        for ((r, c) in comp.cells) if (shineMask[r][c]) inShine++
        return inShine.toDouble() / comp.cells.size
    }

    private fun confidenceFor(
        internalRelief: Double, coherence: Double, compactness: Double, elongation: Double,
        gradientLevel: Double, shineOverlap: Double, skinWeight: Double
    ): Pair<Double, List<String>> {
        val reasons = mutableListOf<String>()
        // Moderate elongation is fine (a bump isn't a perfect circle) but high elongation drifts
        // toward hair/scratch territory, which this project already has dedicated detectors for.
        val shapeFactor = clamp01(1.0 - max(0.0, elongation - 2.0) / 4.0)
        if (internalRelief > 0.35) reasons.add("internal highlight/shadow luma split (relief contrast=${"%.2f".format(internalRelief)})")
        if (coherence > 0.35) reasons.add("consistent single relief-gradient axis (coherence=${"%.2f".format(coherence)})")
        if (compactness > 0.4) reasons.add("compact-to-oval shape consistent with a raised structure")
        if (gradientLevel > 0.4) reasons.add("elevated local edge structure at the candidate boundary")

        var conf = clamp01(
            0.40 * internalRelief + 0.25 * coherence + 0.15 * compactness + 0.20 * gradientLevel
        ) * shapeFactor * skinWeight

        // Shine handling per step_1's own "highlights are not automatically interpreted as bumps"
        // integration requirement: heavy overlap with NO internal relief of its own is almost
        // certainly a flat highlight, not a bump, and is suppressed hard. A SMALL overlap
        // alongside real internal relief (a highlight sitting at one edge of an otherwise-real
        // gradient, physically consistent with a bump's lit apex) is treated as mild corroboration
        // instead of contamination.
        if (shineOverlap > 0.6 && internalRelief < 0.3) {
            conf *= (1.0 - 0.7 * shineOverlap)
            reasons.add("mostly overlaps a flat shine/highlight region without its own internal relief; likely a highlight, not a bump")
        } else if (shineOverlap in 0.05..0.4 && internalRelief >= 0.35) {
            conf = clamp01(conf * 1.1)
            reasons.add("small corroborating highlight near one edge of the relief gradient")
        }

        if (reasons.isEmpty()) reasons.add("below bump/surface-structure confidence threshold")
        return clamp01(conf) to reasons
    }

    /**
     * [boundaryContext], added Batch 4E-D step_3, mirrors [ShineDetectionEngine.analyzeRegion]'s
     * own addition of the same name/contract — optional, defaulted to null so every existing
     * caller/test keeps compiling and keeps its exact prior output. See that function's doc
     * comment and [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport] for the full rationale;
     * not repeated here to avoid drift between the two copies of the same explanation.
     */
    fun analyzeRegion(
        originalFile: File,
        tileSet: MultiScaleTileSet,
        boundaryContext: VisualFeatureCandidateEngine.CandidateBoundaryContext? = null
    ): List<BumpCandidate> {
        val out = mutableListOf<BumpCandidate>()
        var seq = 0
        for (tile in VisualFeatureCandidateEngine.selectTiles(tileSet)) {
            val grid = try { VisualSignalGridExtractor.build(originalFile, tile) } catch (e: Exception) { null } ?: continue
            val skinSupport = VisualFeatureCandidateEngine.skinSupportFor(tile)
            if (skinSupport.skinWeight <= 0.02) continue

            val comps = components(grid)
            if (comps.isEmpty()) continue
            val shineMask = ShineDetectionEngine.shineMask(grid)

            for (comp in comps) {
                val internalRelief = internalReliefContrast(grid, comp)
                val orientation = FeatureOrientationEngine.estimate(grid, comp.cells)
                var sg = 0.0
                for ((r, c) in comp.cells) sg += grid.gradientMagnitude[r][c]
                val meanGradient = sg / max(1, comp.cells.size)
                val gradientLevel = clamp01(meanGradient / max(1.0, grid.regionLumaStdDev * 2.0))
                val shineOverlap = shineOverlapFraction(comp, shineMask)

                val (confidence, reasons) = confidenceFor(
                    internalRelief, orientation.coherence, comp.circularity, comp.elongation,
                    gradientLevel, shineOverlap, skinSupport.skinWeight
                )

                val primaryType = when {
                    confidence >= 0.5 -> SpecializedFeatureType.BUMP_LIKE
                    confidence >= 0.3 -> SpecializedFeatureType.SURFACE_STRUCTURE_LIKE
                    else -> SpecializedFeatureType.UNCERTAIN_SURFACE_STRUCTURE
                }

                val box = boundingBoxOriginal(grid, comp)
                // Batch 4E-D, step_3: same additive candidate-own-footprint refinement as
                // ShineDetectionEngine.analyzeRegion — see that function's doc comment.
                val refinement = boundaryContext?.let {
                    FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
                        originalBoundingBox = box, cells = it.cells, grid = it.patternGrid,
                        normalizedImageWidth = it.geom.normalizedImageWidth,
                        normalizedImageHeight = it.geom.normalizedImageHeight,
                        geom = it.geom,
                        // Batch 4E-E, step_3: same landmark-exclusion-polygon reuse as
                        // ShineDetectionEngine.analyzeRegion / VisualFeatureCandidateEngine.analyzeRegion.
                        landmarkExclusionPolygons = it.regionSet?.exclusions?.map { ex -> ex.points } ?: emptyList()
                    )
                }
                out.add(
                    BumpCandidate(
                        candidateId = "${tile.view}_${tile.region}_${tile.tileId}_bump${seq++}",
                        view = tile.view, region = tile.region, tileId = tile.tileId, scale = tile.scale,
                        boundingBox = box, centroidX = box[0] + box[2] / 2, centroidY = box[1] + box[3] / 2,
                        areaPixels = comp.area * grid.cellSourcePixels * grid.cellSourcePixels,
                        primaryType = primaryType,
                        internalReliefContrast = internalRelief,
                        reliefAxisCoherence = orientation.coherence,
                        compactness = comp.circularity,
                        elongation = comp.elongation,
                        shineOverlapFraction = shineOverlap,
                        skinConfidence = skinSupport.skinConfidenceAtLocation,
                        confidence = confidence,
                        evidenceReasons = reasons,
                        boundarySkinConfidenceAtLocation = refinement?.skinCoverage,
                        boundaryHighConfidenceSkinFraction = refinement?.let {
                            if (it.skinCoverage > 0) (it.highConfidenceSkinCoverage / it.skinCoverage).coerceIn(0.0, 1.0) else 0.0
                        },
                        boundaryExclusionOverlap = refinement?.excludedCoverage,
                        boundaryCellsOverlapped = refinement?.cellsOverlapped
                    )
                )
            }
        }
        return out
    }

    fun analyzeView(
        originalFile: File,
        tileSets: List<MultiScaleTileSet>,
        boundaryContext: VisualFeatureCandidateEngine.CandidateBoundaryContext? = null
    ): List<BumpCandidate> =
        tileSets.flatMap { analyzeRegion(originalFile, it, boundaryContext) }

    fun regionalSummary(view: String, tileSet: MultiScaleTileSet, candidates: List<BumpCandidate>): RegionalBumpSummary {
        val sampledCellsProxy = max(1, candidates.size + (tileSet.microTiles.size * 25))
        val density = (candidates.size.toDouble() / sampledCellsProxy) * 1000.0
        // Batch 4E-A: real usable-skin-area basis alongside the legacy proxy above.
        val usableArea = UsableSkinAreaCalculator.forRegion(view, tileSet)
        return RegionalBumpSummary(
            view = view, region = tileSet.region,
            regionSkinCoverage = tileSet.regionSkinCoverage,
            candidateCount = candidates.size,
            totalAreaPixels = candidates.sumOf { it.areaPixels.toLong() },
            meanInternalReliefContrast = if (candidates.isEmpty()) 0.0 else candidates.map { it.internalReliefContrast }.average(),
            meanConfidence = if (candidates.isEmpty()) 0.0 else candidates.map { it.confidence }.average(),
            densityPer1000Cells = density,
            usableSkinAreaPixels = usableArea.usableSkinAreaPixels,
            areaBasis = usableArea.areaBasis,
            densityPerMillionUsableSkinPixels = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidates.size, usableArea.usableSkinAreaPixels)
        )
    }

    fun json(candidates: List<BumpCandidate>, summaries: List<RegionalBumpSummary>): String {
        val candJson = candidates.joinToString(",") { SpecializedFeatureJson.bumpCandidateJson(it) }
        val sumJson = summaries.joinToString(",") { SpecializedFeatureJson.regionalBumpSummaryJson(it) }
        return """{"method":"$VERSION","candidate_count":${candidates.size},"candidates":[$candJson],"regional_summaries":[$sumJson]}"""
    }
}
