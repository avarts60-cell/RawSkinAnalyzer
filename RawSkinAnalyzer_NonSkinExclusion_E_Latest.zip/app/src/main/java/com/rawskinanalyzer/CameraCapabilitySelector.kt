package com.rawskinanalyzer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build

data class CameraCapability(
    val cameraId: String,
    val lensFacing: Int?,
    val supportsRaw: Boolean,
    val supportsBackwardCompatible: Boolean,
    val hardwareLevel: Int?
)

data class CameraSelection(
    val selected: CameraCapability?,
    val rawCapable: Boolean,
    val reason: String
)

object CameraCapabilitySelector {
    fun inventory(context: Context): List<CameraCapability> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return emptyList()
        val manager=context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return manager.cameraIdList.map { id ->
            val c=manager.getCameraCharacteristics(id)
            val caps=c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
            CameraCapability(
                cameraId=id,
                lensFacing=c.get(CameraCharacteristics.LENS_FACING),
                supportsRaw=caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW),
                supportsBackwardCompatible=caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE),
                hardwareLevel=c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)
            )
        }
    }

    fun select(context: Context, desiredFacing: Int): CameraSelection {
        val candidates=inventory(context).filter {
            it.lensFacing==desiredFacing && it.supportsBackwardCompatible
        }
        val raw=candidates.firstOrNull { it.supportsRaw }
        if (raw!=null) return CameraSelection(raw,true,"FACING_AND_RAW_CAPABLE")
        val fallback=candidates.firstOrNull()
        return if (fallback!=null)
            CameraSelection(fallback,false,"FACING_AVAILABLE_RAW_UNSUPPORTED")
        else CameraSelection(null,false,"NO_COMPATIBLE_CAMERA_FOR_REQUESTED_FACING")
    }

    fun hasCameraPermission(context: Context)=
        context.checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED
}
