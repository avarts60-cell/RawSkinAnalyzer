package com.rawskinanalyzer

/**
 * BATCH 4E-B, step_5 — CANDIDATE QUALITY GATE.
 *
 * Deferred explicitly in Batch 4E-A's own "Exact next implementation step," and this batch's own
 * `step_5_candidate_quality_gate` requirement. Reads already-computed per-candidate signals
 * ([VisualFeatureCandidate.skinSupport], [VisualFeatureCandidate.candidateConfidence],
 * [SpecializedFeatureEvidence.classificationState], [SpecializedFeatureEvidence.scale]) and
 * produces a quality decision SEPARATE from the raw evidence — it never deletes or mutates a
 * [SpecializedFeatureEvidence]/[VisualFeatureCandidate], only classifies it.
 *
 * Inputs this batch's handoff asked for, and what actually backs each one in this codebase today:
 * - skin confidence      -> `skinSupport.skinConfidenceAtLocation` (real)
 * - exclusion overlap     -> `skinSupport.exclusionOverlap` (real)
 * - candidate confidence  -> `candidateConfidence` / `evidence.primaryConfidence` (real)
 * - scale support         -> `evidence.scale` alone (MACRO/MESO/MICRO) — a weak proxy only, since
 *   step_4 (real multi-scale agreement across MACRO/MESO/MICRO) is NOT_DONE this batch. This gate
 *   never rejects solely for being MICRO-only, per this batch's own step_4 rule ("do not discard
 *   valid MICRO-only features merely because they lack MESO/MACRO confirmation") applied here too
 *   — MICRO-only only ever costs a small WEIGHT reduction, never a REJECT.
 * - geometry confidence   -> `skinSupport.boundarySkinConfidenceAtLocation`/`boundaryExclusionOverlap`
 *   when available (Batch 4E-C, step_2: candidate-own-footprint overlap against the
 *   [PatternMapCell] grid, computed by [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport]),
 *   falling back to the coarser whole-tile-aggregate `skinConfidenceAtLocation`/`exclusionOverlap`
 *   when it is not (candidate absent, or boundary refinement not supplied/computable for that
 *   candidate — e.g. no original-image scale relationship for that view). Never fabricated:
 *   absence of either basis is recorded in the decision reasons, not silently defaulted.
 * - local signal quality  -> `morphology.localContrast`/`edgeStrength`, a real but heuristic proxy
 *   (documented, not claimed as calibrated).
 * - capture quality       -> [CaptureQualityReliability] (already built in
 *   `CaptureQualityReliabilityGate`, Batch 3B) — reused here rather than duplicated.
 *
 * Per-feature-type semantics differ deliberately: `LOCALIZED_CONCERN` types (blemish/dark-mark/
 * redness family) require higher skin-confidence and lower exclusion-overlap to ACCEPT than
 * `STRUCTURAL` types (pore/follicular/hair/stubble), because a false-positive localized concern
 * has more downstream weight (it feeds a user-facing skin-concern score) than a missed/extra pore
 * candidate, per this batch's own "do not use one universal threshold when feature-specific
 * semantics require different handling."
 */

enum class CandidateQualityStatus { ACCEPT, WEIGHT, REJECT, INSUFFICIENT_DATA }

data class CandidateQualityDecision(
    val status: CandidateQualityStatus,
    /** 0.0-1.0 multiplier meant to be applied on top of whatever confidence/count a downstream
     * consumer already computed. Never used to INCREASE a confidence value — only to scale it
     * down or leave it unchanged (1.0), per "ensure the gate cannot increase confidence beyond
     * the underlying evidence." */
    val weight: Double,
    val reasons: List<String>
)

private enum class QualityFeatureClass { STRUCTURAL, LOCALIZED_CONCERN }

object CandidateQualityGate {
    const val VERSION = "CANDIDATE_QUALITY_GATE_V1"

    private fun classOf(type: SpecializedFeatureType): QualityFeatureClass = when (type) {
        SpecializedFeatureType.PORE_LIKE, SpecializedFeatureType.FOLLICULAR_OPENING_LIKE,
        SpecializedFeatureType.HAIR_LIKE, SpecializedFeatureType.STUBBLE_LIKE ->
            QualityFeatureClass.STRUCTURAL
        else -> QualityFeatureClass.LOCALIZED_CONCERN
    }

    // Thresholds are deliberately per-class, not universal (see class doc). These are engineering
    // starting points, consistent with every other heuristic threshold in this project — not
    // derived from a labeled dataset, since none exists here.
    private data class Thresholds(
        val rejectExclusionOverlapAbove: Double,
        val rejectSkinConfidenceBelow: Double,
        val acceptSkinConfidenceAtLeast: Double,
        val acceptExclusionOverlapAtMost: Double
    )

    private val thresholdsByClass = mapOf(
        QualityFeatureClass.STRUCTURAL to Thresholds(
            rejectExclusionOverlapAbove = 70.0, rejectSkinConfidenceBelow = 15.0,
            acceptSkinConfidenceAtLeast = 45.0, acceptExclusionOverlapAtMost = 25.0
        ),
        QualityFeatureClass.LOCALIZED_CONCERN to Thresholds(
            rejectExclusionOverlapAbove = 55.0, rejectSkinConfidenceBelow = 25.0,
            acceptSkinConfidenceAtLeast = 60.0, acceptExclusionOverlapAtMost = 15.0
        )
    )

    /**
     * Evaluates a single candidate. [candidate] is optional: when it is not available to the
     * caller (an evidence record whose originating [VisualFeatureCandidate] was not kept in
     * scope), this never fabricates skin-confidence/exclusion-overlap/candidate-confidence —
     * it falls back to [SpecializedFeatureEvidence]'s own `skinConfidence`/`primaryConfidence`
     * (still real, just coarser) and returns INSUFFICIENT_DATA rather than ACCEPT whenever the
     * evidence alone is not decisive, since exclusion overlap in particular cannot be recovered
     * from [SpecializedFeatureEvidence] alone.
     */
    fun evaluate(
        evidence: SpecializedFeatureEvidence,
        candidate: VisualFeatureCandidate?,
        captureQuality: CaptureQualityReliability = CaptureQualityReliability.RELIABLE
    ): CandidateQualityDecision {
        val t = thresholdsByClass.getValue(classOf(evidence.featureType))
        val reasons = mutableListOf<String>()

        val skinConfidence = candidate?.skinSupport?.boundarySkinConfidenceAtLocation
            ?: candidate?.skinSupport?.skinConfidenceAtLocation ?: evidence.skinConfidence
        val exclusionOverlap = candidate?.skinSupport?.boundaryExclusionOverlap
            ?: candidate?.skinSupport?.exclusionOverlap
        val candidateConfidence = candidate?.candidateConfidence ?: evidence.primaryConfidence
        val usedBoundaryGeometry = candidate?.skinSupport?.boundarySkinConfidenceAtLocation != null

        if (candidate == null) reasons.add("no_originating_candidate_available: exclusion_overlap and geometry-based signals could not be checked")
        // Batch 4E-C, step_2: boundary-precision geometry confidence is now wired in when the
        // originating candidate carries it (see CandidateSkinSupport.boundarySkinConfidenceAtLocation
        // / FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport) — this reason line now
        // records which basis (candidate-own-footprint vs whole-tile-aggregate) actually drove
        // skinConfidence/exclusionOverlap above, rather than always declaring it absent.
        if (usedBoundaryGeometry) {
            reasons.add("boundary_geometry_confidence_available (candidate-own-footprint overlap, ${candidate?.skinSupport?.boundaryCellsOverlapped ?: 0} cell(s) sampled)")
            // Batch 4E-E, step_5: record the exclusion BASIS, not just the number — a caller
            // reading only "exclusion_overlap_dominant (72% > ...)" cannot tell a shadow/highlight
            // candidate from one sitting on an eyebrow; this makes that distinction explicit,
            // per this batch's own "store the exclusion basis in the quality decision" requirement.
            val landmarkOverlap = candidate?.skinSupport?.boundaryLandmarkExclusionOverlap
            if (landmarkOverlap != null && landmarkOverlap > 0.0) {
                reasons.add("landmark_exclusion_contribution (${"%.0f".format(landmarkOverlap)}% of this candidate's own footprint overlaps a landmark-derived exclusion region — eyes/eyebrows/lips/approximate-nostril-band/outside-face)")
            }
        } else {
            reasons.add("no_boundary_geometry_confidence_available: using whole-tile-aggregate skin support (candidate absent, or boundary refinement not supplied/computable for this candidate)")
        }

        // --- REJECT: contradictory or clearly unreliable evidence, judged not merely unknown ---
        if (exclusionOverlap != null && exclusionOverlap > t.rejectExclusionOverlapAbove) {
            reasons.add("exclusion_overlap_dominant (${"%.0f".format(exclusionOverlap)}% > ${t.rejectExclusionOverlapAbove}% threshold for ${classOf(evidence.featureType)})")
            return CandidateQualityDecision(CandidateQualityStatus.REJECT, 0.0, reasons)
        }
        if (skinConfidence < t.rejectSkinConfidenceBelow) {
            reasons.add("skin_confidence_below_reject_floor (${"%.0f".format(skinConfidence)} < ${t.rejectSkinConfidenceBelow})")
            return CandidateQualityDecision(CandidateQualityStatus.REJECT, 0.0, reasons)
        }
        if (evidence.classificationState == FeatureClassificationState.UNCERTAIN && candidateConfidence < 0.2) {
            reasons.add("uncertain_classification_with_very_low_candidate_confidence")
            return CandidateQualityDecision(CandidateQualityStatus.REJECT, 0.0, reasons)
        }

        // --- INSUFFICIENT_DATA: not enough signal to judge either way, distinct from a genuine reject ---
        if (candidate == null && evidence.classificationState != FeatureClassificationState.SUPPORTED) {
            reasons.add("insufficient_data_without_originating_candidate")
            return CandidateQualityDecision(CandidateQualityStatus.INSUFFICIENT_DATA, 0.5, reasons)
        }

        // --- ACCEPT: strong evidence on every available axis ---
        val exclusionOk = exclusionOverlap == null || exclusionOverlap <= t.acceptExclusionOverlapAtMost
        val isMicroOnly = evidence.scale == AnalysisScale.MICRO
        if (
            evidence.classificationState == FeatureClassificationState.SUPPORTED &&
            skinConfidence >= t.acceptSkinConfidenceAtLeast &&
            exclusionOk &&
            !isMicroOnly &&
            captureQuality == CaptureQualityReliability.RELIABLE
        ) {
            reasons.add("supported_classification_with_strong_skin_confidence_and_low_exclusion")
            return CandidateQualityDecision(CandidateQualityStatus.ACCEPT, 1.0, reasons)
        }

        // --- WEIGHT: real, usable evidence, but with reasons to trust it a little less. Every
        // factor below only ever multiplies weight downward from 1.0 -- it can never increase it. ---
        var weight = 1.0
        if (evidence.classificationState == FeatureClassificationState.PARTIALLY_SUPPORTED) {
            weight *= 0.75; reasons.add("partially_supported_classification")
        } else if (evidence.classificationState == FeatureClassificationState.UNCERTAIN) {
            weight *= 0.4; reasons.add("uncertain_classification")
        }
        if (isMicroOnly) {
            // Per step_4's own rule: MICRO-only is real evidence, not a rejection reason -- it
            // simply carries a smaller weight until (a future batch's) real MACRO/MESO agreement
            // check can confirm or contradict it.
            weight *= 0.85; reasons.add("micro_only_scale_no_larger_scale_confirmation_available")
        }
        if (skinConfidence < t.acceptSkinConfidenceAtLeast) {
            weight *= 0.8; reasons.add("skin_confidence_below_accept_bar_but_above_reject_floor")
        }
        if (exclusionOverlap != null && exclusionOverlap > t.acceptExclusionOverlapAtMost) {
            weight *= (1.0 - (exclusionOverlap / 100.0) * 0.5)
            reasons.add("partial_exclusion_overlap (${"%.0f".format(exclusionOverlap)}%)")
        }
        when (captureQuality) {
            CaptureQualityReliability.REDUCED -> { weight *= 0.85; reasons.add("reduced_capture_quality_this_session") }
            CaptureQualityReliability.LOW -> { weight *= 0.6; reasons.add("low_capture_quality_this_session") }
            CaptureQualityReliability.RELIABLE -> {}
        }
        weight = weight.coerceIn(0.0, 1.0)

        return CandidateQualityDecision(CandidateQualityStatus.WEIGHT, weight, reasons)
    }

    /** Convenience batch form: evaluates every evidence item, looking its originating candidate up by candidateId. Never drops an entry -- returns exactly one decision per input evidence item, keyed by candidateId. */
    fun evaluateAll(
        evidenceList: List<SpecializedFeatureEvidence>,
        candidatesById: Map<String, VisualFeatureCandidate>,
        captureQuality: CaptureQualityReliability = CaptureQualityReliability.RELIABLE
    ): Map<String, CandidateQualityDecision> =
        evidenceList.associate { it.candidateId to evaluate(it, candidatesById[it.candidateId], captureQuality) }
}
