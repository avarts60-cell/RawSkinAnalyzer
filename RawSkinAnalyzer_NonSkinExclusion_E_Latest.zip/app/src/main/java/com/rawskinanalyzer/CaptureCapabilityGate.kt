package com.rawskinanalyzer

import android.content.Context
import android.hardware.camera2.CameraCharacteristics

data class CaptureCapabilityDecision(
    val cameraId: String?,
    val jpegAllowed: Boolean,
    val rawRequired: Boolean,
    val rawAllowed: Boolean,
    val reason: String
)

object CaptureCapabilityGate {
    fun resolveRear(context: Context, requireRaw: Boolean = true): CaptureCapabilityDecision {
        val selection=CameraCapabilitySelector.select(
            context,
            CameraCharacteristics.LENS_FACING_BACK
        )
        val selected=selection.selected
        if (selected==null) {
            return CaptureCapabilityDecision(
                null, false, requireRaw, false,
                "NO_COMPATIBLE_REAR_CAMERA"
            )
        }
        if (requireRaw && !selection.rawCapable) {
            return CaptureCapabilityDecision(
                selected.cameraId, true, true, false,
                "RAW_REQUIRED_BUT_UNSUPPORTED"
            )
        }
        return CaptureCapabilityDecision(
            selected.cameraId, true, requireRaw, selection.rawCapable,
            if (selection.rawCapable) "REAR_RAW_CAPTURE_SUPPORTED"
            else "REAR_JPEG_CAPTURE_ONLY"
        )
    }
}
