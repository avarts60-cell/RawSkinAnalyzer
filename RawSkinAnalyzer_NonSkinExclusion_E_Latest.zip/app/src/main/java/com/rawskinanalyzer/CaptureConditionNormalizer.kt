package com.rawskinanalyzer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.roundToInt

/**
 * Applies a single, conservative, uniform brightness gain to a *derived analysis copy* of a
 * capture — never to the original evidence (capture.dng / capture.jpg), and never to
 * `analysis_normalized.jpg` (which other analyzers already depend on and which remains an
 * untouched, resized-only copy).
 *
 * What this deliberately does NOT do, by design:
 *  - No per-channel color grading / white-balance correction of skin pixels.
 *  - No smoothing, blurring, blemish removal, or any texture alteration.
 *  - No change to skin tone beyond a flat exposure (brightness) gain applied equally to R/G/B.
 *  - No write when the measured condition is already close to the target (skip threshold),
 *    so well-lit captures are left byte-for-byte alone.
 *
 * This is exposure leveling for *measurement comparability* across the three required views,
 * not cosmetic enhancement. It is intentionally conservative: the gain is clamped and a single
 * scalar, and the output is an additional file alongside the existing normalized copy rather
 * than a replacement, so no existing downstream analyzer's input changes as a side effect of
 * adding this layer.
 */
object CaptureConditionNormalizer {
    private const val SKIP_IF_GAIN_WITHIN = 0.06

    /**
     * Writes an exposure-leveled copy of [source] to [destination] using [profile]'s
     * suggestedExposureGain. Returns false (and writes nothing) if the gain is negligible or
     * the source can't be decoded, so this never introduces an unnecessary alteration.
     */
    fun writeExposureNormalizedCopy(
        source: File,
        destination: File,
        profile: CaptureConditionProfile
    ): Boolean {
        val gain = profile.suggestedExposureGain
        if (kotlin.math.abs(gain - 1.0) < SKIP_IF_GAIN_WITHIN) return false

        val bitmap = BitmapFactory.decodeFile(source.absolutePath) ?: return false
        val out = try {
            Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            bitmap.recycle()
            return false
        }

        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        for (i in pixels.indices) {
            val p = pixels[i]
            val a = (p shr 24) and 0xff
            val r = clamp255(((p shr 16) and 0xff) * gain)
            val g = clamp255(((p shr 8) and 0xff) * gain)
            val b = clamp255((p and 0xff) * gain)
            pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        out.setPixels(pixels, 0, out.width, 0, 0, out.width, out.height)
        bitmap.recycle()

        val written = try {
            destination.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            destination.exists() && destination.length() > 0
        } catch (e: Exception) {
            false
        } finally {
            out.recycle()
        }
        return written
    }

    private fun clamp255(v: Double): Int = v.roundToInt().coerceIn(0, 255)
}
