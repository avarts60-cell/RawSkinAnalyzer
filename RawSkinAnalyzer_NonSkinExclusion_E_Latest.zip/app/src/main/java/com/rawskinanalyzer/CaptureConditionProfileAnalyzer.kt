package com.rawskinanalyzer

import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * A structural, read-only description of the lighting / white-balance conditions a single
 * view was captured under. This never modifies pixels — it only measures them. It exists so
 * that lighting differences between the three required views (FRONT / LEFT_CHEEK /
 * RIGHT_CHEEK) can be represented, compared, and flagged, instead of silently affecting
 * downstream skin-tone/redness/pigmentation readings with no record of why.
 */
data class CaptureConditionProfile(
    val view: String,
    val meanLuma: Double,
    val meanR: Double,
    val meanG: Double,
    val meanB: Double,
    val rgRatio: Double,
    val bgRatio: Double,
    val colorCastMagnitude: Double,
    val dynamicRange: Double,
    val illuminantEstimate: String,
    /**
     * A conservative, clamped scalar (target mid-gray luma / measured mean luma) that a
     * normalization step could apply as a uniform brightness gain to make this view more
     * comparable to the others. This field is descriptive only — computing it does not alter
     * the source image. See [CaptureConditionNormalizer] for the one place this gain is
     * actually applied, and only to a derived analysis copy, never to original evidence.
     */
    val suggestedExposureGain: Double,
    val warnings: List<String>
)

object CaptureConditionProfileAnalyzer {
    private const val TARGET_MID_LUMA = 128.0
    private const val MIN_GAIN = 0.75
    private const val MAX_GAIN = 1.35

    fun analyze(view: String, file: File): CaptureConditionProfile {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            ?: throw IllegalArgumentException("Image decode failed for capture-condition analysis")

        val step = max(1, max(bitmap.width, bitmap.height) / 400)
        var count = 0
        var sumL = 0.0; var sumLSq = 0.0
        var sumR = 0.0; var sumG = 0.0; var sumB = 0.0

        for (y in 0 until bitmap.height step step) {
            for (x in 0 until bitmap.width step step) {
                val p = bitmap.getPixel(x, y)
                val r = (p shr 16) and 0xff
                val g = (p shr 8) and 0xff
                val b = p and 0xff
                val l = 0.2126 * r + 0.7152 * g + 0.0722 * b
                sumL += l; sumLSq += l * l
                sumR += r; sumG += g; sumB += b
                count++
            }
        }
        bitmap.recycle()

        val meanLuma = if (count == 0) 0.0 else sumL / count
        val variance = max(0.0, (if (count == 0) 0.0 else sumLSq / count) - meanLuma * meanLuma)
        val dynamicRange = sqrt(variance)
        val meanR = if (count == 0) 0.0 else sumR / count
        val meanG = if (count == 0) 0.0 else sumG / count
        val meanB = if (count == 0) 0.0 else sumB / count

        // Gray-world style ratios: under neutral lighting, R/G/B channel means of a mixed
        // scene tend toward each other. Large deviation suggests a color cast from the light
        // source rather than the subject itself.
        val rgRatio = if (meanG > 0.0) meanR / meanG else 1.0
        val bgRatio = if (meanG > 0.0) meanB / meanG else 1.0
        val colorCastMagnitude = max(abs(rgRatio - 1.0), abs(bgRatio - 1.0))

        val illuminantEstimate = when {
            bgRatio - rgRatio > 0.12 -> "LIKELY_COOL_OR_BLUE_SHIFTED"
            rgRatio - bgRatio > 0.12 -> "LIKELY_WARM_OR_ORANGE_SHIFTED"
            else -> "NEUTRAL_ESTIMATE"
        }

        val warnings = mutableListOf<String>()
        if (meanLuma < 45.0) warnings += "LOW_LIGHT"
        if (meanLuma > 220.0) warnings += "OVEREXPOSED"
        if (dynamicRange < 18.0) warnings += "LOW_DYNAMIC_RANGE"
        if (colorCastMagnitude > 0.20) warnings += "STRONG_COLOR_CAST"
        else if (colorCastMagnitude > 0.12) warnings += "MODERATE_COLOR_CAST"

        val gain = if (meanLuma <= 0.0) 1.0 else (TARGET_MID_LUMA / meanLuma).coerceIn(MIN_GAIN, MAX_GAIN)

        return CaptureConditionProfile(
            view = view,
            meanLuma = meanLuma,
            meanR = meanR,
            meanG = meanG,
            meanB = meanB,
            rgRatio = rgRatio,
            bgRatio = bgRatio,
            colorCastMagnitude = colorCastMagnitude,
            dynamicRange = dynamicRange,
            illuminantEstimate = illuminantEstimate,
            suggestedExposureGain = gain,
            warnings = warnings
        )
    }

    fun json(x: CaptureConditionProfile): String {
        val w = x.warnings.joinToString(",") { "\"$it\"" }
        return """{"view":"${x.view}","mean_luma":${x.meanLuma},"mean_r":${x.meanR},"mean_g":${x.meanG},"mean_b":${x.meanB},"rg_ratio":${x.rgRatio},"bg_ratio":${x.bgRatio},"color_cast_magnitude":${x.colorCastMagnitude},"dynamic_range":${x.dynamicRange},"illuminant_estimate":"${x.illuminantEstimate}","suggested_exposure_gain":${x.suggestedExposureGain},"warnings":[$w],"method":"capture_condition_profile_v1","medical_diagnosis":false}"""
    }
}
