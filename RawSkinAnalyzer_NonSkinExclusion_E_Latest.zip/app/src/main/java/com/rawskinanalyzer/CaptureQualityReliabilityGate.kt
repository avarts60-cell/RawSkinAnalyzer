package com.rawskinanalyzer

/**
 * BATCH 3B — STEP 10: capture quality vs genuine negative trend.
 *
 * Audit finding: `ThreeViewCaptureConditionAnalyzer` already computes a structural
 * `consistency` signal (HIGH_CAPTURE_CONDITION_CONSISTENCY / MODERATE_CAPTURE_CONDITION_VARIATION
 * / MAJOR_CAPTURE_CONDITION_INCONSISTENCY) from cross-view lighting/color-cast/exposure spread,
 * but it is computed only in `MainActivity` for on-device capture guidance and was never passed
 * into `FinalSkinAnalysisProfileAnalyzer`, `SkinProgressTracker`, `MultiSessionTrendAnalyzer`,
 * or `TrendAwareRoutineAdaptationPolicy` — none of which have ever seen a capture-quality signal
 * at all. This meant a poor-lighting session's score delta reached
 * `RoutineAdaptationEngine`/`TrendAwareRoutineAdaptationPolicy` with exactly the same weight as
 * a well-captured session, the precise failure mode this step exists to prevent.
 *
 * This file does not rebuild `TrendAwareRoutineAdaptationPolicy` or `RoutineAdaptationEngine`
 * (both untouched) — it wraps their already-computed `TrendAwareAdaptationResult` and caps it
 * using the current session's already-computed capture-quality signal.
 */

enum class CaptureQualityReliability { RELIABLE, REDUCED, LOW }

object CaptureQualityReliabilityGate {
    fun classify(consistency: String?): CaptureQualityReliability = when (consistency) {
        "HIGH_CAPTURE_CONDITION_CONSISTENCY" -> CaptureQualityReliability.RELIABLE
        "MODERATE_CAPTURE_CONDITION_VARIATION" -> CaptureQualityReliability.REDUCED
        "MAJOR_CAPTURE_CONDITION_INCONSISTENCY" -> CaptureQualityReliability.LOW
        // Not supplied (older/optional call site): treat as reliable rather than penalizing
        // every caller that hasn't wired capture-condition data through yet, but also never
        // used to escalate — this function only ever caps, never raises, adaptation strength.
        else -> CaptureQualityReliability.RELIABLE
    }

    /**
     * Caps — never escalates — the trend-aware adaptation decision when this session's own
     * capture conditions were unreliable. "A single anomalous session should not normally
     * trigger a major routine change": a LOW-reliability session cannot itself justify
     * CONSIDER_ROUTINE_ADJUSTMENT; a REDUCED-reliability session cannot support HIGH confidence.
     */
    fun apply(
        adaptation: TrendAwareAdaptationResult,
        reliability: CaptureQualityReliability
    ): TrendAwareAdaptationResult {
        if (reliability == CaptureQualityReliability.RELIABLE) return adaptation

        val decision = adaptation.decision
        val reasonTag = if (reliability == CaptureQualityReliability.LOW)
            "CAPTURE_QUALITY_LOW_RELIABILITY_TREND_CAPPED"
        else
            "CAPTURE_QUALITY_REDUCED_TREND_RELIABILITY"

        val cappedAction =
            if (reliability == CaptureQualityReliability.LOW &&
                decision.action == RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT
            ) RoutineAdaptationAction.REVIEW_AND_MONITOR else decision.action

        val cappedConfidence = when {
            reliability == CaptureQualityReliability.LOW -> "LOW"
            reliability == CaptureQualityReliability.REDUCED && decision.adaptationConfidence == "HIGH" -> "MODERATE"
            else -> decision.adaptationConfidence
        }

        return adaptation.copy(
            decision = decision.copy(
                action = cappedAction,
                adaptationConfidence = cappedConfidence,
                reasons = (decision.reasons + reasonTag).distinct()
            ),
            trendReasons = (adaptation.trendReasons + reasonTag).distinct()
        )
    }
}
