package com.rawskinanalyzer

/**
 * BATCH 4B — STEP 1/2: per-characteristic comparability gating.
 *
 * Audit finding (Batch 4A's own "Exact remaining Batch 4A work" item 1): `SessionComparability`
 * (Batch 4A) produces exactly one comparability status for an entire session pair, and
 * `SkinProgressTracker.FeatureProgress` renders a full numerical delta for all eight
 * characteristics regardless of that status. Nothing in the existing pipeline lets one
 * characteristic be reported as reliably comparable while a different characteristic in the
 * same session pair is not — the batch's own architecture rule ("a session can be comparable
 * for one characteristic and limited for another") had no implementation.
 *
 * This file does not recompute session-level comparability (`SessionComparabilityEvaluator`,
 * Batch 4A, untouched) or the raw two-session delta (`SkinProgressTracker.compare`, Batch 1/2,
 * untouched). It is a per-characteristic refinement layer sitting between them: the session-level
 * status is the floor every characteristic inherits, and each characteristic's own
 * already-computed `FinalSkinFinding.confidence` (Batch 1's calibration/confidence stage) can
 * only narrow that further for that one characteristic, never widen it and never affect any
 * other characteristic.
 *
 * Honest limitation, stated up front rather than discovered later: `StoredSkinSession`/
 * `SkinProgressSnapshot` persist only a single session-level confidence string, not a
 * per-characteristic one (see `SkinProgressTracker.kt`). The *previous* session's
 * per-characteristic confidence is therefore not available data — only the *current* session's
 * per-characteristic confidence is. This evaluator uses only what is actually stored; it does
 * not fabricate a previous-session per-characteristic confidence to make the model look more
 * complete than the persisted data supports.
 */
enum class CharacteristicComparabilityStatus {
    DIRECTLY_COMPARABLE,
    COMPARABLE_WITH_LIMITATIONS,
    NOT_COMPARABLE,
    INSUFFICIENT_DATA
}

data class CharacteristicComparabilityResult(
    val characteristic: String,
    val status: CharacteristicComparabilityStatus,
    val reasons: List<String>
)

object CharacteristicComparabilityEvaluator {

    /**
     * Session-level comparability reasons (`SessionComparability.kt`) restated in the
     * per-characteristic reason vocabulary this batch specifies. A session-level reason always
     * applies to every characteristic equally (it describes the pair of sessions, not any one
     * characteristic), so it is simply relabeled, never dropped or reinterpreted.
     */
    private val SESSION_REASON_MAP = mapOf(
        "ANALYSIS_PIPELINE_VERSION_MISMATCH" to "ANALYSIS_VERSION_DIFFERENCE",
        "INSUFFICIENT_USABLE_VIEWS_FOR_COMPARISON" to "INSUFFICIENT_VIEW_DATA",
        "THREE_VIEW_COMPLETENESS_NOT_MET_BY_BOTH_SESSIONS" to "INSUFFICIENT_VIEW_DATA",
        "CAPTURE_QUALITY_LOW_RELIABILITY_SESSION_INVOLVED" to "CAPTURE_CONDITION_MISMATCH",
        "CAPTURE_QUALITY_REDUCED_RELIABILITY_SESSION_INVOLVED" to "CAPTURE_CONDITION_MISMATCH",
        "PREVIOUS_SESSION_CAPTURE_METADATA_UNAVAILABLE" to "INSUFFICIENT_LONGITUDINAL_SUPPORT"
    )

    /**
     * Evaluates one characteristic. [sessionComparability] null means there is no previous
     * session at all (nothing to compare against yet) — distinct from a previous session that
     * exists but was found NOT_COMPARABLE.
     */
    fun evaluate(
        characteristic: String,
        currentCharacteristicConfidence: String,
        sessionComparability: SessionComparabilityResult?
    ): CharacteristicComparabilityResult {
        if (sessionComparability == null) {
            return CharacteristicComparabilityResult(
                characteristic,
                CharacteristicComparabilityStatus.INSUFFICIENT_DATA,
                listOf("INSUFFICIENT_LONGITUDINAL_SUPPORT")
            )
        }

        val mappedSessionReasons = sessionComparability.reasons
            .map { SESSION_REASON_MAP[it] ?: it }
            .distinct()

        if (sessionComparability.status == SessionComparabilityStatus.NOT_COMPARABLE) {
            return CharacteristicComparabilityResult(
                characteristic,
                CharacteristicComparabilityStatus.NOT_COMPARABLE,
                mappedSessionReasons
            )
        }

        val lowCharacteristicConfidence = currentCharacteristicConfidence.uppercase() == "LOW"
        val sessionLimited = sessionComparability.status == SessionComparabilityStatus.LIMITED_COMPARABILITY

        val status = if (sessionLimited || lowCharacteristicConfidence)
            CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS
        else
            CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE

        val reasons = mutableListOf<String>()
        reasons += mappedSessionReasons
        if (lowCharacteristicConfidence) reasons += "LOW_CHARACTERISTIC_CONFIDENCE"

        return CharacteristicComparabilityResult(characteristic, status, reasons)
    }

    /**
     * Evaluates every characteristic in [currentFindings] (the current session's
     * `FinalSkinAnalysisProfile.findings` — already covers exactly the eight characteristics
     * this batch names) against the one shared session-level [sessionComparability] signal.
     */
    fun evaluateAll(
        currentFindings: List<FinalSkinFinding>,
        sessionComparability: SessionComparabilityResult?
    ): List<CharacteristicComparabilityResult> =
        currentFindings.map { finding ->
            evaluate(finding.characteristic, finding.confidence, sessionComparability)
        }

    fun json(results: List<CharacteristicComparabilityResult>): String {
        val items = results.joinToString(",") { r ->
            val reasons = r.reasons.joinToString(",") { "\"$it\"" }
            """{"characteristic":"${r.characteristic}","status":"${r.status}","reasons":[$reasons]}"""
        }
        return "[$items]"
    }
}

/**
 * BATCH 4B — STEP 3: a `FeatureProgress` row (Batch 1's `SkinProgressTracker`, unmodified)
 * re-presented so a NOT_COMPARABLE/INSUFFICIENT_DATA characteristic never shows a numerical
 * delta or direction as if it were a normal, trustworthy comparison — while still preserving
 * both raw historical scores exactly as `SkinProgressTracker` computed them, per this batch's
 * explicit "preserve the raw historical scores" / "do not alter original stored results" rules.
 * `delta`/`direction` are null exactly when the comparison must not be presented as normal —
 * never a fabricated "converted" value standing in for a real one.
 */
data class GatedFeatureProgress(
    val feature: String,
    val comparability: CharacteristicComparabilityStatus,
    val reasons: List<String>,
    val previousScore: Double,
    val currentScore: Double,
    val delta: Double?,
    val direction: ProgressDirection?
)

object CharacteristicGatedProgress {

    /**
     * Pairs each raw [progress] row with its [CharacteristicComparabilityResult] (matched by
     * characteristic/feature name — both come from the same eight-characteristic vocabulary,
     * see `SkinProgressTracker.compare`'s `values` list and `FinalSkinFinding.characteristic`).
     * A feature name with no matching comparability result (should not happen in the current
     * architecture, since every pipeline path computes all eight characteristics
     * unconditionally — see Batch 4A's own note on this) is treated conservatively as
     * INSUFFICIENT_DATA rather than assumed comparable.
     */
    fun gate(
        progress: SkinProgressResult,
        comparabilityByCharacteristic: Map<String, CharacteristicComparabilityResult>
    ): List<GatedFeatureProgress> =
        progress.features.map { f ->
            val comparability = comparabilityByCharacteristic[f.feature]
                ?: CharacteristicComparabilityResult(
                    f.feature,
                    CharacteristicComparabilityStatus.INSUFFICIENT_DATA,
                    listOf("MISSING_CHARACTERISTIC_DATA")
                )

            val suppressNumericalChange =
                comparability.status == CharacteristicComparabilityStatus.NOT_COMPARABLE ||
                    comparability.status == CharacteristicComparabilityStatus.INSUFFICIENT_DATA

            GatedFeatureProgress(
                feature = f.feature,
                comparability = comparability.status,
                reasons = comparability.reasons,
                previousScore = f.previousScore,
                currentScore = f.currentScore,
                delta = if (suppressNumericalChange) null else f.delta,
                direction = if (suppressNumericalChange) null else f.direction
            )
        }

    fun json(rows: List<GatedFeatureProgress>): String {
        val items = rows.joinToString(",") { r ->
            val reasons = r.reasons.joinToString(",") { "\"$it\"" }
            val delta = r.delta?.toString() ?: "null"
            val direction = r.direction?.let { "\"$it\"" } ?: "null"
            """{"feature":"${r.feature}","comparability":"${r.comparability}","reasons":[$reasons],"previous_score":${r.previousScore},"current_score":${r.currentScore},"delta":$delta,"direction":$direction}"""
        }
        return "[$items]"
    }
}
