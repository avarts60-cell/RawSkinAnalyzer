package com.rawskinanalyzer

/**
 * BATCH 4C — Longitudinal Trend Intelligence and Evidence Strength.
 *
 * Core principle (from the batch spec): a numerical difference between two sessions is not
 * automatically a meaningful skin trend. Nothing in the codebase before this batch answered
 * "how much repeated, reliable evidence actually supports this characteristic's trend" — see
 * the audit findings below.
 *
 * Step 1 audit — what already exists and is reused, not rebuilt:
 * - `MultiSessionTrendAnalyzer` (pre-existing) already computes one `FeatureTrend` per
 *   characteristic across up to 5 recent sessions (raw values, average delta, a direction:
 *   SUSTAINED_IMPROVEMENT / STABLE_TREND / SUSTAINED_WORSENING / MIXED_TREND /
 *   INSUFFICIENT_TREND_DATA) and one whole-result `trendConfidence` string derived from session
 *   *count* alone (HIGH/MODERATE/INSUFFICIENT_SESSIONS) — it does not vary per characteristic
 *   and does not read `CaptureQualityReliability` or per-characteristic comparability at all.
 * - `SessionComparability`/`ComparisonConfidence` (Batch 4A) and `CharacteristicComparability`
 *   (Batch 4B) already gate a *single* previous-vs-current pairing, not a multi-session run.
 * - `SessionBaselineSelector` (Batch 4A) already selects a stable whole-session baseline.
 * - `LongitudinalChangeClassifier` (Batch 4A) already reconciles a two-session delta against
 *   the whole-session multi-session trend, but only at whole-session granularity and without a
 *   distinct evidence-state vocabulary (SINGLE_OBSERVATION/EARLY_SIGNAL/REPEATED_SIGNAL/...).
 *
 * This file does not replace any of the above. It is a per-characteristic reconciling layer,
 * exactly one level down from `LongitudinalChangeClassifier`'s existing whole-session role: it
 * takes each characteristic's already-computed `FeatureTrend` (from `MultiSessionTrendAnalyzer`),
 * walks the same underlying stored-session history to determine, transition by transition,
 * which deltas are actually backed by reliable capture conditions (`CaptureQualityReliability`,
 * read from each stored session's own `SessionCaptureContext` — Batch 4A) and, for the newest
 * transition (into the current session), by Batch 4B's per-characteristic comparability — and
 * turns that into an evidence-strength judgment and a stability judgment that
 * `MultiSessionTrendAnalyzer`'s single direction/confidence pair could not represent.
 *
 * Critical separation preserved (batch's own requirement):
 * SESSION_CONFIDENCE (`FinalSkinFinding.confidence`) != COMPARISON_CONFIDENCE
 * (`ComparisonConfidenceLevel`, Batch 4A, one previous-vs-current pairing) != TREND_CONFIDENCE
 * (`TrendConfidenceLevel`, this file, repeated-evidence strength) != CLINICAL_CERTAINTY (never
 * claimed anywhere in this codebase). `TrendConfidenceLevel` is a distinct type from
 * `ComparisonConfidenceLevel` specifically so these are never accidentally interchanged.
 */

/** How much repeated, reliable historical evidence supports a characteristic's current trend. */
enum class RepeatedSessionEvidenceState {
    SINGLE_OBSERVATION,
    EARLY_SIGNAL,
    REPEATED_SIGNAL,
    STRONG_REPEATED_SIGNAL,
    CONTRADICTORY_SIGNAL,
    INSUFFICIENT_HISTORY
}

/** Deliberately its own type — see the "critical separation" note above. */
enum class TrendConfidenceLevel { HIGH, MODERATE, LOW, INSUFFICIENT }

/** Whether a characteristic's direction over time is settled, still moving, or noisy. */
enum class TrendDirectionStability {
    IMPROVING, STABLE, WORSENING, OSCILLATING, UNCERTAIN, INSUFFICIENT_DATA, NOT_COMPARABLE
}

data class CharacteristicTrendIntelligence(
    val characteristic: String,
    val evidenceState: RepeatedSessionEvidenceState,
    val trendConfidence: TrendConfidenceLevel,
    val directionStability: TrendDirectionStability,
    // BASELINE_CHANGE: current score minus the batch-4A-selected fixed baseline session's score
    // for this characteristic. Null when no baseline exists yet. Kept distinct from
    // `recentTrendDirection` below per step 6 ("do not replace baseline comparison with rolling
    // trend, or vice versa").
    val baselineChange: Double?,
    // RECENT_TREND: the existing, unmodified `MultiSessionTrendAnalyzer` direction for this
    // characteristic, carried through rather than recomputed.
    val recentTrendDirection: TrendDirection,
    val explanationTags: List<String>,
    val reliableTransitionsUsed: Int,
    val totalTransitionsConsidered: Int
)

object CharacteristicTrendIntelligenceAnalyzer {

    private const val THRESHOLD = 3.0

    /**
     * Evaluates one characteristic. [orderedHistory] must be ascending by time, already filtered
     * to one analysis version, and must NOT include the current (not-yet-saved) session —
     * mirrors `MultiSessionTrendAnalyzer.analyze`'s own history contract. The current session's
     * score/comparability are passed separately because Batch 4B's per-characteristic
     * comparability only ever exists for the current session (see `CharacteristicComparability.kt`
     * for why the previous session's own per-characteristic confidence is not persisted data).
     */
    fun analyze(
        characteristic: String,
        scoreSelector: (SkinProgressSnapshot) -> Double,
        orderedHistory: List<StoredSkinSession>,
        currentScore: Double,
        currentComparability: CharacteristicComparabilityResult?,
        featureTrend: FeatureTrend?,
        baseline: StoredSkinSession?,
        maxSessions: Int = 5
    ): CharacteristicTrendIntelligence {

        val baselineChange = baseline?.let { currentScore - scoreSelector(it.snapshot) }
        val recentDirection = featureTrend?.direction ?: TrendDirection.INSUFFICIENT_TREND_DATA

        // A NOT_COMPARABLE current pairing means the newest data point cannot be trusted for
        // this characteristic at all — conservative regardless of how much older history exists.
        if (currentComparability?.status == CharacteristicComparabilityStatus.NOT_COMPARABLE) {
            return CharacteristicTrendIntelligence(
                characteristic, RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY,
                TrendConfidenceLevel.INSUFFICIENT, TrendDirectionStability.NOT_COMPARABLE,
                baselineChange, recentDirection, listOf("NOT_COMPARABLE"), 0, 0
            )
        }

        val past = orderedHistory.takeLast(maxSessions)
        if (past.isEmpty()) {
            return CharacteristicTrendIntelligence(
                characteristic, RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY,
                TrendConfidenceLevel.INSUFFICIENT, TrendDirectionStability.INSUFFICIENT_DATA,
                baselineChange, recentDirection, listOf("INSUFFICIENT_HISTORY"), 0, 0
            )
        }

        fun reliabilityOf(s: StoredSkinSession) =
            s.captureContext?.captureQualityReliability ?: CaptureQualityReliability.REDUCED

        val scores = past.map { scoreSelector(it.snapshot) } + currentScore
        val pastReliabilities = past.map { reliabilityOf(it) }

        data class Transition(val delta: Double, val reliable: Boolean)

        val transitions = (1 until scores.size).map { i ->
            val delta = scores[i] - scores[i - 1]
            // The newest transition (into the current session) is gated by Batch 4B's
            // per-characteristic comparability, which is the only signal that knows about this
            // session specifically. Every earlier transition is gated by the *later* stored
            // session's own persisted capture-quality reliability (Batch 4A) — a LOW-reliability
            // session must not silently strengthen a trend just because it exists.
            val reliable = if (i == scores.size - 1) {
                currentComparability == null ||
                    currentComparability.status == CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE ||
                    currentComparability.status == CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS
            } else {
                pastReliabilities[i] != CaptureQualityReliability.LOW
            }
            Transition(delta, reliable)
        }

        val reliable = transitions.filter { it.reliable }
        val explanationTags = mutableListOf<String>()
        if (reliable.size < transitions.size) explanationTags += "CAPTURE_CONDITION_CONFLICT"

        if (reliable.isEmpty()) {
            return CharacteristicTrendIntelligence(
                characteristic, RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY,
                TrendConfidenceLevel.INSUFFICIENT, TrendDirectionStability.INSUFFICIENT_DATA,
                baselineChange, recentDirection,
                (listOf("INSUFFICIENT_HISTORY") + explanationTags).distinct(),
                0, transitions.size
            )
        }

        // -1 = worsening delta, 0 = stable delta, 1 = improving delta (matches the existing
        // `SkinProgressTracker`/`MultiSessionTrendAnalyzer` sign convention: a negative delta on
        // these "problem magnitude" scores is an improvement).
        fun classify(delta: Double) = when {
            delta <= -THRESHOLD -> 1
            delta >= THRESHOLD -> -1
            else -> 0
        }
        val directions = reliable.map { classify(it.delta) }
        val improveCount = directions.count { it == 1 }
        val worsenCount = directions.count { it == -1 }

        val evidenceState: RepeatedSessionEvidenceState
        when {
            improveCount > 0 && worsenCount > 0 -> {
                evidenceState = RepeatedSessionEvidenceState.CONTRADICTORY_SIGNAL
                explanationTags += "CONTRADICTORY_SESSIONS"
            }
            improveCount == 0 && worsenCount == 0 -> {
                evidenceState = if (reliable.size >= 2) RepeatedSessionEvidenceState.REPEATED_SIGNAL
                else RepeatedSessionEvidenceState.SINGLE_OBSERVATION
                explanationTags += "STABLE_OVER_TIME"
            }
            else -> {
                val directionalCount = maxOf(improveCount, worsenCount)
                evidenceState = when {
                    directionalCount == 1 -> RepeatedSessionEvidenceState.SINGLE_OBSERVATION
                    directionalCount == 2 -> RepeatedSessionEvidenceState.EARLY_SIGNAL
                    directionalCount == 3 -> RepeatedSessionEvidenceState.REPEATED_SIGNAL
                    else -> RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL
                }
                when (evidenceState) {
                    RepeatedSessionEvidenceState.SINGLE_OBSERVATION -> explanationTags += "SINGLE_SESSION_CHANGE"
                    RepeatedSessionEvidenceState.EARLY_SIGNAL -> explanationTags += "LOW_TREND_RELIABILITY"
                    else -> explanationTags += if (improveCount > worsenCount) "REPEATED_IMPROVEMENT" else "REPEATED_WORSENING"
                }
            }
        }

        var trendConfidence = when (evidenceState) {
            RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY,
            RepeatedSessionEvidenceState.SINGLE_OBSERVATION -> TrendConfidenceLevel.INSUFFICIENT
            RepeatedSessionEvidenceState.CONTRADICTORY_SIGNAL,
            RepeatedSessionEvidenceState.EARLY_SIGNAL -> TrendConfidenceLevel.LOW
            RepeatedSessionEvidenceState.REPEATED_SIGNAL -> TrendConfidenceLevel.MODERATE
            RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL -> TrendConfidenceLevel.HIGH
        }
        // Never fabricate HIGH trend confidence when the newest session's own comparability was
        // only COMPARABLE_WITH_LIMITATIONS, or when a capture-condition conflict already forced
        // some transitions to be excluded — both cap, never raise.
        if (currentComparability?.status == CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS &&
            trendConfidence == TrendConfidenceLevel.HIGH
        ) {
            trendConfidence = TrendConfidenceLevel.MODERATE
        }
        if (explanationTags.contains("CAPTURE_CONDITION_CONFLICT") && trendConfidence == TrendConfidenceLevel.HIGH) {
            trendConfidence = TrendConfidenceLevel.MODERATE
        }

        val directionStability = when (evidenceState) {
            RepeatedSessionEvidenceState.CONTRADICTORY_SIGNAL -> TrendDirectionStability.OSCILLATING
            RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY -> TrendDirectionStability.INSUFFICIENT_DATA
            RepeatedSessionEvidenceState.SINGLE_OBSERVATION -> TrendDirectionStability.UNCERTAIN
            else -> when {
                improveCount > worsenCount -> TrendDirectionStability.IMPROVING
                worsenCount > improveCount -> TrendDirectionStability.WORSENING
                else -> TrendDirectionStability.STABLE
            }
        }

        return CharacteristicTrendIntelligence(
            characteristic, evidenceState, trendConfidence, directionStability,
            baselineChange, recentDirection, explanationTags.distinct(),
            reliable.size, transitions.size
        )
    }

    /**
     * Evaluates all eight supported characteristics, reusing the already-computed
     * `MultiSessionTrendResult` (its per-characteristic `FeatureTrend`s) and
     * `CharacteristicComparabilityResult` list (Batch 4B) rather than recomputing either.
     */
    fun analyzeAll(
        orderedHistory: List<StoredSkinSession>,
        currentSnapshot: SkinProgressSnapshot,
        multiSessionTrend: MultiSessionTrendResult,
        characteristicComparability: List<CharacteristicComparabilityResult>,
        baseline: StoredSkinSession?,
        maxSessions: Int = 5
    ): List<CharacteristicTrendIntelligence> {
        val comparabilityByName = characteristicComparability.associateBy { it.characteristic }
        val trendByName = multiSessionTrend.features.associateBy { it.feature }
        val selectors: List<Pair<String, (SkinProgressSnapshot) -> Double>> = listOf(
            "REDNESS" to { s: SkinProgressSnapshot -> s.rednessScore },
            "PIGMENTATION_OR_TONE_VARIATION" to { s: SkinProgressSnapshot -> s.pigmentationScore },
            "DARK_MARK_SIGNAL" to { s: SkinProgressSnapshot -> s.darkMarkScore },
            "BLEMISH_LIKE_FEATURES" to { s: SkinProgressSnapshot -> s.blemishLikeScore },
            "TEXTURE_IRREGULARITY" to { s: SkinProgressSnapshot -> s.textureScore },
            "PORE_LIKE_FEATURES" to { s: SkinProgressSnapshot -> s.poreLikeScore },
            "SURFACE_SHINE_SIGNAL" to { s: SkinProgressSnapshot -> s.shineScore },
            "DRYNESS_RELATED_SURFACE_SIGNAL" to { s: SkinProgressSnapshot -> s.drynessScore }
        )
        return selectors.map { (name, selector) ->
            analyze(
                characteristic = name,
                scoreSelector = selector,
                orderedHistory = orderedHistory,
                currentScore = selector(currentSnapshot),
                currentComparability = comparabilityByName[name],
                featureTrend = trendByName[name],
                baseline = baseline,
                maxSessions = maxSessions
            )
        }
    }

    fun json(results: List<CharacteristicTrendIntelligence>): String {
        val items = results.joinToString(",") { r ->
            val tags = r.explanationTags.joinToString(",") { "\"$it\"" }
            val bc = r.baselineChange?.toString() ?: "null"
            """{"characteristic":"${r.characteristic}","evidence_state":"${r.evidenceState}","trend_confidence":"${r.trendConfidence}","direction_stability":"${r.directionStability}","baseline_change":$bc,"recent_trend_direction":"${r.recentTrendDirection}","explanation_tags":[$tags],"reliable_transitions_used":${r.reliableTransitionsUsed},"total_transitions_considered":${r.totalTransitionsConsidered}}"""
        }
        return "[$items]"
    }
}

/**
 * BATCH 4C — STEP 9 (SECONDARY): conservative Brain 2 integration point.
 *
 * Audit finding: `ComparabilityAdaptationGate` (Batch 4B) already caps a `TrendAwareAdaptationResult`
 * using whole-session comparability, but nothing caps it using *this batch's* per-characteristic
 * evidence strength — a `CONSIDER_ROUTINE_ADJUSTMENT` decision whose `affectedFeatures` are only
 * backed by SINGLE_OBSERVATION/EARLY_SIGNAL/CONTRADICTORY_SIGNAL evidence would otherwise reach the
 * routine-adjustment generator with the same weight as one backed by STRONG_REPEATED_SIGNAL evidence.
 * This follows the exact same cap-only pattern as `CaptureQualityReliabilityGate`/
 * `ComparabilityAdaptationGate` — it does not touch `RoutineAdaptationEngine` or
 * `TrendAwareRoutineAdaptationPolicy` internals, only caps their already-computed output.
 */
object TrendIntelligenceAdaptationGate {

    /**
     * [adaptation] should already be the output of `ComparabilityAdaptationGate.apply(...)` (the
     * existing cap-only chain this gate extends). [trendIntelligenceByCharacteristic] is this
     * batch's per-characteristic result, keyed by characteristic name.
     */
    fun apply(
        adaptation: TrendAwareAdaptationResult,
        trendIntelligenceByCharacteristic: Map<String, CharacteristicTrendIntelligence>
    ): TrendAwareAdaptationResult {
        val decision = adaptation.decision
        if (decision.affectedFeatures.isEmpty()) return adaptation

        val affectedIntelligence = decision.affectedFeatures.mapNotNull { trendIntelligenceByCharacteristic[it] }
        if (affectedIntelligence.isEmpty()) return adaptation

        val anyWeakEvidence = affectedIntelligence.any {
            it.evidenceState == RepeatedSessionEvidenceState.SINGLE_OBSERVATION ||
                it.evidenceState == RepeatedSessionEvidenceState.EARLY_SIGNAL ||
                it.evidenceState == RepeatedSessionEvidenceState.CONTRADICTORY_SIGNAL ||
                it.evidenceState == RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY
        }
        val anyRepeatedReliable = affectedIntelligence.any {
            it.evidenceState == RepeatedSessionEvidenceState.REPEATED_SIGNAL ||
                it.evidenceState == RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL
        }

        // A single weak change must not alone justify a strong action: if NONE of the affected
        // characteristics have repeated, reliable evidence, cap CONSIDER_ROUTINE_ADJUSTMENT down.
        if (!anyRepeatedReliable && decision.action == RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT) {
            val cappedDecision = decision.copy(
                action = RoutineAdaptationAction.REVIEW_AND_MONITOR,
                adaptationConfidence = "LOW",
                reasons = (decision.reasons + "TREND_EVIDENCE_INSUFFICIENT_FOR_ADJUSTMENT").distinct()
            )
            return adaptation.copy(
                decision = cappedDecision,
                trendReasons = (adaptation.trendReasons + "TREND_EVIDENCE_INSUFFICIENT_FOR_ADJUSTMENT").distinct()
            )
        }

        // Repeated reliable evidence exists, but it is mixed with weak/contradictory evidence on
        // other affected characteristics — still cap HIGH confidence down to MODERATE rather than
        // let the strongest single characteristic's evidence carry the whole decision's confidence.
        if (anyWeakEvidence && decision.adaptationConfidence == "HIGH") {
            val cappedDecision = decision.copy(
                adaptationConfidence = "MODERATE",
                reasons = (decision.reasons + "MIXED_TREND_EVIDENCE_STRENGTH").distinct()
            )
            return adaptation.copy(
                decision = cappedDecision,
                trendReasons = (adaptation.trendReasons + "MIXED_TREND_EVIDENCE_STRENGTH").distinct()
            )
        }

        return adaptation
    }
}
