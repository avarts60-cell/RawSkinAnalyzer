package com.rawskinanalyzer

data class CommercialProductRecord(
    val productId: String,
    val brand: String,
    val productName: String,
    val ingredientNames: Set<String>,
    val attributes: Set<String>,
    val supportedRoutinePhases: Set<String>,
    val catalogSource: String,
    val lastVerifiedEpochMillis: Long? = null
)

data class CatalogValidationResult(
    val productId: String,
    val valid: Boolean,
    val issues: List<String>
)

object CommercialProductCatalogAdapter {
    fun validate(records: List<CommercialProductRecord>): List<CatalogValidationResult> =
        records.map { record ->
            val issues = mutableListOf<String>()
            if (record.productId.isBlank()) issues += "MISSING_PRODUCT_ID"
            if (record.brand.isBlank()) issues += "MISSING_BRAND"
            if (record.productName.isBlank()) issues += "MISSING_PRODUCT_NAME"
            if (record.ingredientNames.isEmpty()) issues += "MISSING_INGREDIENT_DATA"
            if (record.supportedRoutinePhases.isEmpty()) issues += "MISSING_ROUTINE_PHASE_DATA"
            if (record.catalogSource.isBlank()) issues += "MISSING_CATALOG_SOURCE"

            CatalogValidationResult(
                productId = record.productId,
                valid = issues.isEmpty(),
                issues = issues
            )
        }

    fun normalize(records: List<CommercialProductRecord>): List<ProductCandidate> {
        val validation = validate(records).associateBy { it.productId }
        return records.filter { validation[it.productId]?.valid == true }
            .map { record ->
                ProductCandidate(
                    productId = record.productId,
                    ingredientNames = record.ingredientNames.map { it.trim() }
                        .filter { it.isNotBlank() }
                        .toSet(),
                    attributes = record.attributes.map { it.trim() }
                        .filter { it.isNotBlank() }
                        .toSet(),
                    routinePhases = record.supportedRoutinePhases.map { it.trim() }
                        .filter { it.isNotBlank() }
                        .toSet()
                )
            }
    }
}

object ProductCatalogRepository {
    private var commercialRecords: List<CommercialProductRecord> = emptyList()

    fun replace(records: List<CommercialProductRecord>) {
        commercialRecords = records
    }

    fun candidates(): List<ProductCandidate> =
        if (commercialRecords.isEmpty()) {
            LocalProductCatalog.candidates()
        } else {
            CommercialProductCatalogAdapter.normalize(commercialRecords)
        }

    fun sourceType(): String =
        if (commercialRecords.isEmpty()) "LOCAL_FALLBACK_CATALOG"
        else "COMMERCIAL_CATALOG"
}
