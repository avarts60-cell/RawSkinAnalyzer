package com.rawskinanalyzer

/**
 * BATCH 4B — STEP 4 (SECONDARY): comparability-aware routine adaptation.
 *
 * Existing clean integration boundary found during the Batch 4B audit: `CaptureQualityReliabilityGate`
 * (Batch 3B) already wraps `TrendAwareRoutineAdaptationPolicy`'s output with a cap-only pattern
 * — it never rebuilds `RoutineAdaptationEngine`/`TrendAwareRoutineAdaptationPolicy`, only caps
 * their already-computed `TrendAwareAdaptationResult` using a single session's own capture
 * quality. This file follows the exact same pattern for the new, distinct signal Batch 4A/4B
 * added: whether *this session and the one it's being compared against* are comparable at all
 * (`SessionComparabilityResult`), which `CaptureQualityReliabilityGate` cannot see (it only
 * knows about the current session in isolation, not the pairing).
 *
 * Deliberately a second, separate gate rather than folding this into
 * `CaptureQualityReliabilityGate` itself: that file's docstring and constructor are scoped to
 * "this session's own capture quality", and conflating a single-session signal with a
 * session-pair signal in one function would blur exactly the distinction this batch's
 * `critical_rule` asks to preserve ("capture-condition mismatch should be distinguishable from
 * genuine negative skin trend" — each gate now contributes its own separately-tagged reason).
 *
 * Caps only, never escalates or invents a stronger decision than
 * `TrendAwareRoutineAdaptationPolicy`/`CaptureQualityReliabilityGate` already produced. Does not
 * touch `RoutineAdaptationEngine`, `TrendAwareRoutineAdaptationPolicy`,
 * `TrendAwareRoutineAdjustmentGenerator`, or `RoutineAdjustmentCandidateActivator` — all remain
 * exactly as they were before this batch. No analysis score, historical score, or confidence
 * used elsewhere in the pipeline is modified by this gate; it only shapes the routine-adaptation
 * *decision* object, per this batch's explicit "routine decisions must not modify skin-analysis
 * scores" constraint.
 */
object ComparabilityAdaptationGate {

    private const val NOT_COMPARABLE_TAG = "SESSION_COMPARABILITY_NOT_COMPARABLE_TREND_CAPPED"
    private const val LIMITED_COMPARABILITY_TAG = "SESSION_COMPARABILITY_LIMITED_TREND_CONSERVATIVE"

    /**
     * [comparability] is null when there is no previous session to compare against yet
     * (`SessionComparabilityEvaluator` was never run) — nothing to gate in that case, since
     * `TrendAwareRoutineAdaptationPolicy` already has its own INSUFFICIENT_DATA-style handling
     * for that situation and this gate must not invent an opinion about a comparison that never
     * happened.
     */
    fun apply(
        adaptation: TrendAwareAdaptationResult,
        comparability: SessionComparabilityResult?
    ): TrendAwareAdaptationResult {
        if (comparability == null) return adaptation

        val decision = adaptation.decision

        return when (comparability.status) {
            SessionComparabilityStatus.NOT_COMPARABLE -> {
                // A non-comparable session pair must never be read as reliable worsening (or
                // reliable improvement) — cap any "act on this" decision back to monitoring,
                // and cap confidence to the floor, distinct from a merely-poor-capture-quality
                // cap (see LIMITED_COMPARABILITY_TAG below) so the two causes stay legible.
                val cappedAction =
                    if (decision.action == RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT)
                        RoutineAdaptationAction.REVIEW_AND_MONITOR
                    else decision.action
                adaptation.copy(
                    decision = decision.copy(
                        action = cappedAction,
                        adaptationConfidence = "LOW",
                        reasons = (decision.reasons + NOT_COMPARABLE_TAG).distinct()
                    ),
                    trendReasons = (adaptation.trendReasons + NOT_COMPARABLE_TAG).distinct()
                )
            }
            SessionComparabilityStatus.LIMITED_COMPARABILITY -> {
                // Weaker evidence than NOT_COMPARABLE, but a strong (CONSIDER_ROUTINE_ADJUSTMENT)
                // decision still requires sufficiently reliable longitudinal evidence, which
                // limited comparability does not provide on its own.
                val cappedAction =
                    if (decision.action == RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT)
                        RoutineAdaptationAction.REVIEW_AND_MONITOR
                    else decision.action
                val cappedConfidence = if (decision.adaptationConfidence == "HIGH") "MODERATE" else decision.adaptationConfidence
                adaptation.copy(
                    decision = decision.copy(
                        action = cappedAction,
                        adaptationConfidence = cappedConfidence,
                        reasons = (decision.reasons + LIMITED_COMPARABILITY_TAG).distinct()
                    ),
                    trendReasons = (adaptation.trendReasons + LIMITED_COMPARABILITY_TAG).distinct()
                )
            }
            SessionComparabilityStatus.HIGHLY_COMPARABLE, SessionComparabilityStatus.COMPARABLE -> adaptation
        }
    }
}
