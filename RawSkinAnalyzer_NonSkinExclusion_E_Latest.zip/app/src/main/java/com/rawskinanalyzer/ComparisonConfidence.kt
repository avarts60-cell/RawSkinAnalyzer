package com.rawskinanalyzer

/**
 * BATCH 4A — STEP 3: comparison confidence.
 *
 * Audit finding: `SkinProgressTracker.comparisonConfidence()` already exists but only ever
 * returns two buckets ("HIGH_COMPARISON_CONFIDENCE" / "MODERATE_OR_LOWER_COMPARISON_CONFIDENCE")
 * derived solely from each session's own `AnalysisConfidenceScorer` level — it has never known
 * about capture-condition consistency or session comparability at all. That existing field is
 * left untouched (still computed and still shown by `ProgressScreen`); this file adds a
 * separate, more granular confidence specifically in the observed CHANGE, folding in
 * `SessionComparabilityResult` — the piece `SkinProgressTracker` structurally cannot see,
 * since it never received comparability information as an input.
 *
 * SESSION CONFIDENCE (`AnalysisConfidenceScorer`/`SkinProgressSnapshot.confidence`) describes
 * how much either individual session's own measurements can be trusted. COMPARISON CONFIDENCE,
 * here, describes something different: how much the *delta* between two sessions can be
 * trusted as reflecting a real difference rather than measurement noise or a confound. Two
 * HIGH-confidence sessions captured under inconsistent lighting can still yield a
 * LOW-comparison-confidence change; this is the case the existing two-bucket field could not
 * represent.
 */
enum class ComparisonConfidenceLevel { HIGH, MODERATE, LOW, INSUFFICIENT }

data class ComparisonConfidenceResult(
    val level: ComparisonConfidenceLevel,
    val reasons: List<String>
)

object ComparisonConfidencePolicy {

    fun evaluate(
        comparability: SessionComparabilityResult,
        previousSessionConfidence: String,
        currentSessionConfidence: String
    ): ComparisonConfidenceResult {
        if (comparability.status == SessionComparabilityStatus.NOT_COMPARABLE) {
            return ComparisonConfidenceResult(
                ComparisonConfidenceLevel.INSUFFICIENT,
                comparability.reasons + "SESSIONS_NOT_COMPARABLE"
            )
        }

        // Base confidence is never higher than the weaker of the two individual session
        // confidences — comparison confidence cannot exceed what either session alone
        // supports — then the comparability status can only cap it further, never raise it.
        val base = weaker(previousSessionConfidence, currentSessionConfidence)
        val capped = when (comparability.status) {
            SessionComparabilityStatus.HIGHLY_COMPARABLE -> base
            SessionComparabilityStatus.COMPARABLE -> cap(base, ComparisonConfidenceLevel.MODERATE)
            SessionComparabilityStatus.LIMITED_COMPARABILITY -> cap(base, ComparisonConfidenceLevel.LOW)
            SessionComparabilityStatus.NOT_COMPARABLE -> ComparisonConfidenceLevel.INSUFFICIENT
        }

        val reasons = mutableListOf(
            "BASE_FROM_SESSION_CONFIDENCE_${previousSessionConfidence.uppercase()}_${currentSessionConfidence.uppercase()}"
        )
        reasons += comparability.reasons
        if (capped != base) reasons += "CAPPED_BY_COMPARABILITY_${comparability.status}"

        return ComparisonConfidenceResult(capped, reasons)
    }

    private fun weaker(a: String, b: String): ComparisonConfidenceLevel {
        val la = toLevel(a)
        val lb = toLevel(b)
        return if (la.ordinal >= lb.ordinal) la else lb // higher ordinal = weaker, see order below
    }

    // Ordinal order below (HIGH, MODERATE, LOW, INSUFFICIENT) means larger ordinal = weaker,
    // so "weaker" picks the max ordinal — the more conservative of the two.
    private fun toLevel(confidence: String): ComparisonConfidenceLevel =
        when (confidence.uppercase()) {
            "HIGH" -> ComparisonConfidenceLevel.HIGH
            "MODERATE" -> ComparisonConfidenceLevel.MODERATE
            "LOW" -> ComparisonConfidenceLevel.LOW
            else -> ComparisonConfidenceLevel.INSUFFICIENT
        }

    private fun cap(level: ComparisonConfidenceLevel, ceiling: ComparisonConfidenceLevel): ComparisonConfidenceLevel =
        if (level.ordinal >= ceiling.ordinal) level else ceiling

    fun json(x: ComparisonConfidenceResult): String {
        val r = x.reasons.joinToString(",") { "\"$it\"" }
        return """{"level":"${x.level}","reasons":[$r],"medical_diagnosis":false}"""
    }
}
