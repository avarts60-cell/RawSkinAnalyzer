package com.rawskinanalyzer

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min

/**
 * ConnectedComponentExtractor
 *
 * Batch 4D-D. Shared by every detector (step_1's candidate morphology fields — boundingBox,
 * centroid, area, perimeter, aspectRatio — must come from actual connected structure, not a
 * single flagged cell). Given a boolean grid-cell mask (each detector builds its own from
 * [SignalGrid] signals), runs 8-connected flood-fill labeling and reports the geometric
 * properties step_1/step_2 ask for. This is one shared, reusable implementation rather than
 * each detector re-deriving shape statistics independently.
 */
data class GridComponent(
    val cells: List<Pair<Int, Int>>, // (row, col)
    val minRow: Int, val maxRow: Int, val minCol: Int, val maxCol: Int,
    val area: Int,
    val perimeter: Int,
    val centroidRow: Double,
    val centroidCol: Double,
    val boundingWidth: Int,
    val boundingHeight: Int,
    val aspectRatio: Double,
    /** 4*pi*area / perimeter^2, clamped to [0,1]. 1.0 = a perfect circle; low values = elongated/irregular. */
    val circularity: Double,
    /** boundingBox long-side / short-side; >=1, higher = more elongated (hair/stubble-like). */
    val elongation: Double
)

object ConnectedComponentExtractor {

    /** [mask]\[row]\[col] true = candidate cell. [minArea]/[maxArea] bound which components are returned (in grid cells), so single-noise-cell blobs and whole-tile-spanning masks are both discarded before they reach a detector's confidence scoring. */
    fun extract(mask: Array<BooleanArray>, rows: Int, cols: Int, minArea: Int = 1, maxArea: Int = Int.MAX_VALUE): List<GridComponent> {
        val visited = Array(rows) { BooleanArray(cols) }
        val components = mutableListOf<GridComponent>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (!mask[r][c] || visited[r][c]) continue
                val cells = mutableListOf<Pair<Int, Int>>()
                val stack = ArrayDeque<Pair<Int, Int>>()
                stack.addLast(r to c)
                visited[r][c] = true
                while (stack.isNotEmpty()) {
                    val (cr, cc) = stack.removeLast()
                    cells.add(cr to cc)
                    for (dr in -1..1) for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val nr = cr + dr; val nc = cc + dc
                        if (nr in 0 until rows && nc in 0 until cols && !visited[nr][nc] && mask[nr][nc]) {
                            visited[nr][nc] = true
                            stack.addLast(nr to nc)
                        }
                    }
                }
                if (cells.size < minArea || cells.size > maxArea) continue
                components.add(buildComponent(cells))
            }
        }
        return components
    }

    private fun buildComponent(cells: List<Pair<Int, Int>>): GridComponent {
        val minRow = cells.minOf { it.first }; val maxRow = cells.maxOf { it.first }
        val minCol = cells.minOf { it.second }; val maxCol = cells.maxOf { it.second }
        val area = cells.size
        val centroidRow = cells.sumOf { it.first }.toDouble() / area
        val centroidCol = cells.sumOf { it.second }.toDouble() / area
        val cellSet = cells.toHashSet()
        // Perimeter: count of cell edges whose 4-neighbor is NOT in the component (a discrete boundary length).
        var perimeter = 0
        for ((cr, cc) in cells) {
            for ((dr, dc) in listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)) {
                if ((cr + dr to cc + dc) !in cellSet) perimeter++
            }
        }
        val boundingWidth = maxCol - minCol + 1
        val boundingHeight = maxRow - minRow + 1
        val aspectRatio = boundingWidth.toDouble() / max(1, boundingHeight)
        val circularity = if (perimeter > 0) min(1.0, (4.0 * PI * area) / (perimeter.toDouble() * perimeter.toDouble())) else 0.0
        val longSide = max(boundingWidth, boundingHeight).toDouble()
        val shortSide = max(1, min(boundingWidth, boundingHeight)).toDouble()
        val elongation = longSide / shortSide
        return GridComponent(
            cells = cells, minRow = minRow, maxRow = maxRow, minCol = minCol, maxCol = maxCol,
            area = area, perimeter = perimeter, centroidRow = centroidRow, centroidCol = centroidCol,
            boundingWidth = boundingWidth, boundingHeight = boundingHeight,
            aspectRatio = aspectRatio, circularity = circularity, elongation = elongation
        )
    }
}
