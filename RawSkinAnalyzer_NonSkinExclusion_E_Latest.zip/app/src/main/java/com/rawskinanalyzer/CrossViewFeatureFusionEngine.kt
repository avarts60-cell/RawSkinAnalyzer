package com.rawskinanalyzer

/**
 * CrossViewFeatureFusionEngine
 *
 * Batch 4D-G, step_4/step_5 (P0). Consumes [FeatureCorrespondence] records (never raw candidates
 * directly — correspondence is the ONLY thing this engine trusts to say "these belong together")
 * and produces one [FusedFeatureEvidence] per correspondence, plus per-region [RegionalFusedMetrics]
 * rolled up from those.
 *
 * Fusion weighting (step_4's own requirements, each mapped to a concrete line below):
 *  - "Weight evidence by feature confidence" / "usable-skin confidence": each per-view
 *    contribution is weighted by `confidence * (skinConfidence/100)` — a view with a strong
 *    reading on non-skin-confident pixels does not dominate the fused result.
 *  - "Do not let a weak view erase strong evidence": this is a WEIGHTED AVERAGE, never a min() or
 *    an override — a low-confidence view simply contributes proportionally little, it can never
 *    pull a strong reading down to its own level or vice versa in an all-or-nothing way.
 *  - "Do not convert missing evidence into negative evidence": a view simply absent from
 *    `perViewEvidence` contributes nothing to the weighted average (there is no "0 confidence for
 *    the missing view" term) — this is a straightforward consequence of computing the average
 *    only over `sourceFeatures` that actually exist, but is called out explicitly since it would
 *    be an easy mistake to average over 3 view-slots with silent zeros.
 *  - "Consider capture quality": `FeatureCorrespondence.captureQuality` (this session's
 *    `ThreeViewCaptureConditionAnalyzer` consistency string) applies a single small multiplicative
 *    discount to fused confidence when capture conditions were inconsistent across views —
 *    appropriate for a session-wide caveat, not a per-candidate judgment this engine has no basis
 *    to make more precisely.
 */

data class PerViewFeatureEvidenceRef(
    val candidateId: String,
    val view: String,
    val confidence: Double,
    val area: Int,
    val skinConfidence: Double
)

data class FusedFeatureEvidence(
    val fusionId: String,
    val correspondenceId: String,
    val featureType: SpecializedFeatureType,
    val anatomicalRegion: AnatomicalRegion,
    val fusedConfidence: Double,
    val supportingViews: List<String>,
    val regionalLocation: NormalizedPosition,
    val perViewEvidence: List<PerViewFeatureEvidenceRef>,
    /** Confidence-and-skin-weighted mean of per-view AREA (original-image pixels). Not corrected
     * for any view-to-view scale/resolution difference — see [FeatureCorrespondence]'s own
     * `normalizedSizeApproximate` doc comment for the same caveat. */
    val fusedApparentSizeApproximate: Double,
    val correspondenceState: CorrespondenceState
)

data class RegionalFusedMetrics(
    val region: AnatomicalRegion,
    val rawFeatureCount: Int,
    val fusedFeatureCount: Int,
    val crossViewSupportedCount: Int,
    val meanFusedConfidence: Double,
    val meanApparentSize: Double,
    /** Mean, across the views that actually contributed a `regionSkinCoverage` for this region
     * (from `MultiScaleTileSet`), of that coverage fraction — 0.0 when none available. */
    val meanRegionSkinCoverage: Double,
    /** fusedFeatureCount per 1.0 of meanRegionSkinCoverage — 0.0 when coverage is 0 (avoids a
     * divide-by-zero implying infinite density on an unmeasured region rather than "unknown"). */
    val densityPerUnitSkinCoverage: Double
)

object CrossViewFeatureFusionEngine {
    const val VERSION = "cross_view_feature_fusion_engine_v1"

    private val consistencyDiscount = mapOf(
        "HIGH_CAPTURE_CONDITION_CONSISTENCY" to 1.0,
        "MODERATE_CAPTURE_CONDITION_VARIATION" to 0.92,
        "MAJOR_CAPTURE_CONDITION_INCONSISTENCY" to 0.8
    )

    fun fuse(correspondences: List<FeatureCorrespondence>, evidenceById: Map<String, SpecializedFeatureEvidence>): List<FusedFeatureEvidence> {
        return correspondences.mapIndexedNotNull { idx, c ->
            val perView = c.sourceFeatures.mapNotNull { id ->
                evidenceById[id]?.let { e -> PerViewFeatureEvidenceRef(id, e.sourceView, e.primaryConfidence, e.area, e.skinConfidence) }
            }
            if (perView.isEmpty()) return@mapIndexedNotNull null // source evidence not found (should not normally happen; defensive, not silently faked)

            val weights = perView.map { it.confidence * (it.skinConfidence / 100.0).coerceIn(0.0, 1.0) }
            val weightSum = weights.sum()
            val fusedConfidenceRaw = if (weightSum > 0.0) {
                perView.indices.sumOf { i -> weights[i] * perView[i].confidence } / weightSum
            } else {
                perView.map { it.confidence }.average()
            }
            val discount = consistencyDiscount[c.captureQuality] ?: 1.0
            val fusedConfidence = (fusedConfidenceRaw * discount).coerceIn(0.0, 1.0)

            val fusedSize = if (weightSum > 0.0) {
                perView.indices.sumOf { i -> weights[i] * perView[i].area } / weightSum
            } else {
                perView.map { it.area }.average()
            }

            FusedFeatureEvidence(
                fusionId = "${c.anatomicalRegion}_fused$idx",
                correspondenceId = c.correspondenceId,
                featureType = c.featureType,
                anatomicalRegion = c.anatomicalRegion,
                fusedConfidence = fusedConfidence,
                supportingViews = c.supportingViews,
                regionalLocation = c.normalizedLocation,
                perViewEvidence = perView,
                fusedApparentSizeApproximate = fusedSize,
                correspondenceState = c.state
            )
        }
    }

    fun regionalMetrics(
        fused: List<FusedFeatureEvidence>,
        rawEvidence: List<SpecializedFeatureEvidence>,
        regionSkinCoverage: Map<AnatomicalRegion, List<Double>>
    ): List<RegionalFusedMetrics> {
        val regions = (fused.map { it.anatomicalRegion } + rawEvidence.map { it.anatomicalRegion }).distinct()
        return regions.map { region ->
            val fusedInRegion = fused.filter { it.anatomicalRegion == region }
            val rawCount = rawEvidence.count { it.anatomicalRegion == region }
            val crossViewSupported = fusedInRegion.count { it.supportingViews.size >= 2 }
            val coverageSamples = regionSkinCoverage[region].orEmpty()
            val meanCoverage = if (coverageSamples.isNotEmpty()) coverageSamples.average() else 0.0
            val density = if (meanCoverage > 0.0) fusedInRegion.size / meanCoverage else 0.0
            RegionalFusedMetrics(
                region = region,
                rawFeatureCount = rawCount,
                fusedFeatureCount = fusedInRegion.size,
                crossViewSupportedCount = crossViewSupported,
                meanFusedConfidence = if (fusedInRegion.isEmpty()) 0.0 else fusedInRegion.map { it.fusedConfidence }.average(),
                meanApparentSize = if (fusedInRegion.isEmpty()) 0.0 else fusedInRegion.map { it.fusedApparentSizeApproximate }.average(),
                meanRegionSkinCoverage = meanCoverage,
                densityPerUnitSkinCoverage = density
            )
        }
    }

    fun fusedJson(f: FusedFeatureEvidence): String {
        val views = f.supportingViews.joinToString(",") { "\"${it}\"" }
        val perView = f.perViewEvidence.joinToString(",") {
            """{"candidate_id":"${it.candidateId}","view":"${it.view}","confidence":${it.confidence},"area":${it.area},"skin_confidence":${it.skinConfidence}}"""
        }
        return """{"fusion_id":"${f.fusionId}","correspondence_id":"${f.correspondenceId}","feature_type":"${f.featureType}","anatomical_region":"${f.anatomicalRegion}","fused_confidence":${f.fusedConfidence},"supporting_views":[$views],"regional_location":${FeatureCorrespondenceJson.normalizedPositionJson(f.regionalLocation)},"per_view_evidence":[$perView],"fused_apparent_size_approximate":${f.fusedApparentSizeApproximate},"correspondence_state":"${f.correspondenceState}"}"""
    }

    fun regionalMetricsJson(m: RegionalFusedMetrics): String =
        """{"region":"${m.region}","raw_feature_count":${m.rawFeatureCount},"fused_feature_count":${m.fusedFeatureCount},"cross_view_supported_count":${m.crossViewSupportedCount},"mean_fused_confidence":${m.meanFusedConfidence},"mean_apparent_size":${m.meanApparentSize},"mean_region_skin_coverage":${m.meanRegionSkinCoverage},"density_per_unit_skin_coverage":${m.densityPerUnitSkinCoverage}}"""

    fun json(fused: List<FusedFeatureEvidence>, metrics: List<RegionalFusedMetrics>): String {
        val fj = fused.joinToString(",") { fusedJson(it) }
        val mj = metrics.joinToString(",") { regionalMetricsJson(it) }
        return """{"method":"$VERSION","fused_count":${fused.size},"fused_features":[$fj],"regional_metrics":[$mj]}"""
    }
}
