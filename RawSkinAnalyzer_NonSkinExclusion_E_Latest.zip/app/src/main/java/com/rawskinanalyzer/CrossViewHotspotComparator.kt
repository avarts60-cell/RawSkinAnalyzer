package com.rawskinanalyzer

data class HotspotComparison(
    val result:String,
    val frontCount:Int,
    val leftCount:Int,
    val rightCount:Int,
    val sharedTypeCount:Int,
    val evidenceScore:Double
)

object CrossViewHotspotComparator {
    fun compare(
        front:List<PatternHotspot>,
        left:List<PatternHotspot>,
        right:List<PatternHotspot>
    ):HotspotComparison {
        val all=listOf(front,left,right)
        val nonEmpty=all.count{it.isNotEmpty()}
        if(nonEmpty < 2) return HotspotComparison(
            "INSUFFICIENT_COMPARISON_DATA",front.size,left.size,right.size,0,0.0)

        fun types(x:List<PatternHotspot>)=x.map{it.type}.toSet()
        val sets=all.map(::types)
        val sharedAll=sets.reduce{a,b->a.intersect(b)}
        val sharedPairs=maxOf(
            sets[0].intersect(sets[1]).size,
            sets[0].intersect(sets[2]).size,
            sets[1].intersect(sets[2]).size
        )
        val result=when {
            sharedAll.isNotEmpty() && nonEmpty==3 -> "CONSISTENT_ACROSS_VIEWS"
            sharedPairs>0 -> "PARTIALLY_CONSISTENT"
            else -> "VIEW_SPECIFIC"
        }
        val totalTypes=sets.flatMap{it}.toSet().size
        val score=when {
            totalTypes==0 -> 0.0
            result=="CONSISTENT_ACROSS_VIEWS" -> 100.0
            result=="PARTIALLY_CONSISTENT" -> (sharedPairs.toDouble()/totalTypes*100.0)
            else -> 0.0
        }
        return HotspotComparison(result,front.size,left.size,right.size,
            maxOf(sharedAll.size,sharedPairs),score)
    }

    fun json(x:HotspotComparison)=
        """{"result":"${x.result}","front_hotspot_count":${x.frontCount},"left_cheek_hotspot_count":${x.leftCount},"right_cheek_hotspot_count":${x.rightCount},"shared_type_count":${x.sharedTypeCount},"evidence_score":${x.evidenceScore},"method":"cross_view_hotspot_comparison_v1","medical_diagnosis":false}"""
}
