package com.rawskinanalyzer

data class SpatialAgreementResult(
    val result:String,
    val comparableCells:Int,
    val agreeingCells:Int,
    val agreementPercent:Double
)

object CrossViewSpatialAgreementAnalyzer {
    private fun elevated(c:PatternMapCell, all:List<PatternMapCell>):Boolean {
        val usable=all.filter{it.skinPercent>=10.0}
        if(usable.isEmpty()) return false
        val l=usable.map{it.meanLuma}.average()
        val r=usable.map{it.redness}.average()
        val t=usable.map{it.texture}.average()
        return c.meanLuma<l-18.0 || c.redness>r+8.0 || c.texture>t+12.0
    }

    fun analyze(front:List<PatternMapCell>, left:List<PatternMapCell>, right:List<PatternMapCell>):SpatialAgreementResult {
        var comparable=0; var agreeing=0
        val n=minOf(front.size,left.size,right.size)
        for(i in 0 until n){
            val cells=listOf(front[i],left[i],right[i])
            if(cells.count{it.skinPercent>=10.0}<2) continue
            comparable++
            val hits=cells.count{elevated(it, when(it){front[i]->front; left[i]->left; else->right})}
            if(hits>=2) agreeing++
        }
        val pct=if(comparable==0) 0.0 else agreeing*100.0/comparable
        val result=when {
            comparable<4 -> "INSUFFICIENT_SPATIAL_DATA"
            pct>=60.0 -> "HIGH_SPATIAL_AGREEMENT"
            pct>=25.0 -> "MODERATE_SPATIAL_AGREEMENT"
            else -> "LOW_SPATIAL_AGREEMENT"
        }
        return SpatialAgreementResult(result,comparable,agreeing,pct)
    }

    fun json(x:SpatialAgreementResult)=
        """{"result":"${x.result}","comparable_cells":${x.comparableCells},"agreeing_cells":${x.agreeingCells},"agreement_percent":${x.agreementPercent},"method":"cross_view_spatial_agreement_v1","medical_diagnosis":false}"""
}
