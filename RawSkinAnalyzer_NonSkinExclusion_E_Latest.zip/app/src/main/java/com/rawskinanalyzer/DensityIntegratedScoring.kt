package com.rawskinanalyzer

/**
 * BATCH 4E-B, step_1 — TRUE DENSITY INTEGRATION.
 * BATCH 4E-C, step_1 — CANDIDATE-QUALITY-GATED DENSITY (this update).
 *
 * Batch 4E-A built a real usable-skin-area denominator (`UsableSkinAreaCalculator`) and wired
 * it into `SpecializedRegionalMetric.densityPerMillionUsableSkinPixels` /
 * `RegionalShineSummary.densityPerMillionUsableSkinPixels`. Batch 4E-B, step_1 (this file) then
 * connected that real density into the production scoring path (`FinalSkinAnalysisProfileAnalyzer`,
 * which actually produces the `PORE_LIKE_FEATURES` / `BLEMISH_LIKE_FEATURES` / `DARK_MARK_SIGNAL` /
 * `REDNESS` / `SURFACE_SHINE_SIGNAL` findings the app ships) — but at that point the density figure
 * it read was still the RAW, ungated candidate count: a REJECTed candidate (per
 * `CandidateQualityGate`, wired as a separate diagnostics-only step in Batch 4E-B's own
 * continuation) still counted fully toward `densityPerMillionUsableSkinPixels`, and a WEIGHTed
 * candidate counted as a full 1.0 instead of its gate weight. This update closes exactly that gap
 * (Batch 4E-C's own step_1, and the prior batch's own recorded "Exact next implementation step"):
 * it now prefers `SpecializedRegionalMetric.qualityGatedDensityPerMillionUsableSkinPixels`
 * (numerator = `CandidateQualityGate`'s `qualityWeightedTotal`, so REJECT contributes 0.0 and
 * WEIGHT contributes only its own multiplier) wherever that field is available, falling back to
 * the raw density only when it is not (currently: shine, since `ShineCandidate` has no
 * `SpecializedFeatureEvidence` counterpart and is therefore not evaluated by
 * `CandidateQualityGate` at all — see this file's own "What this deliberately does NOT do" below).
 *
 * What this deliberately does NOT do:
 * - It never replaces the base calibrated score (`SkinScoreCalibration`) — only nudges it, capped
 *   at [MAX_DENSITY_NUDGE] points, per this batch's "do not silently change unrelated score
 *   semantics" / "cannot increase confidence beyond the underlying evidence" rules.
 * - It never fabricates evidence: a characteristic with no matching regional metrics, or where
 *   every matching metric has `densityPerMillionUsableSkinPixels == null` (usable area was zero
 *   or unavailable in that region), is left completely untouched — not nudged toward 0.
 * - It never discards the raw density figure: `SpecializedRegionalMetric.
 *   densityPerMillionUsableSkinPixels` is completely unmodified by this batch (see that file);
 *   this class only changes which of the two already-separate fields it reads to compute the
 *   nudge, and records in `FinalScoreProvenance`'s `selectionReason` which one was actually used
 *   for each nudged characteristic, per "raw and quality-gated measurements remain separate."
 * - It does not extend `CandidateQualityGate` to shine or bump candidates (`ShineCandidate` /
 *   `BumpCandidate` are their own models, not `SpecializedFeatureEvidence`) — doing so would mean
 *   either building a second gate (explicitly disallowed) or materially reshaping the existing
 *   gate's signature, and is out of this step's scope. Shine's nudge therefore still falls back to
 *   its raw (ungated) density this batch; bumps have no characteristic-score integration at all
 *   (raw or gated) either before or after this change, since `characteristicSupportMap` never
 *   included a bump-backed characteristic. Both are documented, not silent, gaps.
 * - `TEXTURE_IRREGULARITY` is intentionally NOT integrated here. No `SpecializedFeatureType`
 *   represents general texture irregularity (only pore-like structure is separately classified —
 *   see `FeatureSeparationEngine`), so there is no real per-candidate density evidence for it to
 *   integrate; inventing one would mean nudging toward a proxy that isn't actually about texture.
 *   This is a real, honest scope boundary, not an oversight (see PROJECT_STATUS.md).
 */
object DensityIntegratedScoring {
    const val VERSION = "DENSITY_INTEGRATION_V1"

    /** Same cap magnitude as the two existing high-resolution-evidence nudges in this project. */
    private const val MAX_DENSITY_NUDGE = 8.0

    /**
     * Heuristic reference density (candidates per ~1 megapixel of usable skin) treated as a
     * "very high" density signal (100 on the 0-100 comparison scale used to compute the nudge
     * direction/magnitude below). This is an uncalibrated engineering starting point — there is
     * no ground-truth dataset in this project to calibrate it against, consistent with every
     * other heuristic constant here (e.g. `SkinScoreCalibration`'s own weights). It only affects
     * the DIRECTION and size of a capped nudge, never the base score itself.
     */
    private const val REFERENCE_DENSITY_PER_MILLION_PIXELS = 40.0

    /**
     * Maps each production characteristic name to the specialized-feature types that provide it
     * real per-candidate density evidence. Mirrors
     * `SkinCharacteristicScoringAnalyzer.highResSupportMap`'s pattern, but against the actual
     * production characteristic names `SkinScoreCalibration`/`FinalSkinAnalysisProfileAnalyzer`
     * use (which differ from that other, secondary scoring path's names).
     */
    private val characteristicSupportMap: Map<String, Set<SpecializedFeatureType>> = mapOf(
        "PORE_LIKE_FEATURES" to setOf(
            SpecializedFeatureType.PORE_LIKE, SpecializedFeatureType.FOLLICULAR_OPENING_LIKE
        ),
        "BLEMISH_LIKE_FEATURES" to setOf(
            SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.BLACKHEAD_LIKE,
            SpecializedFeatureType.WHITEHEAD_LIKE, SpecializedFeatureType.PAPULE_LIKE_VISUAL,
            SpecializedFeatureType.PUSTULE_LIKE_VISUAL
        ),
        "DARK_MARK_SIGNAL" to setOf(
            SpecializedFeatureType.DARK_MARK_LIKE, SpecializedFeatureType.POST_ACNE_MARK_LIKE,
            SpecializedFeatureType.RED_MARK_LIKE, SpecializedFeatureType.PIGMENTATION_LIKE
        ),
        "REDNESS" to setOf(SpecializedFeatureType.LOCALIZED_REDNESS_LIKE)
        // SURFACE_SHINE_SIGNAL is handled separately below via RegionalShineSummary — shine has
        // no SpecializedFeatureType of its own (ShineDetectionEngine is a dedicated model, see
        // Batch 4D-F). TEXTURE_IRREGULARITY intentionally absent — see class doc above.
    )

    data class DensityEvidence(
        /** Raw (ungated) mean density — unchanged in meaning from Batch 4E-B, kept for
         * provenance/diagnostics even when the quality-gated figure below drives the actual nudge. */
        val meanDensityPerMillionUsableSkinPixels: Double,
        /** Batch 4E-C addition. Mean of `qualityGatedDensityPerMillionUsableSkinPixels` across the
         * same supporting regions as the raw mean above; null when no supporting region has that
         * field populated (currently: shine, which has no `CandidateQualityGate` integration — see
         * class doc). Always <= [meanDensityPerMillionUsableSkinPixels] when non-null, since a
         * REJECTed candidate contributes 0.0 and a WEIGHTed one contributes only its own weight. */
        val meanQualityGatedDensityPerMillionUsableSkinPixels: Double?,
        val supportingRegionCount: Int,
        val regionsWithoutUsableArea: Int,
        /** How many of [supportingRegionCount] regions actually had a quality-gated density figure
         * (vs. only the raw one). 0 for shine; equal to [supportingRegionCount] for every
         * specialized-feature characteristic today, since raw and quality-gated density share the
         * same null-vs-non-null usable-area gate. */
        val qualityGatedRegionCount: Int
    ) {
        /** True when this evidence's nudge is actually being computed from gated density rather
         * than falling back to the raw, ungated figure. */
        val usesQualityGatedDensity: Boolean get() = meanQualityGatedDensityPerMillionUsableSkinPixels != null
    }

    private fun clamp(v: Double) = v.coerceIn(0.0, 100.0)

    private fun level(score: Double) = when {
        score >= 60.0 -> "HIGH_SIGNAL"
        score >= 30.0 -> "MODERATE_SIGNAL"
        score >= 12.0 -> "LOW_SIGNAL"
        else -> "MINIMAL_SIGNAL"
    }

    private fun evidenceFromMetrics(metrics: List<SpecializedRegionalMetric>): DensityEvidence? {
        if (metrics.isEmpty()) return null
        val withDensity = metrics.filter { it.densityPerMillionUsableSkinPixels != null }
        if (withDensity.isEmpty()) return null
        // Batch 4E-C, step_1: quality-gated density shares the exact same null-vs-non-null gate
        // as the raw density it's derived from (both come from the same `usableArea` check in
        // SpecializedFeatureEvidenceAssembler.regionalMetrics), so this is never a mismatched
        // subset in today's codebase -- filtered independently anyway so this stays correct even
        // if that invariant changes later.
        val withQualityGatedDensity = withDensity.filter { it.qualityGatedDensityPerMillionUsableSkinPixels != null }
        return DensityEvidence(
            meanDensityPerMillionUsableSkinPixels = withDensity.map { it.densityPerMillionUsableSkinPixels!! }.average(),
            meanQualityGatedDensityPerMillionUsableSkinPixels = if (withQualityGatedDensity.isEmpty()) null
                else withQualityGatedDensity.map { it.qualityGatedDensityPerMillionUsableSkinPixels!! }.average(),
            supportingRegionCount = withDensity.size,
            regionsWithoutUsableArea = metrics.size - withDensity.size,
            qualityGatedRegionCount = withQualityGatedDensity.size
        )
    }

    private fun evidenceFromShine(summaries: List<RegionalShineSummary>): DensityEvidence? {
        if (summaries.isEmpty()) return null
        val withDensity = summaries.filter { it.densityPerMillionUsableSkinPixels != null }
        if (withDensity.isEmpty()) return null
        // Shine has no CandidateQualityGate integration (RegionalShineSummary carries no
        // quality-gate fields -- ShineCandidate is a separate model, never wrapped as
        // SpecializedFeatureEvidence). meanQualityGatedDensityPerMillionUsableSkinPixels is
        // therefore always null here, so nudgedScore below honestly falls back to raw density for
        // SURFACE_SHINE_SIGNAL specifically -- not silently treated as gated.
        return DensityEvidence(
            meanDensityPerMillionUsableSkinPixels = withDensity.map { it.densityPerMillionUsableSkinPixels!! }.average(),
            meanQualityGatedDensityPerMillionUsableSkinPixels = null,
            supportingRegionCount = withDensity.size,
            regionsWithoutUsableArea = summaries.size - withDensity.size,
            qualityGatedRegionCount = 0
        )
    }

    /** Returns the nudged score; null evidence means "leave the base score untouched". Prefers
     * quality-gated density (a REJECTed candidate contributes 0.0, a WEIGHTed one contributes only
     * its weight) over the raw count, falling back to raw only when no quality-gated figure is
     * available for this evidence (currently: shine only — see [evidenceFromShine]). */
    private fun nudgedScore(baseScore: Double, evidence: DensityEvidence): Double {
        val effectiveDensity = evidence.meanQualityGatedDensityPerMillionUsableSkinPixels
            ?: evidence.meanDensityPerMillionUsableSkinPixels
        val densitySignal = clamp(effectiveDensity / REFERENCE_DENSITY_PER_MILLION_PIXELS * 100.0)
        val delta = ((densitySignal - baseScore) * 0.15).coerceIn(-MAX_DENSITY_NUDGE, MAX_DENSITY_NUDGE)
        return clamp(baseScore + delta)
    }

    /**
     * Additive precision layer over an already-computed [base] profile. Never recomputes
     * `RednessAnalysisAnalyzer`/`BlemishFeatureAnalyzer`/`TexturePoreFeatureAnalyzer`/
     * `SurfaceConditionAnalyzer`/`PigmentationTanningAnalyzer` — only reads their already-scored
     * output and nudges it toward real density evidence where that evidence exists. Registers an
     * updated `FinalScoreProvenance` entry for every characteristic actually nudged, carrying the
     * pre-nudge score forward as `replacedScore` so provenance is preserved, not lost, per this
     * batch's "preserve existing score provenance" / "preserve confidence separately from score"
     * rules — confidence itself is never touched here.
     */
    fun apply(
        base: FinalSkinAnalysisProfile,
        specializedRegionalMetrics: List<SpecializedRegionalMetric>,
        shineRegionalSummaries: List<RegionalShineSummary>
    ): FinalSkinAnalysisProfile {
        if (specializedRegionalMetrics.isEmpty() && shineRegionalSummaries.isEmpty()) return base

        val metricsByCharacteristic = characteristicSupportMap.mapValues { (_, types) ->
            specializedRegionalMetrics.filter { it.featureType in types }
        }

        var nudgedFindings = base.findings.map { f ->
            val evidence = if (f.characteristic == "SURFACE_SHINE_SIGNAL") {
                evidenceFromShine(shineRegionalSummaries)
            } else {
                metricsByCharacteristic[f.characteristic]?.let { evidenceFromMetrics(it) }
            } ?: return@map f

            val newScore = nudgedScore(f.score, evidence)
            // Preserve the base analyzer's own provenance stage in the combined sourceStage
            // string rather than overwriting it outright, per "preserve existing score
            // provenance" — a reader of FinalScoreProvenance can still see which analyzer
            // produced the pre-nudge score, not just that a nudge happened.
            val baseStage = FinalScoreRegistry.get(f.characteristic)?.sourceStage ?: "unknown_base_stage"
            FinalScoreRegistry.register(
                f.characteristic, newScore, "$baseStage + DensityIntegratedScoring",
                sourceScore = newScore, replacedScore = f.score,
                selectionReason = "Nudged toward " +
                    (if (evidence.usesQualityGatedDensity)
                        "candidate-quality-gated usable-skin-area density (${evidence.qualityGatedRegionCount} region(s); " +
                            "REJECTed candidates contribute 0, WEIGHTed candidates contribute only their gate weight)"
                     else
                        "raw usable-skin-area candidate density (quality-gated density not available for this feature type)") +
                    " (${evidence.supportingRegionCount} region(s) with measurable usable area" +
                    if (evidence.regionsWithoutUsableArea > 0) ", ${evidence.regionsWithoutUsableArea} without)" else ")"
            )
            f.copy(
                score = newScore,
                level = level(newScore),
                hasHighResolutionDensityEvidence = true,
                highResolutionDensitySupportingRegionCount = evidence.supportingRegionCount
            )
        }
        nudgedFindings = nudgedFindings.sortedByDescending { it.score }.mapIndexed { i, f -> f.copy(priority = i + 1) }

        fun scoreFor(characteristic: String, fallback: Double) =
            nudgedFindings.firstOrNull { it.characteristic == characteristic }?.score ?: fallback

        return base.copy(
            findings = nudgedFindings,
            primaryFinding = nudgedFindings.firstOrNull()?.characteristic ?: base.primaryFinding,
            secondaryFinding = nudgedFindings.getOrNull(1)?.characteristic ?: base.secondaryFinding,
            rednessScore = scoreFor("REDNESS", base.rednessScore),
            darkMarkScore = scoreFor("DARK_MARK_SIGNAL", base.darkMarkScore),
            blemishLikeScore = scoreFor("BLEMISH_LIKE_FEATURES", base.blemishLikeScore),
            poreLikeScore = scoreFor("PORE_LIKE_FEATURES", base.poreLikeScore),
            surfaceShineScore = scoreFor("SURFACE_SHINE_SIGNAL", base.surfaceShineScore)
            // pigmentationScore/textureIrregularityScore/drynessRelatedScore intentionally
            // untouched — see class doc (TEXTURE_IRREGULARITY has no density evidence source),
            // and PIGMENTATION_OR_TONE_VARIATION / DRYNESS_RELATED_SURFACE_SIGNAL are not in
            // characteristicSupportMap for the same "no fabricated evidence" reason.
        )
    }
}
