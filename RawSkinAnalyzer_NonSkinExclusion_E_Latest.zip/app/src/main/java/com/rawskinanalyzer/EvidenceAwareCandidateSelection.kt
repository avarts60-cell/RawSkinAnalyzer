package com.rawskinanalyzer

/**
 * BATCH 3A — EVIDENCE-AWARE CANDIDATE SELECTION.
 *
 * Required production flow for this file:
 * CALIBRATED_FINDINGS -> OBJECTIVE -> OBJECTIVE_STRENGTH -> EVIDENCE_LOOKUP -> CANDIDATE_SELECTION
 *
 * What "evidence" means in this codebase today: there is no clinical/scientific ingredient
 * evidence database anywhere in this project (searched; the only "evidence" entities that exist
 * are FinalScoreProvenance/FinalScoreRegistry, which record *pipeline* provenance — which
 * analyzer/stage produced a score — not clinical evidence for an ingredient's effectiveness).
 * SpecificIngredientMapper's IngredientSelectionRole (PRIMARY / SUPPORTIVE / OPTIONAL) is the
 * only existing structured signal that differentiates how strongly an ingredient option is
 * associated with a concern. This file treats that role as the existing "evidence" structure to
 * reuse, per the batch instruction "reuse existing evidence data... do not fabricate evidence."
 * `evidenceStrength` below is therefore explicitly labeled STRUCTURED_*, never a clinical/
 * percentage claim, so nothing here reads as an invented effectiveness level.
 *
 * This file does not compute score, confidence, or priority — it only reads the already-
 * calibrated SkinObjectiveType (ObjectiveStrengthPolicy, via RoutineTarget ->
 * IngredientStrategyItem -> SpecificIngredientOption) and the already-computed per-concern
 * confidence (SkinConcern.confidence) and decides, deterministically, whether a given
 * ingredient-role candidate is appropriate to select for the routine at the objective's current
 * strength.
 */

enum class CandidateSelectionStatus { SELECTED, LIMITED, DEFERRED }

data class CandidateSelectionDecision(
    val concern: SkinConcernCategory,
    val ingredientName: String,
    val role: IngredientSelectionRole,
    val objectiveType: SkinObjectiveType,
    val evidenceStrength: String,
    val selectionStatus: CandidateSelectionStatus,
    val selectionReason: String,
    val objectiveStrengthReason: String,
    val confidence: String,
    val policyVersion: String
)

object EvidenceAwareCandidateSelectionPolicy {
    const val VERSION = "EVIDENCE_AWARE_CANDIDATE_SELECTION_POLICY_V1"

    /** Objective strength, weakest (0) to strongest (3) — same ordering ObjectiveStrengthPolicy
     *  already uses, duplicated here only as an integer tier for comparison against role tier
     *  (kept local rather than exposing OBJECTIVE_TIER_ORDER from RecommendationCalibration.kt,
     *  since that list is private to that file and this session's scope is not to modify
     *  the already-completed ObjectiveStrengthPolicy). */
    private fun objectiveTier(type: SkinObjectiveType): Int = when (type) {
        SkinObjectiveType.MONITOR -> 0
        SkinObjectiveType.MAINTAIN_CURRENT_STATE -> 1
        SkinObjectiveType.SUPPORT_BALANCE -> 2
        SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE -> 3
    }

    /** Role tier, weakest (1, OPTIONAL) to strongest (3, PRIMARY). PRIMARY/SUPPORTIVE options
     *  are the well-established, first-line categories for a concern; OPTIONAL options are the
     *  ones SpecificIngredientMapper itself already annotates with a compatibility/tolerance
     *  caution (e.g. Azelaic acid as OPTIONAL for TONE_PIGMENTATION) — i.e. the existing data
     *  already marks OPTIONAL as needing more justification, this policy just acts on that. */
    private fun roleTier(role: IngredientSelectionRole): Int = when (role) {
        IngredientSelectionRole.PRIMARY -> 3
        IngredientSelectionRole.SUPPORTIVE -> 2
        IngredientSelectionRole.OPTIONAL -> 1
    }

    /** A weaker objective requires a higher (stronger) role tier to be selected: as objective
     *  strength drops from IMPROVE_VISIBLE_APPEARANCE (all roles eligible) down through
     *  MAINTAIN_CURRENT_STATE (PRIMARY only), fewer roles qualify. MONITOR requires a role tier
     *  higher than any that exists (4), so nothing is ever selected for a monitor-only
     *  objective — see the MONITOR special case in `select` for why that is DEFERRED rather
     *  than LIMITED. */
    private fun requiredRoleTier(objTier: Int): Int = 4 - objTier

    private fun evidenceStrengthFor(role: IngredientSelectionRole): String = when (role) {
        IngredientSelectionRole.PRIMARY -> "STRUCTURED_PRIMARY_ROLE_MATCH"
        IngredientSelectionRole.SUPPORTIVE -> "STRUCTURED_SUPPORTIVE_ROLE_MATCH"
        IngredientSelectionRole.OPTIONAL -> "STRUCTURED_OPTIONAL_ROLE_REVIEW_REQUIRED"
    }

    /**
     * @param options candidates from SpecificIngredientMapper.map() (already carries
     *   objectiveType/objectiveStrengthReason forwarded from the calibrated objective).
     * @param concerns SkinConcernInterpreter.fromFinalProfile() output, used only to look up
     *   this concern's own finding-level confidence and priority for explanation purposes —
     *   the confidence CAP itself was already applied upstream inside
     *   ObjectiveStrengthPolicy.calibrate when it produced option.objectiveType, so this
     *   function does not re-apply a confidence cap; it only reports which concern-level signal
     *   is present alongside the decision.
     */
    fun select(
        options: List<SpecificIngredientOption>,
        concerns: List<SkinConcern>
    ): List<CandidateSelectionDecision> {
        // First-wins lookup, matching the same "keep first occurrence" convention
        // SpecificIngredientMapper.map() already uses via distinctBy for a duplicate concern
        // category (possible when two characteristics map to the same SkinConcernCategory,
        // e.g. PORE_LIKE_FEATURES and TEXTURE_IRREGULARITY both map to PORE_TEXTURE_APPEARANCE).
        val concernByCategory = concerns.groupBy { it.category }.mapValues { it.value.first() }

        return options.map { option ->
            val concern = concernByCategory[option.concern]
            // Missing concern data is preserved explicitly (treated as the most conservative
            // value) rather than assumed away, per "preserve unknown or missing evidence
            // explicitly" — this should not normally happen since options are only ever
            // generated from items derived from these same concerns, but candidate selection
            // must not silently assume high confidence if the lookup ever fails.
            val confidence = concern?.confidence ?: "LOW"
            val priority = concern?.priority ?: Int.MAX_VALUE

            val objTier = objectiveTier(option.objectiveType)
            val rTier = roleTier(option.role)
            val evidence = evidenceStrengthFor(option.role)

            val status: CandidateSelectionStatus
            val reasons: List<String>

            if (objTier == 0) {
                // MONITOR: the calibrated objective strength itself concluded there is not yet
                // enough signal/confidence to act on this concern at all (see
                // ObjectiveStrengthPolicy.calibrate — MONITOR is the lowest score-based tier
                // and is never escalated by confidence or priority). No ingredient candidate is
                // selected or limited; this concern is deferred to a future session's re-scan.
                status = CandidateSelectionStatus.DEFERRED
                reasons = listOf("INSUFFICIENT_INFORMATION")
            } else if (rTier >= requiredRoleTier(objTier)) {
                status = CandidateSelectionStatus.SELECTED
                val targetReason =
                    if (priority <= 1) "TARGETS_PRIMARY_OBJECTIVE" else "TARGETS_SECONDARY_OBJECTIVE"
                // PRIMARY/SUPPORTIVE roles are the established options for this concern in the
                // existing ingredient map; OPTIONAL roles are selected only when the objective is
                // strong enough to require the required tier of 1, but still are not tagged
                // SUPPORTED_BY_EVIDENCE since their own structural evidence tier is the weakest.
                reasons = if (option.role != IngredientSelectionRole.OPTIONAL) {
                    listOf(targetReason, "SUPPORTED_BY_EVIDENCE")
                } else {
                    listOf(targetReason)
                }
            } else {
                status = CandidateSelectionStatus.LIMITED
                reasons = when {
                    confidence == "LOW" -> listOf("LIMITED_BY_CONFIDENCE")
                    option.role == IngredientSelectionRole.OPTIONAL -> listOf("LIMITED_BY_LOW_EVIDENCE")
                    else -> listOf("LIMITED_BY_OBJECTIVE_STRENGTH")
                }
            }

            CandidateSelectionDecision(
                concern = option.concern,
                ingredientName = option.ingredientName,
                role = option.role,
                objectiveType = option.objectiveType,
                evidenceStrength = evidence,
                selectionStatus = status,
                selectionReason = reasons.joinToString("; "),
                objectiveStrengthReason = option.objectiveStrengthReason,
                confidence = confidence,
                policyVersion = VERSION
            )
        }
    }
}
