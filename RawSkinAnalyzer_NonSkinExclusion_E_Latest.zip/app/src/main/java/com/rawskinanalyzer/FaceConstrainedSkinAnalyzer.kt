package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/**
 * FaceConstrainedSkinAnalyzer
 *
 * This is the "step_4 / step_7" connector from the handoff: it does NOT replace or modify
 * `SkinSegmentationEngine` or `LocalizedPatternMapper` (both continue to run exactly as before,
 * untouched — see PROJECT_STATUS.md for why that pipeline stays a shared chokepoint). Instead
 * it re-reads the SAME `PatternMapCell` grid `LocalizedPatternMapper.map()` already produced
 * for a view, and attributes each cell's existing HIGH/MEDIUM/LOW/EXCLUDED evidence
 * (`skinPercent`, `highConfidenceSkinPercent`, the excluded/uncertain percents) to whichever
 * `AnatomicalRegion` polygons (from `AnatomicalRegionMapper`) it geometrically overlaps.
 *
 * Why cell-overlap rather than a fresh per-pixel classification: `LocalizedPatternMapper`
 * already did the per-pixel RGB/YCbCr/HSV skin classification once, at whatever grid
 * resolution the rest of the pipeline agreed on; re-deriving that here from raw pixels would
 * be a second, divergent implementation of the same classifier, which the handoff explicitly
 * warns against ("Do not replace the improved segmentation with another simplistic
 * threshold" / "avoid duplicate implementations"). Reusing the existing cell grid keeps this
 * a pure spatial-attribution step, not a re-classification.
 *
 * Overlap is estimated by sampling each cell that intersects a region's bounding box on a
 * SAMPLE_GRID x SAMPLE_GRID sub-grid and testing each sample point against the region polygon
 * with standard ray-casting point-in-polygon. This is an approximation (a coarse polygon over
 * a coarse cell grid), and `geometryConfidence` on the resulting report is carried through
 * from the region's own confidence for exactly that reason — nothing here upgrades a
 * geometric approximation into a falsely precise number.
 */

data class RegionSkinReport(
    val region: AnatomicalRegion,
    /** Bounding box of the region polygon in normalized-image pixel coordinates. */
    val boundsNormalized: FloatArray, // [left, top, right, bottom]
    /** Same bounding box in original-capture coordinates, when available (see FaceGeometryResult.originalScaleAvailable). */
    val boundsOriginal: FloatArray?,
    val skinCoverage: Double,
    val highConfidenceSkinCoverage: Double,
    val mediumConfidenceSkinCoverage: Double,
    val excludedCoverage: Double,
    /** Portion of excludedCoverage attributable specifically to landmark-based exclusions (eyes/brows/lips/nostrils) overlapping this region, not to the pixel-color classifier. */
    val landmarkExclusionCoverage: Double,
    val geometryConfidence: Double,
    val cellsConsidered: Int
)

/**
 * Batch 4E-C, step_2 addition. A candidate's OWN skin/exclusion overlap, computed against its
 * OWN bounding-box footprint in the [PatternMapCell] grid — as opposed to
 * [VisualFeatureCandidateEngine.skinSupportFor], which assigns every candidate found within a
 * MICRO tile the SAME tile-wide aggregate coverage regardless of where inside that tile the
 * candidate actually sits. This is exactly this batch's step_2 objective ("do not treat every
 * intersecting cell as entirely skin" / "reduce contribution from cells dominated by non-skin
 * area") applied at candidate granularity instead of tile granularity.
 */
data class CandidateBoundarySkinRefinement(
    val skinCoverage: Double,
    val highConfidenceSkinCoverage: Double,
    /** Combined non-skin exclusion for this candidate's OWN footprint: the pixel-classifier
     * exclusion (shadow/highlight/non-skin-color/uncertain, from the [PatternMapCell] grid) PLUS
     * [landmarkExclusionOverlap] below, capped at 100 — the exact same "pixel exclusion +
     * landmark exclusion, min 100" combination [FaceConstrainedSkinAnalyzer.analyze]'s own
     * [RegionSkinReport.excludedCoverage] already uses at region granularity (see
     * `landmarkExclusionCoverage` on that type), applied here at candidate granularity instead —
     * never a second, differently-defined notion of "excluded". When [landmarkExclusionPolygons]
     * is not supplied to [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport] (the pre-Batch
     * 4E-E default), this is identical to the pixel-only value it always was. */
    val excludedCoverage: Double,
    /** Batch 4E-E, step_3 addition. The portion of [excludedCoverage] specifically attributable to
     * this candidate's own footprint overlapping a landmark-derived [ExclusionPolygon] (eyes,
     * eyebrows, lips, the approximate nostril band, or outside-face) — as opposed to the
     * pixel-color classifier's shadow/highlight/non-skin-color signal. Kept separate from
     * [excludedCoverage] so a diagnostics consumer can distinguish "this candidate sits on an
     * eyebrow" from "this candidate sits in a shadow", per this batch's own "preserve exclusion
     * reason" requirement. 0.0 (not null) whenever no landmark polygon was supplied or none
     * overlapped — a real, meaningful zero, not an absence. */
    val landmarkExclusionOverlap: Double,
    /** How many of the candidate's own sample points/cell-overlaps actually contributed —
     * carried through so a caller can tell "a real, if small, footprint was sampled" from
     * "nothing overlapped at all" (the latter already produces a null [CandidateBoundarySkinRefinement]
     * from [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport], never a fabricated zero). */
    val cellsOverlapped: Int
)

object FaceConstrainedSkinAnalyzer {
    const val VERSION = "face_constrained_skin_v1"
    private const val SAMPLE_GRID = 4 // 16 sample points per cell for overlap-fraction estimation

    private fun pointInPolygon(px: Float, py: Float, poly: List<GeometryPoint>): Boolean {
        if (poly.size < 3) return false
        var inside = false
        var j = poly.size - 1
        for (i in poly.indices) {
            val xi = poly[i].normalizedX; val yi = poly[i].normalizedY
            val xj = poly[j].normalizedX; val yj = poly[j].normalizedY
            if (((yi > py) != (yj > py)) &&
                (px < (xj - xi) * (py - yi) / (yj - yi + 1e-9f) + xi)
            ) inside = !inside
            j = i
        }
        return inside
    }

    /** Fraction (0..1) of a cell's area estimated to fall inside [polygons] (union — a sample counts if inside ANY polygon in the list). */
    private fun overlapFraction(cellLeft: Float, cellTop: Float, cellRight: Float, cellBottom: Float, polygons: List<List<GeometryPoint>>): Double {
        if (polygons.isEmpty()) return 0.0
        var hits = 0
        val total = SAMPLE_GRID * SAMPLE_GRID
        for (sy in 0 until SAMPLE_GRID) {
            for (sx in 0 until SAMPLE_GRID) {
                val px = cellLeft + (cellRight - cellLeft) * (sx + 0.5f) / SAMPLE_GRID
                val py = cellTop + (cellBottom - cellTop) * (sy + 0.5f) / SAMPLE_GRID
                if (polygons.any { pointInPolygon(px, py, it) }) hits++
            }
        }
        return hits.toDouble() / total.toDouble()
    }

    /**
     * @param cells the grid LocalizedPatternMapper.map() already produced for this view
     * @param grid the same grid size passed to that map() call (default 6, matching the existing convention)
     * @param normalizedImageWidth/Height must be the dimensions of the SAME normalized bitmap the cells and the region geometry were both computed from
     */
    fun analyze(
        cells: List<PatternMapCell>,
        grid: Int,
        normalizedImageWidth: Int,
        normalizedImageHeight: Int,
        regionSet: RegionSet
    ): List<RegionSkinReport> {
        if (cells.isEmpty() || regionSet.regions.isEmpty()) return emptyList()
        val cellW = normalizedImageWidth.toFloat() / grid.toFloat()
        val cellH = normalizedImageHeight.toFloat() / grid.toFloat()
        val landmarkExclusionPolys = regionSet.exclusions.map { it.points }

        return regionSet.regions.map { regionPolygon ->
            val poly = regionPolygon.points
            val rLeft = poly.minOf { it.normalizedX }; val rRight = poly.maxOf { it.normalizedX }
            val rTop = poly.minOf { it.normalizedY }; val rBottom = poly.maxOf { it.normalizedY }

            var weightedSkin = 0.0
            var weightedHigh = 0.0
            var weightedExcludedPixel = 0.0
            var weightedExcludedLandmark = 0.0
            var weightSum = 0.0
            var cellsConsidered = 0

            for (cell in cells) {
                val cLeft = cell.col * cellW; val cRight = cLeft + cellW
                val cTop = cell.row * cellH; val cBottom = cTop + cellH
                // Broad-phase reject: no bounding-box overlap with region at all.
                if (cRight < rLeft || cLeft > rRight || cBottom < rTop || cTop > rBottom) continue

                val overlap = overlapFraction(cLeft, cTop, cRight, cBottom, listOf(poly))
                if (overlap <= 0.0) continue
                cellsConsidered++
                weightSum += overlap
                weightedSkin += overlap * cell.skinPercent
                weightedHigh += overlap * cell.highConfidenceSkinPercent
                weightedExcludedPixel += overlap * (cell.excludedShadowPercent + cell.excludedHighlightPercent + cell.excludedNonSkinPercent + cell.uncertainPercent)

                val landmarkOverlap = overlapFraction(cLeft, cTop, cRight, cBottom, landmarkExclusionPolys)
                weightedExcludedLandmark += overlap * (landmarkOverlap * 100.0)
            }

            val skinCoverage = if (weightSum > 0) weightedSkin / weightSum else 0.0
            val highCoverage = if (weightSum > 0) weightedHigh / weightSum else 0.0
            val mediumCoverage = max(0.0, skinCoverage - highCoverage)
            val excludedPixelCoverage = if (weightSum > 0) weightedExcludedPixel / weightSum else 0.0
            val excludedLandmarkCoverage = if (weightSum > 0) weightedExcludedLandmark / weightSum else 0.0
            val excludedCoverage = min(100.0, excludedPixelCoverage + excludedLandmarkCoverage)

            val boundsOriginal = if (poly.all { it.originalX != null && it.originalY != null }) {
                floatArrayOf(
                    poly.minOf { it.originalX!! }, poly.minOf { it.originalY!! },
                    poly.maxOf { it.originalX!! }, poly.maxOf { it.originalY!! }
                )
            } else null

            RegionSkinReport(
                region = regionPolygon.region,
                boundsNormalized = floatArrayOf(rLeft, rTop, rRight, rBottom),
                boundsOriginal = boundsOriginal,
                skinCoverage = skinCoverage,
                highConfidenceSkinCoverage = highCoverage,
                mediumConfidenceSkinCoverage = mediumCoverage,
                excludedCoverage = excludedCoverage,
                landmarkExclusionCoverage = excludedLandmarkCoverage,
                geometryConfidence = regionPolygon.confidence,
                cellsConsidered = cellsConsidered
            )
        }
    }

    /**
     * Batch 4E-C, step_2. Computes a candidate's OWN skin/exclusion overlap against its own
     * bounding-box footprint, instead of the whole-MICRO-tile aggregate every candidate found in
     * that tile is otherwise assigned ([VisualFeatureCandidateEngine.skinSupportFor]).
     *
     * [originalBoundingBox] is `[x, y, width, height]` in ORIGINAL-image pixel coordinates —
     * exactly the space [VisualFeatureCandidateEngine.boundingBoxOriginal] already produces for
     * every candidate, so no new coordinate convention is introduced. [cells]/[grid] are the SAME
     * [PatternMapCell] grid this whole file already reuses (never a second classification pass).
     *
     * Reuses [MultiScaleTileExtractor.toNormalized] (the exact algebraic inverse of the
     * `toOriginal` scale this project already establishes elsewhere) to bring the candidate's
     * footprint into the grid's own NORMALIZED coordinate space, then reuses
     * [MultiScaleTileExtractor.tileStats] — the SAME rectangle/cell-overlap weighting this file's
     * own `analyze()` and `MultiScaleTileExtractor.buildTile` already use for regions/tiles — over
     * that footprint instead of duplicating the overlap math a third time.
     *
     * Returns null (never a fabricated 0.0/100.0) when: the candidate's footprint has zero area,
     * no original-to-normalized scale is available for this view (same honest-unavailability
     * condition [toNormalized] itself uses), or the footprint does not actually overlap any cell
     * (distinct from "measured zero skin" — an out-of-grid-bounds footprint is a data problem, not
     * a skin measurement). This mirrors [UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels]'s
     * own "null means unavailable, never zero" contract.
     */
    fun refineCandidateSkinSupport(
        originalBoundingBox: IntArray, // [x, y, width, height]
        cells: List<PatternMapCell>,
        grid: Int,
        normalizedImageWidth: Int,
        normalizedImageHeight: Int,
        geom: FaceGeometryResult,
        /** Batch 4E-E, step_3 addition. The SAME [ExclusionPolygon.points] lists
         * [AnatomicalRegionMapper.map] already produced for this view (eyes, eyebrows, lips, the
         * approximate nostril band, outside-face) — never a second, independently-derived
         * exclusion geometry. Defaulted to empty so every pre-Batch-4E-E caller keeps compiling
         * and keeps its exact prior output (empty list -> [CandidateBoundarySkinRefinement.landmarkExclusionOverlap]
         * is always 0.0, so [CandidateBoundarySkinRefinement.excludedCoverage] is unchanged from
         * before this batch). */
        landmarkExclusionPolygons: List<List<GeometryPoint>> = emptyList()
    ): CandidateBoundarySkinRefinement? {
        if (cells.isEmpty() || originalBoundingBox.size < 4) return null
        val (ox0, oy0, ow, oh) = originalBoundingBox
        if (ow <= 0 || oh <= 0) return null
        val topLeft = MultiScaleTileExtractor.toNormalized(ox0.toFloat(), oy0.toFloat(), geom) ?: return null
        val bottomRight = MultiScaleTileExtractor.toNormalized((ox0 + ow).toFloat(), (oy0 + oh).toFloat(), geom) ?: return null
        val nLeft = min(topLeft.first, bottomRight.first)
        val nRight = max(topLeft.first, bottomRight.first)
        val nTop = min(topLeft.second, bottomRight.second)
        val nBottom = max(topLeft.second, bottomRight.second)
        if (nRight <= nLeft || nBottom <= nTop) return null

        val cellW = normalizedImageWidth.toFloat() / grid
        val cellH = normalizedImageHeight.toFloat() / grid
        val cellsOverlapped = cells.count { cell ->
            val cLeft = cell.col * cellW; val cRight = cLeft + cellW
            val cTop = cell.row * cellH; val cBottom = cTop + cellH
            cRight > nLeft && cLeft < nRight && cBottom > nTop && cTop < nBottom
        }
        if (cellsOverlapped == 0) return null

        val (skin, high, excl) = MultiScaleTileExtractor.tileStats(
            nLeft, nTop, nRight, nBottom, cells, grid, normalizedImageWidth, normalizedImageHeight
        )
        // Batch 4E-E, step_3: the candidate's OWN footprint (not a whole cell, not a whole
        // region) sampled against the landmark-exclusion polygons, using the exact same
        // sample-grid/point-in-polygon machinery `analyze()` above already uses for region-level
        // attribution — reused verbatim, never a second implementation. Empty
        // [landmarkExclusionPolygons] (the pre-4E-E default) always yields 0.0 here, so
        // `excludedCoverage` below is unchanged from before this batch whenever this new
        // parameter is not supplied.
        val landmarkOverlapFraction = if (landmarkExclusionPolygons.isEmpty()) 0.0
            else overlapFraction(nLeft, nTop, nRight, nBottom, landmarkExclusionPolygons)
        val landmarkExclusionOverlap = (landmarkOverlapFraction * 100.0).coerceIn(0.0, 100.0)
        val combinedExcludedCoverage = min(100.0, excl + landmarkExclusionOverlap)
        return CandidateBoundarySkinRefinement(
            skinCoverage = skin, highConfidenceSkinCoverage = high,
            excludedCoverage = combinedExcludedCoverage,
            landmarkExclusionOverlap = landmarkExclusionOverlap,
            cellsOverlapped = cellsOverlapped
        )
    }

    fun json(reports: List<RegionSkinReport>, skippedRegions: List<Pair<AnatomicalRegion, String>>): String {
        val reportsJson = reports.joinToString(",") { r ->
            val bo = r.boundsOriginal
            """{"region":"${r.region}","bounds_normalized":[${r.boundsNormalized.joinToString(",")}],"bounds_original":${
                if (bo == null) "null" else "[${bo.joinToString(",")}]"
            },"skin_coverage":${r.skinCoverage},"high_confidence_skin_coverage":${r.highConfidenceSkinCoverage},"medium_confidence_skin_coverage":${r.mediumConfidenceSkinCoverage},"excluded_coverage":${r.excludedCoverage},"landmark_exclusion_coverage":${r.landmarkExclusionCoverage},"geometry_confidence":${r.geometryConfidence},"cells_considered":${r.cellsConsidered}}"""
        }
        val skippedJson = skippedRegions.joinToString(",") { (r, reason) -> """{"region":"$r","reason":"$reason"}""" }
        return """{"method":"$VERSION","region_reports":[$reportsJson],"skipped_regions":[$skippedJson]}"""
    }
}
