package com.rawskinanalyzer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PointF
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import java.io.File
import java.util.concurrent.ExecutionException
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * FaceGeometryAnalyzer
 *
 * First real face-detection/landmark foundation in this project (see PROJECT_STATUS.md,
 * "PRECISION_SKIN_ANALYSIS_ENGINE" batch, "Known limitations" / "Exact next implementation
 * step" — this file is that next step). Uses on-device ML Kit Face Detection
 * (`com.google.mlkit:face-detection`) with landmark + contour modes enabled, which is the
 * appropriate choice here over MediaPipe Face Landmarker: it needs no bundled `.task` model
 * asset, ships as a small Gradle dependency, runs fully on-device, and its contour set
 * (FACE / EYEBROWS / EYES / LIPS / NOSE_BRIDGE / NOSE_BOTTOM / CHEEKS) already covers most of
 * the landmark groups this batch's handoff asked for.
 *
 * IMPORTANT — coordinate spaces:
 * This analyzer runs on the same `analysis_normalized.jpg` file every other analyzer in this
 * pipeline already consumes (see `MainActivity.latestNormalized`), NOT on the raw
 * `capture.jpg`/`capture.dng` evidence files, which are never decoded, resized, or modified
 * here or anywhere else in the analysis path. `analysis_normalized.jpg` is itself a
 * downscaled copy of `capture.jpg` (`ImageQualityAnalyzer.writeNormalizedCopy`, capped at
 * 1536px on the long side, uniform aspect-preserving scale, no crop). To satisfy this batch's
 * "preserve original 4080x3060 coordinate relationship" requirement without decoding/holding
 * a second, larger bitmap for every stage, this analyzer:
 *   1. Detects faces on the normalized bitmap (fast, already-loaded resolution).
 *   2. Reads only the *bounds* (width/height) of the sibling `capture.jpg` in the same
 *      directory, via `BitmapFactory.Options.inJustDecodeBounds`, which decodes no pixel data.
 *   3. Computes a single uniform scale factor from those two widths (heights, being from the
 *      same aspect-preserving copy, agree with the width-derived scale within rounding) and
 *      exposes both `normalizedPoint` and `originalPoint` on every landmark/contour point, so
 *      any future high-resolution crop extractor can locate the exact original-image region
 *      without this analyzer ever upscaling anything itself.
 * If the original capture file cannot be found or its bounds cannot be decoded, geometry is
 * still returned in normalized-image coordinates only, and `originalScaleAvailable` is false —
 * this is reported explicitly, never silently assumed to be 1:1.
 *
 * ML Kit's Face Detector does not expose a numeric face-detection confidence score (that is
 * only available for the separate smiling/eyes-open classifiers, which are a different
 * signal). `faceDetectionConfidence` here is therefore not a probability from the model; it is
 * a deterministic completeness score computed from how much real evidence ML Kit actually
 * returned (bounding box always present when a face exists; landmark count out of the 10 ML
 * Kit can return; contour count out of the 15 it can return) — this is stated explicitly so it
 * is never mistaken for a calibrated detector probability. Per this batch's confidence rule,
 * nothing here is manufactured: a view where ML Kit returns zero contours reports that
 * honestly via a low completeness score, not a fabricated "medium confidence".
 */

enum class FaceLandmarkGroup {
    LEFT_EYE, RIGHT_EYE, LEFT_EYEBROW, RIGHT_EYEBROW, NOSE, MOUTH,
    FACE_OUTLINE, LEFT_CHEEK, RIGHT_CHEEK
}

/** A point known in both the coordinate space it was detected in and (when available) the original capture's space. */
data class GeometryPoint(
    val normalizedX: Float,
    val normalizedY: Float,
    val originalX: Float?,
    val originalY: Float?
)

data class FaceLandmarkPoint(val type: String, val point: GeometryPoint)

data class FaceContourGroup(val group: FaceLandmarkGroup, val points: List<GeometryPoint>)

data class FaceBounds(
    val normalized: Rect,
    val original: Rect?
)

data class FaceGeometryResult(
    val faceDetected: Boolean,
    /** Deterministic evidence-completeness score in [0,1] — see class doc. Not a model probability. */
    val faceDetectionConfidence: Double,
    val bounds: FaceBounds?,
    val landmarks: List<FaceLandmarkPoint>,
    val contours: List<FaceContourGroup>,
    val normalizedImageWidth: Int,
    val normalizedImageHeight: Int,
    val originalImageWidth: Int?,
    val originalImageHeight: Int?,
    val originalScaleAvailable: Boolean,
    /** Fraction of the 10 possible ML Kit landmark types actually returned. */
    val landmarkCompleteness: Double,
    /** Fraction of the 15 possible ML Kit contour types actually returned. */
    val contourCompleteness: Double,
    /** Combined geometry confidence — see FaceGeometryAnalyzer.geometryConfidenceOf. */
    val geometryConfidence: Double,
    val notes: List<String>
) {
    fun contour(group: FaceLandmarkGroup): List<GeometryPoint> = contours.firstOrNull { it.group == group }?.points ?: emptyList()
    fun landmark(type: String): GeometryPoint? = landmarks.firstOrNull { it.type == type }?.point
}

object FaceGeometryAnalyzer {
    const val VERSION = "face_geometry_v1_mlkit_contours"

    private val detector: FaceDetector by lazy {
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
                .setMinFaceSize(0.15f)
                .build()
        )
    }

    private const val LANDMARK_TYPE_COUNT = 10
    private const val CONTOUR_TYPE_COUNT = 15

    private val contourGroupMap: Map<Int, FaceLandmarkGroup> = mapOf(
        FaceContour.FACE to FaceLandmarkGroup.FACE_OUTLINE,
        FaceContour.LEFT_EYE to FaceLandmarkGroup.LEFT_EYE,
        FaceContour.RIGHT_EYE to FaceLandmarkGroup.RIGHT_EYE,
        FaceContour.LEFT_EYEBROW_TOP to FaceLandmarkGroup.LEFT_EYEBROW,
        FaceContour.LEFT_EYEBROW_BOTTOM to FaceLandmarkGroup.LEFT_EYEBROW,
        FaceContour.RIGHT_EYEBROW_TOP to FaceLandmarkGroup.RIGHT_EYEBROW,
        FaceContour.RIGHT_EYEBROW_BOTTOM to FaceLandmarkGroup.RIGHT_EYEBROW,
        FaceContour.NOSE_BRIDGE to FaceLandmarkGroup.NOSE,
        FaceContour.NOSE_BOTTOM to FaceLandmarkGroup.NOSE,
        FaceContour.UPPER_LIP_TOP to FaceLandmarkGroup.MOUTH,
        FaceContour.UPPER_LIP_BOTTOM to FaceLandmarkGroup.MOUTH,
        FaceContour.LOWER_LIP_TOP to FaceLandmarkGroup.MOUTH,
        FaceContour.LOWER_LIP_BOTTOM to FaceLandmarkGroup.MOUTH,
        FaceContour.LEFT_CHEEK to FaceLandmarkGroup.LEFT_CHEEK,
        FaceContour.RIGHT_CHEEK to FaceLandmarkGroup.RIGHT_CHEEK
    )

    private val landmarkTypeNames: List<Int> = listOf(
        FaceLandmark.LEFT_EYE, FaceLandmark.RIGHT_EYE, FaceLandmark.LEFT_EAR, FaceLandmark.RIGHT_EAR,
        FaceLandmark.LEFT_CHEEK, FaceLandmark.RIGHT_CHEEK, FaceLandmark.NOSE_BASE,
        FaceLandmark.MOUTH_LEFT, FaceLandmark.MOUTH_RIGHT, FaceLandmark.MOUTH_BOTTOM
    )

    private fun landmarkName(type: Int): String = when (type) {
        FaceLandmark.LEFT_EYE -> "LEFT_EYE"
        FaceLandmark.RIGHT_EYE -> "RIGHT_EYE"
        FaceLandmark.LEFT_EAR -> "LEFT_EAR"
        FaceLandmark.RIGHT_EAR -> "RIGHT_EAR"
        FaceLandmark.LEFT_CHEEK -> "LEFT_CHEEK"
        FaceLandmark.RIGHT_CHEEK -> "RIGHT_CHEEK"
        FaceLandmark.NOSE_BASE -> "NOSE_BASE"
        FaceLandmark.MOUTH_LEFT -> "MOUTH_LEFT"
        FaceLandmark.MOUTH_RIGHT -> "MOUTH_RIGHT"
        FaceLandmark.MOUTH_BOTTOM -> "MOUTH_BOTTOM"
        else -> "UNKNOWN_$type"
    }

    /**
     * Reads only the pixel dimensions of [originalCaptureFile] (no pixel data decoded), for
     * computing the normalized->original coordinate scale. Returns null if the file is
     * missing or cannot be read as an image — this is a legitimate, expected outcome (e.g. a
     * session captured before this batch existed) and callers must treat it as
     * "original scale unavailable", never assume 1:1.
     */
    private fun readBoundsOnly(file: File): Pair<Int, Int>? {
        if (!file.exists()) return null
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, opts)
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null
        return opts.outWidth to opts.outHeight
    }

    private fun toGeometryPoint(p: PointF, scaleX: Float?, scaleY: Float?): GeometryPoint =
        GeometryPoint(
            normalizedX = p.x,
            normalizedY = p.y,
            originalX = scaleX?.let { p.x * it },
            originalY = scaleY?.let { p.y * it }
        )

    /**
     * Analyzes [normalizedFile] (an `analysis_normalized.jpg`) for a single face. Looks for a
     * sibling `capture.jpg` in the same directory to establish the original-coordinate scale;
     * pass [originalCaptureFile] explicitly to override that lookup (e.g. from a different
     * naming convention) — defaults to the sibling-file convention this project already uses
     * (`captureDir/capture.jpg` alongside `captureDir/analysis_normalized.jpg`).
     */
    fun analyze(normalizedFile: File, originalCaptureFile: File? = File(normalizedFile.parentFile, "capture.jpg")): FaceGeometryResult {
        val bitmap: Bitmap = BitmapFactory.decodeFile(normalizedFile.absolutePath)
            ?: throw IllegalArgumentException("Cannot decode normalized image for face geometry")
        val notes = mutableListOf<String>()
        try {
            val original = originalCaptureFile?.let { readBoundsOnly(it) }
            val scaleX: Float?
            val scaleY: Float?
            if (original != null && bitmap.width > 0 && bitmap.height > 0) {
                scaleX = original.first.toFloat() / bitmap.width.toFloat()
                scaleY = original.second.toFloat() / bitmap.height.toFloat()
            } else {
                scaleX = null; scaleY = null
                notes += "ORIGINAL_CAPTURE_DIMENSIONS_UNAVAILABLE"
            }

            val input = InputImage.fromBitmap(bitmap, 0)
            val faces: List<Face> = try {
                Tasks.await(detector.process(input), 10, TimeUnit.SECONDS)
            } catch (e: TimeoutException) {
                notes += "FACE_DETECTION_TIMEOUT"
                emptyList()
            } catch (e: ExecutionException) {
                notes += "FACE_DETECTION_ERROR_${e.cause?.javaClass?.simpleName ?: e.javaClass.simpleName}"
                emptyList()
            }

            if (faces.isEmpty()) {
                notes += "NO_FACE_DETECTED"
                return FaceGeometryResult(
                    faceDetected = false,
                    faceDetectionConfidence = 0.0,
                    bounds = null,
                    landmarks = emptyList(),
                    contours = emptyList(),
                    normalizedImageWidth = bitmap.width,
                    normalizedImageHeight = bitmap.height,
                    originalImageWidth = original?.first,
                    originalImageHeight = original?.second,
                    originalScaleAvailable = scaleX != null,
                    landmarkCompleteness = 0.0,
                    contourCompleteness = 0.0,
                    geometryConfidence = 0.0,
                    notes = notes
                )
            }

            // Largest face by bounding-box area — the capture protocol frames one subject
            // filling most of the frame, so this is the correct disambiguation rule when
            // ML Kit returns more than one candidate (e.g. a background person).
            val face = faces.maxByOrNull { it.boundingBox.width().toLong() * it.boundingBox.height().toLong() }!!
            if (faces.size > 1) notes += "MULTIPLE_FACES_DETECTED_USED_LARGEST"

            val boundsNormalized = face.boundingBox
            val boundsOriginal = if (scaleX != null && scaleY != null) {
                Rect(
                    (boundsNormalized.left * scaleX).toInt(),
                    (boundsNormalized.top * scaleY).toInt(),
                    (boundsNormalized.right * scaleX).toInt(),
                    (boundsNormalized.bottom * scaleY).toInt()
                )
            } else null

            val landmarkPoints = mutableListOf<FaceLandmarkPoint>()
            for (type in landmarkTypeNames) {
                val lm = face.getLandmark(type) ?: continue
                landmarkPoints += FaceLandmarkPoint(landmarkName(type), toGeometryPoint(lm.position, scaleX, scaleY))
            }

            val contourGroups = mutableListOf<FaceContourGroup>()
            val presentContourTypes = mutableSetOf<Int>()
            for ((contourType, group) in contourGroupMap) {
                val contour = face.getContour(contourType) ?: continue
                if (contour.points.isEmpty()) continue
                presentContourTypes += contourType
                val points = contour.points.map { toGeometryPoint(it, scaleX, scaleY) }
                val existingIdx = contourGroups.indexOfFirst { it.group == group }
                if (existingIdx >= 0) {
                    contourGroups[existingIdx] = FaceContourGroup(group, contourGroups[existingIdx].points + points)
                } else {
                    contourGroups += FaceContourGroup(group, points)
                }
            }

            val landmarkCompleteness = landmarkPoints.size.toDouble() / LANDMARK_TYPE_COUNT.toDouble()
            val contourCompleteness = presentContourTypes.size.toDouble() / CONTOUR_TYPE_COUNT.toDouble()
            val geometryConfidence = geometryConfidenceOf(landmarkCompleteness, contourCompleteness)

            return FaceGeometryResult(
                faceDetected = true,
                faceDetectionConfidence = geometryConfidence,
                bounds = FaceBounds(boundsNormalized, boundsOriginal),
                landmarks = landmarkPoints,
                contours = contourGroups,
                normalizedImageWidth = bitmap.width,
                normalizedImageHeight = bitmap.height,
                originalImageWidth = original?.first,
                originalImageHeight = original?.second,
                originalScaleAvailable = scaleX != null,
                landmarkCompleteness = landmarkCompleteness,
                contourCompleteness = contourCompleteness,
                geometryConfidence = geometryConfidence,
                notes = notes
            )
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * Deterministic geometry confidence from evidence completeness only — never a fabricated
     * constant. Weighted toward contours (0.6) since region-mask construction
     * (`AnatomicalRegionMapper`) depends primarily on contour points, not sparse landmarks.
     */
    fun geometryConfidenceOf(landmarkCompleteness: Double, contourCompleteness: Double): Double =
        (0.4 * landmarkCompleteness + 0.6 * contourCompleteness).coerceIn(0.0, 1.0)

    fun json(r: FaceGeometryResult): String {
        fun gp(p: GeometryPoint) = """{"nx":${p.normalizedX},"ny":${p.normalizedY},"ox":${p.originalX ?: "null"},"oy":${p.originalY ?: "null"}}"""
        val landmarksJson = r.landmarks.joinToString(",") { """{"type":"${it.type}","point":${gp(it.point)}}""" }
        val contoursJson = r.contours.joinToString(",") { g ->
            """{"group":"${g.group}","points":[${g.points.joinToString(",") { gp(it) }}]}"""
        }
        val boundsJson = r.bounds?.let { b ->
            val orig = b.original
            """{"normalized":{"left":${b.normalized.left},"top":${b.normalized.top},"right":${b.normalized.right},"bottom":${b.normalized.bottom}},"original":${
                if (orig == null) "null" else """{"left":${orig.left},"top":${orig.top},"right":${orig.right},"bottom":${orig.bottom}}"""
            }}"""
        } ?: "null"
        return """{"method":"$VERSION","face_detected":${r.faceDetected},"face_detection_confidence":${r.faceDetectionConfidence},"geometry_confidence":${r.geometryConfidence},"landmark_completeness":${r.landmarkCompleteness},"contour_completeness":${r.contourCompleteness},"normalized_image_width":${r.normalizedImageWidth},"normalized_image_height":${r.normalizedImageHeight},"original_image_width":${r.originalImageWidth ?: "null"},"original_image_height":${r.originalImageHeight ?: "null"},"original_scale_available":${r.originalScaleAvailable},"bounds":$boundsJson,"landmarks":[$landmarksJson],"contours":[$contoursJson],"notes":[${r.notes.joinToString(",") { "\"$it\"" }}]}"""
    }
}
