package com.rawskinanalyzer

/**
 * BATCH 2 — FEATURE-SPECIFIC CALIBRATION AND VALIDATION FRAMEWORK
 *
 * Batch 1 (SkinScoreCalibration.kt) extracted the previously-inlined weighted-sum
 * combination step into one inspectable CALIBRATION stage and made every input, weight,
 * and contribution readable via CalibrationRegistry. It did not check whether any of
 * those inputs, weights, or resulting scores were actually *plausible* — it only recorded
 * what was computed.
 *
 * This file adds the next stage the pipeline diagram calls for:
 *
 *   CHARACTERISTIC ANALYZER -> FEATURE-SPECIFIC CALIBRATION -> 0-100 CHARACTERISTIC SCORE
 *   -> [THIS FILE: per-input plausibility bounds + score-consistency checks] -> CONFIDENCE
 *
 * What this is:
 *   - A named, documented plausibility range for every distinct calibration input
 *     currently produced anywhere in SkinScoreCalibration, with the exact upstream
 *     computation each bound is derived from (see FeatureCalibrationBounds).
 *   - A validator that checks each CalibratedComponent against those bounds, checks for
 *     non-finite values, and recomputes the weighted sum to confirm the recorded
 *     calibrated_score is actually consistent with its own recorded inputs.
 *
 * What this is NOT:
 *   - Not calibration against ground-truth skin measurements. A value can pass every
 *     check here and still have no established relationship to a real skin condition —
 *     see PROJECT_STATUS.md ("What is not established"). These are internal consistency
 *     and engineering-plausibility checks only, meant to catch measurement bugs, unit
 *     mismatches, and silently-clamped inputs — the concrete, checkable groundwork the
 *     project needs before any future ground-truth validation effort is possible, not a
 *     substitute for one.
 *   - Not a gate. Findings are reported, not blocking — no existing pipeline stage output
 *     is withheld or altered because of a validation finding.
 */

enum class CalibrationBoundKind {
    /** Upstream code path clamps/guarantees this range (e.g. `.coerceIn(0.0, 100.0)`). A
     *  violation means the guarantee was broken somewhere — a real defect, not noise. */
    HARD_GUARANTEED,
    /** No upstream clamp exists. The range reflects the working range the calibration
     *  weight was chosen against (see SkinScoreCalibration.kt Batch 1 doc comment: weights
     *  were extracted unchanged from the prior inline formulas, not re-derived from these
     *  bounds), not a mathematical limit. A violation means the input landed outside the
     *  range its weight was implicitly tuned for and the resulting contribution should be
     *  reviewed, not that the number is impossible. */
    SOFT_PLAUSIBILITY
}

data class CalibrationInputBound(
    val inputName: String,
    val min: Double,
    val max: Double,
    val kind: CalibrationBoundKind,
    val rationale: String
)

/**
 * One documented bound per distinct named input across every SkinScoreCalibration
 * function. Built by reading each input back to the exact analyzer code that produces it
 * (see per-entry rationale). Inputs shared across characteristics (e.g. the two
 * "texture_variation" uses in surfaceOiliness/surfaceDryness) share one bound entry.
 */
object FeatureCalibrationBounds {
    const val VERSION = "CALIBRATION_BOUNDS_V1"

    private val bounds: Map<String, CalibrationInputBound> = listOf(
        CalibrationInputBound(
            "localized_redness_normalized", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "SkinFeatureQuantificationAnalyzer.localizedRedness is clamp(redSpread*3.0) to [0,100]."
        ),
        CalibrationInputBound(
            "within_view_redness_variation", 0.0, 60.0, CalibrationBoundKind.SOFT_PLAUSIBILITY,
            "RednessAnalysisAnalyzer: std of per-cell redness (r-g, raw 0-255 channel units) " +
                "averaged across views. Not clamped upstream; 60 covers the high end observed " +
                "for real skin-tone red-green channel spread."
        ),
        CalibrationInputBound(
            "elevated_redness_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "RednessAnalysisAnalyzer: count/size*100.0 over filtered cells — a percentage by construction."
        ),
        CalibrationInputBound(
            "tone_variation_normalized", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "SkinFeatureQuantificationAnalyzer.toneVariation is clamp(...) to [0,100]."
        ),
        CalibrationInputBound(
            "within_view_luma_variation", 0.0, 80.0, CalibrationBoundKind.SOFT_PLAUSIBILITY,
            "PigmentationTanningAnalyzer: std of per-cell meanLuma (raw 0-255 luma units) " +
                "averaged across views. Not clamped upstream; 80 covers strong lighting-driven " +
                "luma spread within a single skin ROI."
        ),
        CalibrationInputBound(
            "dark_area_score", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "ToneColorFeatureAnalyzer.darkAreaScore is SkinFeatureQuantificationAnalyzer.darkFeatureConcentration, " +
                "itself clamp(fusion.fusedDarkAreaConcentration) to [0,100]."
        ),
        CalibrationInputBound(
            "darker_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "PigmentationTanningAnalyzer: count/size*100.0 over filtered cells — a percentage by construction."
        ),
        CalibrationInputBound(
            "candidate_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "BlemishFeatureAnalyzer: candidates.size*100.0/skin.size — a percentage by construction."
        ),
        CalibrationInputBound(
            "hotspot_density", 0.0, 150.0, CalibrationBoundKind.SOFT_PLAUSIBILITY,
            "LocalizedFeatureAnalyzer.hotspotDensity is hotspots.size*100.0/usableCells.size. Percent-shaped " +
                "but not clamped, and PatternHotspotAnalyzer is not restricted to at most one hotspot per " +
                "usable cell, so values above 100 are possible in principle; 150 is a plausibility ceiling, " +
                "not a hard limit."
        ),
        CalibrationInputBound(
            "repeated_feature_bonus", 0.0, 30.0, CalibrationBoundKind.HARD_GUARANTEED,
            "BlemishFeatureAnalyzer assigns exactly one of the fixed values {0.0, 8.0, 18.0, 30.0} " +
                "depending on LocalizedFeatureAnalyzer.repeatedFeatureSignal — a closed set, not a continuum."
        ),
        CalibrationInputBound(
            "base_texture_variation_score", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "TextureCharacterizationAnalyzer returns clamp(variation) to [0,100]."
        ),
        CalibrationInputBound(
            "within_view_texture_variation", 0.0, 60.0, CalibrationBoundKind.SOFT_PLAUSIBILITY,
            "TexturePoreFeatureAnalyzer / SurfaceConditionAnalyzer: std of per-cell texture (mean absolute " +
                "luma difference between adjacent samples, raw units) averaged across views. Not clamped " +
                "upstream; 60 covers high-contrast/high-frequency texture regions observed in practice."
        ),
        CalibrationInputBound(
            "elevated_texture_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "TexturePoreFeatureAnalyzer: count/size*100.0 over filtered cells — a percentage by construction."
        ),
        CalibrationInputBound(
            "pore_like_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "TexturePoreFeatureAnalyzer: skin.count{...}*100.0/values.size — a percentage by construction."
        ),
        CalibrationInputBound(
            "highlight_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "SurfaceConditionAnalyzer: luma.count{...}*100.0/luma.size — a percentage by construction."
        ),
        CalibrationInputBound(
            "texture_variation", 0.0, 60.0, CalibrationBoundKind.SOFT_PLAUSIBILITY,
            "SurfaceConditionAnalyzer: same std-of-per-cell-texture quantity as within_view_texture_variation " +
                "(shared upstream computation, different call site); see that entry."
        ),
        CalibrationInputBound(
            "rough_area_percent", 0.0, 100.0, CalibrationBoundKind.HARD_GUARANTEED,
            "SurfaceConditionAnalyzer: skin.count{...}*100.0/skin.size — a percentage by construction."
        )
    ).associateBy { it.inputName }

    fun forInput(name: String): CalibrationInputBound? = bounds[name]
    fun all(): List<CalibrationInputBound> = bounds.values.toList()
}

enum class CalibrationFindingSeverity { INFO, WARNING, ERROR }

data class CalibrationFinding(
    val code: String,
    val severity: CalibrationFindingSeverity,
    val message: String
)

data class CalibrationValidationResult(
    val characteristic: String,
    val calibrationVersion: String,
    val calibratedScore: Double,
    val valid: Boolean,
    val findings: List<CalibrationFinding>
)

/**
 * Validates a CalibratedComponent (Batch 1's output) against FeatureCalibrationBounds and
 * against its own recorded arithmetic. `valid` is false only when at least one ERROR-level
 * finding is present (non-finite values, a broken HARD_GUARANTEED bound, or a score that
 * does not match its own recorded inputs); SOFT_PLAUSIBILITY violations and missing bounds
 * are reported as WARNING/INFO and do not affect `valid`.
 */
object FeatureCalibrationValidator {
    const val VERSION = "CALIBRATION_VALIDATION_V1"
    private const val SCORE_TOLERANCE = 0.001

    fun validate(component: CalibratedComponent): CalibrationValidationResult {
        val findings = mutableListOf<CalibrationFinding>()

        component.inputs.forEach { input ->
            if (!input.normalizedValue.isFinite()) {
                findings += CalibrationFinding(
                    "NON_FINITE_INPUT_VALUE", CalibrationFindingSeverity.ERROR,
                    "input '${input.name}' is not finite (${input.normalizedValue})"
                )
                return@forEach
            }
            val bound = FeatureCalibrationBounds.forInput(input.name)
            if (bound == null) {
                findings += CalibrationFinding(
                    "NO_BOUND_SPECIFIED", CalibrationFindingSeverity.INFO,
                    "no plausibility bound yet defined for input '${input.name}'; " +
                        "add one to FeatureCalibrationBounds before relying on this check for it"
                )
            } else if (input.normalizedValue < bound.min || input.normalizedValue > bound.max) {
                val severity = if (bound.kind == CalibrationBoundKind.HARD_GUARANTEED)
                    CalibrationFindingSeverity.ERROR else CalibrationFindingSeverity.WARNING
                findings += CalibrationFinding(
                    "INPUT_OUT_OF_EXPECTED_RANGE", severity,
                    "input '${input.name}'=${input.normalizedValue} outside expected " +
                        "[${bound.min},${bound.max}] (${bound.kind}): ${bound.rationale}"
                )
            }
            if (input.weight < 0.0) {
                findings += CalibrationFinding(
                    "NEGATIVE_CALIBRATION_WEIGHT", CalibrationFindingSeverity.WARNING,
                    "input '${input.name}' has a negative weight (${input.weight}); every current " +
                        "calibration function uses non-negative weights, so this is unexpected"
                )
            }
        }

        if (!component.calibratedScore.isFinite()) {
            findings += CalibrationFinding(
                "NON_FINITE_CALIBRATED_SCORE", CalibrationFindingSeverity.ERROR,
                "calibrated_score for ${component.characteristic} is not finite (${component.calibratedScore})"
            )
        } else {
            if (component.calibratedScore < 0.0 || component.calibratedScore > 100.0) {
                findings += CalibrationFinding(
                    "CALIBRATED_SCORE_OUT_OF_RANGE", CalibrationFindingSeverity.ERROR,
                    "calibrated_score ${component.calibratedScore} for ${component.characteristic} " +
                        "is outside [0,100] despite SkinScoreCalibration.calibrate() clamping — " +
                        "indicates the recorded score was not produced by that function"
                )
            }
            val finiteInputs = component.inputs.all { it.normalizedValue.isFinite() }
            if (finiteInputs) {
                val rawSum = component.inputs.sumOf { it.contribution }
                val expected = rawSum.coerceIn(0.0, 100.0)
                if (kotlin.math.abs(component.calibratedScore - expected) > SCORE_TOLERANCE) {
                    findings += CalibrationFinding(
                        "SCORE_INPUT_SUM_MISMATCH", CalibrationFindingSeverity.ERROR,
                        "calibrated_score ${component.calibratedScore} does not match the clamped sum of " +
                            "this component's own recorded input contributions (expected $expected from " +
                            "raw sum $rawSum) for ${component.characteristic}"
                    )
                }
                if (rawSum > 100.0) {
                    findings += CalibrationFinding(
                        "RAW_WEIGHTED_SUM_CLAMPED", CalibrationFindingSeverity.INFO,
                        "raw weighted sum $rawSum for ${component.characteristic} exceeded 100 and was " +
                            "clamped to 100.0; one or more inputs may be running past the working range " +
                            "its weight was chosen for — see any INPUT_OUT_OF_EXPECTED_RANGE findings above"
                    )
                }
            }
        }

        val valid = findings.none { it.severity == CalibrationFindingSeverity.ERROR }
        return CalibrationValidationResult(
            component.characteristic, component.calibrationVersion, component.calibratedScore, valid, findings
        )
    }

    fun validateAll(components: List<CalibratedComponent>): List<CalibrationValidationResult> =
        components.map { validate(it) }

    fun json(r: CalibrationValidationResult): String {
        val findings = r.findings.joinToString(",") { f ->
            """{"code":"${f.code}","severity":"${f.severity}","message":${quote(f.message)}}"""
        }
        return """{"characteristic":"${r.characteristic}","calibration_version":"${r.calibrationVersion}",""" +
            """"calibrated_score":${r.calibratedScore},"valid":${r.valid},"findings":[$findings]}"""
    }

    fun sessionJson(results: List<CalibrationValidationResult>): String {
        val errorCount = results.sumOf { res -> res.findings.count { it.severity == CalibrationFindingSeverity.ERROR } }
        val warningCount = results.sumOf { res -> res.findings.count { it.severity == CalibrationFindingSeverity.WARNING } }
        val infoCount = results.sumOf { res -> res.findings.count { it.severity == CalibrationFindingSeverity.INFO } }
        return """{"validation_version":"$VERSION","bounds_version":"${FeatureCalibrationBounds.VERSION}",""" +
            """"all_valid":${results.all { it.valid }},"error_count":$errorCount,"warning_count":$warningCount,""" +
            """"info_count":$infoCount,"results":[${results.joinToString(",") { json(it) }}],""" +
            """"note":"engineering plausibility and internal-consistency checks only; not clinical validation",""" +
            """"medical_diagnosis":false}"""
    }

    private fun quote(s: String): String =
        "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
}
