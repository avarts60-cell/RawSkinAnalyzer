package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/**
 * FeatureCandidateDetectors
 *
 * Batch 4D-D, steps 2 and 4-8 (P0). Candidate DETECTION (this file, "is there a structure here")
 * is kept deliberately separate from feature CLASSIFICATION (`FeatureSeparationEngine`, "what kind
 * of structure is it"), per this batch's own "important" note on `feature_engine_architecture`.
 *
 * Detection here is two-stage:
 *  1. [structuralCandidateMask] flags any grid cell showing ANY of the five signal patterns this
 *     batch's P0 scope covers (darkness/elongation for hair, contrast/compactness for pores,
 *     darkness for dark-marks, chroma shift for redness, local-variance elevation for texture).
 *     This is deliberately permissive — "do not force classification" (step_1) means the
 *     detection stage should not silently drop a cell just because it doesn't cleanly match one
 *     signal; that judgment belongs to [FeatureSeparationEngine].
 *  2. [ConnectedComponentExtractor] turns that mask into actual shaped structures (this is what
 *     keeps every local high-contrast pixel from becoming its own "feature" — the
 *     `feature_engine_architecture.important` warning this batch calls out explicitly).
 */
object FeatureCandidateDetectors {

    /** Cells this many local-luma std-deviations below the tile's own mean are considered "locally dark" — tile-relative, not a fixed absolute threshold, so lighting varies per capture without a re-tuned constant. */
    private const val DARKNESS_STD_MULTIPLIER = 1.15
    private const val CONTRAST_STD_MULTIPLIER = 1.0
    private const val REDNESS_CR_DELTA = 6.0
    private const val VARIANCE_ELEVATION_MULTIPLIER = 1.6

    private const val MIN_COMPONENT_AREA_CELLS = 2
    // Bounds a component to a plausible local-structure size relative to the tile — prevents a
    // large, roughly-uniform shadow/illumination gradient across most of the tile from being
    // treated as one giant "candidate" (step_7's illumination-vs-localized-redness distinction,
    // generalized to every detector).
    private fun maxComponentArea(totalCells: Int) = max(MIN_COMPONENT_AREA_CELLS + 1, (totalCells * 0.35).toInt())

    fun structuralCandidateMask(grid: SignalGrid): Array<BooleanArray> {
        val meanVariance = run {
            var s = 0.0; var n = 0
            for (r in 0 until grid.rows) for (c in 0 until grid.cols) { s += grid.localVariance[r][c]; n++ }
            if (n > 0) s / n else 0.0
        }
        val mask = Array(grid.rows) { BooleanArray(grid.cols) }
        for (r in 0 until grid.rows) {
            for (c in 0 until grid.cols) {
                val luma = grid.luma[r][c]
                val darkThreshold = grid.regionMeanLuma - DARKNESS_STD_MULTIPLIER * grid.regionLumaStdDev
                val isDark = luma < darkThreshold
                val isHighContrast = grid.gradientMagnitude[r][c] > (grid.regionLumaStdDev * CONTRAST_STD_MULTIPLIER)
                val isRedShifted = grid.cr[r][c] > grid.regionMeanCr + REDNESS_CR_DELTA
                val isTextured = grid.localVariance[r][c] > meanVariance * VARIANCE_ELEVATION_MULTIPLIER
                mask[r][c] = isDark || isHighContrast || isRedShifted || isTextured
            }
        }
        return mask
    }

    fun components(grid: SignalGrid): List<GridComponent> {
        val mask = structuralCandidateMask(grid)
        val total = grid.rows * grid.cols
        return ConnectedComponentExtractor.extract(mask, grid.rows, grid.cols, MIN_COMPONENT_AREA_CELLS, maxComponentArea(total))
    }

    /** Mean of each grid signal over a component's cells — the aggregate morphology values [FeatureSeparationEngine] scores against. */
    data class ComponentSignals(val meanLuma: Double, val meanCb: Double, val meanCr: Double, val meanGradient: Double, val meanVariance: Double)

    fun signalsOf(grid: SignalGrid, comp: GridComponent): ComponentSignals {
        var sl = 0.0; var scb = 0.0; var scr = 0.0; var sg = 0.0; var sv = 0.0
        for ((r, c) in comp.cells) { sl += grid.luma[r][c]; scb += grid.cb[r][c]; scr += grid.cr[r][c]; sg += grid.gradientMagnitude[r][c]; sv += grid.localVariance[r][c] }
        val n = max(1, comp.cells.size).toDouble()
        return ComponentSignals(sl / n, scb / n, scr / n, sg / n, sv / n)
    }
}
