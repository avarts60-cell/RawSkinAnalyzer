package com.rawskinanalyzer

/**
 * FeatureCorrespondenceEngine
 *
 * Batch 4D-G, step_3 (P0). Builds [FeatureCorrespondence] records linking
 * [SpecializedFeatureEvidence] candidates across FRONT FACE / LEFT CHEEK / RIGHT CHEEK (this
 * project's actual `MainActivity.SessionStep.label` strings — the handoff's own
 * FRONT_FACE/LEFT_CHEEK/RIGHT_CHEEK naming is the enum-style spelling of the same three views).
 *
 * Matching NEVER compares raw pixel coordinates between views (this batch's own explicit rule) —
 * every distance computation here goes through [RegionalNormalizationEngine], and a pair is only
 * ever compared when both ends resolved to genuine `RegionPolygon`-derived positions
 * ([RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE]); a pair where either side fell
 * back to the "position unknown" center placeholder is never treated as a spatial match — see
 * `compatible()` below.
 *
 * Absence handling: a candidate with no cross-view partner still produces its OWN
 * [FeatureCorrespondence] record (a single-view correspondence, `state = UNCERTAIN`, per this
 * batch's explicit "Permit single-view features" / "Do not treat missing visibility as proof of
 * absence" rules) rather than being silently dropped.
 *
 * Clustering uses union-find so a chain of pairwise-compatible candidates across all three views
 * merges into ONE correspondence (not three separate pairwise ones), matching "supportingViews"
 * being a genuine set of views, not a count of pairs.
 */
object FeatureCorrespondenceEngine {
    const val VERSION = "feature_correspondence_engine_v1"

    private val hairFamily = setOf(SpecializedFeatureType.HAIR_LIKE, SpecializedFeatureType.STUBBLE_LIKE)
    private val poreFamily = setOf(SpecializedFeatureType.PORE_LIKE, SpecializedFeatureType.FOLLICULAR_OPENING_LIKE)
    private val blemishFamily = setOf(
        SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.BLACKHEAD_LIKE, SpecializedFeatureType.WHITEHEAD_LIKE,
        SpecializedFeatureType.PAPULE_LIKE_VISUAL, SpecializedFeatureType.PUSTULE_LIKE_VISUAL, SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE
    )
    private val darkFamily = setOf(
        SpecializedFeatureType.DARK_MARK_LIKE, SpecializedFeatureType.PIGMENTATION_LIKE,
        SpecializedFeatureType.RED_MARK_LIKE, SpecializedFeatureType.POST_ACNE_MARK_LIKE, SpecializedFeatureType.UNCERTAIN_DARK_FEATURE
    )
    private val rednessFamily = setOf(SpecializedFeatureType.LOCALIZED_REDNESS_LIKE)
    private val bumpFamily = setOf(
        SpecializedFeatureType.BUMP_LIKE, SpecializedFeatureType.SURFACE_STRUCTURE_LIKE, SpecializedFeatureType.UNCERTAIN_SURFACE_STRUCTURE
    )
    private val families = listOf(hairFamily, poreFamily, blemishFamily, darkFamily, rednessFamily, bumpFamily)
    private fun familyIndex(t: SpecializedFeatureType): Int = families.indexOfFirst { t in it }

    private const val MAX_NORM_DISTANCE = 0.3
    private const val MIN_AREA_RATIO = 0.2

    private fun areaRatio(a: Int, b: Int): Double {
        if (a <= 0 || b <= 0) return 0.0
        return minOf(a, b).toDouble() / maxOf(a, b).toDouble()
    }

    /** Only meaningful reasons to think two DIFFERENT-view candidates are the same physical
     * feature: same type family, both resolved to true region geometry, close within that
     * geometry, and roughly consistent apparent size. */
    private fun edgeStrength(a: SpecializedFeatureEvidence, na: NormalizedPosition, b: SpecializedFeatureEvidence, nb: NormalizedPosition): Double? {
        if (a.sourceView == b.sourceView) return null // never merge two candidates from the same view here
        if (na.method != RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE) return null
        if (nb.method != RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE) return null
        val famA = familyIndex(a.featureType); val famB = familyIndex(b.featureType)
        if (famA < 0 || famA != famB) return null
        val dist = RegionalNormalizationEngine.distance(na, nb)
        if (dist > MAX_NORM_DISTANCE) return null
        val ratio = areaRatio(a.area, b.area)
        if (ratio < MIN_AREA_RATIO) return null
        val exactTypeBonus = if (a.featureType == b.featureType) 0.15 else 0.0
        val distanceFactor = (1.0 - dist / MAX_NORM_DISTANCE).coerceIn(0.0, 1.0)
        return (0.45 * distanceFactor + 0.25 * ratio + 0.15 * minOf(a.primaryConfidence, b.primaryConfidence) + exactTypeBonus).coerceIn(0.0, 1.0)
    }

    private class UnionFind(n: Int) {
        val parent = IntArray(n) { it }
        fun find(x: Int): Int { var r = x; while (parent[r] != r) r = parent[r]; parent[x] = r; return r }
        fun union(a: Int, b: Int) { val ra = find(a); val rb = find(b); if (ra != rb) parent[ra] = rb }
    }

    /**
     * [evidence] the full session evidence list (all three views). [regionSetsByView] maps
     * `sourceView` -> that view's [RegionSet] (see [PostAcneSpatialAssociationEngine.associate]
     * for the same convention). [sessionId]/[captureQuality] are passed straight through onto
     * every produced [FeatureCorrespondence] (`sourceSessionIds`/`captureQuality` fields).
     *
     * Only [SpecializedFeatureEvidence.classificationState] SUPPORTED or PARTIALLY_SUPPORTED
     * candidates produce correspondence records — the weakest (UNCERTAIN) raw readings remain
     * fully available in their own untouched evidence file, they simply don't get promoted into
     * this derived layer, keeping correspondence volume meaningful rather than exhaustive.
     */
    fun buildCorrespondences(
        evidence: List<SpecializedFeatureEvidence>,
        regionSetsByView: Map<String, RegionSet>,
        sessionId: String,
        captureQuality: String?
    ): List<FeatureCorrespondence> {
        val eligible = evidence.filter { it.classificationState != FeatureClassificationState.UNCERTAIN }
        val out = mutableListOf<FeatureCorrespondence>()
        var seq = 0

        for ((region, groupList) in eligible.groupBy { it.anatomicalRegion }) {
            val items = groupList
            val positions = items.map { RegionalNormalizationEngine.normalize(regionSetsByView[it.sourceView], region, it.sourceCoordinates.first, it.sourceCoordinates.second) }
            val uf = UnionFind(items.size)
            // per-pair edge strengths, kept so cluster confidence can average the ACTUAL matched edges rather than re-deriving it after union
            val edgeStrengths = mutableMapOf<Pair<Int, Int>, Double>()

            for (i in items.indices) {
                for (j in i + 1 until items.size) {
                    val strength = edgeStrength(items[i], positions[i], items[j], positions[j]) ?: continue
                    edgeStrengths[i to j] = strength
                    uf.union(i, j)
                }
            }

            val clusters = (items.indices).groupBy { uf.find(it) }
            for ((_, memberIdx) in clusters) {
                val members = memberIdx.map { items[it] }
                val memberViews = members.map { it.sourceView }.distinct()
                val dominantType = members.groupingBy { it.featureType }.eachCount().maxByOrNull { it.value }!!.key
                val minSkin = members.minOf { it.skinConfidence }
                val avgAreaRatioApprox = if (members.size >= 2) {
                    val areas = members.map { it.area }
                    (areas.minOrNull() ?: 0).toDouble() / (areas.maxOrNull() ?: 1).coerceAtLeast(1)
                } else 1.0
                // Cluster's own centroid position: mean of members' own normalized positions
                // that used true geometry; falls back to the plain average (including the
                // fallback center) only when NONE of the members had true geometry.
                val memberPositions = memberIdx.map { positions[it] }
                val truePositions = memberPositions.filter { it.method == RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE }
                val basisPositions = if (truePositions.isNotEmpty()) truePositions else memberPositions
                val meanNx = basisPositions.map { it.nx }.average()
                val meanNy = basisPositions.map { it.ny }.average()
                val clusterPosition = NormalizedPosition(
                    nx = meanNx, ny = meanNy,
                    method = if (truePositions.isNotEmpty()) RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE else RegionalNormalizationEngine.METHOD_UNAVAILABLE_FALLBACK,
                    outOfBounds = basisPositions.any { it.outOfBounds }
                )

                val reasons = mutableListOf<String>()
                val state: CorrespondenceState
                val confidence: Double

                if (members.size == 1) {
                    state = CorrespondenceState.UNCERTAIN
                    confidence = (members[0].primaryConfidence * 0.5).coerceIn(0.0, 1.0)
                    reasons.add("no compatible candidate found in another captured view for this region/feature-type; correspondence unconfirmed, not ruled out")
                } else {
                    val relevantEdges = edgeStrengths.filter { (k, _) -> k.first in memberIdx && k.second in memberIdx }.values
                    val meanEdge = if (relevantEdges.isNotEmpty()) relevantEdges.average() else 0.3
                    confidence = meanEdge.coerceIn(0.0, 1.0)
                    state = when {
                        memberViews.size >= 2 && meanEdge >= 0.55 -> CorrespondenceState.SUPPORTED
                        memberViews.size >= 2 -> CorrespondenceState.PARTIAL
                        else -> CorrespondenceState.UNCERTAIN // same-view cluster bridged only through a fallback-geometry member; kept, not discarded
                    }
                    reasons.add("matched across ${memberViews.size} view(s) (${memberViews.joinToString(", ")}) with mean correspondence strength ${"%.2f".format(meanEdge)}")
                    if (members.size > memberViews.size) reasons.add("ambiguous: ${members.size} candidates resolved into ${memberViews.size} distinct view(s) — more than one same-view candidate matched the same cross-view partner")
                }

                out.add(
                    FeatureCorrespondence(
                        correspondenceId = "${region}_corr${seq++}",
                        featureType = dominantType,
                        anatomicalRegion = region,
                        normalizedLocation = clusterPosition,
                        sourceFeatures = members.map { it.candidateId },
                        supportingViews = memberViews,
                        correspondenceConfidence = confidence,
                        evidenceReasons = reasons,
                        normalizedSizeApproximate = avgAreaRatioApprox,
                        shapeDescriptor = members.first().shape,
                        regionalContext = region.toString(),
                        skinConfidence = minSkin,
                        captureQuality = captureQuality,
                        sourceSessionIds = listOf(sessionId),
                        state = state
                    )
                )
            }
        }
        return out
    }

    fun json(correspondences: List<FeatureCorrespondence>): String {
        val body = correspondences.joinToString(",") { FeatureCorrespondenceJson.json(it) }
        return """{"method":"$VERSION","correspondence_count":${correspondences.size},"correspondences":[$body]}"""
    }
}
