package com.rawskinanalyzer

/**
 * FeatureCorrespondenceModels
 *
 * Batch 4D-G, step_1. A [FeatureCorrespondence] is a SEPARATE derived object linking one or more
 * [SpecializedFeatureEvidence] candidate IDs that this session's [FeatureCorrespondenceEngine]
 * judged plausibly represent the same physical skin feature seen from different camera views (or,
 * for a single-view feature, links exactly one candidate). It never merges or destroys the
 * underlying candidates — `sourceFeatures` holds their IDs; the raw [SpecializedFeatureEvidence]
 * / [VisualFeatureCandidate] records those IDs point to are untouched and remain independently
 * readable, per this batch's own "Do not destroy or merge the original candidates" rule.
 *
 * [normalizedLocation] is a [NormalizedPosition] from [RegionalNormalizationEngine] — see that
 * file for the true-vs-fallback distinction (`method` field) this batch's step_2 introduces.
 *
 * `additional_fields_if_supported` from the handoff are included, each honestly scoped:
 *  - [normalizedSizeApproximate]: an area RATIO (not a physical size, and not corrected for any
 *    view-to-view resolution/scale difference — no such correction exists in this project) —
 *    named "Approximate" rather than bare "normalizedSize" to keep that limitation visible at the
 *    call site, not just in a doc comment.
 *  - [shapeDescriptor] / [regionalContext]: read from the underlying candidate's own already-
 *    computed shape string / region name, not re-derived.
 *  - [skinConfidence]: the minimum skin confidence across [sourceFeatures] (a correspondence is
 *    only as trustworthy as its least-trusted supporting candidate).
 *  - [captureQuality]: `MainActivity.lastCaptureConditionConsistency` (this batch's own
 *    "Use existing three-view consistency architecture" requirement) passed through as-is.
 *  - [sourceSessionIds]: currently always a single-element list (this session's own ID) — cross-
 *    SESSION correspondence is not implemented (see [FeatureIdentityRecord] / PROJECT_STATUS.md);
 *    the field exists now so a future longitudinal batch does not need a model migration.
 */
enum class CorrespondenceState { SUPPORTED, PARTIAL, UNCERTAIN, NOT_CORRESPONDING }

/**
 * A feature position expressed relative to its OWN anatomical region's own geometry, not to the
 * source image's raw pixel grid — see [RegionalNormalizationEngine] for how [method] distinguishes
 * a true `RegionPolygon`-derived value from the rarer fallback.
 */
data class NormalizedPosition(
    val nx: Double,
    val ny: Double,
    val method: String,
    /** True if the raw (nx,ny) fell outside [0,1] before being clamped — i.e. the source point sat outside its own region polygon's own bounding extent (region assignment and region-relative normalization use slightly different geometry, so this is possible and is recorded rather than hidden by silent clamping). */
    val outOfBounds: Boolean
)

data class FeatureCorrespondence(
    val correspondenceId: String,
    val featureType: SpecializedFeatureType,
    val anatomicalRegion: AnatomicalRegion,
    val normalizedLocation: NormalizedPosition,
    val sourceFeatures: List<String>,
    val supportingViews: List<String>,
    val correspondenceConfidence: Double,
    val evidenceReasons: List<String>,
    val normalizedSizeApproximate: Double,
    val shapeDescriptor: String,
    val regionalContext: String,
    val skinConfidence: Double,
    val captureQuality: String?,
    val sourceSessionIds: List<String>,
    val state: CorrespondenceState
)

object FeatureCorrespondenceJson {
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    fun normalizedPositionJson(p: NormalizedPosition): String =
        """{"nx":${p.nx},"ny":${p.ny},"method":"${p.method}","out_of_bounds":${p.outOfBounds}}"""

    fun json(c: FeatureCorrespondence): String {
        val src = c.sourceFeatures.joinToString(",") { "\"${esc(it)}\"" }
        val views = c.supportingViews.joinToString(",") { "\"${esc(it)}\"" }
        val reasons = c.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }
        val sessions = c.sourceSessionIds.joinToString(",") { "\"${esc(it)}\"" }
        val cq = if (c.captureQuality != null) "\"${esc(c.captureQuality)}\"" else "null"
        return """{"correspondence_id":"${c.correspondenceId}","feature_type":"${c.featureType}","anatomical_region":"${c.anatomicalRegion}","normalized_location":${normalizedPositionJson(c.normalizedLocation)},"source_features":[$src],"supporting_views":[$views],"correspondence_confidence":${c.correspondenceConfidence},"evidence_reasons":[$reasons],"normalized_size_approximate":${c.normalizedSizeApproximate},"shape_descriptor":"${esc(c.shapeDescriptor)}","regional_context":"${esc(c.regionalContext)}","skin_confidence":${c.skinConfidence},"capture_quality":$cq,"source_session_ids":[$sessions],"state":"${c.state}"}"""
    }
}
