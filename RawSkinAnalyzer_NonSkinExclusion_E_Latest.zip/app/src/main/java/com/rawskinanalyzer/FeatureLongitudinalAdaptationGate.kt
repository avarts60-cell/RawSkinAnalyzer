package com.rawskinanalyzer

/**
 * FeatureLongitudinalAdaptationGate
 *
 * Batch 4D-H, step_9 (P1). Exposes conservative feature-level longitudinal evidence to Brain 2
 * (the routine-adaptation/recommendation chain) through the exact same cap-only pattern already
 * established by `CaptureQualityReliabilityGate` (Batch 3B) and `ComparabilityAdaptationGate`
 * (Batch 4B) — this file adds a THIRD, separate gate for a THIRD distinct signal
 * (feature-level trend strength/confidence), rather than folding it into either existing gate,
 * for the same reason `ComparabilityAdaptationGate`'s own doc comment gives: conflating distinct
 * signals into one function blurs which cause produced a given cap.
 *
 * This gate runs LAST in the adaptation chain (after `CaptureQualityReliabilityGate` and
 * `ComparabilityAdaptationGate`/`TrendIntelligenceAdaptationGate` have already applied their own
 * caps) and can only cap further, never escalate — it cannot turn a REVIEW_AND_MONITOR decision
 * back into CONSIDER_ROUTINE_ADJUSTMENT, and it cannot raise confidence. Feature-level evidence is
 * inherently weaker/more granular than characteristic-level evidence (a single pore or blemish
 * candidate, not an aggregate score), so per step_9's "never escalate recommendations from weak
 * feature-level evidence" rule, feature-level trends are only ever able to REDUCE confidence in an
 * already-decided characteristic-level action — they are never themselves capable of producing or
 * strengthening a CONSIDER_ROUTINE_ADJUSTMENT decision. This file does not redesign
 * `RoutineAdaptationEngine`, `TrendAwareRoutineAdaptationPolicy`, or either of the two existing
 * gates.
 */
object FeatureLongitudinalAdaptationGate {

    private const val WEAK_FEATURE_EVIDENCE_TAG = "FEATURE_LEVEL_EVIDENCE_WEAK_OR_UNCERTAIN_CONSERVATIVE"
    private const val FEATURE_NOT_COMPARABLE_TAG = "FEATURE_LEVEL_EVIDENCE_NOT_COMPARABLE"
    private const val MIN_SUMMARIES_FOR_TRUST = 1
    private const val LOW_CONFIDENCE_SHARE_THRESHOLD = 0.5

    /**
     * [featureResult] is the same [FeatureLongitudinalResult] already computed once by
     * [FeatureLongitudinalTrendAnalyzer] (via `UiAnalysisAssembler`/
     * `FinalSkinAnalysisProfileAnalyzer`) — this gate performs no comparison of its own, only
     * reads the result to decide whether the ALREADY-COMPUTED [adaptation] decision should be
     * capped further.
     */
    fun apply(
        adaptation: TrendAwareAdaptationResult,
        featureResult: FeatureLongitudinalResult
    ): TrendAwareAdaptationResult {
        val decision = adaptation.decision

        // Nothing to cap: either the decision is already conservative (REVIEW_AND_MONITOR or
        // weaker), or there is no feature-level signal at all to weigh in on it — either way
        // this gate has nothing useful to add, and per "cap-only" it must never manufacture a
        // decision it cannot cap.
        if (decision.action != RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT) return adaptation

        if (featureResult.comparability.status == SessionComparabilityStatus.NOT_COMPARABLE) {
            return adaptation.copy(
                decision = decision.copy(
                    action = RoutineAdaptationAction.REVIEW_AND_MONITOR,
                    adaptationConfidence = "LOW",
                    reasons = (decision.reasons + FEATURE_NOT_COMPARABLE_TAG).distinct()
                ),
                trendInfluenceApplied = adaptation.trendInfluenceApplied,
                trendReasons = (adaptation.trendReasons + FEATURE_NOT_COMPARABLE_TAG).distinct()
            )
        }

        if (featureResult.summaries.size < MIN_SUMMARIES_FOR_TRUST) return adaptation

        val uncertainOrWorse = featureResult.summaries.count {
            it.trendState == FeatureTrendState.UNCERTAIN ||
                it.trendState == FeatureTrendState.INSUFFICIENT_DATA ||
                it.trendState == FeatureTrendState.NOT_COMPARABLE
        }
        val lowConfidenceShare = uncertainOrWorse.toDouble() / featureResult.summaries.size

        if (lowConfidenceShare >= LOW_CONFIDENCE_SHARE_THRESHOLD) {
            val cappedConfidence = if (decision.adaptationConfidence == "HIGH") "MODERATE" else decision.adaptationConfidence
            return adaptation.copy(
                decision = decision.copy(
                    adaptationConfidence = cappedConfidence,
                    reasons = (decision.reasons + WEAK_FEATURE_EVIDENCE_TAG).distinct()
                ),
                trendReasons = (adaptation.trendReasons + WEAK_FEATURE_EVIDENCE_TAG).distinct()
            )
        }

        return adaptation
    }
}
