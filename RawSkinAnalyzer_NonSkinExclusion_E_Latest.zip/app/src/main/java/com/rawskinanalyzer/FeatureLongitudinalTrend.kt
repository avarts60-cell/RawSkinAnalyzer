package com.rawskinanalyzer

import kotlin.math.abs

/**
 * FeatureLongitudinalTrend
 *
 * Batch 4D-H, step_3/step_4/step_6/step_7. Consumes real cross-session
 * [FeatureChangeEvidence] (from [LongitudinalFeatureContract.compareIdentities], Batch 4D-G —
 * that function already exists and is reused verbatim, per the handoff's "do not create a
 * parallel longitudinal engine" instruction) and produces:
 *  - region-wide count/density/regional-distribution change (step_3's remaining measurements
 *    that [LongitudinalFeatureContract] deliberately left uncomputed, since they are per-region
 *    judgments rather than per-feature matches — see that file's own trailing comment),
 *  - a conservative per-region/per-type [FeatureTrendState] classification (step_4),
 *  - a compact [FeatureTrendSummary] shaped for Progress/History (step_6/step_7).
 *
 * Every rule in the handoff's step_11 ("accuracy and uncertainty") is enforced here structurally,
 * not just in wording:
 *  - A single [FeatureChangeEvidence] of NEW_FEATURE_CANDIDATE never alone yields WORSENING —
 *    classification requires a minimum confidence AND (for anything stronger than UNCERTAIN)
 *    requires the comparability gate to be at least COMPARABLE.
 *  - RESOLVED_FEATURE_CANDIDATE never alone yields IMPROVING for the same reason.
 *  - NOT_COMPARABLE sessions (all evidence is UNCERTAIN_CHANGE) always classify as
 *    NOT_COMPARABLE, never STABLE (STABLE is itself a claim that requires trustworthy evidence).
 *  - Fewer than [MIN_EVIDENCE_FOR_CLASSIFICATION] change records for a region+type pair yields
 *    INSUFFICIENT_DATA rather than guessing from one data point.
 */

enum class FeatureTrendState {
    IMPROVING, WORSENING, STABLE, MIXED, INSUFFICIENT_DATA, NOT_COMPARABLE, UNCERTAIN
}

data class RegionalFeatureChangeMetrics(
    val region: AnatomicalRegion,
    val previousCount: Int,
    val currentCount: Int,
    val countDelta: Int,
    val previousDensity: Double?,
    val currentDensity: Double?,
    val densityDelta: Double?,
    val persistentCount: Int,
    val newCandidateCount: Int,
    val possibleResolutionCount: Int,
    val regionalDistributionShift: Boolean
)

data class FeatureTrendSummary(
    val featureCategory: SpecializedFeatureType,
    val region: AnatomicalRegion,
    val trendState: FeatureTrendState,
    val changeConfidence: Double,
    val supportingSessions: Int,
    val evidenceReason: String
)

data class FeatureLongitudinalResult(
    val changes: List<FeatureChangeEvidence>,
    val regionalMetrics: List<RegionalFeatureChangeMetrics>,
    val summaries: List<FeatureTrendSummary>,
    val comparability: SessionComparabilityResult,
    val overallDataStatus: String
)

object FeatureLongitudinalTrendAnalyzer {
    const val VERSION = "feature_longitudinal_trend_v1"
    private const val MIN_EVIDENCE_FOR_CLASSIFICATION = 1 // per region+type pair, this session vs previous
    private const val MIN_CONFIDENCE_FOR_DIRECTIONAL_CLAIM = 0.35
    private const val DENSITY_SHIFT_THRESHOLD = 0.15 // absolute density-fraction change

    /**
     * [previousRecords] is null when there is nothing valid to compare against (no previous
     * session, or the previous session predates feature-evidence persistence — see
     * `SkinSessionRepository.previousFeatureIdentityRecords`), distinct from an empty list
     * (a previous session WAS recorded and genuinely had zero features). Both cases still
     * return a real [FeatureLongitudinalResult] — never a null/absent result — so Progress/
     * History always have something honest to show (per step_6's own "preserve
     * NOT_COMPARABLE/INSUFFICIENT_DATA states" requirement) rather than silently omitting the
     * feature-trend section.
     */
    fun analyze(
        previousRecords: List<FeatureIdentityRecord>?,
        currentRecords: List<FeatureIdentityRecord>,
        comparability: SessionComparabilityResult?
    ): FeatureLongitudinalResult {
        if (previousRecords == null || comparability == null) {
            return FeatureLongitudinalResult(
                changes = emptyList(),
                regionalMetrics = emptyList(),
                summaries = emptyList(),
                comparability = comparability ?: SessionComparabilityResult(
                    SessionComparabilityStatus.NOT_COMPARABLE,
                    listOf("NO_PREVIOUS_FEATURE_EVIDENCE_AVAILABLE")
                ),
                overallDataStatus = "INSUFFICIENT_DATA"
            )
        }

        val changes = LongitudinalFeatureContract.compareIdentities(previousRecords, currentRecords, comparability)
        val regionalMetrics = regionalChangeMetrics(previousRecords, currentRecords, changes)
        val summaries = classify(changes, comparability)

        val overallDataStatus = when {
            comparability.status == SessionComparabilityStatus.NOT_COMPARABLE -> "NOT_COMPARABLE"
            changes.isEmpty() -> "INSUFFICIENT_DATA"
            else -> "EVIDENCE_AVAILABLE"
        }

        return FeatureLongitudinalResult(changes, regionalMetrics, summaries, comparability, overallDataStatus)
    }

    /**
     * Step_3's region-wide measurements ("count change", "density change", "regional
     * distribution change", "persistent/new/possible-resolution counts") — these are judgments
     * about a REGION as a whole, computed from the same [changes] list
     * [LongitudinalFeatureContract.compareIdentities] already produced, not a second matching
     * pass. Density uses each record's own region as the unit (feature count is not itself
     * normalized by skin area here — that normalization already happens once, upstream, in
     * `CrossViewFeatureFusionEngine.regionalMetrics`'s `RegionalFusedMetrics.density`; this
     * function reuses relative COUNT change within a region as the density-change proxy so it
     * does not need a second skin-coverage sample that this layer does not have — an honest
     * scoping note, not a silent approximation).
     */
    private fun regionalChangeMetrics(
        previous: List<FeatureIdentityRecord>,
        current: List<FeatureIdentityRecord>,
        changes: List<FeatureChangeEvidence>
    ): List<RegionalFeatureChangeMetrics> {
        val regions = (previous.map { it.anatomicalRegion } + current.map { it.anatomicalRegion }).distinct()
        return regions.map { region ->
            val prevCount = previous.count { it.anatomicalRegion == region }
            val curCount = current.count { it.anatomicalRegion == region }
            val regionChanges = changes.filter { it.anatomicalRegion == region }
            val persistent = regionChanges.count { it.changeType == FeatureChangeType.PERSISTING_FEATURE }
            val newCandidates = regionChanges.count { it.changeType == FeatureChangeType.NEW_FEATURE_CANDIDATE }
            val resolved = regionChanges.count { it.changeType == FeatureChangeType.RESOLVED_FEATURE_CANDIDATE }

            // Density here is COUNT relative to this session's own total feature count in the
            // region set, i.e. "share of all detected features that sit in this region" — a
            // relative distribution measure, not an absolute per-skin-area density (that already
            // exists separately in RegionalFusedMetrics). Null (not zero) when there is nothing
            // to divide by, so an empty session is never displayed as "0% density" (a real,
            // comparable reading) versus "no data".
            val prevTotal = previous.size
            val curTotal = current.size
            val prevDensity = if (prevTotal > 0) prevCount.toDouble() / prevTotal else null
            val curDensity = if (curTotal > 0) curCount.toDouble() / curTotal else null
            val densityDelta = if (prevDensity != null && curDensity != null) curDensity - prevDensity else null
            val distributionShift = densityDelta != null && abs(densityDelta) >= DENSITY_SHIFT_THRESHOLD

            RegionalFeatureChangeMetrics(
                region = region,
                previousCount = prevCount,
                currentCount = curCount,
                countDelta = curCount - prevCount,
                previousDensity = prevDensity,
                currentDensity = curDensity,
                densityDelta = densityDelta,
                persistentCount = persistent,
                newCandidateCount = newCandidates,
                possibleResolutionCount = resolved,
                regionalDistributionShift = distributionShift
            )
        }
    }

    /**
     * Step_4: conservative classification per (featureType, region) pair. Never calls
     * IMPROVING/WORSENING from a single low-confidence record, never treats NOT_COMPARABLE
     * evidence as STABLE, and always preserves the underlying evidence reasons rather than
     * replacing them with a bare label.
     */
    private fun classify(
        changes: List<FeatureChangeEvidence>,
        comparability: SessionComparabilityResult
    ): List<FeatureTrendSummary> {
        if (comparability.status == SessionComparabilityStatus.NOT_COMPARABLE) {
            return changes.groupBy { it.featureType to it.anatomicalRegion }.map { (key, group) ->
                val (type, region) = key
                FeatureTrendSummary(
                    featureCategory = type, region = region,
                    trendState = FeatureTrendState.NOT_COMPARABLE,
                    changeConfidence = 0.0, supportingSessions = 1,
                    evidenceReason = "Sessions are not sufficiently comparable, so no feature-level change can be shown: ${comparability.reasons.joinToString("; ")}."
                )
            }
        }

        return changes.groupBy { it.featureType to it.anatomicalRegion }.map { (key, group) ->
            val (type, region) = key
            if (group.size < MIN_EVIDENCE_FOR_CLASSIFICATION) {
                return@map FeatureTrendSummary(
                    featureCategory = type, region = region,
                    trendState = FeatureTrendState.INSUFFICIENT_DATA,
                    changeConfidence = 0.0, supportingSessions = 1,
                    evidenceReason = "Not enough comparable evidence yet for this feature type in this region."
                )
            }

            val avgConfidence = group.map { it.confidence }.average()
            val types = group.map { it.changeType }.toSet()

            val hasWeakOnlyEvidence = avgConfidence < MIN_CONFIDENCE_FOR_DIRECTIONAL_CLAIM
            val state = when {
                hasWeakOnlyEvidence -> FeatureTrendState.UNCERTAIN
                types.size == 1 && types.first() == FeatureChangeType.PERSISTING_FEATURE ->
                    FeatureTrendState.STABLE
                // A pattern dominated by resolutions (image evidence of features no longer
                // visible) reads as visually IMPROVING appearance — explicitly NOT "resolved"
                // or "healed", per step_4/step_11's own wording rule. Requires the group to be
                // resolution-dominated, not a single resolved candidate among many persisting
                // ones (that would be MIXED below).
                types.all { it == FeatureChangeType.RESOLVED_FEATURE_CANDIDATE || it == FeatureChangeType.PERSISTING_FEATURE } &&
                    group.count { it.changeType == FeatureChangeType.RESOLVED_FEATURE_CANDIDATE } > group.count { it.changeType == FeatureChangeType.PERSISTING_FEATURE } ->
                    FeatureTrendState.IMPROVING
                // Symmetric case for new-candidate-dominated groups — visually WORSENING
                // appearance, explicitly NOT "new lesion" or "onset".
                types.all { it == FeatureChangeType.NEW_FEATURE_CANDIDATE || it == FeatureChangeType.PERSISTING_FEATURE } &&
                    group.count { it.changeType == FeatureChangeType.NEW_FEATURE_CANDIDATE } > group.count { it.changeType == FeatureChangeType.PERSISTING_FEATURE } ->
                    FeatureTrendState.WORSENING
                types.contains(FeatureChangeType.NEW_FEATURE_CANDIDATE) && types.contains(FeatureChangeType.RESOLVED_FEATURE_CANDIDATE) ->
                    FeatureTrendState.MIXED
                types.contains(FeatureChangeType.SIZE_CHANGE) || types.contains(FeatureChangeType.VISIBILITY_CHANGE) ->
                    FeatureTrendState.MIXED
                types.contains(FeatureChangeType.UNCERTAIN_CHANGE) -> FeatureTrendState.UNCERTAIN
                else -> FeatureTrendState.STABLE
            }

            val reason = when (state) {
                FeatureTrendState.IMPROVING -> "More previously-recorded features of this type in this region were absent than persisted in the latest comparable session; this reflects visible appearance only, not confirmed resolution."
                FeatureTrendState.WORSENING -> "More new feature candidates of this type appeared in this region than persisted features remained unchanged; this reflects visible appearance only, not a confirmed new condition."
                FeatureTrendState.STABLE -> "Features of this type in this region matched consistently between the two comparable sessions."
                FeatureTrendState.MIXED -> "Evidence for this type in this region includes both new and no-longer-visible features, or notable size/visibility change, without a single consistent direction."
                FeatureTrendState.UNCERTAIN -> "Evidence confidence for this type in this region is too low to state a direction."
                FeatureTrendState.INSUFFICIENT_DATA -> "Not enough comparable evidence yet."
                FeatureTrendState.NOT_COMPARABLE -> "Sessions are not sufficiently comparable."
            }

            FeatureTrendSummary(
                featureCategory = type, region = region,
                trendState = state,
                changeConfidence = avgConfidence,
                supportingSessions = 2, // exactly previous + current; this layer does not yet look further back
                evidenceReason = reason
            )
        }
    }

    fun regionalMetricsJson(m: RegionalFeatureChangeMetrics): String =
        """{"region":"${m.region}","previous_count":${m.previousCount},"current_count":${m.currentCount},"count_delta":${m.countDelta},"previous_density":${m.previousDensity ?: "null"},"current_density":${m.currentDensity ?: "null"},"density_delta":${m.densityDelta ?: "null"},"persistent_count":${m.persistentCount},"new_candidate_count":${m.newCandidateCount},"possible_resolution_count":${m.possibleResolutionCount},"regional_distribution_shift":${m.regionalDistributionShift}}"""

    fun summaryJson(s: FeatureTrendSummary): String =
        """{"feature_category":"${s.featureCategory}","region":"${s.region}","trend_state":"${s.trendState}","change_confidence":${s.changeConfidence},"supporting_sessions":${s.supportingSessions},"evidence_reason":"${s.evidenceReason.replace("\"", "\\\"")}"}"""

    fun json(result: FeatureLongitudinalResult): String {
        val changesJson = result.changes.joinToString(",") { LongitudinalFeatureContract.changeJson(it) }
        val regionalJson = result.regionalMetrics.joinToString(",") { regionalMetricsJson(it) }
        val summariesJson = result.summaries.joinToString(",") { summaryJson(it) }
        val reasons = result.comparability.reasons.joinToString(",") { "\"$it\"" }
        return """{"method":"$VERSION","overall_data_status":"${result.overallDataStatus}","comparability":{"status":"${result.comparability.status}","reasons":[$reasons]},"changes":[$changesJson],"regional_metrics":[$regionalJson],"summaries":[$summariesJson],"medical_diagnosis":false}"""
    }
}
