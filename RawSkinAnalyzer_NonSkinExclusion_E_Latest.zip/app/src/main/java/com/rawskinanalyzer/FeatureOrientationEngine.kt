package com.rawskinanalyzer

import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * FeatureOrientationEngine
 *
 * Batch 4D-F2, step_2 (P0). Replaces the approximated hair/stubble "orientation" that
 * `SpecializedFeatureClassifiers.refineHairAndStubble` previously derived only from a same-region
 * candidate COUNT (its own doc comment called this out explicitly: "a genuine per-pixel
 * orientation-histogram comparison would need raw gradient direction data this batch's existing
 * SignalGrid does not expose (only gradient magnitude)").
 *
 * This engine computes that missing orientation directly from [SignalGrid.luma] — no new tile
 * decode, no new pixel source. It reuses the exact luma array `VisualSignalGridExtractor` already
 * built for this component's own candidate detection pass, so orientation is derived from the
 * SAME pixels the candidate's other evidence already came from.
 *
 * Method: a per-cell central-difference gradient (gx, gy) — identical math to
 * `VisualSignalGridExtractor.computeGradients`, just kept as components instead of collapsed to
 * magnitude — fed into a structure tensor over the component's own cells:
 *   Jxx = sum(gx^2), Jyy = sum(gy^2), Jxy = sum(gx*gy)
 *   dominant gradient angle = 0.5 * atan2(2*Jxy, Jxx - Jyy)
 *   coherence = sqrt((Jxx-Jyy)^2 + 4*Jxy^2) / (Jxx + Jyy), in [0,1]
 * This is a standard structure-tensor orientation estimate (the same principle behind
 * fingerprint/fiber orientation fields), not a novel or unverified technique.
 *
 * A hair/stubble strand's own long axis runs PERPENDICULAR to its edge gradient (the gradient
 * points across the strand, from dark strand to lighter surrounding skin or vice versa) — so the
 * reported [OrientationEstimate.axisDegrees] is the gradient angle rotated 90 degrees, wrapped to
 * [0,180) since an axis (unlike a direction) has no distinguishable head/tail.
 *
 * [coherence] is genuinely informative here: a real hair/stubble strand's edge gradients point
 * consistently across its own axis (high coherence), while a rounder, more isotropic structure
 * (a pore, a follicular opening, a blemish) has gradients pointing outward in many directions
 * (low coherence). This gives `refineHairAndStubble` a real elongated-vs-round discriminator
 * beyond `elongation`/`aspectRatio` alone, from an independent (gradient-direction) signal.
 */
object FeatureOrientationEngine {
    const val VERSION = "feature_orientation_engine_v1"

    data class OrientationEstimate(
        /** Elongation axis in degrees, [0,180). -1.0 when the component had too little gradient energy to estimate reliably (near-flat cells only). */
        val axisDegrees: Double,
        /** 0-1. How consistently component-cell gradients agree with a single dominant axis; 0 when [axisDegrees] is -1.0. */
        val coherence: Double
    )

    private const val MIN_GRADIENT_ENERGY = 4.0 // sum(gx^2+gy^2) below this over the whole component is too little signal to trust an axis estimate

    /**
     * [cells] should be the component's own (row,col) list plus, ideally, its immediate
     * neighborhood — callers here pass the component's own cells, which is sufficient at
     * MICRO-tile scale since hair/stubble structures are already only a few cells wide.
     */
    fun estimate(grid: SignalGrid, cells: List<Pair<Int, Int>>): OrientationEstimate {
        var jxx = 0.0; var jyy = 0.0; var jxy = 0.0
        for ((r, c) in cells) {
            val left = grid.luma[r][max(0, c - 1)]
            val right = grid.luma[r][min(grid.cols - 1, c + 1)]
            val up = grid.luma[max(0, r - 1)][c]
            val down = grid.luma[min(grid.rows - 1, r + 1)][c]
            val gx = right - left
            val gy = down - up
            jxx += gx * gx
            jyy += gy * gy
            jxy += gx * gy
        }
        val energy = jxx + jyy
        if (energy < MIN_GRADIENT_ENERGY) return OrientationEstimate(-1.0, 0.0)

        val gradientAngleRad = 0.5 * atan2(2.0 * jxy, jxx - jyy)
        var axisDeg = Math.toDegrees(gradientAngleRad) + 90.0 // rotate gradient angle to the perpendicular (strand) axis
        axisDeg %= 180.0
        if (axisDeg < 0.0) axisDeg += 180.0

        val coherence = (sqrt((jxx - jyy) * (jxx - jyy) + 4.0 * jxy * jxy) / energy).coerceIn(0.0, 1.0)
        return OrientationEstimate(axisDeg, coherence)
    }

    /** Smallest angular distance between two AXIS angles (mod 180, so 179 and 1 are 2 degrees apart, not 178). */
    fun axisDistanceDegrees(a: Double, b: Double): Double {
        val d = kotlin.math.abs(a - b) % 180.0
        return min(d, 180.0 - d)
    }

    /**
     * Circular mean of a set of coherence-weighted AXIS angles (mod 180), via the standard
     * double-angle trick (an axis has period 180, so doubling maps it onto a period-360 circle
     * where ordinary circular-mean vector averaging applies, then the result is halved back).
     * Returns null when there is no usable orientation evidence at all in [estimates].
     */
    fun circularMeanAxisDegrees(estimates: List<OrientationEstimate>): Double? {
        val usable = estimates.filter { it.axisDegrees >= 0.0 && it.coherence > 0.05 }
        if (usable.isEmpty()) return null
        var sx = 0.0; var sy = 0.0
        for (e in usable) {
            val doubled = Math.toRadians(e.axisDegrees * 2.0)
            sx += e.coherence * kotlin.math.cos(doubled)
            sy += e.coherence * kotlin.math.sin(doubled)
        }
        if (sx == 0.0 && sy == 0.0) return null
        var meanDoubled = Math.toDegrees(atan2(sy, sx))
        if (meanDoubled < 0.0) meanDoubled += 360.0
        return meanDoubled / 2.0
    }
}
