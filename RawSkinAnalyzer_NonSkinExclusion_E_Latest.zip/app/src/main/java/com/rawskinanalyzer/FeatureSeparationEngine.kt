package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/**
 * FeatureSeparationEngine
 *
 * Batch 4D-D, step_11 — the first real feature/object separation layer. Takes one detected
 * structural component (shape + signal aggregates from `FeatureCandidateDetectors`) and scores
 * it independently against every classification_dimension this batch's handoff specifies, THEN
 * picks a primary type. A candidate is never forced into a single label if more than one
 * likelihood clears [SECONDARY_TYPE_THRESHOLD] — both are preserved, per step_11's explicit
 * "preserve secondary possibilities and uncertainty" rule.
 *
 * `shineLikelihood` is always 0.0 here and never contributes to this classifier's primary/secondary
 * selection — and stays that way even after Batch 4D-F added real shine detection, because this
 * field only scores the SAME dark/high-contrast/red-shift/texture-elevation structural mask
 * `FeatureCandidateDetectors.structuralCandidateMask` builds, which by construction cannot flag a
 * bright, low-chroma specular highlight (see that mask's own signals). Real, non-fabricated shine
 * evidence exists as its own candidate stream in [ShineDetectionEngine] (Batch 4D-F, step_1),
 * built on a separate bright/desaturated mask over the same [SignalGrid] — see that file's doc
 * comment for why this is a second detection pass rather than a value forced into this one.
 * `blemishLikeLikelihood` is a first-pass COMBINATION of pore/redness/dark-mark evidence (the
 * signals a blemish-like structure would plausibly share), not the dedicated shape/color/context
 * classifier step_12 specifies — step_12 itself is P1 and not implemented this batch.
 */
object FeatureSeparationEngine {
    private const val SECONDARY_TYPE_THRESHOLD = 0.45
    private const val MIN_PRIMARY_CONFIDENCE_FOR_KNOWN_TYPE = 0.4

    fun classify(
        comp: GridComponent,
        signals: FeatureCandidateDetectors.ComponentSignals,
        grid: SignalGrid
    ): Pair<FeatureEvidence, FeatureClassification> {
        val reasons = mutableListOf<String>()

        // --- hair/stubble: thin + elongated + locally dark + edge-defined (step_4) ---
        val darknessDepth = clamp01((grid.regionMeanLuma - signals.meanLuma) / max(1.0, grid.regionLumaStdDev * 2.0))
        val elongationScore = clamp01((comp.elongation - 1.5) / 4.0) // elongation 1.5..5.5 -> 0..1
        val thinness = clamp01(1.0 - (min(comp.boundingWidth, comp.boundingHeight).toDouble() / 4.0))
        val edgeDefined = clamp01(signals.meanGradient / max(1.0, grid.regionLumaStdDev * 1.5))
        val hairStubble = clamp01(0.35 * elongationScore + 0.25 * thinness + 0.25 * darknessDepth + 0.15 * edgeDefined)
        if (hairStubble > 0.4) reasons.add("elongated thin dark structure (elongation=${"%.2f".format(comp.elongation)})")

        // --- pore/follicular: compact, small, moderately dark/high-contrast, NOT elongated (step_5) ---
        val compactness = comp.circularity
        val smallSize = clamp01(1.0 - (comp.area.toDouble() / 12.0))
        val lowElongation = clamp01(1.0 - (comp.elongation - 1.0) / 2.0)
        val poreContrast = clamp01(signals.meanGradient / max(1.0, grid.regionLumaStdDev * 1.2))
        val pore = clamp01((0.3 * compactness + 0.25 * smallSize + 0.25 * lowElongation + 0.2 * poreContrast) * (1.0 - 0.6 * hairStubble))
        if (pore > 0.4) reasons.add("compact small-scale contrast structure (circularity=${"%.2f".format(comp.circularity)})")

        // follicular is treated as a related-but-distinct compact-opening reading: like pore but
        // weighted more toward darkness-at-center than edge strength, per step_5's "keep pore and
        // follicular evidence distinguishable even when they overlap conceptually".
        val follicular = clamp01((0.4 * compactness + 0.35 * darknessDepth + 0.25 * smallSize) * (1.0 - 0.6 * hairStubble))

        // --- dark-mark / pigmentation-like: broader local darkness, not thin/elongated (step_6) ---
        val darkMark = clamp01(darknessDepth * (1.0 - 0.7 * hairStubble) * clamp01(1.0 - (thinness - 0.6).coerceAtLeast(0.0)))
        if (darkMark > 0.4) reasons.add("localized darkness relative to region mean (depth=${"%.2f".format(darknessDepth)})")

        // --- redness: chroma shift above the tile's own mean, independent of darkness (step_7) ---
        val rednessShift = clamp01((signals.meanCr - grid.regionMeanCr) / 20.0)
        val redness = clamp01(rednessShift)
        if (redness > 0.4) reasons.add("chroma red-shift vs. local skin reference (delta_cr=${"%.2f".format(signals.meanCr - grid.regionMeanCr)})")

        // --- texture irregularity: local-variance elevation, larger/looser shape (step_8) ---
        val textureShape = clamp01((comp.area.toDouble() - 3.0) / 15.0)
        val textureVarianceScore = clamp01(signals.meanVariance / max(1.0, grid.regionLumaStdDev * grid.regionLumaStdDev * 0.6))
        val texture = clamp01(0.6 * textureVarianceScore + 0.4 * textureShape)
        if (texture > 0.4) reasons.add("local-variance elevation vs. regional baseline (variance=${"%.2f".format(signals.meanVariance)})")

        // --- shine: P1, not implemented this batch — recorded as zero, never estimated. ---
        val shine = 0.0

        // --- blemish-like: coarse first-pass combination only (dedicated classifier is step_12, P1). ---
        val blemishLike = clamp01(0.4 * pore + 0.3 * redness + 0.3 * darkMark)
        if (blemishLike > 0.5) reasons.add("combined pore/redness/dark-mark evidence (coarse pre-step_12 signal)")

        if (reasons.isEmpty()) reasons.add("no single signal cleared the classification threshold")

        val evidence = FeatureEvidence(
            hairStubbleLikelihood = hairStubble,
            follicularLikelihood = follicular,
            poreLikelihood = pore,
            darkMarkLikelihood = darkMark,
            rednessLikelihood = redness,
            blemishLikeLikelihood = blemishLike,
            textureLikelihood = texture,
            shineLikelihood = shine
        )

        val ranked = listOf(
            FeatureCandidateType.HAIR_OR_STUBBLE_CANDIDATE to hairStubble,
            FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE to max(pore, follicular),
            FeatureCandidateType.DARK_MARK_CANDIDATE to darkMark,
            FeatureCandidateType.REDNESS_REGION to redness,
            FeatureCandidateType.TEXTURE_IRREGULARITY_CANDIDATE to texture,
            FeatureCandidateType.BLEMISH_LIKE_CANDIDATE to blemishLike
        ).sortedByDescending { it.second }

        val best = ranked.first()
        val primary = if (best.second >= MIN_PRIMARY_CONFIDENCE_FOR_KNOWN_TYPE) best.first else FeatureCandidateType.UNKNOWN_CANDIDATE
        val secondary = ranked.drop(1).filter { it.second >= SECONDARY_TYPE_THRESHOLD }.map { it.first }
        // Confidence reflects the strength of the best-matching signal even when it fell short of
        // MIN_PRIMARY_CONFIDENCE_FOR_KNOWN_TYPE (i.e. primary == UNKNOWN_CANDIDATE) — an honest
        // "how close did the strongest signal get", not a claim of having successfully classified.
        return evidence to FeatureClassification(
            primaryFeatureType = primary,
            secondaryFeatureTypes = secondary,
            classificationConfidence = best.second,
            evidenceReasons = reasons
        )
    }

    private fun clamp01(v: Double) = max(0.0, min(1.0, v))
}
