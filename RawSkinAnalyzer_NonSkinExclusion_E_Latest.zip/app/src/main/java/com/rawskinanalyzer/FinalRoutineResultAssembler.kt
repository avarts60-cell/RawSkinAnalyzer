package com.rawskinanalyzer

data class FinalRoutineResult(
    val primaryFinding: String,
    val secondaryFinding: String,
    val prioritizedConcerns: List<String>,
    val morningRoutine: List<String>,
    val eveningRoutine: List<String>,
    val alternatingPlan: List<String>,
    val ingredientPlan: List<String>,
    val productRecommendations: List<ProductRecommendation>,
    val cautions: List<String>
)

object FinalRoutineResultAssembler {
    fun assemble(
        primaryFinding: String,
        secondaryFinding: String,
        schedule: RoutineSchedule,
        ingredientPlans: List<IngredientUsePlan>,
        recommendations: List<ProductRecommendation>
    ): FinalRoutineResult {
        val morning = schedule.morningSteps.map {
            "${it.category} — ${it.schedule}"
        }
        val evening = schedule.eveningBaseSteps.map {
            "${it.category} — ${it.schedule}"
        }
        val alternating = schedule.alternatingNightSteps.map {
            "${it.schedule}: ${it.category}"
        }
        val ingredients = ingredientPlans.map {
            "${it.ingredientName}: ${it.frequencyGuidance}"
        }
        val cautions = ingredientPlans.mapNotNull { it.caution }.distinct()

        return FinalRoutineResult(
            primaryFinding = primaryFinding,
            secondaryFinding = secondaryFinding,
            prioritizedConcerns = ingredientPlans.map { it.concern.name }.distinct(),
            morningRoutine = morning,
            eveningRoutine = evening,
            alternatingPlan = alternating,
            ingredientPlan = ingredients,
            productRecommendations = recommendations,
            cautions = cautions
        )
    }
}
