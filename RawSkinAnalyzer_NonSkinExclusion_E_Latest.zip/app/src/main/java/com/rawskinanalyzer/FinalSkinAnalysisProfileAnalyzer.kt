package com.rawskinanalyzer

data class FinalSkinFinding(
    val characteristic:String,
    val score:Double,
    val level:String,
    val priority:Int,
    val evidence:String,
    val confidence:String,
    // Batch 4E-B, step_1: whether this finding's score was nudged using real usable-skin-area
    // candidate density evidence (see DensityIntegratedScoring), and how many (view,region)
    // pairs supported that nudge. Defaults preserve every existing construction site's behavior
    // and output shape unchanged.
    val hasHighResolutionDensityEvidence: Boolean = false,
    val highResolutionDensitySupportingRegionCount: Int = 0
)

data class FinalSkinAnalysisProfile(
    val findings:List<FinalSkinFinding>,
    val primaryFinding:String,
    val secondaryFinding:String,
    val overallProfile:String,
    val analysisConfidence:String,
    // Per-characteristic scores carried forward from analyze() so downstream
    // consumers (progress tracking, multi-session trend) can read them without
    // re-deriving from the generic `findings` list by string-matching `characteristic`.
    val rednessScore:Double,
    val pigmentationScore:Double,
    val darkMarkScore:Double,
    val blemishLikeScore:Double,
    val textureIrregularityScore:Double,
    val poreLikeScore:Double,
    val surfaceShineScore:Double,
    val drynessRelatedScore:Double
)

object FinalSkinAnalysisProfileAnalyzer {
    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_SIGNAL"
        score>=30.0 -> "MODERATE_SIGNAL"
        score>=12.0 -> "LOW_SIGNAL"
        else -> "MINIMAL_SIGNAL"
    }

    private fun minConfidence(vararg values:String)=when {
        values.any { it=="LOW" } -> "LOW"
        values.all { it=="HIGH" } -> "HIGH"
        else -> "MODERATE"
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):FinalSkinAnalysisProfile {
        val redness=RednessAnalysisAnalyzer.analyze(front,left,right)
        val pigment=PigmentationTanningAnalyzer.analyze(front,left,right)
        val blemish=BlemishFeatureAnalyzer.analyze(front,left,right)
        val texture=TexturePoreFeatureAnalyzer.analyze(front,left,right)
        val surface=SurfaceConditionAnalyzer.analyze(front,left,right)

        val darkMarkScore=when(pigment.localizedDarkMarkSignal) {
            "HIGH_LOCALIZED_DARK_MARK_SIGNAL" -> 75.0
            "MODERATE_LOCALIZED_DARK_MARK_SIGNAL" -> 45.0
            "LOW_LOCALIZED_DARK_MARK_SIGNAL" -> 20.0
            else -> 5.0
        }

        val raw=listOf(
            FinalSkinFinding("REDNESS",redness.overallRednessScore,level(redness.overallRednessScore),0,
                "${redness.distribution}; ${redness.crossViewConsistency}",redness.confidence),
            FinalSkinFinding("PIGMENTATION_OR_TONE_VARIATION",pigment.pigmentationVariationScore,level(pigment.pigmentationVariationScore),0,
                pigment.broadToneShiftSignal,pigment.confidence),
            FinalSkinFinding("DARK_MARK_SIGNAL",darkMarkScore,level(darkMarkScore),0,
                pigment.localizedDarkMarkSignal,pigment.confidence),
            FinalSkinFinding("BLEMISH_LIKE_FEATURES",blemish.blemishLikeScore,level(blemish.blemishLikeScore),0,
                "${blemish.distribution}; ${blemish.repetition}",blemish.confidence),
            FinalSkinFinding("TEXTURE_IRREGULARITY",texture.textureIrregularityScore,level(texture.textureIrregularityScore),0,
                "${texture.distribution}; ${texture.crossViewConsistency}",texture.confidence),
            FinalSkinFinding("PORE_LIKE_FEATURES",texture.poreLikeSignalScore,level(texture.poreLikeSignalScore),0,
                texture.distribution,texture.confidence),
            FinalSkinFinding("SURFACE_SHINE_SIGNAL",surface.oilinessSignalScore,level(surface.oilinessSignalScore),0,
                surface.dominantSurfaceSignal,surface.confidence),
            FinalSkinFinding("DRYNESS_RELATED_SURFACE_SIGNAL",surface.drynessRelatedSignalScore,level(surface.drynessRelatedSignalScore),0,
                surface.dominantSurfaceSignal,surface.confidence)
        ).sortedByDescending { it.score }

        // Register every final score at the point where it becomes authoritative.
        FinalScoreRegistry.register(
            "REDNESS", redness.overallRednessScore,
            "RednessAnalysisAnalyzer", redness.overallRednessScore,
            selectionReason = "Dedicated redness analyzer output selected for final profile"
        )
        FinalScoreRegistry.register(
            "PIGMENTATION_OR_TONE_VARIATION", pigment.pigmentationVariationScore,
            "PigmentationTanningAnalyzer", pigment.pigmentationVariationScore,
            selectionReason = "Dedicated pigmentation analyzer output selected for final profile"
        )
        FinalScoreRegistry.register(
            "DARK_MARK_SIGNAL", darkMarkScore,
            "PigmentationTanningAnalyzer.localizedDarkMarkSignal",
            darkMarkScore,
            selectionReason = "Categorical dark-mark signal mapped to explicit final severity score"
        )
        FinalScoreRegistry.register(
            "BLEMISH_LIKE_FEATURES", blemish.blemishLikeScore,
            "BlemishFeatureAnalyzer", blemish.blemishLikeScore,
            selectionReason = "Dedicated blemish-like analyzer output selected for final profile"
        )
        FinalScoreRegistry.register(
            "TEXTURE_IRREGULARITY", texture.textureIrregularityScore,
            "TexturePoreFeatureAnalyzer.textureIrregularityScore", texture.textureIrregularityScore,
            selectionReason = "Dedicated texture analyzer output selected for final profile"
        )
        FinalScoreRegistry.register(
            "PORE_LIKE_FEATURES", texture.poreLikeSignalScore,
            "TexturePoreFeatureAnalyzer.poreLikeSignalScore", texture.poreLikeSignalScore,
            selectionReason = "Dedicated pore-like analyzer output selected for final profile"
        )
        FinalScoreRegistry.register(
            "SURFACE_SHINE_SIGNAL", surface.oilinessSignalScore,
            "SurfaceConditionAnalyzer.oilinessSignalScore", surface.oilinessSignalScore,
            selectionReason = "Dedicated surface-condition analyzer output selected for final profile"
        )
        FinalScoreRegistry.register(
            "DRYNESS_RELATED_SURFACE_SIGNAL", surface.drynessRelatedSignalScore,
            "SurfaceConditionAnalyzer.drynessRelatedSignalScore", surface.drynessRelatedSignalScore,
            selectionReason = "Dedicated surface-condition analyzer output selected for final profile"
        )

        val ranked=raw.mapIndexed { i,f -> f.copy(priority=i+1) }
        val significant=ranked.count { it.score>=12.0 }
        val overall=when {
            significant>=4 -> "MULTI_CHARACTERISTIC_VISIBLE_SKIN_PROFILE"
            significant>=2 -> "MULTI_FACTOR_VISIBLE_SKIN_PROFILE"
            significant==1 -> "SINGLE_DOMINANT_VISIBLE_SKIN_CHARACTERISTIC"
            else -> "LIMITED_STRONG_VISIBLE_SKIN_SIGNAL"
        }

        return FinalSkinAnalysisProfile(
            findings = ranked,
            primaryFinding = ranked.firstOrNull()?.characteristic ?: "INSUFFICIENT_DATA",
            secondaryFinding = ranked.getOrNull(1)?.characteristic ?: "NONE",
            overallProfile = overall,
            analysisConfidence = minConfidence(
                redness.confidence,pigment.confidence,blemish.confidence,
                texture.confidence,surface.confidence
            ),
            rednessScore = redness.overallRednessScore,
            pigmentationScore = pigment.pigmentationVariationScore,
            darkMarkScore = darkMarkScore,
            blemishLikeScore = blemish.blemishLikeScore,
            textureIrregularityScore = texture.textureIrregularityScore,
            poreLikeScore = texture.poreLikeSignalScore,
            surfaceShineScore = surface.oilinessSignalScore,
            drynessRelatedScore = surface.drynessRelatedSignalScore
        )
    }

    /**
     * Batch 4E-B, step_1/step_7: additive precision layer over [analyze]. The base score for
     * every characteristic is computed exactly as before (this function does not reimplement or
     * alter [analyze] in any way) — this overload only asks [DensityIntegratedScoring] to nudge
     * the result toward real usable-skin-area candidate density evidence where that evidence
     * exists, and leaves every characteristic without matching evidence completely untouched.
     * Callers that pass no evidence (default empty lists) get back exactly [analyze]'s own
     * output, unchanged in every field.
     */
    fun analyzeWithHighResolutionDensityEvidence(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>,
        specializedRegionalMetrics: List<SpecializedRegionalMetric> = emptyList(),
        shineRegionalSummaries: List<RegionalShineSummary> = emptyList()
    ):FinalSkinAnalysisProfile {
        val base = analyze(front, left, right)
        return DensityIntegratedScoring.apply(base, specializedRegionalMetrics, shineRegionalSummaries)
    }

    fun json(
        x:FinalSkinAnalysisProfile,
        toleranceRepository: ToleranceStateRepository = InMemoryToleranceStateRepository(),
        // Batch 3B step 10: this session's ThreeViewCaptureConditionResult.consistency, if the
        // caller has it (MainActivity computes it separately from CaptureConditionProfiles).
        // Null preserves old behavior (treated as RELIABLE, never penalized) for callers that
        // haven't wired capture-condition data through to this function yet.
        captureConditionConsistency: String? = null,
        // BATCH 4A — additive, default null preserves existing behavior exactly for any
        // caller that hasn't been updated (persisted session simply gets an unknown capture
        // context, same as before this parameter existed).
        usableViewCount: Int? = null,
        // BATCH 4D-H — STEP 1/12: additive, default-empty preserves existing behavior exactly
        // for any caller that hasn't been updated (persisted session simply records
        // feature-evidence as unavailable, same as before this parameter existed). This is
        // `MainActivity.lastFeatureIdentityRecords` — this session's OWN fused specialized
        // feature evidence, already built every session by
        // `runFeatureCorrespondenceAndFusion()` (Batch 4D-G) but never passed to persistence
        // until now.
        currentFeatureIdentityRecords: List<FeatureIdentityRecord> = emptyList()
    ):String {
        val findings=x.findings.joinToString(","){f ->
            """{"characteristic":"${f.characteristic}","score":${f.score},"level":"${f.level}","priority":${f.priority},"evidence":"${f.evidence}","confidence":"${f.confidence}","has_high_resolution_density_evidence":${f.hasHighResolutionDensityEvidence},"high_resolution_density_supporting_region_count":${f.highResolutionDensitySupportingRegionCount}}"""
        }
        val provenance=FinalScoreRegistry.all().joinToString(","){p ->
            val replaced=p.replacedScore?.toString() ?: "null"
            """{"characteristic":"${p.characteristic}","final_score":${p.finalScore},"source_stage":"${p.sourceStage}","source_score":${p.sourceScore},"replaced_score":$replaced,"selection_reason":"${p.selectionReason}"}"""
        }
        val concerns = SkinConcernInterpreter.fromFinalProfile(x)
        val objectives = SkinObjectivePlanner.plan(concerns, x.analysisConfidence)
        val concernJson = concerns.joinToString(",") { c ->
            """{"category":"${c.category}","priority":${c.priority},"score":${c.score},"level":"${c.level}","evidence_source":"${c.evidenceSource}","interpretation":"${c.interpretation}","confidence":"${c.confidence}"}"""
        }
        val objectiveJson = objectives.joinToString(",") { o ->
            """{"concern":"${o.concern}","priority":${o.priority},"objective_type":"${o.objectiveType}","title":"${o.title}","rationale":"${o.rationale}","evidence_source":"${o.evidenceSource}","strength_reason":"${o.strengthReason}"}"""
        }
        val strategy = RoutineStrategyPlanner.plan(objectives)
        val ingredientStrategy = IngredientStrategyPlanner.plan(strategy)
        val routineAssembly = RoutineCompatibilityPlanner.plan(ingredientStrategy)
        val routineSchedule = RoutineSchedulePlanner.plan(strategy, routineAssembly)
        val userRoutineContext = RoutineContextPlanner.defaultContext()
        val contextAdjustedSchedule = RoutineContextPlanner.apply(routineSchedule, userRoutineContext)
        val specificIngredients = SpecificIngredientMapper.map(ingredientStrategy, userRoutineContext)
        // Batch 3A: evidence-aware candidate selection. Connects the calibrated objective
        // strength (ObjectiveStrengthPolicy, carried forward onto each SpecificIngredientOption)
        // to candidate selection, using the existing IngredientSelectionRole as the structured
        // evidence signal. See EvidenceAwareCandidateSelection.kt for the full policy.
        val candidateSelections = EvidenceAwareCandidateSelectionPolicy.select(specificIngredients, concerns)
        val candidateSelectionByKey = candidateSelections.associateBy {
            "${it.concern}:${it.ingredientName}:${it.role}"
        }
        // Only SELECTED candidates are carried into use-planning/product-matching — a candidate
        // that is DEFERRED (objective is MONITOR-only; not enough signal to act on yet) or
        // LIMITED (this role's structural evidence tier does not meet what the current
        // objective strength requires) must not silently reach the same routine-plan strength as
        // a fully-selected candidate. This is the actual behavior change requested by the batch
        // ("low-strength objectives must not silently become high-strength recommendations") —
        // everything else in this file (score, confidence, priority, the candidates themselves)
        // is unchanged; only which candidates flow onward is affected.
        val selectedIngredients = specificIngredients.filter { option ->
            candidateSelectionByKey["${option.concern}:${option.ingredientName}:${option.role}"]
                ?.selectionStatus == CandidateSelectionStatus.SELECTED
        }

        // Batch 3B: candidate-level compatibility on the actual named, selected ingredients
        // (RoutineCompatibilityPlanner above still runs at category level for the schedule
        // skeleton; this is the missing named-ingredient layer — see the audit note in
        // RoutineCompatibilityPlanner.kt).
        val candidateCompatibility = CandidateCompatibilityPolicy.plan(selectedIngredients)
        val compatibilityByName = candidateCompatibility.associateBy { it.ingredientName }

        // Batch 3B: tolerance state. Read each selected ingredient's current record, apply this
        // session's transition (routine inclusion is the only feedback signal available inside
        // this pure analysis function — see ToleranceFeedback's kdoc; a real UI-driven reaction
        // report would call ToleranceTransitionPolicy.transition directly with MILD/STRONG
        // feedback outside of this analysis pass), then persist the result via the caller-
        // supplied repository (defaults to a non-persistent in-memory store so this function
        // stays pure/testable without a real Android Context).
        val toleranceBefore = selectedIngredients
            .map { it.ingredientName }
            .distinct()
            .associateWith { toleranceRepository.get(it) }
        val toleranceAfter = toleranceBefore.mapValues { (_, before) ->
            val feedback = if (before.state == ToleranceState.UNKNOWN)
                ToleranceFeedback.FIRST_TIME_INCLUDED else ToleranceFeedback.STABLE_CONTINUED_USE
            val after = ToleranceTransitionPolicy.transition(before, feedback)
            toleranceRepository.save(after)
            after
        }

        val toleranceFilterDecisions = ToleranceAwareCandidateFilter.apply(selectedIngredients, toleranceAfter)
        val toleranceFilterByName = toleranceFilterDecisions.associateBy { it.ingredientName }

        // Ingredients tolerance has fully EXCLUDED (PAUSED, or capped simultaneous-introduction
        // count) do not reach use-planning/product-matching this session — LIMITED ingredients
        // still reach it, but at a capped intensity below.
        val toleranceApprovedIngredients = selectedIngredients.filter {
            toleranceFilterByName[it.ingredientName]?.outcome != ToleranceFilterOutcome.EXCLUDED
        }

        val routineIntensityDecisions = toleranceApprovedIngredients.map { candidate ->
            val concernConfidence = concerns.firstOrNull { it.category == candidate.concern }?.confidence ?: "LOW"
            RoutineIntensityPolicy.calibrate(
                ingredientName = candidate.ingredientName,
                objectiveType = candidate.objectiveType,
                confidence = concernConfidence,
                compatibility = compatibilityByName[candidate.ingredientName]?.action ?: RoutineCompatibilityAction.REVIEW_REQUIRED,
                tolerance = toleranceAfter[candidate.ingredientName]?.state ?: ToleranceState.UNKNOWN
            )
        }
        val intensityByName = routineIntensityDecisions.associateBy { it.ingredientName }


        // Batch 4D-A: intensity/tolerance were already computed above (routineIntensityDecisions/
        // intensityByName, toleranceAfter) but were never actually passed into use-planning —
        // concentration/frequency guidance previously reflected only the static
        // UserRoutineContext preference. This is the real connection this batch adds.
        val toleranceStateByName = toleranceAfter.mapValues { (_, record) -> record.state }
        val ingredientUsePlans = IngredientUsePlanner.plan(
            toleranceApprovedIngredients,
            userRoutineContext,
            intensityByName,
            toleranceStateByName
        )
        val productRequirements = ProductSelectionPlanner.requirements(ingredientUsePlans)
        val productCatalogCandidates = ProductCatalogRepository.candidates()
        val productMatches = ProductSelectionPlanner.rank(productRequirements, productCatalogCandidates)
        val acceptedProductMatches = productMatches.filter { it.accepted }
        val productRecommendations = ProductRecommendationAssembler.assemble(
            productRequirements,
            acceptedProductMatches,
            ingredientUsePlans
        )
        val finalRoutineResult = FinalRoutineResultAssembler.assemble(
            x.primaryFinding,
            x.secondaryFinding,
            contextAdjustedSchedule,
            ingredientUsePlans,
            productRecommendations
        )
        val currentProgressSnapshot = SkinProgressSnapshot(
            pigmentationScore = x.pigmentationScore,
            darkMarkScore = x.darkMarkScore,
            blemishLikeScore = x.blemishLikeScore,
            rednessScore = x.rednessScore,
            poreLikeScore = x.poreLikeScore,
            shineScore = x.surfaceShineScore,
            textureScore = x.textureIrregularityScore,
            drynessScore = x.drynessRelatedScore,
            confidence = x.analysisConfidence
        )
        val analysisVersion = "final_skin_analysis_profile_v29"
        // BATCH 4B: `previousSession` (full StoredSkinSession, including capture context) is
        // needed here — not just `previousSnapshot` — so `SessionComparabilityEvaluator` (Batch
        // 4A) can run in this exported-JSON path the same way it already does in
        // `UiAnalysisAssembler`. `previousProgressSnapshot` below is still sourced from the same
        // object as before (`previousSession?.snapshot`), so no existing behavior changes.
        val previousSession = SkinSessionRepository.previousSession(analysisVersion)
        val previousProgressSnapshot = previousSession?.snapshot
        val progressResult = SkinProgressTracker.compare(
            previousProgressSnapshot,
            currentProgressSnapshot
        )
        val progressFeatureJson = progressResult.features.joinToString(",") { p ->
            """{"feature":"${p.feature}","previous_score":${p.previousScore},"current_score":${p.currentScore},"delta":${p.delta},"direction":"${p.direction}"}"""
        }
        val trendHistory = SkinSessionRepository.compatibleHistory(analysisVersion) + currentProgressSnapshot
        val multiSessionTrend = MultiSessionTrendAnalyzer.analyze(trendHistory)
        val trendFeaturesJson = multiSessionTrend.features.joinToString(",") { t ->
            val values = t.values.joinToString(",")
            """{"feature":"${t.feature}","values":[$values],"average_delta":${t.averageDelta},"direction":"${t.direction}"}"""
        }
        val rawTrendAwareAdaptation = TrendAwareRoutineAdaptationPolicy.evaluate(
            progressResult,
            multiSessionTrend
        )
        // Batch 3B step 10: cap (never escalate) the adaptation decision using this session's
        // own capture-quality reliability, before anything downstream (the trend-adjustment
        // generator, the candidate activator, execution) consumes it — so a poor-lighting
        // session cannot produce a CONSIDER_ROUTINE_ADJUSTMENT/HIGH-confidence result at any
        // later stage either. See CaptureQualityReliabilityGate.kt.
        val captureQualityReliability = CaptureQualityReliabilityGate.classify(captureConditionConsistency)
        val captureGatedAdaptation = CaptureQualityReliabilityGate.apply(rawTrendAwareAdaptation, captureQualityReliability)

        // BATCH 4B — steps 1-4: session-level comparability (Batch 4A, previously only reached
        // the UI path via `UiAnalysisAssembler` and was never exported by this JSON path),
        // per-characteristic comparability gating, and the conservative comparability-aware
        // adaptation cap (SECONDARY integration point), computed here so the persisted/exported
        // JSON carries the same comparability information the UI already shows.
        val currentCaptureContextForComparability = SessionCaptureContext.from(captureConditionConsistency, usableViewCount)
        val sessionComparability = previousSession?.let {
            SessionComparabilityEvaluator.evaluate(it, currentCaptureContextForComparability, analysisVersion)
        }
        val characteristicComparability =
            CharacteristicComparabilityEvaluator.evaluateAll(x.findings, sessionComparability)
        val characteristicComparabilityByName = characteristicComparability.associateBy { it.characteristic }
        val gatedProgressFeatures =
            CharacteristicGatedProgress.gate(progressResult, characteristicComparabilityByName)
        val characteristicComparabilityJson = CharacteristicComparabilityEvaluator.json(characteristicComparability)
        val gatedProgressFeaturesJson = CharacteristicGatedProgress.json(gatedProgressFeatures)
        val comparabilityGatedAdaptation = ComparabilityAdaptationGate.apply(captureGatedAdaptation, sessionComparability)

        // BATCH 4D-H — STEP 2/3/5/12: feature-level longitudinal change, computed here (the
        // real, single production save/export path — see the comment on the `save()` call
        // below) using the previous session's STORED feature-identity records (STEP 2's actual
        // cross-session identity, not this session's records compared to themselves) and this
        // session's own `currentFeatureIdentityRecords` (built earlier this session by
        // `MainActivity.runFeatureCorrespondenceAndFusion()`). Reuses `sessionComparability`
        // (already computed immediately above) exactly as step_7 requires — this is not a
        // second, independently-derived comparability judgment.
        val previousFeatureIdentityRecords = SkinSessionRepository.previousFeatureIdentityRecords(analysisVersion)
        val featureLongitudinalResult = FeatureLongitudinalTrendAnalyzer.analyze(
            previousRecords = previousFeatureIdentityRecords,
            currentRecords = currentFeatureIdentityRecords,
            comparability = sessionComparability
        )
        val featureLongitudinalJson = FeatureLongitudinalTrendAnalyzer.json(featureLongitudinalResult)

        // BATCH 4C: per-characteristic repeated-session evidence/trend-confidence/direction-
        // stability, exported here so the persisted/exported JSON path carries the same
        // longitudinal intelligence the UI path (`UiAnalysisAssembler`) already computes. Reuses
        // `multiSessionTrend`, `characteristicComparability`, and `SkinSessionRepository`'s
        // baseline selection rather than recomputing any underlying trend/comparability value.
        val baselineSelectionForTrend = SkinSessionRepository.selectBaseline(analysisVersion)
        val orderedSessionHistory = SkinSessionRepository.history()
            .filter { it.analysisVersion == analysisVersion }
            .sortedBy { it.createdAtEpochMillis }
        val characteristicTrendIntelligence = CharacteristicTrendIntelligenceAnalyzer.analyzeAll(
            orderedHistory = orderedSessionHistory,
            currentSnapshot = currentProgressSnapshot,
            multiSessionTrend = multiSessionTrend,
            characteristicComparability = characteristicComparability,
            baseline = baselineSelectionForTrend.baseline
        )
        val trendIntelligenceByCharacteristic = characteristicTrendIntelligence.associateBy { it.characteristic }
        val characteristicTrendIntelligenceJson = CharacteristicTrendIntelligenceAnalyzer.json(characteristicTrendIntelligence)
        val trendAwareAdaptation = FeatureLongitudinalAdaptationGate.apply(
            TrendIntelligenceAdaptationGate.apply(
                comparabilityGatedAdaptation,
                trendIntelligenceByCharacteristic
            ),
            featureLongitudinalResult
        )
        // NOTE: generatedRoutineAdjustment must be computed before controlledRoutineRevision,
        // which consumes it as an input (RoutineAdjustmentCandidateActivator.activate reviews
        // the candidates that TrendAwareRoutineAdjustmentGenerator.generate proposes).
        val generatedRoutineAdjustment = TrendAwareRoutineAdjustmentGenerator.generate(
            trendAwareAdaptation.decision,
            multiSessionTrend,
            ingredientUsePlans,
            finalRoutineResult
        )
        val adjustmentCandidatesJson = generatedRoutineAdjustment.candidates.joinToString(",") { c ->
            """{"concern":"${c.concern}","target_ingredient":"${c.targetIngredient}","proposed_frequency":"${c.proposedFrequency}","reason":"${c.reason}"}"""
        }
        val retainedRoutineJson = generatedRoutineAdjustment.retainedRoutine.joinToString(",") { "\"$it\"" }
        val adjustmentFlagsJson = generatedRoutineAdjustment.reviewFlags.joinToString(",") { "\"$it\"" }
        val controlledRoutineRevision = RoutineAdjustmentCandidateActivator.activate(
            generatedRoutineAdjustment,
            ingredientUsePlans,
            finalRoutineResult,
            toleranceByIngredient = toleranceAfter
        )
        fun candidateJson(c: ActivatedAdjustmentCandidate): String =
            """{"concern":"${c.concern}","target_ingredient":"${c.targetIngredient}","proposed_frequency":"${c.proposedFrequency}","status":"${c.status}","reason":"${c.reason}"}"""
        val approvedCandidatesJson = controlledRoutineRevision.approvedCandidates.joinToString(",") { candidateJson(it) }
        val rejectedCandidatesJson = controlledRoutineRevision.rejectedCandidates.joinToString(",") { candidateJson(it) }
        val revisedMorningJson = controlledRoutineRevision.revisedMorningRoutine.joinToString(",") { "\"$it\"" }
        val revisedEveningJson = controlledRoutineRevision.revisedEveningRoutine.joinToString(",") { "\"$it\"" }
        val revisedAlternatingJson = controlledRoutineRevision.revisedAlternatingPlan.joinToString(",") { "\"$it\"" }
        val activationChangeLogJson = controlledRoutineRevision.changeLog.joinToString(",") { "\"$it\"" }
        val activationFlagsJson = controlledRoutineRevision.reviewFlags.joinToString(",") { "\"$it\"" }
        val routineAdaptation = trendAwareAdaptation.decision
        val adaptationReasonsJson = routineAdaptation.reasons.joinToString(",") { "\"$it\"" }
        val affectedFeaturesJson = routineAdaptation.affectedFeatures.joinToString(",") { "\"$it\"" }
        val trendReasonsJson = trendAwareAdaptation.trendReasons.joinToString(",") { "\"$it\"" }
        val routineExecution = RoutineAdaptationExecutor.execute(
            routineAdaptation,
            finalRoutineResult
        )
        val executedMorningJson = routineExecution.morningRoutine.joinToString(",") { "\"$it\"" }
        val executedEveningJson = routineExecution.eveningRoutine.joinToString(",") { "\"$it\"" }
        val executedAlternatingJson = routineExecution.alternatingPlan.joinToString(",") { "\"$it\"" }
        val executedIngredientJson = routineExecution.ingredientPlan.joinToString(",") { "\"$it\"" }
        val appliedChangesJson = routineExecution.appliedChanges.joinToString(",") { "\"$it\"" }
        val reviewFlagsJson = routineExecution.reviewFlags.joinToString(",") { "\"$it\"" }
        val sessionId = "session_" + System.currentTimeMillis()
        val sessionTimestamp = System.currentTimeMillis()
        // BATCH 4A — step 1: this is the single real persist call for a session (see
        // `UiAnalysisAssembler`'s file-level comment — it never saves). Capture context is
        // recorded here, at the same point the score snapshot itself becomes durable, so a
        // future comparison against this session has real capture-condition/view-completeness
        // data instead of "unknown".
        SkinSessionRepository.save(
            sessionId = sessionId,
            createdAtEpochMillis = sessionTimestamp,
            analysisVersion = analysisVersion,
            snapshot = currentProgressSnapshot,
            captureContext = SessionCaptureContext.from(captureConditionConsistency, usableViewCount),
            // BATCH 4D-H — STEP 1/12: this is the actual persistence write step_1 asked for —
            // this session's own fused feature evidence (already built by
            // `runFeatureCorrespondenceAndFusion()`, passed in as `currentFeatureIdentityRecords`)
            // now survives into the next session's comparison via `PersistentSkinSessionStore`.
            // `featureEvidenceAvailable = true` unconditionally here (this IS the real save path
            // that computes feature evidence every session) — a session predating this batch, or
            // saved through any future path that doesn't compute feature evidence, is the only
            // way this marker is ever false/absent, never this call site.
            featureIdentityRecords = currentFeatureIdentityRecords,
            featureEvidenceCaptureQuality = FeatureEvidenceCaptureQuality(
                featureEvidenceAvailable = true,
                captureConditionConsistency = captureConditionConsistency,
                usableViewCount = usableViewCount
            )
        )
        val finalMorningJson = finalRoutineResult.morningRoutine.joinToString(",") { "\"$it\"" }
        val finalEveningJson = finalRoutineResult.eveningRoutine.joinToString(",") { "\"$it\"" }
        val finalAlternatingJson = finalRoutineResult.alternatingPlan.joinToString(",") { "\"$it\"" }
        val finalIngredientJson = finalRoutineResult.ingredientPlan.joinToString(",") { "\"$it\"" }
        val finalConcernJson = finalRoutineResult.prioritizedConcerns.joinToString(",") { "\"$it\"" }
        val finalCautionJson = finalRoutineResult.cautions.joinToString(",") { "\"$it\"" }
        val recommendationJson = productRecommendations.joinToString(",") { r ->
            val reasons = r.matchReasons.joinToString(",") { "\"$it\"" }
            val cautionJson = r.caution?.let { "\"$it\"" } ?: "null"
            """{"product_id":"${r.productId}","concern":"${r.concern}","target_ingredient":"${r.targetIngredient}","routine_phase":"${r.routinePhase}","match_score":${r.matchScore},"match_reasons":[$reasons],"recommendation_status":"${r.recommendationStatus}","explanation":"${r.explanation}","caution":$cautionJson}"""
        }
        val productMatchJson = acceptedProductMatches.joinToString(",") { match ->
            val reasons = match.reasons.joinToString(",") { "\"$it\"" }
            """{"product_id":"${match.productId}","target_ingredient":"${match.targetIngredient}","score":${match.score},"accepted":${match.accepted},"reasons":[$reasons]}"""
        }
        val productRequirementJson = productRequirements.joinToString(",") { r ->
            val required = r.requiredAttributes.joinToString(",") { "\"$it\"" }
            val excluded = r.excludedAttributes.joinToString(",") { "\"$it\"" }
            """{"concern":"${r.concern}","target_ingredient":"${r.targetIngredient}","routine_phase":"${r.routinePhase}","desired_strength":"${r.desiredStrength}","desired_frequency":"${r.desiredFrequency}","required_attributes":[$required],"excluded_attributes":[$excluded]}"""
        }
        val ingredientUseJson = ingredientUsePlans.joinToString(",") { p ->
            val cautionJson = p.caution?.let { "\"$it\"" } ?: "null"
            """{"concern":"${p.concern}","ingredient_name":"${p.ingredientName}","concentration_guidance":"${p.concentrationGuidance}","frequency_guidance":"${p.frequencyGuidance}","routine_phase":"${p.routinePhase}","introduction_rule":"${p.introductionRule}","caution":$cautionJson,"intensity_level":"${p.intensityLevel}","intensity_reason":"${p.intensityReason}","tolerance_state":"${p.toleranceState}"}"""
        }
        val candidateCompatibilityJson = candidateCompatibility.joinToString(",") { d ->
            """{"concern":"${d.concern}","ingredient_name":"${d.ingredientName}","role":"${d.role}","routine_phase":"${d.routinePhase}","action":"${d.action}","reason":"${d.reason}"}"""
        }
        val toleranceJson = toleranceAfter.values.joinToString(",") { t ->
            """{"ingredient_name":"${t.ingredientName}","state":"${t.state}","sessions_at_current_state":${t.sessionsAtCurrentState},"reason":"${t.reason.replace("\"","'")}"}"""
        }
        val toleranceFilterJson = toleranceFilterDecisions.joinToString(",") { t ->
            """{"ingredient_name":"${t.ingredientName}","role":"${t.role}","tolerance_state":"${t.toleranceState}","outcome":"${t.outcome}","reason":"${t.reason}"}"""
        }
        val routineIntensityJson = routineIntensityDecisions.joinToString(",") { r ->
            """{"ingredient_name":"${r.ingredientName}","level":"${r.level}","reason":"${r.reason}"}"""
        }
        val captureQualityReliabilityJson =
            """{"reliability":"$captureQualityReliability","source_consistency":${captureConditionConsistency?.let { "\"$it\"" } ?: "null"}}"""
        val specificIngredientJson = specificIngredients.joinToString(",") { i ->
            val cautionJson = i.caution?.let { "\"$it\"" } ?: "null"
            """{"concern":"${i.concern}","ingredient_name":"${i.ingredientName}","role":"${i.role}","routine_phase":"${i.routinePhase}","source_category":"${i.sourceCategory}","caution":$cautionJson,"objective_type":"${i.objectiveType}"}"""
        }
        val candidateSelectionJson = candidateSelections.joinToString(",") { c ->
            """{"concern":"${c.concern}","ingredient_name":"${c.ingredientName}","role":"${c.role}","objective_type":"${c.objectiveType}","evidence_strength":"${c.evidenceStrength}","selection_status":"${c.selectionStatus}","selection_reason":"${c.selectionReason}","objective_strength_reason":"${c.objectiveStrengthReason}","confidence":"${c.confidence}","policy_version":"${c.policyVersion}"}"""
        }
        val morningScheduleJson = contextAdjustedSchedule.morningSteps.joinToString(",") { step ->
            """{"time":"${step.time}","category":"${step.category}","role":"${step.role}","schedule":"${step.schedule}","rationale":"${step.rationale}"}"""
        }
        val eveningScheduleJson = contextAdjustedSchedule.eveningBaseSteps.joinToString(",") { step ->
            """{"time":"${step.time}","category":"${step.category}","role":"${step.role}","schedule":"${step.schedule}","rationale":"${step.rationale}"}"""
        }
        val alternatingScheduleJson = contextAdjustedSchedule.alternatingNightSteps.joinToString(",") { step ->
            """{"time":"${step.time}","category":"${step.category}","role":"${step.role}","schedule":"${step.schedule}","rationale":"${step.rationale}"}"""
        }
        val weeklyPatternJson = contextAdjustedSchedule.weeklyPattern.joinToString(",") { "\"$it\"" }
        val compatibilityJson = routineAssembly.morning
            .plus(routineAssembly.evening)
            .distinctBy { "${it.ingredientCategory}:${it.routinePhase}:${it.action}" }
            .joinToString(",") { d ->
                """{"ingredient_category":"${d.ingredientCategory}","routine_phase":"${d.routinePhase}","action":"${d.action}","reason":"${d.reason}"}"""
            }
        val alternatingJson = routineAssembly.alternating.joinToString(",") { d ->
            """{"ingredient_category":"${d.ingredientCategory}","routine_phase":"${d.routinePhase}","action":"${d.action}","reason":"${d.reason}"}"""
        }
        val ingredientJson = ingredientStrategy.joinToString(",") { i ->
            """{"concern":"${i.concern}","role":"${i.role}","ingredient_category":"${i.ingredientCategory}","routine_phase":"${i.routinePhase}","rationale":"${i.rationale}"}"""
        }
        val targetJson = strategy.targets.joinToString(",") { t ->
            """{"role":"${t.role}","concern":"${t.concern}","objective":"${t.objective}","rationale":"${t.rationale}"}"""
        }
        val morningJson = strategy.morningFramework.joinToString(",") { "\"$it\"" }
        val eveningJson = strategy.eveningFramework.joinToString(",") { "\"$it\"" }
        return """{"findings":[$findings],"score_provenance":[$provenance],"skin_concerns":[$concernJson],"skin_objectives":[$objectiveJson],"routine_strategy":{"targets":[$targetJson],"morning_framework":[$morningJson],"evening_framework":[$eveningJson],"strategy_note":"${strategy.strategyNote}"},"ingredient_strategy":[$ingredientJson],"routine_compatibility":{"decisions":[$compatibilityJson],"alternating_or_review":[$alternatingJson]},"specific_ingredient_options":[$specificIngredientJson],"evidence_aware_candidate_selection":{"policy_version":"${EvidenceAwareCandidateSelectionPolicy.VERSION}","decisions":[$candidateSelectionJson]},"candidate_compatibility":{"policy_version":"${CandidateCompatibilityPolicy.VERSION}","decisions":[$candidateCompatibilityJson]},"tolerance_state":{"policy_version":"${ToleranceTransitionPolicy.VERSION}","records":[$toleranceJson],"filter_decisions":[$toleranceFilterJson]},"routine_intensity":{"policy_version":"${RoutineIntensityPolicy.VERSION}","decisions":[$routineIntensityJson]},"capture_quality_reliability":$captureQualityReliabilityJson,"ingredient_use_plan":[$ingredientUseJson],"product_requirements":[$productRequirementJson],"product_catalog_matches":{"catalog_source":"${ProductCatalogRepository.sourceType()}","accepted_matches":[$productMatchJson]},"product_recommendations":[$recommendationJson],"final_skincare_result":{"primary_finding":"${finalRoutineResult.primaryFinding}","secondary_finding":"${finalRoutineResult.secondaryFinding}","prioritized_concerns":[$finalConcernJson],"morning_routine":[$finalMorningJson],"evening_routine":[$finalEveningJson],"alternating_plan":[$finalAlternatingJson],"ingredient_plan":[$finalIngredientJson],"cautions":[$finalCautionJson]},"skin_progress":{"overall_direction":"${progressResult.overallDirection}","comparison_confidence":"${progressResult.comparisonConfidence}","features":[$progressFeatureJson]},"characteristic_comparability":$characteristicComparabilityJson,"gated_progress_features":$gatedProgressFeaturesJson,"feature_longitudinal_trend":$featureLongitudinalJson,"characteristic_trend_intelligence":$characteristicTrendIntelligenceJson,"multi_session_trend":{"overall_direction":"${multiSessionTrend.overallDirection}","trend_confidence":"${multiSessionTrend.trendConfidence}","sessions_used":${multiSessionTrend.sessionsUsed},"features":[$trendFeaturesJson]},"routine_adaptation":{"action":"${routineAdaptation.action}","reasons":[$adaptationReasonsJson],"affected_features":[$affectedFeaturesJson],"adaptation_confidence":"${routineAdaptation.adaptationConfidence}","trend_influence_applied":${trendAwareAdaptation.trendInfluenceApplied},"trend_reasons":[$trendReasonsJson]},"trend_aware_routine_adjustment":{"status":"${generatedRoutineAdjustment.status}","candidates":[$adjustmentCandidatesJson],"retained_routine":[$retainedRoutineJson],"review_flags":[$adjustmentFlagsJson]},"candidate_activation":{"status":"${controlledRoutineRevision.status}","approved_candidates":[$approvedCandidatesJson],"rejected_candidates":[$rejectedCandidatesJson],"revised_morning_routine":[$revisedMorningJson],"revised_evening_routine":[$revisedEveningJson],"revised_alternating_plan":[$revisedAlternatingJson],"change_log":[$activationChangeLogJson],"review_flags":[$activationFlagsJson]},"routine_adaptation_execution":{"action":"${routineExecution.action}","morning_routine":[$executedMorningJson],"evening_routine":[$executedEveningJson],"alternating_plan":[$executedAlternatingJson],"ingredient_plan":[$executedIngredientJson],"applied_changes":[$appliedChangesJson],"review_flags":[$reviewFlagsJson],"execution_status":"${routineExecution.executionStatus}"},"session":{"session_id":"$sessionId","created_at_epoch_millis":$sessionTimestamp,"analysis_version":"$analysisVersion","previous_session_available":${previousProgressSnapshot != null}},"routine_context":{"complexity":"${userRoutineContext.complexity}","tolerance_preference":"${userRoutineContext.tolerancePreference}","active_intensity_preference":"${userRoutineContext.activeIntensityPreference}","morning_time_limit_minutes":${userRoutineContext.morningTimeLimitMinutes ?: "null"},"evening_time_limit_minutes":${userRoutineContext.eveningTimeLimitMinutes ?: "null"}},"routine_schedule":{"morning_steps":[$morningScheduleJson],"evening_base_steps":[$eveningScheduleJson],"alternating_night_steps":[$alternatingScheduleJson],"weekly_pattern":[$weeklyPatternJson]},"primary_finding":"${x.primaryFinding}","secondary_finding":"${x.secondaryFinding}","overall_profile":"${x.overallProfile}","analysis_confidence":"${x.analysisConfidence}","recommendation_calibration_version":"${ObjectiveStrengthPolicy.VERSION}","method":"final_skin_analysis_profile_v29","medical_diagnosis":false}"""
    }
}
