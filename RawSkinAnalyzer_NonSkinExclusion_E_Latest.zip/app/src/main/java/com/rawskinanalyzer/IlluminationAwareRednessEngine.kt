package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/**
 * IlluminationAwareRednessEngine
 *
 * Batch 4D-E, step_5. Separates broad illumination/color-cast effects (already measured per-view
 * by [CaptureConditionProfileAnalyzer], Batch 4C) from localized skin redness read off individual
 * [VisualFeatureCandidate]s (Batch 4D-D). This does not re-measure lighting — it consumes the
 * existing [CaptureConditionProfile] for the candidate's view and uses it to decide how much of a
 * candidate's chroma-red-shift is attributable to global cast vs. a genuinely localized structure.
 */
object IlluminationAwareRednessEngine {
    private fun clamp01(v: Double) = max(0.0, min(1.0, v))

    /**
     * [captureConditions] keyed by view name (FRONT_FACE / LEFT_CHEEK / RIGHT_CHEEK), same
     * identifiers [VisualFeatureCandidate.view] already carries.
     */
    fun refine(
        candidates: List<VisualFeatureCandidate>,
        captureConditions: Map<String, CaptureConditionProfile>
    ): List<LocalizedRednessRefinement> {
        val rednessLeaning = candidates.filter { it.evidence.rednessLikelihood > 0.15 }

        return rednessLeaning.map { c ->
            val reasons = mutableListOf<String>()
            val profile = captureConditions[c.view]

            if (profile == null) {
                // No capture-condition data for this view: preserve uncertainty rather than assume
                // neutral lighting (this step's explicit "preserve uncertainty when illumination
                // prevents reliable separation" requirement).
                reasons.add("no capture-condition profile available for this view; illumination not separable")
                return@map LocalizedRednessRefinement(
                    candidateId = c.candidateId,
                    localizedRednessConfidence = c.evidence.rednessLikelihood * 0.7, // discounted, not discarded
                    colorCastAdjustedDeltaCr = 0.0,
                    illuminationReliable = false,
                    evidenceReasons = reasons
                )
            }

            // A candidate's Cr was already computed relative to its own tile's regionMeanCr
              // (FeatureCandidateDetectors), which partially self-corrects for a uniform per-tile
            // cast already. What a per-tile baseline CANNOT distinguish is a cast affecting the
            // *whole view* uniformly (e.g. warm indoor light making every tile's baseline shift
            // together) from a real localized-redness structure riding on top of it. Broad-region
            // color-cast magnitude is the signal that tells them apart: a strong cast doesn't, by
            // itself, create a *local* elevation above the view's own already-shifted mean, so a
            // candidate's local redness signal is discounted only in proportion to how unreliable
            // the illuminant reading makes chroma judgments in general, not zeroed out.
            val castMagnitude = profile.colorCastMagnitude
            val illuminationReliable = castMagnitude <= 0.20 && profile.warnings.none { it == "LOW_LIGHT" || it == "OVEREXPOSED" }

            val castDiscount = when {
                castMagnitude > 0.30 -> 0.5
                castMagnitude > 0.20 -> 0.7
                castMagnitude > 0.12 -> 0.85
                else -> 1.0
            }

            if (!illuminationReliable) {
                reasons.add("capture condition reduces confidence: illuminant=${profile.illuminantEstimate}, color_cast_magnitude=${"%.2f".format(castMagnitude)}")
            } else {
                reasons.add("capture condition supports reliable chroma separation (color_cast_magnitude=${"%.2f".format(castMagnitude)})")
            }
            if (profile.warnings.isNotEmpty()) reasons.add("capture warnings present: ${profile.warnings.joinToString(",")}")

            val localizedConfidence = clamp01(c.evidence.rednessLikelihood * castDiscount)
            // The candidate's own local-vs-tile-mean delta is already the "local neighboring skin
            // as reference" signal this step calls for (grid.regionMeanCr was computed per-tile,
            // i.e. from the candidate's own immediate surroundings, not a distant/global sample).
            val adjustedDeltaCr = (c.morphology.meanCr - 0.0) // meanCr already tile-relative upstream; retained here as the reported figure, not re-based against a different origin

            if (localizedConfidence > 0.4) reasons.add("localized chroma red-shift persists after cast discount")

            LocalizedRednessRefinement(
                candidateId = c.candidateId,
                localizedRednessConfidence = localizedConfidence,
                colorCastAdjustedDeltaCr = adjustedDeltaCr,
                illuminationReliable = illuminationReliable,
                evidenceReasons = reasons
            )
        }
    }
}
