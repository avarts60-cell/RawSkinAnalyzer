package com.rawskinanalyzer
import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.*
data class ImageFeatures(val width:Int,val height:Int,val meanLuma:Double,val stdLuma:Double,val meanR:Double,val meanG:Double,val meanB:Double,val rednessIndex:Double,val darkPercent:Double,val brightPercent:Double,val textureScore:Double)
object ImageFeatureExtractor {
 fun extract(file:File):ImageFeatures {
  val b=BitmapFactory.decodeFile(file.absolutePath)?:throw IllegalArgumentException("Cannot decode image")
  val step=max(1,max(b.width,b.height)/512); var n=0; var sl=0.0;var sl2=0.0;var sr=0.0;var sg=0.0;var sb=0.0;var dark=0;var bright=0;var tex=0.0;var tn=0
  for(y in 0 until b.height step step) for(x in 0 until b.width step step){val p=b.getPixel(x,y);val r=((p shr 16)and 255).toDouble();val g=((p shr 8)and 255).toDouble();val bl=(p and 255).toDouble();val l=.2126*r+.7152*g+.0722*bl;n++;sl+=l;sl2+=l*l;sr+=r;sg+=g;sb+=bl;if(l<=40)dark++;if(l>=220)bright++;if(x>=step){val q=b.getPixel(x-step,y);tex+=abs(l-(.2126*((q shr 16)and 255)+.7152*((q shr 8)and 255)+.0722*(q and 255)));tn++}}
  val dn=n.toDouble();val mean=sl/dn;val f=ImageFeatures(b.width,b.height,mean,sqrt(max(0.0,sl2/dn-mean*mean)),sr/dn,sg/dn,sb/dn,(sr-sg)/dn,dark*100/dn,bright*100/dn,if(tn==0)0.0 else tex/tn);b.recycle();return f
 }
 fun json(f:ImageFeatures)="""{"width":${f.width},"height":${f.height},"mean_luma":${f.meanLuma},"std_luma":${f.stdLuma},"mean_red":${f.meanR},"mean_green":${f.meanG},"mean_blue":${f.meanB},"redness_index":${f.rednessIndex},"dark_percent":${f.darkPercent},"bright_percent":${f.brightPercent},"texture_score":${f.textureScore}}"""
}