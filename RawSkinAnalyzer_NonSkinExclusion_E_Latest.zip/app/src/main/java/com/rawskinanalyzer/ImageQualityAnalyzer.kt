package com.rawskinanalyzer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class ImageQualityReport(
    val width: Int,
    val height: Int,
    val meanLuma: Double,
    val contrast: Double,
    val darkClipPercent: Double,
    val brightClipPercent: Double,
    val detailScore: Double,
    val warnings: List<String>,
    val pass: Boolean
)

object ImageQualityAnalyzer {
    fun analyze(file: File): ImageQualityReport {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            ?: throw IllegalArgumentException("JPEG decode failed")

        val step = max(1, max(bitmap.width, bitmap.height) / 512)
        var count = 0
        var sum = 0.0
        var sumSq = 0.0
        var dark = 0
        var bright = 0
        var detailSum = 0.0
        var detailCount = 0
        var previousRow: DoubleArray? = null

        for (y in 0 until bitmap.height step step) {
            val row = DoubleArray((bitmap.width + step - 1) / step)
            var i = 0
            for (x in 0 until bitmap.width step step) {
                val p = bitmap.getPixel(x, y)
                val l = 0.2126 * ((p shr 16) and 0xff) +
                        0.7152 * ((p shr 8) and 0xff) +
                        0.0722 * (p and 0xff)
                row[i] = l
                count++
                sum += l
                sumSq += l * l
                if (l <= 5.0) dark++
                if (l >= 250.0) bright++
                if (i > 0) {
                    detailSum += abs(l - row[i - 1])
                    detailCount++
                }
                i++
            }
            previousRow?.let { prev ->
                val width = min(prev.size, row.size)
                for (j in 0 until width) {
                    detailSum += abs(row[j] - prev[j])
                    detailCount++
                }
            }
            previousRow = row
        }

        bitmap.recycle()

        val mean = if (count == 0) 0.0 else sum / count
        val variance = max(0.0, sumSq / max(1, count) - mean * mean)
        val contrast = sqrt(variance)
        val darkPct = if (count == 0) 100.0 else dark * 100.0 / count
        val brightPct = if (count == 0) 100.0 else bright * 100.0 / count
        val detail = if (detailCount == 0) 0.0 else detailSum / detailCount

        val warnings = mutableListOf<String>()
        if (mean < 45.0) warnings += "LOW_BRIGHTNESS"
        if (mean > 220.0) warnings += "HIGH_BRIGHTNESS"
        if (contrast < 18.0) warnings += "LOW_CONTRAST"
        if (darkPct > 20.0) warnings += "DARK_CLIPPING"
        if (brightPct > 20.0) warnings += "BRIGHT_CLIPPING"
        if (detail < 4.0) warnings += "LOW_DETAIL_OR_BLUR"

        val fail = mean < 20.0 || mean > 240.0 || contrast < 8.0 || detail < 1.5
        return ImageQualityReport(
            width = bitmap.width,
            height = bitmap.height,
            meanLuma = mean,
            contrast = contrast,
            darkClipPercent = darkPct,
            brightClipPercent = brightPct,
            detailScore = detail,
            warnings = warnings,
            pass = !fail
        )
    }

    fun writeNormalizedCopy(source: File, destination: File, maxSide: Int = 1536): Boolean {
        val bitmap = BitmapFactory.decodeFile(source.absolutePath) ?: return false
        val scale = min(1.0, maxSide.toDouble() / max(bitmap.width, bitmap.height).toDouble())
        val width = max(1, (bitmap.width * scale).toInt())
        val height = max(1, (bitmap.height * scale).toInt())
        val out = if (width == bitmap.width && height == bitmap.height) {
            bitmap
        } else {
            Bitmap.createScaledBitmap(bitmap, width, height, true)
        }

        destination.outputStream().use {
            out.compress(Bitmap.CompressFormat.JPEG, 95, it)
        }
        if (out !== bitmap) out.recycle()
        bitmap.recycle()
        return destination.exists() && destination.length() > 0
    }
}
