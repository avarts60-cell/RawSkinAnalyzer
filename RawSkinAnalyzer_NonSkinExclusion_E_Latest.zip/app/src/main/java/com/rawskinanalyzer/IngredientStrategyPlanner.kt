package com.rawskinanalyzer
enum class IngredientRole { PRIMARY_OPTION, SUPPORTIVE_OPTION, CAUTION }
data class IngredientStrategyItem(
 val concern:SkinConcernCategory,
 val role:IngredientRole,
 val ingredientCategory:String,
 val routinePhase:String,
 val rationale:String,
 // Batch 3A: carried forward from RoutineTarget.objectiveType so the calibrated objective
 // strength reaches candidate selection instead of dead-ending at RoutineStrategy (where only
 // the index-based RoutineTargetRole and a display title survived previously).
 val objectiveType: SkinObjectiveType,
 val objectiveStrengthReason: String
)
object IngredientStrategyPlanner {
 fun plan(strategy:RoutineStrategy)=strategy.targets.flatMap{ target ->
  listOf(
   IngredientStrategyItem(target.concern,IngredientRole.PRIMARY_OPTION,"OBJECTIVE_TARGETED_SUPPORT","AM_OR_PM","Primary category derived from the prioritized routine target.",target.objectiveType,target.strengthReason),
   IngredientStrategyItem(target.concern,IngredientRole.SUPPORTIVE_OPTION,"BARRIER_OR_TOLERANCE_SUPPORT","AM_OR_PM","Supportive category intended to preserve routine simplicity and tolerance.",target.objectiveType,target.strengthReason),
   IngredientStrategyItem(target.concern,IngredientRole.CAUTION,"COMPATIBILITY_REVIEW_REQUIRED","AM_OR_PM","Do not automatically stack intensive categories without a compatibility rule.",target.objectiveType,target.strengthReason)
  )
 }
}