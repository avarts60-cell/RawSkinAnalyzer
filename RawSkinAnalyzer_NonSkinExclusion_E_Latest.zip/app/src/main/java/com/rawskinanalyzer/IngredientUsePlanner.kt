package com.rawskinanalyzer

/**
 * BATCH 4D-A — connects the already-computed `RoutineIntensityDecision` (Batch 3B,
 * `RoutineIntensityPolicy`) and per-ingredient `ToleranceState` (Batch 3B) to concrete
 * concentration/frequency guidance. Audit finding (see PROJECT_STATUS.md, Batch 4D-A entry):
 * `FinalSkinAnalysisProfileAnalyzer.json()` already computed `routineIntensityDecisions`/
 * `intensityByName` before this batch, but never passed them into this planner — concentration
 * and frequency guidance was previously derived only from the static, session-level
 * `UserRoutineContext` (a stated preference), with no connection at all to the dynamic,
 * per-ingredient tolerance/compatibility/objective-strength ceiling `RoutineIntensityPolicy`
 * already calibrates. This file closes exactly that gap; it does not recompute intensity,
 * tolerance, compatibility, or evidence — those keep meaning "own thing" per the standing
 * critical-separation rule and are only read here.
 */

data class IngredientUsePlan(
    val concern: SkinConcernCategory,
    val ingredientName: String,
    val concentrationGuidance: String,
    val frequencyGuidance: String,
    val routinePhase: String,
    val introductionRule: String,
    val caution: String?,
    // Batch 4D-A: carried through for explainability (step 10 / P1) — not new computation,
    // just the already-computed intensity decision surfaced alongside the guidance it shaped.
    // Defaulted so pre-existing test call sites that construct an IngredientUsePlan directly
    // (e.g. Batch3BPoliciesTest.kt) continue to compile unchanged.
    val intensityLevel: String = "NOT_SPECIFIED",
    val intensityReason: String = "NOT_SPECIFIED",
    val toleranceState: String = "UNKNOWN"
)

object IngredientUsePlanner {
    /**
     * @param intensityByName this candidate's already-computed `RoutineIntensityDecision`
     *   (`RoutineIntensityPolicy.calibrate`, Batch 3B) keyed by ingredient name. Optional/
     *   default-empty so existing callers that have not been updated still compile and behave
     *   exactly as before (see `guidanceFor`: an absent entry falls back to the pre-Batch-4D-A
     *   behavior of using only `context`, never introducing a new default).
     * @param toleranceByName this candidate's current `ToleranceState` keyed by ingredient name,
     *   surfaced on the returned plan for explainability only — the actual tolerance ceiling is
     *   already baked into `intensityByName`'s level by `RoutineIntensityPolicy`, so this is not
     *   read a second time to make a decision, only to report it.
     */
    fun plan(
        options: List<SpecificIngredientOption>,
        context: UserRoutineContext,
        intensityByName: Map<String, RoutineIntensityDecision> = emptyMap(),
        toleranceByName: Map<String, ToleranceState> = emptyMap()
    ): List<IngredientUsePlan> = options.map { option ->
        val cautious = context.tolerancePreference == TolerancePreference.CAUTIOUS
        val lowIntensity = context.activeIntensityPreference == ActiveIntensityPreference.LOW
        val intensityDecision = intensityByName[option.ingredientName]
        val intensityLevel = intensityDecision?.level

        val (concentration, frequency) = guidanceFor(option, cautious || lowIntensity, intensityLevel)

        val introductionRule = when {
            // MINIMAL is a hard ceiling from tolerance/compatibility (RoutineIntensityPolicy) —
            // never silently reintroduced or escalated by a user preference.
            intensityLevel == RoutineIntensityLevel.MINIMAL -> "REVIEW_REQUIRED_BEFORE_USE"
            intensityLevel == RoutineIntensityLevel.CONSERVATIVE -> "START_CONSERVATIVELY_AND_REVIEW_TOLERANCE"
            cautious || lowIntensity -> "START_CONSERVATIVELY_AND_REVIEW_TOLERANCE"
            else -> "INTRODUCE_GRADUALLY_AND_REVIEW_TOLERANCE"
        }

        IngredientUsePlan(
            concern = option.concern,
            ingredientName = option.ingredientName,
            concentrationGuidance = concentration,
            frequencyGuidance = frequency,
            routinePhase = option.routinePhase,
            introductionRule = introductionRule,
            caution = option.caution,
            intensityLevel = intensityLevel?.name ?: "NOT_SPECIFIED",
            intensityReason = intensityDecision?.reason ?: "NOT_SPECIFIED",
            toleranceState = (toleranceByName[option.ingredientName] ?: ToleranceState.UNKNOWN).name
        )
    }

    private fun guidanceFor(
        option: SpecificIngredientOption,
        userPrefersConservative: Boolean,
        intensityLevel: RoutineIntensityLevel?
    ): Pair<String, String> {
        // MINIMAL means tolerance is in CAUTION or compatibility requires separation/review
        // (RoutineIntensityPolicy's hard-ceiling branches) — no concentration/frequency category
        // is safe to assert here; explicitly return a review state rather than guessing, per
        // step 4/5's "if it cannot be safely determined, return REVIEW/NOT_SPECIFIED."
        if (intensityLevel == RoutineIntensityLevel.MINIMAL) {
            return "REVIEW_REQUIRED" to "REVIEW_REQUIRED"
        }

        // Intensity can only make guidance MORE conservative than the user's own stated
        // preference, never less — CAUTIOUS_ESCALATION does not by itself unlock a higher-
        // frequency tier than STANDARD already offers (see RoutineIntensityPolicy's own doc
        // comment: "do not create an aggressive schedule from a single analysis"). When no
        // intensity decision was supplied (default empty map, e.g. an older/unmigrated caller),
        // this falls back to exactly the pre-Batch-4D-A behavior of using only the user
        // preference, so existing behavior is preserved when this parameter isn't provided.
        val conservative = userPrefersConservative || intensityLevel == RoutineIntensityLevel.CONSERVATIVE

        return when (option.ingredientName) {
            "Niacinamide" ->
                if (conservative) "LOWER_STRENGTH_OPTION" to "START_FEW_SESSIONS_PER_WEEK"
                else "STANDARD_COSMETIC_STRENGTH_OPTION" to "START_REGULARLY_AND_REVIEW"
            "Vitamin C" ->
                if (conservative) "LOWER_STRENGTH_OPTION" to "START_FEW_MORNING_SESSIONS_PER_WEEK"
                else "STANDARD_COSMETIC_STRENGTH_OPTION" to "START_REGULARLY_AND_REVIEW"
            "Azelaic acid" ->
                if (conservative) "LOWER_INTENSITY_OPTION" to "START_FEW_SESSIONS_PER_WEEK"
                else "PRODUCT_LABEL_COMPATIBLE_OPTION" to "INTRODUCE_GRADUALLY"
            "Salicylic acid" ->
                "PRODUCT_LABEL_COMPATIBLE_OPTION" to
                    if (conservative) "START_INFREQUENTLY" else "START_FEW_SESSIONS_PER_WEEK"
            "Ceramides" ->
                "FORMULATION_DEPENDENT_SUPPORT_LEVEL" to "REGULAR_USE_AS_NEEDED"
            "Glycerin" ->
                "FORMULATION_DEPENDENT_SUPPORT_LEVEL" to "REGULAR_USE_AS_NEEDED"
            else ->
                "PRODUCT_SPECIFIC_REVIEW_REQUIRED" to "INTRODUCE_GRADUALLY"
        }
    }
}