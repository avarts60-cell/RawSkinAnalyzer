package com.rawskinanalyzer

enum class IntegrityTrendSupport {
    FULL,
    QUALIFIED,
    LIMITED
}

data class IntegrityAwareTrendConfidenceResult(
    val support: IntegrityTrendSupport,
    val adjustedConfidence: String,
    val integrityReason: String,
    val multiSessionTrendAllowed: Boolean
)

object IntegrityAwareTrendConfidencePolicy {

    fun evaluate(
        telemetry: SkinSessionIntegrityTelemetry,
        existingConfidence: String
    ): IntegrityAwareTrendConfidenceResult {
        return when (telemetry.status) {
            SkinSessionIntegrityStatus.SESSION_DATA_VALID ->
                IntegrityAwareTrendConfidenceResult(
                    support = IntegrityTrendSupport.FULL,
                    adjustedConfidence = existingConfidence,
                    integrityReason = "SESSION_HISTORY_VALID",
                    multiSessionTrendAllowed = telemetry.safeHistoryAvailable
                )

            SkinSessionIntegrityStatus.SESSION_DATA_PARTIALLY_RECOVERED ->
                IntegrityAwareTrendConfidenceResult(
                    support = IntegrityTrendSupport.QUALIFIED,
                    adjustedConfidence = downgrade(existingConfidence),
                    integrityReason = "SESSION_HISTORY_PARTIALLY_RECOVERED",
                    multiSessionTrendAllowed = telemetry.safeHistoryAvailable
                )

            SkinSessionIntegrityStatus.SESSION_DATA_RECOVERY_FAILED ->
                IntegrityAwareTrendConfidenceResult(
                    support = IntegrityTrendSupport.LIMITED,
                    adjustedConfidence = "LOW",
                    integrityReason = "SAFE_SESSION_HISTORY_UNAVAILABLE",
                    multiSessionTrendAllowed = false
                )
        }
    }

    private fun downgrade(confidence: String): String =
        when (confidence.uppercase()) {
            "HIGH" -> "MODERATE"
            "MODERATE" -> "LOW"
            "LOW" -> "LOW"
            else -> "LOW"
        }
}
