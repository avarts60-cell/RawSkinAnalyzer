package com.rawskinanalyzer

data class CatalogProduct(
    val productId: String,
    val displayName: String,
    val ingredientNames: Set<String>,
    val attributes: Set<String>,
    val routinePhases: Set<String>
)

object LocalProductCatalog {
    fun products(): List<CatalogProduct> = listOf(
        CatalogProduct(
            productId = "catalog_niacinamide",
            displayName = "Niacinamide Category Candidate",
            ingredientNames = setOf("Niacinamide"),
            attributes = setOf("INGREDIENT_MATCH"),
            routinePhases = setOf("AM", "PM", "AM_OR_PM")
        ),
        CatalogProduct(
            productId = "catalog_vitamin_c",
            displayName = "Vitamin C Category Candidate",
            ingredientNames = setOf("Vitamin C"),
            attributes = setOf("INGREDIENT_MATCH"),
            routinePhases = setOf("AM", "AM_OR_PM")
        ),
        CatalogProduct(
            productId = "catalog_azelaic_acid",
            displayName = "Azelaic Acid Category Candidate",
            ingredientNames = setOf("Azelaic acid"),
            attributes = setOf("INGREDIENT_MATCH"),
            routinePhases = setOf("PM", "AM_OR_PM")
        ),
        CatalogProduct(
            productId = "catalog_salicylic_acid",
            displayName = "Salicylic Acid Category Candidate",
            ingredientNames = setOf("Salicylic acid"),
            attributes = setOf("INGREDIENT_MATCH"),
            routinePhases = setOf("PM", "AM_OR_PM")
        ),
        CatalogProduct(
            productId = "catalog_ceramides",
            displayName = "Ceramide Category Candidate",
            ingredientNames = setOf("Ceramides"),
            attributes = setOf("INGREDIENT_MATCH"),
            routinePhases = setOf("AM", "PM", "AM_OR_PM")
        ),
        CatalogProduct(
            productId = "catalog_glycerin",
            displayName = "Glycerin Category Candidate",
            ingredientNames = setOf("Glycerin"),
            attributes = setOf("INGREDIENT_MATCH"),
            routinePhases = setOf("AM", "PM", "AM_OR_PM")
        )
    )

    fun candidates(): List<ProductCandidate> =
        products().map {
            ProductCandidate(
                productId = it.productId,
                ingredientNames = it.ingredientNames,
                attributes = it.attributes,
                routinePhases = it.routinePhases
            )
        }
}
