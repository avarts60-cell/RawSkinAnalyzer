package com.rawskinanalyzer

data class LocalizedFeatureAnalysisResult(
    val totalHotspots:Int,
    val hotspotDensity:Double,
    val clusterCount:Int,
    val repeatedFeatureSignal:String,
    val concentration:String,
    val distribution:String,
    val dominantLocalizedCharacteristic:String,
    val confidence:String
)

object LocalizedFeatureAnalyzer {
    private fun allHotspots(front:List<PatternMapCell>, left:List<PatternMapCell>, right:List<PatternMapCell>) =
        listOf(front,left,right).flatMap { PatternHotspotAnalyzer.analyze(it) }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):LocalizedFeatureAnalysisResult {
        val fusion=MultiViewSkinDataFusionAnalyzer.analyze(front,left,right)
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val clusters=PatternSignalClusteringAnalyzer.analyze(front,left,right).clusters
        val hotspots=allHotspots(front,left,right)
        val usableCells=listOf(front,left,right).flatMap { it.filter { c -> c.skinPercent>=10.0 } }
        val density=if(usableCells.isEmpty()) 0.0 else hotspots.size*100.0/usableCells.size
        val repeated=when {
            fusion.usableViews>=3 && fusion.crossViewSupport=="HIGH_CROSS_VIEW_SUPPORT" && hotspots.size>=3 ->
                "HIGH_REPEATED_LOCALIZED_FEATURE_SIGNAL"
            fusion.usableViews>=2 && hotspots.size>=2 ->
                "MODERATE_REPEATED_LOCALIZED_FEATURE_SIGNAL"
            hotspots.isNotEmpty() -> "LOW_REPEATED_LOCALIZED_FEATURE_SIGNAL"
            else -> "NO_STRONG_REPEATED_LOCALIZED_FEATURE_SIGNAL"
        }
        val strongClusters=clusters.count { it.classification=="STRONG_LOCALIZED_CLUSTER" }
        val moderateClusters=clusters.count { it.classification=="MODERATE_LOCALIZED_CLUSTER" }
        val concentration=when {
            strongClusters>0 || clusters.any { it.cellCount>=6 } -> "HIGH_LOCALIZED_FEATURE_CONCENTRATION"
            moderateClusters>0 || clusters.any { it.cellCount>=3 } -> "MODERATE_LOCALIZED_FEATURE_CONCENTRATION"
            hotspots.size>=2 -> "LOW_LOCALIZED_FEATURE_CONCENTRATION"
            else -> "ISOLATED_OR_LIMITED_FEATURES"
        }
        val distribution=when {
            fusion.crossViewSupport=="HIGH_CROSS_VIEW_SUPPORT" && fusion.usableViews>=3 ->
                "MULTI_VIEW_DISTRIBUTED"
            fusion.usableViews>=2 && hotspots.size>=2 -> "MULTI_VIEW_PARTIAL_DISTRIBUTION"
            hotspots.isNotEmpty() -> "VIEW_LOCALIZED"
            else -> "NO_STRONG_FEATURE_DISTRIBUTION"
        }
        val dominant=when {
            repeated=="HIGH_REPEATED_LOCALIZED_FEATURE_SIGNAL" &&
                    concentration=="HIGH_LOCALIZED_FEATURE_CONCENTRATION" ->
                "REPEATED_CONCENTRATED_LOCALIZED_FEATURES"
            concentration=="HIGH_LOCALIZED_FEATURE_CONCENTRATION" ->
                "CONCENTRATED_LOCALIZED_FEATURES"
            repeated.startsWith("MODERATE") || repeated.startsWith("HIGH") ->
                "REPEATED_LOCALIZED_FEATURES"
            hotspots.size==1 -> "ISOLATED_LOCALIZED_FEATURE"
            else -> "LIMITED_LOCALIZED_FEATURE_SIGNAL"
        }
        return LocalizedFeatureAnalysisResult(
            hotspots.size,density,clusters.size,repeated,concentration,distribution,dominant,q.confidence
        )
    }

    fun json(x:LocalizedFeatureAnalysisResult)=
        """{"total_hotspots":${x.totalHotspots},"hotspot_density":${x.hotspotDensity},"cluster_count":${x.clusterCount},"repeated_feature_signal":"${x.repeatedFeatureSignal}","concentration":"${x.concentration}","distribution":"${x.distribution}","dominant_localized_characteristic":"${x.dominantLocalizedCharacteristic}","confidence":"${x.confidence}","method":"localized_feature_analysis_v1","medical_diagnosis":false}"""
}
