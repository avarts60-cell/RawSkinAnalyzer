package com.rawskinanalyzer

import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.abs
import kotlin.math.max

data class PatternMapCell(
    val row:Int,
    val col:Int,
    val samples:Int,
    val skinPercent:Double,
    val meanLuma:Double,
    val redness:Double,
    val texture:Double,
    val darkPercent:Double,
    // --- precision-analysis additions (additive; existing fields above are unchanged in meaning) ---
    val highConfidenceSkinPercent:Double,
    val excludedShadowPercent:Double,
    val excludedHighlightPercent:Double,
    val excludedNonSkinPercent:Double,
    val uncertainPercent:Double,
    val meanConfidenceWeight:Double
)

/**
 * Cell-level pattern mapper. This is the single chokepoint nearly every feature analyzer
 * (redness, texture, pore, blemish, pigmentation, hotspot, cross-view, stability, etc.)
 * consumes via `map()`. Upgrading skin classification here — rather than duplicating logic
 * per analyzer — makes the improved skin representation an actual gate for the whole
 * downstream pipeline instead of a display-only layer, per the existing filter pattern
 * `cells.filter { it.skinPercent >= 10.0 }` already used throughout the codebase.
 *
 * skinPercent now means "usable skin" (HIGH + MEDIUM confidence, see SkinSegmentationEngine)
 * rather than a raw single-threshold RGB match. meanLuma/redness/texture are now computed
 * only from usable-skin pixels, weighted by classification confidence, so specular
 * highlights and shadow-crushed pixels — previously silently included — no longer
 * contaminate color and texture measurements.
 */
object LocalizedPatternMapper {
    fun map(file:File, grid:Int=6):List<PatternMapCell> {
        val b=BitmapFactory.decodeFile(file.absolutePath)
            ?: throw IllegalArgumentException("Cannot decode normalized image")
        val out=mutableListOf<PatternMapCell>()
        for(row in 0 until grid) for(col in 0 until grid) {
            val x0=col*b.width/grid; val x1=(col+1)*b.width/grid
            val y0=row*b.height/grid; val y1=(row+1)*b.height/grid
            val step=max(1,max(x1-x0,y1-y0)/48)
            var total=0
            var highConf=0; var medConf=0; var lowConf=0
            var excludedShadow=0; var excludedHighlight=0; var excludedNotSkin=0
            var weightSum=0.0
            var lumaSum=0.0; var redSum=0.0
            var dark=0; var textureSum=0.0; var textureN=0
            var prevUsable=false; var prevLuma=0.0
            for(y in y0 until y1 step step) for(x in x0 until x1 step step) {
                val p=b.getPixel(x,y)
                val r=(p shr 16 and 255).toDouble()
                val g=(p shr 8 and 255).toDouble()
                val bl=(p and 255).toDouble()
                total++
                val cls = SkinSegmentationEngine.classify(r,g,bl)
                when (cls.exclusion) {
                    ExclusionReason.SHADOW_CRUSH -> excludedShadow++
                    ExclusionReason.SPECULAR_HIGHLIGHT -> excludedHighlight++
                    ExclusionReason.NOT_SKIN_COLOR -> excludedNotSkin++
                    else -> {}
                }
                when (cls.tier) {
                    SkinConfidenceTier.HIGH -> highConf++
                    SkinConfidenceTier.MEDIUM -> medConf++
                    SkinConfidenceTier.LOW -> lowConf++
                    SkinConfidenceTier.EXCLUDED -> {}
                }
                val usable = cls.tier==SkinConfidenceTier.HIGH || cls.tier==SkinConfidenceTier.MEDIUM
                if (usable) {
                    val lum=0.2126*r+0.7152*g+0.0722*bl
                    val w=cls.weight
                    weightSum+=w
                    lumaSum+=lum*w
                    redSum+=(r-g)*w
                    if(lum<55) dark++
                    // Texture: local luma gradient between adjacent usable-skin samples only,
                    // so a hair/shadow/highlight pixel next to skin no longer inflates the
                    // texture reading of the skin pixel beside it.
                    if(x>=x0+step && prevUsable) {
                        textureSum+=abs(lum-prevLuma)*w
                        textureN++
                    }
                    prevUsable=true; prevLuma=lum
                } else {
                    prevUsable=false
                }
            }
            val usableCount = highConf+medConf
            val wDenom = max(1e-6, weightSum)
            out+=PatternMapCell(
                row=row, col=col, samples=total,
                skinPercent = usableCount*100.0/max(1,total),
                meanLuma = if(weightSum==0.0) 0.0 else lumaSum/wDenom,
                redness = if(weightSum==0.0) 0.0 else redSum/wDenom,
                texture = if(textureN==0) 0.0 else textureSum/textureN,
                darkPercent = if(usableCount==0) 0.0 else dark*100.0/usableCount,
                highConfidenceSkinPercent = highConf*100.0/max(1,total),
                excludedShadowPercent = excludedShadow*100.0/max(1,total),
                excludedHighlightPercent = excludedHighlight*100.0/max(1,total),
                excludedNonSkinPercent = excludedNotSkin*100.0/max(1,total),
                uncertainPercent = lowConf*100.0/max(1,total),
                meanConfidenceWeight = if(total==0) 0.0 else weightSum/total
            )
        }
        b.recycle()
        return out
    }

    fun json(cells:List<PatternMapCell>):String =
        """{"grid_rows":6,"grid_cols":6,"cells":[${cells.joinToString(","){
            """{"row":${it.row},"col":${it.col},"samples":${it.samples},"skin_percent":${it.skinPercent},"mean_luma":${it.meanLuma},"redness":${it.redness},"texture":${it.texture},"dark_percent":${it.darkPercent},"high_confidence_skin_percent":${it.highConfidenceSkinPercent},"excluded_shadow_percent":${it.excludedShadowPercent},"excluded_highlight_percent":${it.excludedHighlightPercent},"excluded_non_skin_percent":${it.excludedNonSkinPercent},"uncertain_percent":${it.uncertainPercent},"mean_confidence_weight":${it.meanConfidenceWeight}}"""
        }}],"method":"localized_pattern_mapping_v2_confidence_weighted","segmentation_engine":"${SkinSegmentationEngine.VERSION}","medical_diagnosis":false}"""
}
