package com.rawskinanalyzer

/**
 * BATCH 4A — STEPS 7 & 8: conservative longitudinal change classification, with
 * repeated-session confirmation against single-session anomalies.
 *
 * Audit finding: the existing two-session comparison (`SkinProgressTracker.overallDirection`:
 * IMPROVED/STABLE/WORSENED/INSUFFICIENT_COMPARISON_DATA) and the existing multi-session trend
 * (`MultiSessionTrendAnalyzer.overallDirection`) are computed independently and never
 * reconciled — nothing stops a single noisy/anomalous latest session from being reported as
 * "WORSENED" even when the last several sessions were flat, and nothing folds in the new
 * `SessionComparabilityResult`/`ComparisonConfidenceResult` from this batch. This file does not
 * replace either existing analyzer; it is a thin reconciling layer over their already-computed
 * outputs.
 *
 * This is the layer that actually enforces "do not label a session as worsening solely
 * because its raw score differs" and "single anomalous sessions should not automatically
 * dominate a trend" — everything upstream of this file still just reports the raw comparison.
 */
enum class LongitudinalChangeClassification {
    IMPROVING,
    STABLE,
    WORSENING,
    UNCERTAIN,
    INSUFFICIENT_DATA,
    NOT_COMPARABLE
}

data class LongitudinalChangeResult(
    val classification: LongitudinalChangeClassification,
    val reasons: List<String>
)

object LongitudinalChangeClassifier {

    fun classify(
        progressResult: SkinProgressResult,
        multiSessionTrend: MultiSessionTrendResult,
        comparability: SessionComparabilityResult,
        comparisonConfidence: ComparisonConfidenceResult
    ): LongitudinalChangeResult {
        if (comparability.status == SessionComparabilityStatus.NOT_COMPARABLE) {
            return LongitudinalChangeResult(
                LongitudinalChangeClassification.NOT_COMPARABLE,
                comparability.reasons
            )
        }

        if (progressResult.overallDirection == ProgressDirection.INSUFFICIENT_COMPARISON_DATA) {
            return LongitudinalChangeResult(
                LongitudinalChangeClassification.INSUFFICIENT_DATA,
                listOf("NO_PRIOR_COMPATIBLE_SESSION")
            )
        }

        val singleSessionDirection = when (progressResult.overallDirection) {
            ProgressDirection.IMPROVED -> LongitudinalChangeClassification.IMPROVING
            ProgressDirection.WORSENED -> LongitudinalChangeClassification.WORSENING
            ProgressDirection.STABLE -> LongitudinalChangeClassification.STABLE
            ProgressDirection.INSUFFICIENT_COMPARISON_DATA -> LongitudinalChangeClassification.INSUFFICIENT_DATA
        }

        // Low/insufficient comparison confidence: the two-session delta alone is not trusted
        // enough to assert a direction. It can still be *confirmed*, per step 8, if a longer,
        // independently-computed multi-session trend agrees — a repeated pattern carries more
        // weight than one low-confidence comparison. A trend needs INSUFFICIENT_TREND_DATA to
        // not qualify (`MultiSessionTrendAnalyzer` already requires 3+ sessions for a real
        // trend), so this cannot be satisfied by the same two sessions being double-counted.
        if (comparisonConfidence.level == ComparisonConfidenceLevel.LOW ||
            comparisonConfidence.level == ComparisonConfidenceLevel.INSUFFICIENT
        ) {
            val confirmed = confirmingTrend(singleSessionDirection, multiSessionTrend)
            return if (confirmed) {
                LongitudinalChangeResult(
                    singleSessionDirection,
                    listOf(
                        "LOW_COMPARISON_CONFIDENCE_BUT_CONFIRMED_BY_REPEATED_MULTI_SESSION_TREND",
                        "MULTI_SESSION_TREND_SESSIONS_USED_${multiSessionTrend.sessionsUsed}"
                    )
                )
            } else {
                LongitudinalChangeResult(
                    LongitudinalChangeClassification.UNCERTAIN,
                    listOf("COMPARISON_CONFIDENCE_${comparisonConfidence.level}") + comparisonConfidence.reasons
                )
            }
        }

        // Comparison confidence is at least MODERATE. Still guard against a single-session
        // anomaly contradicting an established, better-evidenced multi-session trend: if the
        // longer trend disagrees outright (e.g. this session reads WORSENED but the last
        // several sessions were STABLE_TREND or moving the other way), don't overreact to the
        // one newest delta.
        if (contradictingTrend(singleSessionDirection, multiSessionTrend)) {
            return LongitudinalChangeResult(
                LongitudinalChangeClassification.UNCERTAIN,
                listOf(
                    "LATEST_SESSION_DELTA_CONTRADICTS_ESTABLISHED_MULTI_SESSION_TREND",
                    "MULTI_SESSION_TREND_${multiSessionTrend.overallDirection}"
                )
            )
        }

        return LongitudinalChangeResult(
            singleSessionDirection,
            listOf("COMPARISON_CONFIDENCE_${comparisonConfidence.level}") + comparability.reasons
        )
    }

    private fun confirmingTrend(
        direction: LongitudinalChangeClassification,
        trend: MultiSessionTrendResult
    ): Boolean = when (direction) {
        LongitudinalChangeClassification.IMPROVING -> trend.overallDirection == TrendDirection.SUSTAINED_IMPROVEMENT
        LongitudinalChangeClassification.WORSENING -> trend.overallDirection == TrendDirection.SUSTAINED_WORSENING
        LongitudinalChangeClassification.STABLE -> trend.overallDirection == TrendDirection.STABLE_TREND
        else -> false
    }

    private fun contradictingTrend(
        direction: LongitudinalChangeClassification,
        trend: MultiSessionTrendResult
    ): Boolean {
        if (trend.overallDirection == TrendDirection.INSUFFICIENT_TREND_DATA) return false
        return when (direction) {
            LongitudinalChangeClassification.WORSENING ->
                trend.overallDirection == TrendDirection.SUSTAINED_IMPROVEMENT || trend.overallDirection == TrendDirection.STABLE_TREND
            LongitudinalChangeClassification.IMPROVING ->
                trend.overallDirection == TrendDirection.SUSTAINED_WORSENING || trend.overallDirection == TrendDirection.STABLE_TREND
            else -> false
        }
    }

    fun json(x: LongitudinalChangeResult): String {
        val r = x.reasons.joinToString(",") { "\"$it\"" }
        return """{"classification":"${x.classification}","reasons":[$r],"medical_diagnosis":false}"""
    }
}
