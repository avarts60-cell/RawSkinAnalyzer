package com.rawskinanalyzer

import kotlin.math.abs

/**
 * LongitudinalFeatureContract
 *
 * Batch 4D-G, step_6/step_7 (P0 as specified; delivered as a CONTRACT plus a working comparison
 * function, not a fully wired repeated-session feature). Honest scoping, stated once here:
 *
 * This project has never persisted fused feature-level evidence across sessions before this
 * batch — `PersistentSkinSessionStore`/`SkinSessionRepository` store characteristic-LEVEL scores
 * only (see `MultiSessionTrendAnalyzer`). Wiring [FeatureIdentityRecord] storage into that
 * repository (a schema change plus a read/write path) is real additional work this batch did not
 * attempt, per the handoff's own step_8 P1 framing ("Connect... WHERE THE EXISTING INTERFACES
 * SUPPORT IT") and scope_control's coherent-subset rule — see PROJECT_STATUS.md's "known
 * limitations" for this batch.
 *
 * What IS real and working here: [extractIdentity] builds the exact metadata shape step_6 asks
 * for from a genuine [FusedFeatureEvidence], and [compareIdentities] is a real, testable
 * region+type+position matching function between two [FeatureIdentityRecord] lists — it will
 * work correctly the moment a caller has two real lists (e.g. once persistence exists, or for two
 * in-memory sessions within a single process). It is gated on [SessionComparabilityStatus]
 * exactly as step_7 requires (`NOT_COMPARABLE` yields no computed changes, only
 * `UNCERTAIN_CHANGE` placeholders), so it does not need to be revisited when persistence is
 * eventually added — only the caller that fetches the previous session's records does.
 */

enum class FeatureChangeType {
    PERSISTING_FEATURE, NEW_FEATURE_CANDIDATE, RESOLVED_FEATURE_CANDIDATE,
    SIZE_CHANGE, VISIBILITY_CHANGE, DENSITY_CHANGE, REGIONAL_DISTRIBUTION_CHANGE, UNCERTAIN_CHANGE
}

data class FeatureIdentityRecord(
    val featureType: SpecializedFeatureType,
    val anatomicalRegion: AnatomicalRegion,
    val normalizedLocation: NormalizedPosition,
    val apparentSize: Double,
    val featureConfidence: Double,
    val sourceView: String,
    val sessionId: String,
    val captureQuality: String?,
    /** "Use existing session comparability architecture" — this is the CURRENT session's own
     * standing relative to comparability gating context, not a value computed against a specific
     * prior session (a single record cannot know which future session it will later be compared
     * against) — actual pairwise comparability is evaluated separately, in [compareIdentities],
     * where both sessions are known. */
    val comparabilityState: String
) {
    companion object {
        /** step_6's own `required_metadata` list, applied directly. [correspondenceId] is kept
         * alongside (not itself in the required list) purely so a future persistence layer can
         * trace a stored identity record back to the correspondence/fusion pass that produced it
         * without a separate lookup table. */
        fun extractIdentity(
            fused: FusedFeatureEvidence,
            perView: PerViewFeatureEvidenceRef,
            sessionId: String,
            comparabilityState: String
        ): FeatureIdentityRecord = FeatureIdentityRecord(
            featureType = fused.featureType,
            anatomicalRegion = fused.anatomicalRegion,
            normalizedLocation = fused.regionalLocation,
            apparentSize = perView.area.toDouble(),
            featureConfidence = perView.confidence,
            sourceView = perView.view,
            sessionId = sessionId,
            captureQuality = null,
            comparabilityState = comparabilityState
        )
    }
}

data class FeatureChangeEvidence(
    val changeType: FeatureChangeType,
    val featureType: SpecializedFeatureType,
    val anatomicalRegion: AnatomicalRegion,
    val previousIdentity: FeatureIdentityRecord?,
    val currentIdentity: FeatureIdentityRecord?,
    val confidence: Double,
    val evidenceReasons: List<String>
)

object LongitudinalFeatureContract {
    const val VERSION = "longitudinal_feature_contract_v1"

    private const val MATCH_DISTANCE_THRESHOLD = 0.25
    private const val SIZE_CHANGE_RATIO_THRESHOLD = 1.6 // >=60% area change in either direction

    private fun samePlace(a: FeatureIdentityRecord, b: FeatureIdentityRecord): Boolean {
        if (a.anatomicalRegion != b.anatomicalRegion) return false
        if (a.normalizedLocation.method != RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE) return false
        if (b.normalizedLocation.method != RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE) return false
        return RegionalNormalizationEngine.distance(a.normalizedLocation, b.normalizedLocation) <= MATCH_DISTANCE_THRESHOLD
    }

    /**
     * [comparability] must already reflect the SAME two sessions [previous]/[current] came from
     * (this function does not re-derive it — that decision belongs to
     * [SessionComparabilityEvaluator], per step_7's "use existing comparability gates").
     * `NOT_COMPARABLE` produces exactly one [FeatureChangeEvidence] per current-session record,
     * all `UNCERTAIN_CHANGE`, rather than a real (and misleading) PERSISTING/NEW/RESOLVED call.
     */
    fun compareIdentities(
        previous: List<FeatureIdentityRecord>,
        current: List<FeatureIdentityRecord>,
        comparability: SessionComparabilityResult
    ): List<FeatureChangeEvidence> {
        if (comparability.status == SessionComparabilityStatus.NOT_COMPARABLE) {
            return current.map {
                FeatureChangeEvidence(
                    changeType = FeatureChangeType.UNCERTAIN_CHANGE,
                    featureType = it.featureType, anatomicalRegion = it.anatomicalRegion,
                    previousIdentity = null, currentIdentity = it, confidence = 0.0,
                    evidenceReasons = listOf("sessions not comparable (${comparability.reasons.joinToString("; ")}); no change can be meaningfully computed")
                )
            }
        }

        val comparabilityDiscount = when (comparability.status) {
            SessionComparabilityStatus.HIGHLY_COMPARABLE -> 1.0
            SessionComparabilityStatus.COMPARABLE -> 0.9
            SessionComparabilityStatus.LIMITED_COMPARABILITY -> 0.65
            SessionComparabilityStatus.NOT_COMPARABLE -> 0.0 // unreachable here, handled above
        }

        val out = mutableListOf<FeatureChangeEvidence>()
        val matchedPrevious = mutableSetOf<Int>()

        for (cur in current) {
            val familyRegionCandidates = previous.withIndex().filter { (i, p) -> i !in matchedPrevious && p.featureType == cur.featureType && samePlace(p, cur) }
            val match = familyRegionCandidates.minByOrNull { (_, p) -> RegionalNormalizationEngine.distance(p.normalizedLocation, cur.normalizedLocation) }

            if (match == null) {
                out.add(
                    FeatureChangeEvidence(
                        changeType = FeatureChangeType.NEW_FEATURE_CANDIDATE,
                        featureType = cur.featureType, anatomicalRegion = cur.anatomicalRegion,
                        previousIdentity = null, currentIdentity = cur,
                        confidence = (cur.featureConfidence * comparabilityDiscount).coerceIn(0.0, 1.0),
                        evidenceReasons = listOf("no matching feature of this type found at this position in the previous comparable session")
                    )
                )
                continue
            }

            val (prevIdx, prev) = match
            matchedPrevious += prevIdx
            val sizeRatio = if (prev.apparentSize > 0.0) maxOf(cur.apparentSize, prev.apparentSize) / minOf(cur.apparentSize, prev.apparentSize).coerceAtLeast(1.0) else 1.0
            val confidenceDelta = abs(cur.featureConfidence - prev.featureConfidence)

            val changeType = when {
                sizeRatio >= SIZE_CHANGE_RATIO_THRESHOLD -> FeatureChangeType.SIZE_CHANGE
                confidenceDelta >= 0.35 -> FeatureChangeType.VISIBILITY_CHANGE
                else -> FeatureChangeType.PERSISTING_FEATURE
            }
            val reasons = mutableListOf("matched to a previous-session feature of the same type within ${"%.2f".format(MATCH_DISTANCE_THRESHOLD)} normalized distance")
            if (changeType == FeatureChangeType.SIZE_CHANGE) reasons.add("apparent size ratio ${"%.2f".format(sizeRatio)}x between sessions")
            if (changeType == FeatureChangeType.VISIBILITY_CHANGE) reasons.add("confidence changed by ${"%.2f".format(confidenceDelta)} between sessions")

            out.add(
                FeatureChangeEvidence(
                    changeType = changeType, featureType = cur.featureType, anatomicalRegion = cur.anatomicalRegion,
                    previousIdentity = prev, currentIdentity = cur,
                    confidence = ((1.0 - confidenceDelta.coerceIn(0.0, 1.0)) * comparabilityDiscount).coerceIn(0.0, 1.0),
                    evidenceReasons = reasons
                )
            )
        }

        for ((i, prev) in previous.withIndex()) {
            if (i in matchedPrevious) continue
            out.add(
                FeatureChangeEvidence(
                    changeType = FeatureChangeType.RESOLVED_FEATURE_CANDIDATE,
                    featureType = prev.featureType, anatomicalRegion = prev.anatomicalRegion,
                    previousIdentity = prev, currentIdentity = null,
                    confidence = (prev.featureConfidence * comparabilityDiscount).coerceIn(0.0, 1.0),
                    evidenceReasons = listOf("present in the previous comparable session; no matching feature of this type found at this position in the current session")
                )
            )
        }

        // DENSITY_CHANGE / REGIONAL_DISTRIBUTION_CHANGE are region-wide judgments (not
        // per-feature matches like everything above) and are NOT computed here — see
        // PROJECT_STATUS.md; the two change types remain in the enum per step_7's required list
        // so the shape is ready when that region-level comparison is implemented.
        return out
    }

    fun identityJson(r: FeatureIdentityRecord): String {
        val cq = if (r.captureQuality != null) "\"${r.captureQuality}\"" else "null"
        return """{"feature_type":"${r.featureType}","anatomical_region":"${r.anatomicalRegion}","normalized_location":${FeatureCorrespondenceJson.normalizedPositionJson(r.normalizedLocation)},"apparent_size":${r.apparentSize},"feature_confidence":${r.featureConfidence},"source_view":"${r.sourceView}","session_id":"${r.sessionId}","capture_quality":$cq,"comparability_state":"${r.comparabilityState}"}"""
    }

    fun changeJson(c: FeatureChangeEvidence): String {
        val reasons = c.evidenceReasons.joinToString(",") { "\"${it.replace("\"", "\\\"")}\"" }
        val prev = if (c.previousIdentity != null) identityJson(c.previousIdentity) else "null"
        val cur = if (c.currentIdentity != null) identityJson(c.currentIdentity) else "null"
        return """{"change_type":"${c.changeType}","feature_type":"${c.featureType}","anatomical_region":"${c.anatomicalRegion}","previous_identity":$prev,"current_identity":$cur,"confidence":${c.confidence},"evidence_reasons":[$reasons]}"""
    }

    fun identitiesJson(records: List<FeatureIdentityRecord>): String =
        """{"method":"$VERSION","identity_count":${records.size},"identities":[${records.joinToString(",") { identityJson(it) }}]}"""
}
