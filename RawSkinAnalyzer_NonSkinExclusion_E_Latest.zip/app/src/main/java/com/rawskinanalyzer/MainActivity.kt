package com.rawskinanalyzer

import android.graphics.BitmapFactory

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.DngCreator
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import android.view.TextureView
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.rawskinanalyzer.ui.nav.AppRoot
import com.rawskinanalyzer.ui.state.AnalysisViewModel
import com.rawskinanalyzer.ui.state.UiSessionStep
import com.rawskinanalyzer.ui.theme.RawSkinAnalyzerTheme
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    // UI-1A: `preview` is now created and supplied by the Compose Analyze screen
    // (see AnalyzeScreen's AndroidView factory + onPreviewCreated below) instead of an
    // XML layout findViewById. The Camera2 wiring against it (surfaceTextureListener,
    // setDefaultBufferSize, etc.) below is unchanged.
    private lateinit var preview: TextureView
    // UI-1A: the ViewModel is the single place UI state is now pushed to; the old
    // `output`/`status` TextViews are gone, replaced by calls into `viewModel` from the
    // same call sites that used to set `.text` directly.
    private val viewModel: AnalysisViewModel by viewModels()
    private val cameraManager by lazy { getSystemService(CameraManager::class.java) }
    private val cameraThread = HandlerThread("RawSkinCamera").apply { start() }
    private val cameraHandler = Handler(cameraThread.looper)

    private var cameraId = "0"
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var rawReader: ImageReader? = null
    private var jpegReader: ImageReader? = null

    // Batch 3B: this session's cross-view capture-condition consistency, set by
    // runCaptureConditionConsistency() (which runs earlier in the pipeline, see the call order
    // in the capture-completion handler) and read by runFinalSkinAnalysisProfile() so
    // CaptureQualityReliabilityGate can cap trend-adaptation confidence for a poorly-lit
    // session. Null until that stage has run (or if it failed) — FinalSkinAnalysisProfileAnalyzer.json()
    // treats null as RELIABLE, i.e. never penalizes a session it has no signal for.
    private var lastCaptureConditionConsistency: String? = null

    private var captureId = ""
    private var captureDir: File? = null
    private var dngFile: File? = null
    private var jpegFile: File? = null
    private var captureResult: TotalCaptureResult? = null
    private var rawImage: Image? = null
    private var dngWritten = AtomicBoolean(false)
    private var jpegWritten = AtomicBoolean(false)
    private var captureCallbackReceived = AtomicBoolean(false)
    private var finishing = AtomicBoolean(false)
    private val log = StringBuilder()
    private enum class SessionStep(val folder:String, val label:String) {
        FRONT("front","FRONT FACE"), LEFT_CHEEK("left_cheek","LEFT CHEEK"), RIGHT_CHEEK("right_cheek","RIGHT CHEEK")
    }
    private var sessionId = ""
    private var sessionRoot: File? = null
    private var currentStep = SessionStep.FRONT
    private val completedSteps = linkedSetOf<SessionStep>()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) openCamera() else add("CAMERA PERMISSION: DENIED")
        }

    private fun SessionStep.toUiStep(): UiSessionStep = when (this) {
        SessionStep.FRONT -> UiSessionStep.FRONT
        SessionStep.LEFT_CHEEK -> UiSessionStep.LEFT_CHEEK
        SessionStep.RIGHT_CHEEK -> UiSessionStep.RIGHT_CHEEK
    }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        // UI-1B: wire the already-implemented persistent session store (previously only
        // PersistentToleranceStateStore was actually connected below; SkinSessionRepository
        // itself still defaulted to InMemorySkinSessionStore, so multi-session trend/progress
        // and this new History screen would have silently reset on every app restart despite
        // PersistentSkinSessionStore already existing as tested source — this was the
        // explicitly flagged next step from the prior session's status log). No new storage
        // mechanism is introduced; this only activates the existing one.
        SkinSessionRepository.configure(PersistentSkinSessionStore(this))
        sessionId = "SESSION_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        sessionRoot = File(getExternalFilesDir(null), "sessions/$sessionId").apply { mkdirs() }
        viewModel.resetForNewSession(sessionId)
        viewModel.setSessionHistory(SkinSessionRepository.history())

        // UI-1A: Compose is now the root content. The Analyze screen supplies the
        // TextureView (via onPreviewCreated below) that the existing Camera2 pipeline
        // (openCamera/createSession/captureEvidence, all unchanged) drives directly.
        setContent {
            RawSkinAnalyzerTheme {
                AppRoot(
                    viewModel = viewModel,
                    onPreviewCreated = { textureView ->
                        preview = textureView
                        preview.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                            override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) = openCamera()
                            override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}
                            override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean { closeCamera(); return true }
                            override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                        }
                    },
                    onSelectStep = { uiStep ->
                        val step = SessionStep.values().first { it.toUiStep() == uiStep }
                        selectStep(step)
                    },
                    onCapture = { captureEvidence() },
                    onSwitchCamera = { id -> cameraId = id; openCamera() }
                )
            }
        }
    }

    private fun selectStep(step: SessionStep) {
        currentStep = step
        log.clear()
        add("THREE-PHOTO SESSION")
        add("SESSION ID: $sessionId")
        add("CURRENT STEP: ${step.label}")
        add("PROTOCOL: FRONT → LEFT CHEEK → RIGHT CHEEK")
        viewModel.setCurrentStep(step.toUiStep())
    }

    private fun latestNormalized(step: SessionStep): File? = File(sessionRoot, step.folder).walkTopDown().filter { it.isFile && it.name == "analysis_normalized.jpg" }.maxByOrNull { it.lastModified() }
    private fun runSessionFeatureExtraction() {
        try {
            val fs=SessionStep.values().associateWith { latestNormalized(it) ?: throw IllegalStateException("Missing ${it.label}") }
            val ft=fs.mapValues { ImageFeatureExtractor.extract(it.value) }
            val names=mapOf(SessionStep.FRONT to "front_features.json",SessionStep.LEFT_CHEEK to "left_cheek_features.json",SessionStep.RIGHT_CHEEK to "right_cheek_features.json")
            for ((step,v) in ft) { File(sessionRoot!!,names[step]!!).writeText(ImageFeatureExtractor.json(v)); add("${step.label} FEATURES: SAVED") }
            val l=ft[SessionStep.LEFT_CHEEK]!!; val r=ft[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"session_analysis.json").writeText("""{"session_id":"$sessionId","left_right_luma_delta":${kotlin.math.abs(l.meanLuma-r.meanLuma)},"left_right_redness_delta":${kotlin.math.abs(l.rednessIndex-r.rednessIndex)},"left_right_texture_delta":${kotlin.math.abs(l.textureScore-r.textureScore)},"analysis_data_ready":true}""")
            add("SESSION COMPARISON: COMPLETE"); add("ANALYSIS DATA READY")
        } catch(e:Exception){ recordAnalysisFailure("FEATURE EXTRACTION", e) }
    }

    private fun runSkinRegionAnalysis() {
        try {
            val steps=SessionStep.values()
            val results=linkedMapOf<SessionStep,SkinRegionResult>()
            for(step in steps){
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=SkinRegionAnalyzer.analyze(file); results[step]=r
                val name=when(step){
                    SessionStep.FRONT -> "front_skin_region.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_skin_region.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_skin_region.json"
                }
                File(sessionRoot!!,name).writeText(SkinRegionAnalyzer.json(r))
                add("${step.label} SKIN REGION: SAVED")
            }
            val l=results[SessionStep.LEFT_CHEEK]!!; val r=results[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"skin_region_session.json").writeText("""{"session_id":"$sessionId","left_skin_percent":${l.skinPercent},"right_skin_percent":${r.skinPercent},"left_right_redness_delta":${kotlin.math.abs(l.redness-r.redness)},"left_right_texture_delta":${kotlin.math.abs(l.texture-r.texture)},"skin_region_analysis_ready":true}""")
            add("SKIN REGION COMPARISON: COMPLETE")
            add("SKIN REGION ANALYSIS READY")
        } catch(e:Exception){ recordAnalysisFailure("SKIN REGION", e) }
    }

    private fun runSkinFeatureInterpretation() {
        try {
            val results=linkedMapOf<SessionStep,SkinInterpretation>()
            for(step in SessionStep.values()){
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=SkinFeatureInterpreter.analyze(file); results[step]=r
                val name=when(step){
                    SessionStep.FRONT -> "front_skin_interpretation.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_skin_interpretation.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_skin_interpretation.json"
                }
                File(sessionRoot!!,name).writeText(SkinFeatureInterpreter.json(r))
                add("${step.label} SKIN PATTERNS: SAVED")
            }
            val l=results[SessionStep.LEFT_CHEEK]!!; val r=results[SessionStep.RIGHT_CHEEK]!!
            File(sessionRoot!!,"skin_interpretation_session.json").writeText("""{"session_id":"$sessionId","left_right_redness_mean_delta":${kotlin.math.abs(l.rednessMean-r.rednessMean)},"left_right_tone_variation_delta":${kotlin.math.abs(l.toneStd-r.toneStd)},"left_right_texture_variation_delta":${kotlin.math.abs(l.textureVariation-r.textureVariation)},"interpretation_ready":true,"medical_diagnosis":false}""")
            add("SKIN PATTERN COMPARISON: COMPLETE")
            add("SKIN FEATURE INTERPRETATION READY")
        } catch(e:Exception){ recordAnalysisFailure("SKIN INTERPRETATION", e) }
    }

    private var analysisRunning = false
    private var analysisCompletedForSession: String? = null
    private var analysisStageFailures = mutableListOf<String>()

    // Face-geometry batch: populated by runFaceGeometryAnalysis(), consumed by
    // runFaceConstrainedSkinAnalysis(). Kept as plain per-session fields consistent with how
    // this pipeline already threads per-view state (see analysisStageFailures above) rather
    // than introducing a new caching layer.
    private var lastFaceGeometryByStep = linkedMapOf<SessionStep, FaceGeometryResult>()
    private var lastRegionSetByStep = linkedMapOf<SessionStep, RegionSet>()

    // Batch 4D-C: cached from runFaceConstrainedSkinAnalysis() (which already computes both of
    // these) so runMultiScaleTileExtraction() can reuse them without a third redundant
    // LocalizedPatternMapper.map() decode of the same view — see that stage's own doc comment
    // for why tile metadata generation is deliberately zero-additional-bitmap-decode.
    private var lastPatternCellsByStep = linkedMapOf<SessionStep, List<PatternMapCell>>()
    private var lastRegionSkinReportsByStep = linkedMapOf<SessionStep, List<RegionSkinReport>>()

    // Batch 4D-D: cached from runMultiScaleTileExtraction() so runVisualFeatureCandidateAnalysis()
    // can reuse the exact same tile pyramid rather than re-running MultiScaleTileExtractor.extractAll()
    // a second time for the same view (which would re-derive the same coverage math from the same
    // cached cells/reports for no benefit).
    private var lastTileSetsByStep = linkedMapOf<SessionStep, List<MultiScaleTileSet>>()

    // Batch 4D-E: cached from runVisualFeatureCandidateAnalysis() and runCaptureConditionConsistency()
    // respectively, so runSpecializedFeatureAnalysis() can reuse both without re-decoding pixels or
    // re-running candidate detection a second time for the same view.
    private var lastCandidatesByStep = linkedMapOf<SessionStep, List<VisualFeatureCandidate>>()
    private var lastCaptureConditionProfileByStep = linkedMapOf<SessionStep, CaptureConditionProfile>()
    private var lastSpecializedFeatureEvidence: List<SpecializedFeatureEvidence> = emptyList()

    // Batch 4D-F: cached from runShineDetectionAnalysis() so runSpecializedFeatureAnalysis() (shine
    // contamination suppression) and runSurfaceConditionAnalysis() (high-resolution shine nudge)
    // can both reuse the same shine candidate list without a second SignalGrid decode pass.
    private var lastShineCandidatesByStep = linkedMapOf<SessionStep, List<ShineCandidate>>()

    // Batch 4E-B, step_1: cached from runSpecializedFeatureAnalysis() / runShineDetectionAnalysis()
    // so runFinalSkinAnalysisProfile() can feed DensityIntegratedScoring real usable-skin-area
    // density evidence without recomputing regional metrics or re-running shine detection a
    // second time for the same session.
    private var lastSpecializedRegionalMetrics: List<SpecializedRegionalMetric> = emptyList()
    private var lastShineRegionalSummaries: List<RegionalShineSummary> = emptyList()

    // Batch 4D-F2: cached from runBumpDetectionAnalysis() / runSpecializedFeatureAnalysis()
    // respectively, so runPostAcneAssociationAnalysis() can reuse both without re-decoding pixels
    // or re-running the specialized classifiers a second time for the same session.
    private var lastBumpCandidatesByStep = linkedMapOf<SessionStep, List<BumpCandidate>>()
    private var lastPostAcneAssociations: List<PostAcneSpatialAssociation> = emptyList()

    // Batch 4D-G: cached from runFeatureCorrespondenceAndFusion(), which runs after
    // runPostAcneAssociationAnalysis(). lastFeatureIdentityRecords are this session's OWN records
    // only — no previous-session comparison is wired yet (see LongitudinalFeatureContract's own
    // doc comment and PROJECT_STATUS.md), so lastLongitudinalChangeEvidence stays empty this batch.
    private var lastFeatureCorrespondences: List<FeatureCorrespondence> = emptyList()
    private var lastFusedFeatureEvidence: List<FusedFeatureEvidence> = emptyList()
    private var lastRegionalFusedMetrics: List<RegionalFusedMetrics> = emptyList()
    private var lastFeatureIdentityRecords: List<FeatureIdentityRecord> = emptyList()

    private fun resetAnalysisStateForNewSession() {
        analysisRunning = false
        analysisCompletedForSession = null
    }

    private fun runFullAnalysisPipelineOnce() {
        beginFinalScoreProvenance()
        reportHeuristicAnalysisPolicy()
        if (!validateSkinRoiInputs()) return
        reportCameraCapabilities()
        analysisStageFailures.clear()
        val currentSession = sessionId ?: return
        if (analysisRunning || analysisCompletedForSession == currentSession) {
            add("ANALYSIS PIPELINE: ALREADY HANDLED FOR CURRENT SESSION")
            return
        }
        analysisRunning = true
        try {
            runCaptureConditionConsistency()
            runFaceGeometryAnalysis()
            runSessionFeatureExtraction()
            runSkinRegionAnalysis()
            runSkinFeatureInterpretation()
            runLocalizedVariationAnalysis()
            runThreeViewConsistencyAnalysis()
            runLocalizedPatternMapping()
            runFaceConstrainedSkinAnalysis()
            runMultiScaleTileExtraction()
            runVisualFeatureCandidateAnalysis()
            runShineDetectionAnalysis()
            runBumpDetectionAnalysis()
            runSpecializedFeatureAnalysis()
            runPostAcneAssociationAnalysis()
            runFeatureCorrespondenceAndFusion()
            runPatternHotspotDetection()
            runCrossViewHotspotComparison()
            runCrossViewSpatialAgreement()
            runSessionPatternConfidence()
            runPatternEvidenceSummary()
            runPatternStabilityAnalysis()
            runPatternRepeatabilityAnalysis()
            runPatternSignalRanking()
            runPatternSignalClustering()
            runSkinDataQualityProfile()
            runMultiViewSkinDataFusion()
            runSkinFeatureQuantification()
            runToneColorFeatureAnalysis()
            runTextureCharacterization()
            runLocalizedFeatureAnalysis()
            runMultiViewSkinFeatureFusion()
            runSkinCharacteristicScoring()
            runRednessAnalysis()
            runPigmentationTanningAnalysis()
            runBlemishFeatureAnalysis()
            runTexturePoreFeatureAnalysis()
            runSurfaceConditionAnalysis()
            runFinalSkinAnalysisProfile()
            if (analysisStageFailures.isNotEmpty()) {
                add("ANALYSIS RESULT: FAILED_STAGES=${analysisStageFailures.joinToString(",")}")
                add("SESSION NOT READY FOR FINAL ANALYSIS")
                return
            }
            analysisCompletedForSession = currentSession
            add("SESSION READY FOR ANALYSIS")
        } finally {
            analysisRunning = false
        }
    }

    private fun runFaceGeometryAnalysis() {
        try {
            lastFaceGeometryByStep.clear()
            lastRegionSetByStep.clear()
            lastPatternCellsByStep.clear()
            lastRegionSkinReportsByStep.clear()
            lastTileSetsByStep.clear()
            for (step in SessionStep.values()) {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val geometry = FaceGeometryAnalyzer.analyze(image)
                val regionSet = AnatomicalRegionMapper.map(geometry)
                lastFaceGeometryByStep[step] = geometry
                lastRegionSetByStep[step] = regionSet

                val geometryName = when (step) {
                    SessionStep.FRONT -> "front_face_geometry.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_face_geometry.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_face_geometry.json"
                }
                val regionName = when (step) {
                    SessionStep.FRONT -> "front_anatomical_regions.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_anatomical_regions.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_anatomical_regions.json"
                }
                File(sessionRoot!!, geometryName).writeText(FaceGeometryAnalyzer.json(geometry))
                File(sessionRoot!!, regionName).writeText(AnatomicalRegionMapper.json(regionSet))

                if (!geometry.faceDetected) {
                    // Explicit no-face handling per this batch's requirement — this does not
                    // fail the pipeline stage: a poor-coverage side view is a legitimate,
                    // recordable outcome, not an exceptional error. Downstream (skin
                    // segmentation, pattern mapping) already runs independently of face
                    // geometry and is unaffected; only the face-constrained regional layer
                    // for this view will report zero regions.
                    add("${step.label} FACE GEOMETRY: NO_FACE_DETECTED")
                } else {
                    add("${step.label} FACE GEOMETRY: faces=1 regions=${regionSet.regions.size} skipped=${regionSet.skippedRegions.size} geometry_confidence=${"%.2f".format(geometry.geometryConfidence)}")
                }
            }
            add("FACE GEOMETRY ANALYSIS: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("FACE GEOMETRY", e)
        }
    }

    private fun runFaceConstrainedSkinAnalysis() {
        try {
            for (step in SessionStep.values()) {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val geometry = lastFaceGeometryByStep[step]
                    ?: throw IllegalStateException("Missing face geometry for ${step.label} — runFaceGeometryAnalysis must run first")
                val regionSet = lastRegionSetByStep[step] ?: RegionSet(emptyList(), emptyList(), emptyList())
                val grid = 6 // matches LocalizedPatternMapper.map()'s own default; must stay in sync with that call
                val cells = LocalizedPatternMapper.map(image, grid)
                val reports = FaceConstrainedSkinAnalyzer.analyze(
                    cells = cells,
                    grid = grid,
                    normalizedImageWidth = geometry.normalizedImageWidth,
                    normalizedImageHeight = geometry.normalizedImageHeight,
                    regionSet = regionSet
                )
                lastPatternCellsByStep[step] = cells
                lastRegionSkinReportsByStep[step] = reports
                val name = when (step) {
                    SessionStep.FRONT -> "front_face_constrained_skin.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_face_constrained_skin.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_face_constrained_skin.json"
                }
                File(sessionRoot!!, name).writeText(FaceConstrainedSkinAnalyzer.json(reports, regionSet.skippedRegions))
                add("${step.label} FACE-CONSTRAINED SKIN MAP: regions_reported=${reports.size}")
            }
            add("FACE-CONSTRAINED SKIN ANALYSIS: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("FACE-CONSTRAINED SKIN ANALYSIS", e)
        }
    }

    /**
     * Batch 4D-C: multi-scale high-resolution tile foundation. Runs immediately after
     * runFaceConstrainedSkinAnalysis() (needs its cached cells/region-skin-reports, and needs
     * lastRegionSetByStep/lastFaceGeometryByStep from runFaceGeometryAnalysis()). Produces one
     * MultiScaleTileSet per mapped region per view — see MultiScaleTileExtractor's own doc
     * comment for why this generates zero additional bitmap decodes. A view with no detected
     * face (empty regionSet) legitimately produces zero tile sets, same non-fatal handling
     * runFaceGeometryAnalysis() already uses for NO_FACE_DETECTED.
     */
    private fun runMultiScaleTileExtraction() {
        try {
            for (step in SessionStep.values()) {
                val geometry = lastFaceGeometryByStep[step]
                    ?: throw IllegalStateException("Missing face geometry for ${step.label} — runFaceGeometryAnalysis must run first")
                val regionSet = lastRegionSetByStep[step] ?: RegionSet(emptyList(), emptyList(), emptyList())
                val cells = lastPatternCellsByStep[step] ?: emptyList()
                val reports = lastRegionSkinReportsByStep[step] ?: emptyList()
                val grid = 6 // must stay in sync with the grid used by runFaceConstrainedSkinAnalysis()

                val tileSets = if (cells.isEmpty() || regionSet.regions.isEmpty()) {
                    emptyList()
                } else {
                    MultiScaleTileExtractor.extractAll(
                        view = step.label,
                        regionSet = regionSet,
                        regionSkinReports = reports,
                        geom = geometry,
                        cells = cells,
                        grid = grid
                    )
                }

                val tileName = when (step) {
                    SessionStep.FRONT -> "front_multi_scale_tiles.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_multi_scale_tiles.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_multi_scale_tiles.json"
                }
                val diagName = when (step) {
                    SessionStep.FRONT -> "front_multi_scale_tile_diagnostics.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_multi_scale_tile_diagnostics.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_multi_scale_tile_diagnostics.json"
                }
                File(sessionRoot!!, tileName).writeText(
                    if (tileSets.isEmpty())
                        """{"method":"${MultiScaleTileExtractor.VERSION}","view":"${step.label}","region_tile_sets":[]}"""
                    else MultiScaleTileExtractor.json(tileSets)
                )
                val diagnostics = TileDiagnostics.summarize(step.label, tileSets, geometry)
                File(sessionRoot!!, diagName).writeText(TileDiagnostics.json(diagnostics))

                lastTileSetsByStep[step] = tileSets

                val totalTiles = tileSets.sumOf { it.allTiles().size }
                add("${step.label} MULTI-SCALE TILES: regions=${tileSets.size} tiles=$totalTiles fine_tiled=${diagnostics.regionsFineTiled} skipped=${diagnostics.regionsSkippedFineTiling}")
            }
            add("MULTI-SCALE TILE EXTRACTION: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("MULTI-SCALE TILE EXTRACTION", e)
        }
    }

    /**
     * Batch 4D-D: high-resolution Visual Feature Candidate and Structure Analysis Engine.
     * Runs immediately after runMultiScaleTileExtraction() (needs its cached tile pyramid).
     * Decodes actual MICRO-tile pixels from the same `capture.jpg` FaceGeometryAnalyzer already
     * reads for original-coordinate scale (see FaceGeometryAnalyzer.analyze's originalCaptureFile
     * default) — no new evidence file is introduced. A view with zero tile sets (no face detected,
     * or every region gated out of fine tiling for low skin coverage) legitimately produces zero
     * candidates, the same non-fatal handling every earlier per-view stage already uses.
     */
    private fun runVisualFeatureCandidateAnalysis() {
        try {
            for (step in SessionStep.values()) {
                val tileSets = lastTileSetsByStep[step] ?: emptyList()
                val normalizedFile = latestNormalized(step)
                val originalFile = if (normalizedFile != null) File(normalizedFile.parentFile, "capture.jpg") else null

                val candidates = if (tileSets.isEmpty() || originalFile == null || !originalFile.exists()) {
                    emptyList()
                } else {
                    // Batch 4E-C, step_2: reuse this exact view's own already-cached PatternMapCell
                    // grid + FaceGeometryResult (both produced earlier this same session, by
                    // runFaceConstrainedSkinAnalysis()/runFaceGeometryAnalysis()) for candidate-own
                    // boundary-precision skin attribution — never a second classification pass.
                    // Absent for either (shouldn't happen once tileSets is non-empty, since tile
                    // extraction itself required the same two caches, but handled defensively) means
                    // candidates simply keep their pre-4E-C tile-wide skin support, exactly as before.
                    val cells = lastPatternCellsByStep[step]
                    val geometry = lastFaceGeometryByStep[step]
                    // Batch 4E-E, step_3: also thread this view's already-cached RegionSet
                    // (built earlier this session by runFaceGeometryAnalysis(), same source
                    // AnatomicalRegionMapper.map() produced it from) through, so candidate-own
                    // boundary refinement can check landmark-exclusion-polygon overlap in
                    // addition to the pixel-classifier grid it already checked. Absent -> null,
                    // exactly the pre-4E-E behavior (no landmark-exclusion refinement attempted).
                    val regionSet = lastRegionSetByStep[step]
                    val boundaryContext = if (cells != null && cells.isNotEmpty() && geometry != null)
                        VisualFeatureCandidateEngine.CandidateBoundaryContext(cells = cells, patternGrid = 6, geom = geometry, regionSet = regionSet)
                    else null
                    VisualFeatureCandidateEngine.analyzeView(originalFile, tileSets, boundaryContext)
                }
                lastCandidatesByStep[step] = candidates
                val candidatesByRegion = candidates.groupBy { it.region }
                val summaries = tileSets.map { ts ->
                    VisualFeatureCandidateEngine.aggregate(step.label, ts, candidatesByRegion[ts.region] ?: emptyList())
                }

                val candName = when (step) {
                    SessionStep.FRONT -> "front_visual_feature_candidates.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_visual_feature_candidates.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_visual_feature_candidates.json"
                }
                val diagName = when (step) {
                    SessionStep.FRONT -> "front_visual_feature_diagnostics.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_visual_feature_diagnostics.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_visual_feature_diagnostics.json"
                }
                File(sessionRoot!!, candName).writeText(VisualFeatureCandidateEngine.json(candidates, summaries))
                val diagnostics = VisualFeatureDiagnostics.summarize(step.label, candidates)
                File(sessionRoot!!, diagName).writeText(VisualFeatureDiagnostics.json(diagnostics))

                add("${step.label} VISUAL FEATURE CANDIDATES: total=${candidates.size} unclassified=${diagnostics.unclassifiedCount} regions_summarized=${summaries.size}")
            }
            add("VISUAL FEATURE CANDIDATE ANALYSIS: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("VISUAL FEATURE CANDIDATE ANALYSIS", e)
        }
    }

    /**
     * Batch 4D-F, step_1: dedicated shine/specular-highlight candidate detection. Runs immediately
     * after runVisualFeatureCandidateAnalysis() and reuses its exact same cached tile-set pyramid
     * (`lastTileSetsByStep`) and the same `capture.jpg` original-coordinate file — no new decode
     * path, per this batch's "reuse existing high-resolution tiles" rule. A view with zero tile
     * sets produces zero shine candidates, the same non-fatal handling every earlier per-view
     * stage already uses.
     */
    private fun runShineDetectionAnalysis() {
        try {
            val allSummaries = mutableListOf<RegionalShineSummary>()
            for (step in SessionStep.values()) {
                val tileSets = lastTileSetsByStep[step] ?: emptyList()
                val normalizedFile = latestNormalized(step)
                val originalFile = if (normalizedFile != null) File(normalizedFile.parentFile, "capture.jpg") else null

                val shineCandidates = if (tileSets.isEmpty() || originalFile == null || !originalFile.exists()) {
                    emptyList()
                } else {
                    // Batch 4E-D, step_3: reuse this exact view's own already-cached
                    // PatternMapCell grid + FaceGeometryResult (same caches
                    // runVisualFeatureCandidateAnalysis() already built the equivalent context
                    // from for structural candidates, Batch 4E-C step_2) for shine candidate-own
                    // boundary-precision skin attribution — never a second classification pass.
                    val cells = lastPatternCellsByStep[step]
                    val geometry = lastFaceGeometryByStep[step]
                    // Batch 4E-E, step_3: also thread this view's already-cached RegionSet
                    // (built earlier this session by runFaceGeometryAnalysis(), same source
                    // AnatomicalRegionMapper.map() produced it from) through, so candidate-own
                    // boundary refinement can check landmark-exclusion-polygon overlap in
                    // addition to the pixel-classifier grid it already checked. Absent -> null,
                    // exactly the pre-4E-E behavior (no landmark-exclusion refinement attempted).
                    val regionSet = lastRegionSetByStep[step]
                    val boundaryContext = if (cells != null && cells.isNotEmpty() && geometry != null)
                        VisualFeatureCandidateEngine.CandidateBoundaryContext(cells = cells, patternGrid = 6, geom = geometry, regionSet = regionSet)
                    else null
                    ShineDetectionEngine.analyzeView(originalFile, tileSets, boundaryContext)
                }
                lastShineCandidatesByStep[step] = shineCandidates

                val summaries = tileSets.map { ts ->
                    ShineDetectionEngine.regionalSummary(step.label, ts, shineCandidates.filter { it.region == ts.region })
                }
                allSummaries.addAll(summaries)

                val shineName = when (step) {
                    SessionStep.FRONT -> "front_shine_candidates.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_shine_candidates.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_shine_candidates.json"
                }
                File(sessionRoot!!, shineName).writeText(ShineDetectionEngine.json(shineCandidates, summaries))
                add("${step.label} SHINE CANDIDATES: total=${shineCandidates.size} regions_summarized=${summaries.size}")
            }
            val allShine = SessionStep.values().flatMap { lastShineCandidatesByStep[it] ?: emptyList() }
            // Batch 4E-B, step_1: cached so runFinalSkinAnalysisProfile() can pass real
            // usable-skin-area shine density evidence into DensityIntegratedScoring.
            lastShineRegionalSummaries = allSummaries
            add("SHINE DETECTION ANALYSIS: COMPLETE (total_candidates=${allShine.size})")
        } catch (e: Exception) {
            recordAnalysisFailure("SHINE DETECTION ANALYSIS", e)
        }
    }

    /**
     * Batch 4D-F2, step_1: dedicated bump/surface-structure candidate detection. Runs immediately
     * after runShineDetectionAnalysis() (needs its cached tile-set pyramid AND, per
     * [BumpSurfaceStructureEngine]'s own "highlights are not automatically interpreted as bumps"
     * requirement, would need to re-derive the shine mask anyway — it currently recomputes the
     * mask itself from the shared grid rather than consuming [lastShineCandidatesByStep], since
     * the mask (not the already-thresholded candidate list) is the finer-grained signal this
     * detector's per-cell overlap check needs). A view with zero tile sets produces zero bump
     * candidates, the same non-fatal handling every earlier per-view stage already uses.
     */
    private fun runBumpDetectionAnalysis() {
        try {
            for (step in SessionStep.values()) {
                val tileSets = lastTileSetsByStep[step] ?: emptyList()
                val normalizedFile = latestNormalized(step)
                val originalFile = if (normalizedFile != null) File(normalizedFile.parentFile, "capture.jpg") else null

                val bumpCandidates = if (tileSets.isEmpty() || originalFile == null || !originalFile.exists()) {
                    emptyList()
                } else {
                    // Batch 4E-D, step_3: same reuse pattern as runShineDetectionAnalysis()
                    // immediately above — see that call site's comment.
                    val cells = lastPatternCellsByStep[step]
                    val geometry = lastFaceGeometryByStep[step]
                    // Batch 4E-E, step_3: also thread this view's already-cached RegionSet
                    // (built earlier this session by runFaceGeometryAnalysis(), same source
                    // AnatomicalRegionMapper.map() produced it from) through, so candidate-own
                    // boundary refinement can check landmark-exclusion-polygon overlap in
                    // addition to the pixel-classifier grid it already checked. Absent -> null,
                    // exactly the pre-4E-E behavior (no landmark-exclusion refinement attempted).
                    val regionSet = lastRegionSetByStep[step]
                    val boundaryContext = if (cells != null && cells.isNotEmpty() && geometry != null)
                        VisualFeatureCandidateEngine.CandidateBoundaryContext(cells = cells, patternGrid = 6, geom = geometry, regionSet = regionSet)
                    else null
                    BumpSurfaceStructureEngine.analyzeView(originalFile, tileSets, boundaryContext)
                }
                lastBumpCandidatesByStep[step] = bumpCandidates

                val summaries = tileSets.map { ts ->
                    BumpSurfaceStructureEngine.regionalSummary(step.label, ts, bumpCandidates.filter { it.region == ts.region })
                }

                val bumpName = when (step) {
                    SessionStep.FRONT -> "front_bump_candidates.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_bump_candidates.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_bump_candidates.json"
                }
                File(sessionRoot!!, bumpName).writeText(BumpSurfaceStructureEngine.json(bumpCandidates, summaries))

                val bumpDiagName = when (step) {
                    SessionStep.FRONT -> "front_bump_diagnostics.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_bump_diagnostics.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_bump_diagnostics.json"
                }
                val bumpDiagnostics = VisualFeatureDiagnostics.summarizeBumps(step.label, bumpCandidates)
                File(sessionRoot!!, bumpDiagName).writeText(VisualFeatureDiagnostics.bumpDiagnosticsJson(bumpDiagnostics))

                add("${step.label} BUMP/SURFACE-STRUCTURE CANDIDATES: total=${bumpCandidates.size} regions_summarized=${summaries.size}")
            }
            val allBumps = SessionStep.values().flatMap { lastBumpCandidatesByStep[it] ?: emptyList() }
            add("BUMP/SURFACE-STRUCTURE DETECTION: COMPLETE (total_candidates=${allBumps.size})")
        } catch (e: Exception) {
            recordAnalysisFailure("BUMP/SURFACE-STRUCTURE DETECTION", e)
        }
    }

    /**
     * Batch 4D-G, step_2: builds the `sourceView label -> RegionSet` map every stage from here on
     * that needs true anatomical normalization shares — one place, so
     * [runPostAcneAssociationAnalysis] and [runFeatureCorrespondenceAndFusion] can't disagree
     * about which RegionSet belongs to which view.
     */
    private fun regionSetsByViewLabel(): Map<String, RegionSet> =
        SessionStep.values().mapNotNull { step -> lastRegionSetByStep[step]?.let { step.label to it } }.toMap()

    /**
     * Batch 4D-F2, step_3 (upgraded in Batch 4D-G, step_2 to true anatomical normalization when
     * available): real spatial association between post-acne-mark-family evidence and nearby
     * compatible blemish evidence. Runs immediately after runSpecializedFeatureAnalysis()
     * (needs its cached session-wide [lastSpecializedFeatureEvidence] list) — no candidate
     * detection or classification is re-run, per [PostAcneSpatialAssociationEngine]'s own
     * "operates on evidence already assembled" design.
     */
    private fun runPostAcneAssociationAnalysis() {
        try {
            val associations = PostAcneSpatialAssociationEngine.associate(lastSpecializedFeatureEvidence, regionSetsByViewLabel())
            lastPostAcneAssociations = associations
            File(sessionRoot!!, "session_post_acne_associations.json")
                .writeText(PostAcneSpatialAssociationEngine.json(associations))
            val assocDiagnostics = VisualFeatureDiagnostics.summarizeAssociations(associations)
            File(sessionRoot!!, "session_post_acne_association_diagnostics.json")
                .writeText(VisualFeatureDiagnostics.associationDiagnosticsJson(assocDiagnostics))
            add("POST-ACNE SPATIAL ASSOCIATION: COMPLETE (total_associations=${associations.size})")
        } catch (e: Exception) {
            recordAnalysisFailure("POST-ACNE SPATIAL ASSOCIATION", e)
        }
    }

    /**
     * Batch 4D-G, steps 1/3/4/5/9/10 (P0). Runs after runPostAcneAssociationAnalysis() (needs its
     * cached [lastSpecializedFeatureEvidence]) and reuses [lastRegionSetByStep] (step_2's true
     * normalization), [lastCaptureConditionConsistency] (step_4's "use existing three-view
     * consistency architecture"), and [lastTileSetsByStep] (region skin coverage for step_5's
     * density metric) — no candidate detection, classification, or geometry mapping is re-run.
     *
     * Also builds this session's OWN [FeatureIdentityRecord]s (step_6's metadata shape) from the
     * fused evidence and writes them out, so a future batch that adds persistence has real
     * records to persist immediately rather than needing to build the extraction step too. Actual
     * cross-session comparison ([LongitudinalFeatureContract.compareIdentities], step_7) is NOT
     * invoked here — there is no previous session's stored identity-record list to compare
     * against yet (see PROJECT_STATUS.md).
     */
    private fun runFeatureCorrespondenceAndFusion() {
        try {
            val evidence = lastSpecializedFeatureEvidence
            val regionSets = regionSetsByViewLabel()
            val sid = sessionId ?: "UNKNOWN_SESSION"

            val correspondences = FeatureCorrespondenceEngine.buildCorrespondences(
                evidence, regionSets, sid, lastCaptureConditionConsistency
            )
            lastFeatureCorrespondences = correspondences
            File(sessionRoot!!, "session_feature_correspondence.json")
                .writeText(FeatureCorrespondenceEngine.json(correspondences))
            add("FEATURE CORRESPONDENCE: COMPLETE (total=${correspondences.size})")

            val evidenceById = evidence.associateBy { it.candidateId }
            val fused = CrossViewFeatureFusionEngine.fuse(correspondences, evidenceById)
            lastFusedFeatureEvidence = fused

            val coverageByRegion = mutableMapOf<AnatomicalRegion, MutableList<Double>>()
            for (step in SessionStep.values()) {
                for (ts in lastTileSetsByStep[step] ?: emptyList()) {
                    coverageByRegion.getOrPut(ts.region) { mutableListOf() }.add(ts.regionSkinCoverage)
                }
            }
            val regionalMetrics = CrossViewFeatureFusionEngine.regionalMetrics(fused, evidence, coverageByRegion)
            lastRegionalFusedMetrics = regionalMetrics
            File(sessionRoot!!, "session_fused_features.json")
                .writeText(CrossViewFeatureFusionEngine.json(fused, regionalMetrics))
            add("CROSS-VIEW FEATURE FUSION: COMPLETE (fused=${fused.size})")

            // step_6: identity records for THIS session's own fused evidence (see doc comment above)
            val identityRecords = fused.flatMap { f ->
                f.perViewEvidence.map { pv -> FeatureIdentityRecord.extractIdentity(f, pv, sid, "CURRENT_SESSION_ONLY_NO_PRIOR_COMPARISON") }
            }
            lastFeatureIdentityRecords = identityRecords
            File(sessionRoot!!, "session_feature_identity_records.json")
                .writeText(LongitudinalFeatureContract.identitiesJson(identityRecords))

            // step_9: unified diagnostics
            val perViewDiag = SessionStep.values().map { step ->
                val stepEvidence = evidence.filter { it.sourceView == step.label }
                val stepBumps = lastBumpCandidatesByStep[step] ?: emptyList()
                val stepShineCount = (lastShineCandidatesByStep[step] ?: emptyList()).size
                UnifiedFeatureDiagnostics.perView(step.label, stepEvidence, stepBumps, stepShineCount)
            }
            val unified = UnifiedFeatureDiagnostics.session(
                perViewDiag, correspondences, fused, lastPostAcneAssociations.size, regionalMetrics, identityRecords.size
            )
            File(sessionRoot!!, "session_unified_feature_diagnostics.json")
                .writeText(UnifiedFeatureDiagnostics.sessionJson(unified))
            add("UNIFIED FEATURE DIAGNOSTICS: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("FEATURE CORRESPONDENCE AND FUSION", e)
        }
    }

    /**
     * Batch 4D-E: pore/follicle refinement, hair/stubble refinement, dedicated blemish and
     * dark-mark classification, and illumination-aware localized redness, assembled into the
     * unified [SpecializedFeatureEvidence] model and rolled up into per-region metrics. Runs
     * immediately after runVisualFeatureCandidateAnalysis() (needs its cached per-view candidate
     * list) and reuses runCaptureConditionConsistency()'s cached per-view lighting profiles for
     * step_5's illumination separation — no pixels are re-decoded and no candidate detection is
     * re-run; this stage only re-scores/re-groups evidence that already exists.
     *
     * NOTE: [SessionStep.label] ("FRONT FACE") and the capture-condition subsystem's own view
     * identifiers ("FRONT_FACE") differ only by a space-vs-underscore, a pre-existing
     * inconsistency between those two independently-built subsystems. [captureConditionKeyFor]
     * normalizes across it here rather than renaming either existing subsystem's identifiers,
     * which would risk breaking their own already-written output files/consumers.
     */
    private fun captureConditionKeyFor(step: SessionStep): String = when (step) {
        SessionStep.FRONT -> "FRONT_FACE"
        SessionStep.LEFT_CHEEK -> "LEFT_CHEEK"
        SessionStep.RIGHT_CHEEK -> "RIGHT_CHEEK"
    }

    private fun runSpecializedFeatureAnalysis() {
        try {
            val captureConditionsByView = SessionStep.values().associate { step ->
                captureConditionKeyFor(step) to lastCaptureConditionProfileByStep[step]
            }.filterValues { it != null }.mapValues { it.value!! }

            val allEvidence = mutableListOf<SpecializedFeatureEvidence>()
            val tileSetsByView = linkedMapOf<String, List<MultiScaleTileSet>>()
            // Batch 4E-B, step_5: candidateId -> VisualFeatureCandidate across every view, so
            // CandidateQualityGate (via regionalMetrics()) can look up each evidence item's
            // originating candidate for exclusion-overlap/candidate-confidence checks that
            // SpecializedFeatureEvidence alone does not carry. Built once here rather than inside
            // the per-step loop since candidate IDs are unique across the whole session.
            val allCandidatesById = SessionStep.values()
                .flatMap { lastCandidatesByStep[it] ?: emptyList() }
                .associateBy { it.candidateId }
            // Batch 4E-B, step_5: reuses the same capture-condition-consistency signal
            // CaptureQualityReliabilityGate already classifies for trend adaptation (Batch 3B) --
            // not a new capture-quality computation, the existing one applied to a new consumer.
            val captureQualityReliability = CaptureQualityReliabilityGate.classify(lastCaptureConditionConsistency)

            for (step in SessionStep.values()) {
                val candidates = lastCandidatesByStep[step] ?: emptyList()
                val tileSets = lastTileSetsByStep[step] ?: emptyList()
                tileSetsByView[step.label] = tileSets

                // Candidate views were stamped by MultiScaleTileExtractor with step.label
                // ("FRONT FACE"); re-key onto the capture-condition view identifier so
                // IlluminationAwareRednessEngine can actually find this view's lighting profile.
                val remapped = if (captureConditionsByView.containsKey(captureConditionKeyFor(step))) {
                    mapOf(step.label to captureConditionsByView.getValue(captureConditionKeyFor(step)))
                } else emptyMap()

                val shineForStep = lastShineCandidatesByStep[step] ?: emptyList()
                val evidence = if (candidates.isEmpty()) emptyList()
                    else SpecializedFeatureEvidenceAssembler.assemble(candidates, remapped, shineForStep)
                allEvidence.addAll(evidence)

                val evName = when (step) {
                    SessionStep.FRONT -> "front_specialized_feature_evidence.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_specialized_feature_evidence.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_specialized_feature_evidence.json"
                }
                val viewMetrics = SpecializedFeatureEvidenceAssembler.regionalMetrics(evidence, mapOf(step.label to tileSets), allCandidatesById, captureQualityReliability)
                File(sessionRoot!!, evName).writeText(SpecializedFeatureEvidenceAssembler.json(evidence, viewMetrics))
                add("${step.label} SPECIALIZED FEATURE EVIDENCE: total=${evidence.size} supported=${evidence.count { it.classificationState == FeatureClassificationState.SUPPORTED }}")

                // Batch 4E-E, step_7: candidate-level non-skin exclusion diagnostics -- reuses the
                // exact same CandidateQualityGate.evaluateAll this step already needed for
                // viewMetrics above (not a second gate implementation), just re-keyed by
                // candidateId so summarizeExclusion can report which/how-many candidates were
                // rejected/weighted specifically because of exclusion, alongside the
                // landmark-vs-pixel exclusion basis every surviving candidate carries.
                val exclusionDecisions = CandidateQualityGate.evaluateAll(evidence, allCandidatesById, captureQualityReliability)
                val exclusionDiag = VisualFeatureDiagnostics.summarizeExclusion(step.label, candidates, exclusionDecisions)
                val exclusionDiagName = when (step) {
                    SessionStep.FRONT -> "front_exclusion_diagnostics.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_exclusion_diagnostics.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_exclusion_diagnostics.json"
                }
                File(sessionRoot!!, exclusionDiagName).writeText(VisualFeatureDiagnostics.exclusionDiagnosticsJson(exclusionDiag))

                // Batch 4E-E continued, EXACT REMAINING WORK item #2: numeric hair/stubble and
                // shine contamination diagnostics -- reuses this step's own already-computed
                // `candidates`/`shineForStep`, no new detection or classification.
                val contaminationDiag = SpecializedFeatureEvidenceAssembler.contaminationDiagnostics(step.label, candidates, shineForStep)
                val contaminationDiagName = when (step) {
                    SessionStep.FRONT -> "front_contamination_diagnostics.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_contamination_diagnostics.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_contamination_diagnostics.json"
                }
                File(sessionRoot!!, contaminationDiagName).writeText(SpecializedFeatureEvidenceAssembler.contaminationDiagnosticsJson(contaminationDiag))
            }

            val allMetrics = SpecializedFeatureEvidenceAssembler.regionalMetrics(allEvidence, tileSetsByView, allCandidatesById, captureQualityReliability)
            File(sessionRoot!!, "session_specialized_feature_evidence.json")
                .writeText(SpecializedFeatureEvidenceAssembler.json(allEvidence, allMetrics))
            lastSpecializedFeatureEvidence = allEvidence
            // Batch 4E-B, step_1: cached so runFinalSkinAnalysisProfile() can pass real
            // usable-skin-area density evidence into DensityIntegratedScoring without
            // recomputing regionalMetrics() a second time for the same session.
            lastSpecializedRegionalMetrics = allMetrics

            // Batch 4E-A, step_1/step_11: true usable-skin-area per view and per region,
            // written as its own diagnostics file. Reuses the exact tileSetsByView already
            // built above for regionalMetrics — no extra tile computation.
            val usableAreaByView = tileSetsByView.mapValues { (view, tileSets) -> UsableSkinAreaCalculator.forView(view, tileSets) }
            val allRegionAreas = usableAreaByView.values.flatten()
            val viewTotals = usableAreaByView.values.map { UsableSkinAreaCalculator.totalForView(it) }
            val usableAreaJson = """{"method":"${UsableSkinAreaCalculator.VERSION}","regions":[${
                allRegionAreas.joinToString(",") { UsableSkinAreaCalculator.json(it) }
            }],"per_view_totals":[${viewTotals.joinToString(",") { UsableSkinAreaCalculator.json(it) }}]}"""
            File(sessionRoot!!, "session_usable_skin_area.json").writeText(usableAreaJson)

            add("SPECIALIZED FEATURE ANALYSIS: COMPLETE (total_evidence=${allEvidence.size})")
        } catch (e: Exception) {
            recordAnalysisFailure("SPECIALIZED FEATURE ANALYSIS", e)
        }
    }

    private fun runLocalizedVariationAnalysis() {
        try {
            for(step in SessionStep.values()) {
                val file=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val r=LocalizedVariationAnalyzer.analyze(file)
                val name=when(step){
                    SessionStep.FRONT -> "front_localized_variation.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_localized_variation.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_localized_variation.json"
                }
                File(sessionRoot!!,name).writeText(LocalizedVariationAnalyzer.json(r))
                add("${step.label} LOCALIZED VARIATION: SAVED")
            }
            add("LOCALIZED VARIATION ANALYSIS: COMPLETE")
        } catch(e:Exception){ recordAnalysisFailure("LOCALIZED VARIATION", e) }
    }

    private fun runThreeViewConsistencyAnalysis() {
        try {
            val f=SkinFeatureInterpreter.analyze(latestNormalized(SessionStep.FRONT) ?: throw IllegalStateException("Missing FRONT"))
            val l=SkinFeatureInterpreter.analyze(latestNormalized(SessionStep.LEFT_CHEEK) ?: throw IllegalStateException("Missing LEFT"))
            val r=SkinFeatureInterpreter.analyze(latestNormalized(SessionStep.RIGHT_CHEEK) ?: throw IllegalStateException("Missing RIGHT"))
            val result=ThreeViewConsistencyAnalyzer.analyze(f,l,r)
            File(sessionRoot!!,"three_view_consistency.json").writeText(ThreeViewConsistencyAnalyzer.json(result))
            add("THREE-VIEW CONSISTENCY: ${result.consistency}")
            add("THREE-VIEW CONSISTENCY ANALYSIS: COMPLETE")
        } catch(e:Exception){ recordAnalysisFailure("THREE-VIEW CONSISTENCY", e) }
    }

    private fun runLocalizedPatternMapping() {
        try {
            val steps = SessionStep.values()
            for (step in steps) {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val cells = LocalizedPatternMapper.map(image)
                val name = when (step) {
                    SessionStep.FRONT -> "front_pattern_map.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_pattern_map.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_pattern_map.json"
                }
                File(sessionRoot!!, name).writeText(LocalizedPatternMapper.json(cells))
                when (step) {
                    SessionStep.FRONT -> add("FRONT FACE PATTERN MAP: SAVED")
                    SessionStep.LEFT_CHEEK -> add("LEFT CHEEK PATTERN MAP: SAVED")
                    SessionStep.RIGHT_CHEEK -> add("RIGHT CHEEK PATTERN MAP: SAVED")
                }
            }
            add("LOCALIZED PATTERN MAPPING: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("LOCALIZED PATTERN MAPPING", e)
        }
    }

    private fun runPatternHotspotDetection() {
        try {
            for (step in SessionStep.values()) {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                val cells = LocalizedPatternMapper.map(image)
                val hotspots = PatternHotspotAnalyzer.analyze(cells)
                val name = when (step) {
                    SessionStep.FRONT -> "front_pattern_hotspots.json"
                    SessionStep.LEFT_CHEEK -> "left_cheek_pattern_hotspots.json"
                    SessionStep.RIGHT_CHEEK -> "right_cheek_pattern_hotspots.json"
                }
                File(sessionRoot!!, name).writeText(PatternHotspotAnalyzer.json(hotspots))
                when (step) {
                    SessionStep.FRONT -> add("FRONT FACE PATTERN HOTSPOTS: SAVED count=${hotspots.size}")
                    SessionStep.LEFT_CHEEK -> add("LEFT CHEEK PATTERN HOTSPOTS: SAVED count=${hotspots.size}")
                    SessionStep.RIGHT_CHEEK -> add("RIGHT CHEEK PATTERN HOTSPOTS: SAVED count=${hotspots.size}")
                }
            }
            add("PATTERN HOTSPOT DETECTION: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN HOTSPOT DETECTION", e)
        }
    }

    private fun runCrossViewHotspotComparison() {
        add("CROSS-VIEW HOTSPOT COMPARISON: STARTED")
        try {
            fun hotspotsFor(step: SessionStep): List<PatternHotspot> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return PatternHotspotAnalyzer.analyze(LocalizedPatternMapper.map(image))
            }
            val result = CrossViewHotspotComparator.compare(
                hotspotsFor(SessionStep.FRONT),
                hotspotsFor(SessionStep.LEFT_CHEEK),
                hotspotsFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "cross_view_hotspot_comparison.json")
                .writeText(CrossViewHotspotComparator.json(result))
            add("CROSS-VIEW HOTSPOT COMPARISON: COMPLETE")
            add("CROSS-VIEW HOTSPOT RESULT: ${result.result}")
        } catch (e: Exception) {
            recordAnalysisFailure("CROSS-VIEW HOTSPOT COMPARISON", e)
        }
    }

    private fun runCrossViewSpatialAgreement() {
        add("CROSS-VIEW SPATIAL AGREEMENT: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = CrossViewSpatialAgreementAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "cross_view_spatial_agreement.json")
                .writeText(CrossViewSpatialAgreementAnalyzer.json(result))
            add("CROSS-VIEW SPATIAL AGREEMENT: COMPLETE")
            add("SPATIAL AGREEMENT RESULT: ${result.result}")
        } catch (e: Exception) {
            recordAnalysisFailure("CROSS-VIEW SPATIAL AGREEMENT", e)
        }
    }

    private fun runSessionPatternConfidence() {
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val front = mapFor(SessionStep.FRONT)
            val left = mapFor(SessionStep.LEFT_CHEEK)
            val right = mapFor(SessionStep.RIGHT_CHEEK)
            val spatial = CrossViewSpatialAgreementAnalyzer.analyze(front, left, right)
            val result = SessionPatternConfidenceAnalyzer.analyze(front, left, right, spatial)
            File(sessionRoot!!, "session_pattern_confidence.json")
                .writeText(SessionPatternConfidenceAnalyzer.json(result))
            add("PATTERN CONFIDENCE: ${result.level}")
            add("CONFIDENCE SCORE: ${"%.1f".format(java.util.Locale.US, result.score)}/100")
            add("SESSION PATTERN CONFIDENCE: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("SESSION PATTERN CONFIDENCE", e)
        }
    }

    private fun runPatternEvidenceSummary() {
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val front = mapFor(SessionStep.FRONT)
            val left = mapFor(SessionStep.LEFT_CHEEK)
            val right = mapFor(SessionStep.RIGHT_CHEEK)
            val spatial = CrossViewSpatialAgreementAnalyzer.analyze(front, left, right)
            val confidence = SessionPatternConfidenceAnalyzer.analyze(front, left, right, spatial)
            val summary = PatternEvidenceSummaryAnalyzer.analyze(
                front, left, right, spatial, confidence
            )
            File(sessionRoot!!, "pattern_evidence_summary.json")
                .writeText(PatternEvidenceSummaryAnalyzer.json(summary))
            add("PATTERN EVIDENCE SUMMARY: COMPLETE")
            add("EVIDENCE STATUS: ${summary.status}")
            add("PATTERN SIGNAL: ${summary.signal}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN EVIDENCE SUMMARY", e)
        }
    }

    private fun runPatternStabilityAnalysis() {
        add("PATTERN STABILITY ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternStabilityAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_stability_analysis.json")
                .writeText(PatternStabilityAnalyzer.json(result))
            add("PATTERN STABILITY ANALYSIS: COMPLETE")
            add("PATTERN STABILITY RESULT: ${result.result}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN STABILITY ANALYSIS", e)
        }
    }

    private fun runPatternRepeatabilityAnalysis() {
        add("PATTERN REPEATABILITY ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternRepeatabilityAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_repeatability_analysis.json")
                .writeText(PatternRepeatabilityAnalyzer.json(result))
            add("PATTERN REPEATABILITY ANALYSIS: COMPLETE")
            add("PATTERN REPEATABILITY RESULT: ${result.result}")
            add("REPEATABILITY SCORE: ${"%.1f".format(java.util.Locale.US, result.score)}/100")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN REPEATABILITY ANALYSIS", e)
        }
    }

    private fun runPatternSignalRanking() {
        add("PATTERN SIGNAL RANKING: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternSignalRankingAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_signal_ranking.json")
                .writeText(PatternSignalRankingAnalyzer.json(result))
            add("PATTERN SIGNAL RANKING: COMPLETE")
            add("TOP SIGNALS: ${result.signals.size}")
            add("HIGHEST SUPPORT: ${result.topClassification}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN SIGNAL RANKING", e)
        }
    }

    private fun runPatternSignalClustering() {
        add("PATTERN SIGNAL CLUSTERING: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result = PatternSignalClusteringAnalyzer.analyze(
                mapFor(SessionStep.FRONT), mapFor(SessionStep.LEFT_CHEEK), mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!, "pattern_signal_clusters.json")
                .writeText(PatternSignalClusteringAnalyzer.json(result))
            add("PATTERN SIGNAL CLUSTERING: COMPLETE")
            add("PATTERN CLUSTERS: ${result.clusters.size}")
            add("STRONGEST CLUSTER: ${result.clusters.firstOrNull()?.classification ?: "NONE"}")
        } catch (e: Exception) {
            recordAnalysisFailure("PATTERN SIGNAL CLUSTERING", e)
        }
    }

    private fun runSkinDataQualityProfile() {
        add("SKIN DATA QUALITY PROFILE: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=SkinDataQualityProfileAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"skin_data_quality_profile.json")
                .writeText(SkinDataQualityProfileAnalyzer.json(result))
            add("SKIN DATA QUALITY PROFILE: COMPLETE")
            result.views.forEach { add("${it.view} DATA: ${if(it.usable) "USABLE" else "LIMITED"} (${String.format(java.util.Locale.US,"%.1f",it.score)})") }
            add("SKIN DATA STATUS: ${result.overallStatus}")
        } catch(e:Exception) {
            recordAnalysisFailure("SKIN DATA QUALITY PROFILE", e)
        }
    }

    private fun runMultiViewSkinDataFusion() {
        add("MULTI-VIEW SKIN DATA FUSION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image = latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=MultiViewSkinDataFusionAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"multi_view_skin_data.json")
                .writeText(MultiViewSkinDataFusionAnalyzer.json(result))
            add("MULTI-VIEW SKIN DATA FUSION: COMPLETE")
            add("USABLE SKIN VIEWS: ${result.usableViews}/3")
            add("CROSS-VIEW SUPPORT: ${result.crossViewSupport}")
            add("SKIN DATA FUSION STATUS: ${result.overallStatus}")
            // Pre-existing defect found during Batch 4A audit: this line previously called
            // an undefined function `reportAuthoritativeSkinDataState(usableViews)` with an
            // undefined variable `usableViews` (should have been `result.usableViews`) —
            // this would not compile. Fixed as a one-line correctness fix, not a redesign:
            // the two lines above already report the same usable-view count and status, so
            // removing the broken call loses no information.
        } catch(e:Exception) {
            recordAnalysisFailure("MULTI-VIEW SKIN DATA FUSION", e)
        }
    }

    private fun runSkinFeatureQuantification() {
        add("SKIN FEATURE QUANTIFICATION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=SkinFeatureQuantificationAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"skin_feature_quantification.json")
                .writeText(SkinFeatureQuantificationAnalyzer.json(result))
            add("SKIN FEATURE QUANTIFICATION: COMPLETE")
            add("TONE VARIATION: ${String.format(java.util.Locale.US,"%.1f",result.toneVariation)}")
            add("LOCALIZED REDNESS: ${String.format(java.util.Locale.US,"%.1f",result.localizedRedness)}")
            add("TEXTURE VARIATION: ${String.format(java.util.Locale.US,"%.1f",result.textureVariation)}")
            add("SKIN FEATURE CONFIDENCE: ${result.confidence}")
        } catch(e:Exception) {
            recordAnalysisFailure("SKIN FEATURE QUANTIFICATION", e)
        }
    }

    private fun runToneColorFeatureAnalysis() {
        add("TONE AND COLOR FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=ToneColorFeatureAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"tone_color_feature_analysis.json")
                .writeText(ToneColorFeatureAnalyzer.json(result))
            add("TONE AND COLOR FEATURE ANALYSIS: COMPLETE")
            add("TONE CHARACTERISTIC: ${result.toneUniformity}")
            add("REDNESS SIGNAL: ${result.rednessSignal}")
            add("DARK AREA SIGNAL: ${result.darkAreaSignal}")
            add("TONE/COLOR PROFILE: ${result.overallToneColorCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("TONE AND COLOR FEATURE ANALYSIS", e)
        }
    }

    private fun runTextureCharacterization() {
        add("TEXTURE CHARACTERIZATION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=TextureCharacterizationAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"texture_characterization.json")
                .writeText(TextureCharacterizationAnalyzer.json(result))
            add("TEXTURE CHARACTERIZATION: COMPLETE")
            add("OVERALL TEXTURE: ${result.overallTexture}")
            add("LOCALIZED TEXTURE: ${result.localizedTextureSignal}")
            add("TEXTURE DISTRIBUTION: ${result.textureDistribution}")
            add("TEXTURE PROFILE: ${result.dominantTextureCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("TEXTURE CHARACTERIZATION", e)
        }
    }

    private fun runLocalizedFeatureAnalysis() {
        add("LOCALIZED FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=LocalizedFeatureAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"localized_feature_analysis.json")
                .writeText(LocalizedFeatureAnalyzer.json(result))
            add("LOCALIZED FEATURE ANALYSIS: COMPLETE")
            add("LOCALIZED HOTSPOTS: ${result.totalHotspots}")
            add("FEATURE CONCENTRATION: ${result.concentration}")
            add("FEATURE DISTRIBUTION: ${result.distribution}")
            add("LOCALIZED FEATURE PROFILE: ${result.dominantLocalizedCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("LOCALIZED FEATURE ANALYSIS", e)
        }
    }

    private fun runMultiViewSkinFeatureFusion() {
        add("MULTI-VIEW SKIN FEATURE FUSION: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=MultiViewSkinFeatureFusionAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"multi_view_skin_feature_profile.json")
                .writeText(MultiViewSkinFeatureFusionAnalyzer.json(result))
            add("MULTI-VIEW SKIN FEATURE FUSION: COMPLETE")
            add("DOMINANT FEATURE DOMAIN: ${result.dominantFeatureDomain}")
            add("SECONDARY FEATURE DOMAIN: ${result.secondaryFeatureDomain}")
            add("OVERALL FEATURE SIGNAL: ${result.overallFeatureSignal}")
            add("SKIN FEATURE FUSION CONFIDENCE: ${result.confidence}")
        } catch(e:Exception) {
            recordAnalysisFailure("MULTI-VIEW SKIN FEATURE FUSION", e)
        }
    }

    private fun runSkinCharacteristicScoring() {
        add("SKIN CHARACTERISTIC SCORING: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            // Batch 4D-E, step_10: additive precision layer. Falls back to the exact same base
            // scoring this stage always ran when no high-resolution specialized evidence is
            // available yet (e.g. an older session, or a view where VisualFeatureCandidateEngine
            // produced zero candidates) — analyzeWithHighResolutionEvidence returns the base
            // result unchanged in that case.
            val result=SkinCharacteristicScoringAnalyzer.analyzeWithHighResolutionEvidence(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK),
                lastSpecializedFeatureEvidence
            )
            File(sessionRoot!!,"skin_characteristic_scores.json")
                .writeText(SkinCharacteristicScoringAnalyzer.json(result))
            add("SKIN CHARACTERISTIC SCORING: COMPLETE")
            result.scores.forEach {
                val hiRes = if (it.hasHighResolutionEvidence) " [high-res supported, n=${it.highResolutionSupportingCandidateCount}]" else ""
                add("${it.characteristic}: ${String.format(java.util.Locale.US,"%.1f",it.score)} (${it.level})$hiRes")
            }
            add("PRIMARY CHARACTERISTIC: ${result.primaryCharacteristic}")
            add("SECONDARY CHARACTERISTIC: ${result.secondaryCharacteristic}")
        } catch(e:Exception) {
            recordAnalysisFailure("SKIN CHARACTERISTIC SCORING", e)
        }
    }

    private fun runRednessAnalysis() {
        add("REDNESS ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=RednessAnalysisAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"redness_analysis.json")
                .writeText(RednessAnalysisAnalyzer.json(result))
            add("REDNESS ANALYSIS: COMPLETE")
            add("REDNESS SCORE: ${String.format(java.util.Locale.US,"%.1f",result.overallRednessScore)}")
            add("REDNESS LEVEL: ${result.rednessLevel}")
            add("REDNESS DISTRIBUTION: ${result.distribution}")
            add("REDNESS CROSS-VIEW: ${result.crossViewConsistency}")
        } catch(e:Exception) {
            recordAnalysisFailure("REDNESS ANALYSIS", e)
        }
    }

    private fun runPigmentationTanningAnalysis() {
        add("PIGMENTATION AND TANNING ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=PigmentationTanningAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"pigmentation_tanning_analysis.json")
                .writeText(PigmentationTanningAnalyzer.json(result))
            add("PIGMENTATION AND TANNING ANALYSIS: COMPLETE")
            add("PIGMENTATION SCORE: ${String.format(java.util.Locale.US,"%.1f",result.pigmentationVariationScore)}")
            add("PIGMENTATION LEVEL: ${result.pigmentationLevel}")
            add("BROAD TONE SHIFT: ${result.broadToneShiftSignal}")
            add("LOCALIZED DARK MARKS: ${result.localizedDarkMarkSignal}")
            add("PIGMENTATION CROSS-VIEW: ${result.crossViewConsistency}")
        } catch(e:Exception) {
            recordAnalysisFailure("PIGMENTATION AND TANNING ANALYSIS", e)
        }
    }

    private fun runBlemishFeatureAnalysis() {
        add("BLEMISH-LIKE FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=BlemishFeatureAnalyzer.analyze(
                mapFor(SessionStep.FRONT),
                mapFor(SessionStep.LEFT_CHEEK),
                mapFor(SessionStep.RIGHT_CHEEK)
            )
            File(sessionRoot!!,"blemish_like_feature_analysis.json")
                .writeText(BlemishFeatureAnalyzer.json(result))
            add("BLEMISH-LIKE FEATURE ANALYSIS: COMPLETE")
            add("BLEMISH-LIKE SCORE: ${String.format(java.util.Locale.US,"%.1f",result.blemishLikeScore)}")
            add("BLEMISH-LIKE LEVEL: ${result.blemishLikeLevel}")
            add("BLEMISH DISTRIBUTION: ${result.distribution}")
            add("BLEMISH CROSS-VIEW: ${result.crossViewSupport}")
        } catch(e:Exception) {
            recordAnalysisFailure("BLEMISH-LIKE FEATURE ANALYSIS", e)
        }
    }

    private fun runTexturePoreFeatureAnalysis() {
        add("TEXTURE AND PORE FEATURE ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val result=TexturePoreFeatureAnalyzer.analyze(mapFor(SessionStep.FRONT),mapFor(SessionStep.LEFT_CHEEK),mapFor(SessionStep.RIGHT_CHEEK))
            File(sessionRoot!!,"texture_pore_feature_analysis.json").writeText(TexturePoreFeatureAnalyzer.json(result))
            add("TEXTURE AND PORE FEATURE ANALYSIS: COMPLETE")
            add("TEXTURE IRREGULARITY SCORE: ${String.format(java.util.Locale.US,"%.1f",result.textureIrregularityScore)}")
            add("TEXTURE LEVEL: ${result.textureLevel}")
            add("PORE-LIKE SIGNAL SCORE: ${String.format(java.util.Locale.US,"%.1f",result.poreLikeSignalScore)}")
            add("PORE-LIKE LEVEL: ${result.poreLikeLevel}")
            add("TEXTURE CROSS-VIEW: ${result.crossViewConsistency}")
        } catch(e:Exception) {
            recordAnalysisFailure("TEXTURE AND PORE FEATURE ANALYSIS", e)
        }
    }

    private fun runSurfaceConditionAnalysis() {
        add("SURFACE OILINESS AND DRYNESS SIGNAL ANALYSIS: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step) ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val base=SurfaceConditionAnalyzer.analyze(
                mapFor(SessionStep.FRONT),mapFor(SessionStep.LEFT_CHEEK),mapFor(SessionStep.RIGHT_CHEEK)
            )
            // Batch 4D-F, step_1/step_10: additive high-resolution shine-candidate nudge. Falls
            // back to the exact same base result every existing session produced when no shine
            // candidates exist yet (older session, or a view where ShineDetectionEngine found none).
            val allShine = SessionStep.values().flatMap { lastShineCandidatesByStep[it] ?: emptyList() }
            val result=SurfaceConditionAnalyzer.applyHighResolutionShineEvidence(base, allShine)
            File(sessionRoot!!,"surface_condition_analysis.json").writeText(SurfaceConditionAnalyzer.json(result))
            add("SURFACE OILINESS AND DRYNESS SIGNAL ANALYSIS: COMPLETE")
            add("SURFACE SHINE SCORE: ${String.format(java.util.Locale.US,"%.1f",result.oilinessSignalScore)}")
            add("SURFACE SHINE LEVEL: ${result.oilinessLevel}" + if (result.hasHighResolutionShineEvidence) " [high-res supported, n=${result.highResolutionShineCandidateCount}]" else "")
            add("DRYNESS-RELATED SCORE: ${String.format(java.util.Locale.US,"%.1f",result.drynessRelatedSignalScore)}")
            add("DRYNESS-RELATED LEVEL: ${result.drynessRelatedLevel}")
            add("DOMINANT SURFACE SIGNAL: ${result.dominantSurfaceSignal}")
        } catch(e:Exception) {
            recordAnalysisFailure("SURFACE OILINESS AND DRYNESS SIGNAL ANALYSIS", e)
        }
    }

    private fun runFinalSkinAnalysisProfile() {
        add("FINAL SKIN ANALYSIS PROFILE: STARTED")
        try {
            fun mapFor(step: SessionStep): List<PatternMapCell> {
                val image=latestNormalized(step)
                    ?: throw IllegalStateException("Missing normalized image for ${step.label}")
                return LocalizedPatternMapper.map(image)
            }
            val frontCells = mapFor(SessionStep.FRONT)
            val leftCells = mapFor(SessionStep.LEFT_CHEEK)
            val rightCells = mapFor(SessionStep.RIGHT_CHEEK)
            // Batch 4E-B, step_1/step_7: real usable-skin-area density evidence (already computed
            // this session by runSpecializedFeatureAnalysis()/runShineDetectionAnalysis(), no
            // recomputation here) is now actually consumed by the final characteristic scores,
            // not just stored in diagnostics JSON — see DensityIntegratedScoring for exactly
            // which characteristics this affects and why some are intentionally excluded.
            val result=FinalSkinAnalysisProfileAnalyzer.analyzeWithHighResolutionDensityEvidence(
                frontCells, leftCells, rightCells,
                specializedRegionalMetrics = lastSpecializedRegionalMetrics,
                shineRegionalSummaries = lastShineRegionalSummaries
            )
            // BATCH 4A: usable-view count for this session, from the same existing
            // MultiViewSkinDataFusionAnalyzer already used elsewhere in the pipeline
            // (runMultiViewSkinDataFusion) — recomputed here from the same frontCells/
            // leftCells/rightCells rather than reading a shared field, since this call site
            // doesn't otherwise depend on that separate stage's execution order.
            val sessionUsableViewCount = MultiViewSkinDataFusionAnalyzer.analyze(frontCells, leftCells, rightCells).usableViews
            // UI-1B: build the read-only structured bundle (routine/progress/trend/skin-map)
            // BEFORE the persisting json() call below, so both read identical "previous
            // session" state and UiAnalysisAssembler never advances tolerance/session state
            // itself — see UiAnalysisAssembler.kt's file-level doc comment.
            val toleranceRepositoryForSession = PersistentToleranceStateStore(this)
            val analysisBundle = UiAnalysisAssembler.assemble(
                result,
                toleranceRepository = toleranceRepositoryForSession,
                captureConditionConsistency = lastCaptureConditionConsistency,
                usableViewCount = sessionUsableViewCount,
                currentFeatureIdentityRecords = lastFeatureIdentityRecords
            )
            val skinMap = SkinMapAssembler.assemble(frontCells, leftCells, rightCells)
            File(sessionRoot!!,"final_skin_analysis_profile.json")
                .writeText(FinalSkinAnalysisProfileAnalyzer.json(
                    result,
                    toleranceRepository = toleranceRepositoryForSession,
                    captureConditionConsistency = lastCaptureConditionConsistency,
                    usableViewCount = sessionUsableViewCount,
                    currentFeatureIdentityRecords = lastFeatureIdentityRecords
                ))
            // BATCH 4D-H — STEP 8: cross-session-enriched unified diagnostics. The earlier
            // "session_unified_feature_diagnostics.json" (written by
            // runFeatureCorrespondenceAndFusion(), before this stage) genuinely cannot include
            // cross-session comparison — the previous session's stored records are only fetched
            // once this stage's own comparability/JSON-save logic runs, which is why this batch
            // writes a SECOND file here rather than restructuring pipeline stage order (a much
            // larger, riskier change this batch's scope_control defers). Reuses
            // `analysisBundle.featureLongitudinalResult` computed immediately above by
            // UiAnalysisAssembler — no comparison is run twice.
            val crossSessionPerViewDiag = SessionStep.values().map { step ->
                val stepEvidence = lastSpecializedFeatureEvidence.filter { it.sourceView == step.label }
                val stepBumps = lastBumpCandidatesByStep[step] ?: emptyList()
                val stepShineCount = (lastShineCandidatesByStep[step] ?: emptyList()).size
                UnifiedFeatureDiagnostics.perView(step.label, stepEvidence, stepBumps, stepShineCount)
            }
            val crossSessionUnified = UnifiedFeatureDiagnostics.session(
                crossSessionPerViewDiag,
                lastFeatureCorrespondences,
                lastFusedFeatureEvidence,
                lastPostAcneAssociations.size,
                lastRegionalFusedMetrics,
                lastFeatureIdentityRecords.size,
                crossSessionResult = analysisBundle.featureLongitudinalResult
            )
            File(sessionRoot!!, "session_unified_feature_diagnostics_cross_session.json")
                .writeText(UnifiedFeatureDiagnostics.sessionJson(crossSessionUnified))
            add("FINAL SKIN ANALYSIS PROFILE: COMPLETE")
            reportCalibrationProvenance()
            reportCalibrationValidation()
            reportFinalScoreProvenance()
            result.findings.forEach {
                add("PRIORITY ${it.priority}: ${it.characteristic} — ${String.format(java.util.Locale.US,"%.1f",it.score)} (${it.level})")
            }
            add("PRIMARY SKIN FINDING: ${result.primaryFinding}")
            add("SECONDARY SKIN FINDING: ${result.secondaryFinding}")
            add("OVERALL SKIN PROFILE: ${result.overallProfile}")
            add("FINAL ANALYSIS CONFIDENCE: ${result.analysisConfidence}")
            runOnUiThread {
                viewModel.setFinalProfile(result)
                viewModel.setAnalysisBundle(analysisBundle)
                viewModel.setSkinMap(skinMap)
                viewModel.setSessionHistory(SkinSessionRepository.history())
                viewModel.setAnalysisReady(true)
            }
        } catch(e:Exception) {
            recordAnalysisFailure("FINAL SKIN ANALYSIS PROFILE", e)
            runOnUiThread { viewModel.setError("Analysis could not be completed for this session.") }
        }
    }

    private fun recordAnalysisFailure(stage: String, error: Exception) {
        analysisStageFailures.add(stage)
        add("$stage ERROR: ${error.javaClass.simpleName}: ${error.message}")
    }

    private fun reportHeuristicAnalysisPolicy() {
        add("ANALYSIS SCORE POLICY: ${AnalysisScorePolicy.VERSION}")
        add("ANALYSIS SCORE STATUS: HEURISTIC_AND_UNCALIBRATED")
        add("ANALYSIS CONFIDENCE STATUS: RULE_BASED_NOT_STATISTICALLY_CALIBRATED")
    }

    private fun validateSkinRoiInputs(): Boolean {
        val steps=listOf(SessionStep.FRONT, SessionStep.LEFT_CHEEK, SessionStep.RIGHT_CHEEK)
        var allValid=true
        steps.forEach { step ->
            try {
                val image=latestNormalized(step)
                if(image==null) {
                    add("SKIN ROI ${step.label}: MISSING_NORMALIZED_IMAGE")
                    allValid=false
                } else {
                    val bitmap = BitmapFactory.decodeFile(image.absolutePath)
                    if (bitmap == null) {
                        add("SKIN ROI ${step.label}: NORMALIZED_IMAGE_DECODE_FAILED")
                        allValid = false
                    } else {
                        try {
                            val result = SkinRoiValidator.validate(bitmap) { pixel ->
                                SkinRegionAnalyzer.isSkinColor(pixel)
                            }
                            add("SKIN ROI ${step.label}: ${result.reason}; overall=${String.format(java.util.Locale.US,"%.3f",result.overallSkinFraction)} central=${String.format(java.util.Locale.US,"%.3f",result.centralSkinFraction)}")
                            if(!result.valid) allValid=false
                        } finally {
                            bitmap.recycle()
                        }
                    }
                }
            } catch(e: Exception) {
                add("SKIN ROI ${step.label} ERROR: ${e.javaClass.simpleName}: ${e.message}")
                allValid=false
            }
        }
        if(!allValid) add("ANALYSIS BLOCKED: SKIN ROI VALIDITY FAILED")
        return allValid
    }

    private fun validateCaptureCapabilities(): Boolean {
        return try {
            val decision=CaptureCapabilityGate.resolveRear(this, requireRaw = true)
            add("CAPTURE CAPABILITY: ${decision.reason}; camera=${decision.cameraId}; jpeg=${decision.jpegAllowed}; rawRequired=${decision.rawRequired}; raw=${decision.rawAllowed}")
            if (!decision.jpegAllowed || (decision.rawRequired && !decision.rawAllowed)) {
                add("CAPTURE BLOCKED: REQUIRED CAMERA CAPABILITY UNAVAILABLE")
                false
            } else true
        } catch (e: Exception) {
            add("CAPTURE CAPABILITY ERROR: ${e.javaClass.simpleName}: ${e.message}")
            false
        }
    }

    private fun reportCameraCapabilities() {
        try {
            val cameras=CameraCapabilitySelector.inventory(this)
            add("CAMERA CAPABILITY INVENTORY: ${cameras.size} CAMERA(S)")
            cameras.forEach {
                add("CAMERA id=${it.cameraId} facing=${it.lensFacing} raw=${it.supportsRaw} compatible=${it.supportsBackwardCompatible} level=${it.hardwareLevel}")
            }
            val rear=CameraCapabilitySelector.select(this, android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK)
            add("CAMERA REAR SELECTION: ${rear.reason}; raw=${rear.rawCapable}; id=${rear.selected?.cameraId}")
        } catch (e: Exception) {
            recordAnalysisFailure("CAMERA CAPABILITY VALIDATION", e)
        }
    }

    private fun beginFinalScoreProvenance() {
        FinalScoreRegistry.clear()
        CalibrationRegistry.clear()
        add("FINAL SCORE PROVENANCE: STARTED")
    }
    private fun reportFinalScoreProvenance() {
        add("FINAL SCORE PROVENANCE: COMPLETE")
        FinalScoreRegistry.all().forEach { p ->
            val replaced = p.replacedScore?.let { " replaced=$it" } ?: ""
            add("FINAL SCORE SOURCE: ${p.characteristic} score=${p.finalScore} source=${p.sourceStage} sourceScore=${p.sourceScore}$replaced reason=${p.selectionReason}")
        }
    }
    private fun reportCalibrationProvenance() {
        val components = CalibrationRegistry.all()
        if (components.isEmpty()) return
        try {
            File(sessionRoot!!, "calibration_provenance.json")
                .writeText(SkinScoreCalibration.sessionJson(components))
        } catch (e: Exception) {
            recordAnalysisFailure("CALIBRATION PROVENANCE EXPORT", e)
        }
        add("CALIBRATION PROVENANCE: COMPLETE")
        components.forEach { c ->
            val breakdown = c.inputs.joinToString(", ") { "${it.name}=${String.format(java.util.Locale.US,"%.2f",it.contribution)}" }
            add("CALIBRATED: ${c.characteristic} score=${String.format(java.util.Locale.US,"%.1f",c.calibratedScore)} [$breakdown]")
        }
    }
    private fun reportCalibrationValidation() {
        val components = CalibrationRegistry.all()
        if (components.isEmpty()) return
        try {
            val results = FeatureCalibrationValidator.validateAll(components)
            File(sessionRoot!!, "calibration_validation.json")
                .writeText(FeatureCalibrationValidator.sessionJson(results))
            add("CALIBRATION VALIDATION: COMPLETE")
            results.forEach { r ->
                add("VALIDATED: ${r.characteristic} valid=${r.valid} score=${String.format(java.util.Locale.US,"%.1f",r.calibratedScore)}")
                r.findings.forEach { f ->
                    add("  ${f.severity} ${f.code}: ${f.message}")
                }
            }
        } catch (e: Exception) {
            recordAnalysisFailure("CALIBRATION VALIDATION", e)
        }
    }

    private fun add(message: String) {
        log.appendLine(message)
        runOnUiThread { viewModel.appendLog(message) }
    }

    private fun openCamera() {
        if (!validateCaptureCapabilities()) return
        if (!preview.isAvailable) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }
        closeCamera()
        log.clear()
        try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: run { add("STREAM MAP: MISSING"); return }
            val rawSize = map.getOutputSizes(ImageFormat.RAW_SENSOR)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: run { add("RAW_SENSOR: UNAVAILABLE"); return }
            val jpegSize = map.getOutputSizes(ImageFormat.JPEG)
                ?.maxByOrNull { it.width.toLong() * it.height }
                ?: run { add("JPEG: UNAVAILABLE"); return }
            val previewSize = map.getOutputSizes(SurfaceTexture::class.java)?.firstOrNull()
                ?: run { add("PREVIEW: UNAVAILABLE"); return }

            preview.surfaceTexture!!.setDefaultBufferSize(previewSize.width, previewSize.height)
            previewSurface = Surface(preview.surfaceTexture)
            rawReader = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 2)
            jpegReader = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 2)

            rawReader!!.setOnImageAvailableListener({ reader ->
                val image = reader.acquireNextImage() ?: return@setOnImageAvailableListener
                handleRawImage(image)
            }, cameraHandler)

            jpegReader!!.setOnImageAvailableListener({ reader ->
                reader.acquireNextImage()?.use { image -> saveJpeg(image) }
            }, cameraHandler)

            add("Camera $cameraId")
            add("DNG target: ${rawSize.width}x${rawSize.height}")
            add("JPEG target: ${jpegSize.width}x${jpegSize.height}")

            cameraManager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    createSession()
                }
                override fun onDisconnected(camera: CameraDevice) {
                    add("CAMERA: DISCONNECTED")
                    camera.close()
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    add("CAMERA ERROR: $error")
                    camera.close()
                }
            }, cameraHandler)
        } catch (e: Exception) {
            recordAnalysisFailure("OPEN", e)
        }
    }

    private fun createSession() {
        val d = device ?: return
        d.createCaptureSession(
            listOf(previewSurface!!, rawReader!!.surface, jpegReader!!.surface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    val request = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                        addTarget(previewSurface!!)
                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                        set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
                    }.build()
                    s.setRepeatingRequest(request, object : CameraCaptureSession.CaptureCallback() {
                        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                            val iso = result.get(CaptureResult.SENSOR_SENSITIVITY)
                            val exp = result.get(CaptureResult.SENSOR_EXPOSURE_TIME)
                            runOnUiThread {
                                viewModel.setCameraStatus("Camera $cameraId | ISO ${iso ?: "?"} | ${exp?.div(1_000_000.0) ?: "?"} ms")
                            }
                        }
                    }, cameraHandler)
                    add("PREVIEW SESSION: PASS")
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    add("PREVIEW SESSION: FAIL")
                }
            }, cameraHandler
        )
    }

    private fun captureEvidence() {
        val d = device ?: run { add("CAPTURE: CAMERA NOT READY"); return }
        val s = session ?: run { add("CAPTURE: SESSION NOT READY"); return }

        log.clear()
        captureId = "CAP_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        captureDir = File(sessionRoot ?: getExternalFilesDir(null), "${currentStep.folder}/$captureId").apply { mkdirs() }
        dngFile = File(captureDir, "capture.dng")
        jpegFile = File(captureDir, "capture.jpg")
        captureResult = null
        rawImage?.close()
        rawImage = null
        dngWritten.set(false)
        jpegWritten.set(false)
        captureCallbackReceived.set(false)
        finishing.set(false)

        add("THREE-PHOTO SESSION")
        add("SESSION ID: $sessionId")
        add("SESSION STEP: ${currentStep.label}")
        add("CAPTURE ID: $captureId")
        add("CAMERA: $cameraId")
        add("DNG: capture.dng")
        add("JPEG: capture.jpg")

        try {
            val request = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(rawReader!!.surface)
                addTarget(jpegReader!!.surface)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            }.build()

            s.capture(request, object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                    captureResult = result
                    captureCallbackReceived.set(true)
                    add("CAPTURE CALLBACK: PASS")
                    tryWriteDng()
                    scheduleFinish()
                }

                override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                    add("CAPTURE CALLBACK: FAIL reason=${failure.reason}")
                    scheduleFinish()
                }
            }, cameraHandler)
        } catch (e: Exception) {
            recordAnalysisFailure("CAPTURE", e)
        }
    }

    private fun handleRawImage(image: Image) {
        if (captureDir == null) {
            image.close()
            return
        }
        rawImage?.close()
        rawImage = image
        add("RAW IMAGE: ARRIVED ${image.width}x${image.height}")
        tryWriteDng()
    }

    private fun tryWriteDng() {
        val image = rawImage ?: return
        val result = captureResult ?: return
        val file = dngFile ?: return
        if (dngWritten.get()) return
        try {
            val chars = cameraManager.getCameraCharacteristics(cameraId)
            DngCreator(chars, result).use { creator ->
                FileOutputStream(file).use { stream ->
                    creator.writeImage(stream, image)
                }
            }
            dngWritten.set(file.exists() && file.length() > 0)
            add("DNG: ${if (dngWritten.get()) "SAVED" else "FAIL"} bytes=${file.length()}")
        } catch (e: Exception) {
            recordAnalysisFailure("DNG WRITE", e)
        } finally {
            image.close()
            rawImage = null
        }
    }

    private fun saveJpeg(image: Image) {
        val file = jpegFile ?: return
        try {
            FileOutputStream(file).use { stream ->
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                stream.write(bytes)
            }
            jpegWritten.set(file.exists() && file.length() > 0)
            add("JPEG: ${if (jpegWritten.get()) "SAVED" else "FAIL"} bytes=${file.length()}")
        } catch (e: Exception) {
            recordAnalysisFailure("JPEG WRITE", e)
        }
    }

    private fun scheduleFinish() {
        cameraHandler.removeCallbacksAndMessages("finish")
        cameraHandler.postDelayed({ finishEvidence() }, 2500)
    }

    private fun finishEvidence() {
        if (!finishing.compareAndSet(false, true)) return
        tryWriteDng()

        val dir = captureDir ?: return
        val result = captureResult
        val iso = result?.get(CaptureResult.SENSOR_SENSITIVITY)
        val exposure = result?.get(CaptureResult.SENSOR_EXPOSURE_TIME)
        val frame = result?.get(CaptureResult.SENSOR_FRAME_DURATION)
        val af = result?.get(CaptureResult.CONTROL_AF_STATE)
        val ae = result?.get(CaptureResult.CONTROL_AE_STATE)
        val awb = result?.get(CaptureResult.CONTROL_AWB_STATE)

        val quality = when {
            ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED -> "LOW_LIGHT_WARNING"
            iso != null && iso > 8000 -> "HIGH_NOISE_RISK"
            iso != null && iso > 3200 -> "ELEVATED_NOISE_RISK"
            else -> "NO_BASIC_WARNING"
        }

        val dng = dngFile
        val jpg = jpegFile
        val metadata = File(dir, "metadata.json")

        val dngHash = dng?.takeIf { it.exists() && it.length() > 0 }?.let { sha256(it) }
        val jpgHash = jpg?.takeIf { it.exists() && it.length() > 0 }?.let { sha256(it) }

        metadata.writeText("""
{
  "capture_id": "$captureId",
  "camera_id": "$cameraId",
  "timestamp_epoch_ms": ${System.currentTimeMillis()},
  "release_state": "RELEASE_UNVERIFIED",
  "artifacts": {
    "dng": {"name": "capture.dng", "saved": ${dngWritten.get()}, "bytes": ${dng?.length() ?: 0}, "sha256": ${json(dngHash)}},
    "jpeg": {"name": "capture.jpg", "saved": ${jpegWritten.get()}, "bytes": ${jpg?.length() ?: 0}, "sha256": ${json(jpgHash)}}
  },
  "capture": {
    "callback_pass": ${captureCallbackReceived.get()},
    "iso": ${iso ?: "null"},
    "exposure_ns": ${exposure ?: "null"},
    "frame_duration_ns": ${frame ?: "null"},
    "focus_state": ${af ?: "null"},
    "ae_state": ${ae ?: "null"},
    "awb_state": ${awb ?: "null"}
  },
  "quality_class": "$quality"
}
""".trimIndent())

        val metadataHash = sha256(metadata)

        val analysisPass = try {
            val sourceJpeg = jpg ?: throw IllegalStateException("JPEG missing")
            val report = ImageQualityAnalyzer.analyze(sourceJpeg)
            val normalized = File(dir, "analysis_normalized.jpg")
            val normalizedSaved = if (report.pass) {
                ImageQualityAnalyzer.writeNormalizedCopy(sourceJpeg, normalized)
            } else false

            add("ANALYSIS SIZE: ${report.width}x${report.height}")
            add("MEAN LUMA: ${"%.2f".format(java.util.Locale.US, report.meanLuma)}")
            add("CONTRAST: ${"%.2f".format(java.util.Locale.US, report.contrast)}")
            add("DARK CLIP %: ${"%.2f".format(java.util.Locale.US, report.darkClipPercent)}")
            add("BRIGHT CLIP %: ${"%.2f".format(java.util.Locale.US, report.brightClipPercent)}")
            add("DETAIL SCORE: ${"%.2f".format(java.util.Locale.US, report.detailScore)}")
            add("PROCESSING WARNINGS: ${if (report.warnings.isEmpty()) "NONE" else report.warnings.joinToString(",")}")
            add("NORMALIZED IMAGE: ${if (normalizedSaved) "SAVED" else "NOT_SAVED"}")
            add("ANALYSIS INPUT: ${if (report.pass && normalizedSaved) "PASS" else "FAIL"}")
            if (normalizedSaved) {
                try {
                    recordCaptureConditionForStep(normalized)
                } catch (e: Exception) {
                    recordAnalysisFailure("CAPTURE CONDITION (${currentStep.label})", e)
                }
            }
            report.pass && normalizedSaved
        } catch (e: Exception) {
            recordAnalysisFailure("ANALYSIS", e)
            false
        }

        val pass = dngWritten.get() && jpegWritten.get() && captureCallbackReceived.get()

        add("METADATA: SAVED")
        add("DNG SHA-256: ${dngHash ?: "UNAVAILABLE"}")
        add("JPEG SHA-256: ${jpgHash ?: "UNAVAILABLE"}")
        add("METADATA SHA-256: $metadataHash")
        add("QUALITY: $quality")
        add("EVIDENCE RESULT: ${if (pass) "PASS" else "FAIL"}")
        if (pass && analysisPass) {
            completedSteps.add(currentStep)
            runOnUiThread { viewModel.setCompletedSteps(completedSteps.map { it.toUiStep() }.toSet()) }
            add("SESSION STEP RESULT: PASS (${currentStep.label})")
            if (completedSteps.size == 3) {
                File(sessionRoot!!, "session_manifest.json").writeText("{\"session_id\":\"$sessionId\",\"required_steps\":[\"FRONT\",\"LEFT_CHEEK\",\"RIGHT_CHEEK\"],\"session_ready_for_analysis\":true}")
                add("SESSION COMPLETE: 3/3")
                runOnUiThread { viewModel.setAnalysisRunning(true) }
                runFullAnalysisPipelineOnce()
                runOnUiThread {
                    viewModel.setAnalysisRunning(false)
                    viewModel.setCameraStatus("SESSION READY FOR ANALYSIS")
                }
            } else {
                val next = SessionStep.values().first { it !in completedSteps }
                currentStep = next
                add("NEXT REQUIRED STEP: ${next.label}")
                runOnUiThread {
                    viewModel.setCurrentStep(next.toUiStep())
                    viewModel.setCameraStatus("NEXT: ${next.label}")
                }
            }
        } else {
            add("SESSION STEP RESULT: RETAKE REQUIRED (${currentStep.label})")
            runOnUiThread { viewModel.setCameraStatus("RETAKE: ${currentStep.label}") }
        }

        runOnUiThread {
            viewModel.setCaptureQuality(if (pass) "PASS | $quality" else "FAIL")
        }
    }

    /**
     * Per-capture insertion point for capture-condition normalization. Runs immediately after
     * the existing quality-gated `analysis_normalized.jpg` copy is written, on that derived
     * copy only — `capture.dng` / `capture.jpg` (the evidence artifacts hashed above) are never
     * touched. Writes a structural CaptureConditionProfile plus, when the measured exposure
     * differs meaningfully from a mid-gray target, a separate exposure-leveled derived file.
     * Neither existing analyzers nor `analysis_normalized.jpg` are affected by this step.
     */
    private fun recordCaptureConditionForStep(normalized: File) {
        val dir = captureDir ?: return
        val profile = CaptureConditionProfileAnalyzer.analyze(currentStep.label, normalized)
        File(dir, "capture_condition.json").writeText(CaptureConditionProfileAnalyzer.json(profile))
        add("CAPTURE CONDITION (${currentStep.label}): luma=${"%.1f".format(java.util.Locale.US, profile.meanLuma)} illuminant=${profile.illuminantEstimate} warnings=${if (profile.warnings.isEmpty()) "NONE" else profile.warnings.joinToString(",")}")
        val leveled = File(dir, "analysis_lighting_normalized.jpg")
        val leveledWritten = CaptureConditionNormalizer.writeExposureNormalizedCopy(normalized, leveled, profile)
        add("EXPOSURE-LEVELED COPY: ${if (leveledWritten) "SAVED (gain=${"%.2f".format(java.util.Locale.US, profile.suggestedExposureGain)})" else "NOT_NEEDED_OR_SKIPPED"}")
    }

    /**
     * Session-level stage, run first in the analysis pipeline (before feature extraction),
     * comparing capture conditions across all three required views. This is the appropriate
     * downstream boundary: every later stage that computes left/right or cross-view deltas
     * from `analysis_normalized.jpg` can be read alongside this file to know whether those
     * deltas might be confounded by inconsistent lighting rather than the skin itself. It does
     * not gate or block later stages by itself — it produces structured evidence for them.
     */
    private fun runCaptureConditionConsistency() {
        try {
            val f = CaptureConditionProfileAnalyzer.analyze("FRONT_FACE", latestNormalized(SessionStep.FRONT) ?: throw IllegalStateException("Missing FRONT"))
            val l = CaptureConditionProfileAnalyzer.analyze("LEFT_CHEEK", latestNormalized(SessionStep.LEFT_CHEEK) ?: throw IllegalStateException("Missing LEFT"))
            val r = CaptureConditionProfileAnalyzer.analyze("RIGHT_CHEEK", latestNormalized(SessionStep.RIGHT_CHEEK) ?: throw IllegalStateException("Missing RIGHT"))
            File(sessionRoot!!, "front_capture_condition.json").writeText(CaptureConditionProfileAnalyzer.json(f))
            File(sessionRoot!!, "left_cheek_capture_condition.json").writeText(CaptureConditionProfileAnalyzer.json(l))
            File(sessionRoot!!, "right_cheek_capture_condition.json").writeText(CaptureConditionProfileAnalyzer.json(r))
            lastCaptureConditionProfileByStep[SessionStep.FRONT] = f
            lastCaptureConditionProfileByStep[SessionStep.LEFT_CHEEK] = l
            lastCaptureConditionProfileByStep[SessionStep.RIGHT_CHEEK] = r
            val result = ThreeViewCaptureConditionAnalyzer.analyze(f, l, r)
            lastCaptureConditionConsistency = result.consistency
            File(sessionRoot!!, "capture_condition_session.json").writeText(ThreeViewCaptureConditionAnalyzer.json(result))
            add("CAPTURE CONDITION CONSISTENCY: ${result.consistency}")
            if (result.crossViewWarnings.isNotEmpty()) {
                add("CAPTURE CONDITION WARNINGS: ${result.crossViewWarnings.joinToString(",")}")
            }
            add("CAPTURE CONDITION ANALYSIS: COMPLETE")
        } catch (e: Exception) {
            recordAnalysisFailure("CAPTURE CONDITION CONSISTENCY", e)
        }
    }

    private fun json(value: String?): String = value?.let { "\"$it\"" } ?: "null"

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8192)
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun closeCamera() {
        try { rawImage?.close() } catch (_: Exception) {}
        rawImage = null
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { previewSurface?.release() } catch (_: Exception) {}
        try { rawReader?.close() } catch (_: Exception) {}
        try { jpegReader?.close() } catch (_: Exception) {}
        session = null; device = null; previewSurface = null; rawReader = null; jpegReader = null
    }

    override fun onDestroy() {
        closeCamera()
        cameraThread.quitSafely()
        super.onDestroy()
    }
}
