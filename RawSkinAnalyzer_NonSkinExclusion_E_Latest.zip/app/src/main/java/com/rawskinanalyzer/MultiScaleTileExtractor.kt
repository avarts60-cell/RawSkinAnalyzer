package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/**
 * MultiScaleTileExtractor
 *
 * Batch 4D-C, steps 3-7 and 9-12. Builds the overlapping MACRO/MESO/MICRO analysis-tile
 * pyramid this batch's handoff asks for, per anatomical region, per view.
 *
 * Deliberate design choice — why this does NOT decode any bitmap: every tile's
 * `skinCoverage`/`highConfidenceSkinCoverage`/`excludedCoverage` is derived entirely from the
 * SAME `PatternMapCell` grid `LocalizedPatternMapper.map()` already produced for that view (the
 * identical source `FaceConstrainedSkinAnalyzer` already reuses — see that file's own doc
 * comment for why re-deriving skin classification here would be a second, divergent
 * implementation the handoff explicitly warns against). A tile's overlap with each cell is
 * computed as a plain axis-aligned rectangle intersection (tiles, unlike region polygons, are
 * themselves rectangles, so this needs no point-in-polygon sampling), weighted by the fraction
 * of the tile's own area each cell contributes. This satisfies step_9's "avoid decoding the
 * entire 4080x3060 image repeatedly" about as completely as possible: tile *metadata* generation
 * for an entire session touches zero additional bitmap pixels beyond what
 * `LocalizedPatternMapper`/`FaceConstrainedSkinAnalyzer` already decoded for that view. Actual
 * high-resolution pixel decoding for a specific tile is a separate, lazy, on-demand operation
 * (`RegionOfInterestExtractor.decodeCrop`), left to whichever future consumer (step_11) actually
 * needs pixels rather than being done eagerly for every tile this stage enumerates.
 *
 * Coarse-to-fine performance strategy (step_9): MACRO is always produced for a mapped region
 * (one tile = the whole region crop). MESO/MICRO tiling is skipped (with an explicit
 * `skippedReason`, not silently) when the region's own `RegionSkinReport.skinCoverage` is below
 * [MIN_SKIN_COVERAGE_FOR_FINE_TILING] — there is no value in producing dozens of overlapping
 * fine tiles over a region `FaceConstrainedSkinAnalyzer` already found to be mostly
 * non-skin/excluded (e.g. a profile view's far cheek, or an under-eye band that turned out to be
 * mostly eyelid). This is the region-level gate from step_9's required
 * "Face-level scan -> Region-level scan -> Candidate tile selection" ordering, reusing the
 * region-level result that already exists rather than recomputing it.
 */

enum class AnalysisScale { MACRO, MESO, MICRO }

data class AnalysisTile(
    val tileId: String,
    val view: String,
    val region: AnatomicalRegion,
    val scale: AnalysisScale,
    // Original-capture-image coordinates (see FaceGeometryResult.originalScaleAvailable for
    // when these may be unavailable/normalized-only — see originalCoordinatesAvailable below).
    val sourceX: Int,
    val sourceY: Int,
    val width: Int,
    val height: Int,
    val originalImageWidth: Int?,
    val originalImageHeight: Int?,
    val originalCoordinatesAvailable: Boolean,
    val skinCoverage: Double,
    val highConfidenceSkinCoverage: Double,
    val excludedCoverage: Double,
    /** Carried through unmodified from the region's own AnatomicalRegionMapper confidence — never re-derived or upgraded here. */
    val geometryConfidence: Double
)

data class MultiScaleTileSet(
    val view: String,
    val region: AnatomicalRegion,
    val macroTiles: List<AnalysisTile>,
    val mesoTiles: List<AnalysisTile>,
    val microTiles: List<AnalysisTile>,
    val regionSkinCoverage: Double,
    val regionHighConfidenceSkinCoverage: Double,
    val regionExcludedCoverage: Double,
    /** Non-null only when MESO/MICRO tiling was skipped for this region — see class doc's coarse-to-fine gate. MACRO is still always present. */
    val fineTilingSkippedReason: String?
) {
    fun allTiles(): List<AnalysisTile> = macroTiles + mesoTiles + microTiles
}

object MultiScaleTileExtractor {
    const val VERSION = "multi_scale_tile_extractor_v1"

    /** Region-level usable-skin coverage (percent, 0-100) below which MESO/MICRO tiling is skipped for that region this session (MACRO is unaffected). */
    private const val MIN_SKIN_COVERAGE_FOR_FINE_TILING = 15.0

    /** MESO: a moderate subdivision capturing localized structures within the region, per step_3. */
    private const val MESO_DIVISIONS = 2
    private const val MESO_OVERLAP_FRACTION = 0.15

    /** MICRO: the finest subdivision, preserving fine skin detail per step_3. */
    private const val MICRO_DIVISIONS = 4
    private const val MICRO_OVERLAP_FRACTION = 0.25

    /** Batch 4E-C, step_2: widened from `private` to `internal` (no behavior change) so
     * [FaceConstrainedSkinAnalyzer]'s new candidate-boundary-precision function can reuse this
     * EXACT rectangle/cell-overlap weighting instead of a second, divergent implementation — the
     * same "widen visibility to share logic" pattern already established by
     * [VisualFeatureCandidateEngine.skinSupportFor]/`selectTiles` for [ShineDetectionEngine]. */
    internal fun tileStats(
        tileLeft: Float, tileTop: Float, tileRight: Float, tileBottom: Float,
        cells: List<PatternMapCell>, grid: Int, normW: Int, normH: Int
    ): Triple<Double, Double, Double> {
        val cellW = normW.toFloat() / grid
        val cellH = normH.toFloat() / grid
        val tileArea = max(1e-6f, (tileRight - tileLeft) * (tileBottom - tileTop))
        var wSkin = 0.0; var wHigh = 0.0; var wExcl = 0.0; var wSum = 0.0
        for (cell in cells) {
            val cLeft = cell.col * cellW; val cRight = cLeft + cellW
            val cTop = cell.row * cellH; val cBottom = cTop + cellH
            val ix0 = max(tileLeft, cLeft); val iy0 = max(tileTop, cTop)
            val ix1 = min(tileRight, cRight); val iy1 = min(tileBottom, cBottom)
            val iw = max(0f, ix1 - ix0); val ih = max(0f, iy1 - iy0)
            val overlapArea = iw * ih
            if (overlapArea <= 0f) continue
            val w = (overlapArea / tileArea).toDouble()
            wSum += w
            wSkin += w * cell.skinPercent
            wHigh += w * cell.highConfidenceSkinPercent
            wExcl += w * (cell.excludedShadowPercent + cell.excludedHighlightPercent + cell.excludedNonSkinPercent + cell.uncertainPercent)
        }
        return if (wSum > 0) Triple(wSkin / wSum, wHigh / wSum, min(100.0, wExcl / wSum)) else Triple(0.0, 0.0, 0.0)
    }

    /** Maps a normalized-image x/y to original-image coordinates using the SAME affine relationship (uniform aspect-preserving scale, no rotation) FaceGeometryAnalyzer/AnatomicalRegionMapper already establish — no second scale estimate. Batch 4E-C: widened from `private` to `internal` alongside its exact inverse, [toNormalized], below — see that function's doc for why both need to be shared rather than re-derived. */
    internal fun toOriginal(nx: Float, ny: Float, geom: FaceGeometryResult): Pair<Float, Float>? {
        if (!geom.originalScaleAvailable || geom.originalImageWidth == null || geom.originalImageHeight == null) return null
        val scaleX = geom.originalImageWidth.toFloat() / geom.normalizedImageWidth.toFloat()
        val scaleY = geom.originalImageHeight.toFloat() / geom.normalizedImageHeight.toFloat()
        return (nx * scaleX) to (ny * scaleY)
    }

    /**
     * Batch 4E-C, step_2 addition. The exact algebraic inverse of [toOriginal] above (same
     * `scaleX`/`scaleY`, division instead of multiplication) — not a second, independently
     * estimated scale relationship. Needed because [FaceConstrainedSkinAnalyzer]'s new
     * candidate-boundary-precision function receives a candidate's bounding box in
     * ORIGINAL-image coordinates (as every [VisualFeatureCandidate] already reports it — see
     * [VisualFeatureCandidateEngine.boundingBoxOriginal]) but [PatternMapCell]'s grid, and
     * [tileStats] above, are both defined in NORMALIZED-image coordinate space. Returns null
     * under the exact same unavailability condition as [toOriginal] (no original-scale
     * relationship for this view) — never fabricates a scale.
     */
    internal fun toNormalized(ox: Float, oy: Float, geom: FaceGeometryResult): Pair<Float, Float>? {
        if (!geom.originalScaleAvailable || geom.originalImageWidth == null || geom.originalImageHeight == null) return null
        val scaleX = geom.originalImageWidth.toFloat() / geom.normalizedImageWidth.toFloat()
        val scaleY = geom.originalImageHeight.toFloat() / geom.normalizedImageHeight.toFloat()
        if (scaleX <= 0f || scaleY <= 0f) return null
        return (ox / scaleX) to (oy / scaleY)
    }


    private fun buildTile(
        tileId: String, view: String, region: AnatomicalRegion, scale: AnalysisScale,
        nLeft: Float, nTop: Float, nRight: Float, nBottom: Float,
        geom: FaceGeometryResult, geometryConfidence: Double,
        cells: List<PatternMapCell>, grid: Int
    ): AnalysisTile {
        val (skin, high, excl) = tileStats(nLeft, nTop, nRight, nBottom, cells, grid, geom.normalizedImageWidth, geom.normalizedImageHeight)
        val oTL = toOriginal(nLeft, nTop, geom)
        val oBR = toOriginal(nRight, nBottom, geom)
        val available = oTL != null && oBR != null
        val sx: Int; val sy: Int; val w: Int; val h: Int
        if (available) {
            sx = max(0, oTL!!.first.toInt()); sy = max(0, oTL.second.toInt())
            val ex = min(geom.originalImageWidth ?: Int.MAX_VALUE, oBR!!.first.toInt())
            val ey = min(geom.originalImageHeight ?: Int.MAX_VALUE, oBR.second.toInt())
            w = max(0, ex - sx); h = max(0, ey - sy)
        } else {
            // No original-scale relationship for this view — report the tile honestly in
            // normalized-image pixel space rather than fabricating a scale, per this batch's
            // "do not invent physical dimensions" / "do not fabricate" rules.
            sx = max(0, nLeft.toInt()); sy = max(0, nTop.toInt())
            w = max(0, nRight.toInt() - sx); h = max(0, nBottom.toInt() - sy)
        }
        return AnalysisTile(
            tileId = tileId, view = view, region = region, scale = scale,
            sourceX = sx, sourceY = sy, width = w, height = h,
            originalImageWidth = if (available) geom.originalImageWidth else null,
            originalImageHeight = if (available) geom.originalImageHeight else null,
            originalCoordinatesAvailable = available,
            skinCoverage = skin, highConfidenceSkinCoverage = high, excludedCoverage = excl,
            geometryConfidence = geometryConfidence
        )
    }

    /** Generates an overlapping [divisions] x [divisions] grid of tiles covering [nLeft,nRight]x[nTop,nBottom], each enlarged by [overlapFraction] of one grid step so adjacent tiles share a border margin (reduces boundary artifacts, per this batch's design principles). */
    private fun buildOverlappingTiles(
        view: String, region: AnatomicalRegion, scale: AnalysisScale,
        nLeft: Float, nTop: Float, nRight: Float, nBottom: Float,
        divisions: Int, overlapFraction: Double,
        geom: FaceGeometryResult, geometryConfidence: Double,
        cells: List<PatternMapCell>, grid: Int
    ): List<AnalysisTile> {
        val stepX = (nRight - nLeft) / divisions
        val stepY = (nBottom - nTop) / divisions
        if (stepX <= 0f || stepY <= 0f) return emptyList()
        val padX = (stepX * overlapFraction).toFloat()
        val padY = (stepY * overlapFraction).toFloat()
        val tiles = mutableListOf<AnalysisTile>()
        var idx = 0
        for (row in 0 until divisions) for (col in 0 until divisions) {
            val tLeft = max(nLeft, nLeft + col * stepX - padX)
            val tRight = min(nRight, nLeft + (col + 1) * stepX + padX)
            val tTop = max(nTop, nTop + row * stepY - padY)
            val tBottom = min(nBottom, nTop + (row + 1) * stepY + padY)
            if (tRight <= tLeft || tBottom <= tTop) continue
            val tileId = "${view}_${region}_${scale}_${idx}"
            tiles += buildTile(tileId, view, region, scale, tLeft, tTop, tRight, tBottom, geom, geometryConfidence, cells, grid)
            idx++
        }
        return tiles
    }

    /**
     * @param cells the PatternMapCell grid LocalizedPatternMapper.map() already produced for
     *   this view — reused, never recomputed.
     * @param grid the grid size that call used (must match; the project's existing convention
     *   is 6, same default as LocalizedPatternMapper.map()/FaceConstrainedSkinAnalyzer).
     */
    fun extract(
        view: String,
        regionPolygon: RegionPolygon,
        regionSkinReport: RegionSkinReport?,
        geom: FaceGeometryResult,
        cells: List<PatternMapCell>,
        grid: Int
    ): MultiScaleTileSet {
        val region = regionPolygon.region
        val poly = regionPolygon.points
        val nLeft = poly.minOf { it.normalizedX }; val nRight = poly.maxOf { it.normalizedX }
        val nTop = poly.minOf { it.normalizedY }; val nBottom = poly.maxOf { it.normalizedY }

        val regionSkin = regionSkinReport?.skinCoverage ?: 0.0
        val regionHigh = regionSkinReport?.highConfidenceSkinCoverage ?: 0.0
        val regionExcl = regionSkinReport?.excludedCoverage ?: 0.0

        val macro = listOf(
            buildTile("${view}_${region}_MACRO_0", view, region, AnalysisScale.MACRO, nLeft, nTop, nRight, nBottom, geom, regionPolygon.confidence, cells, grid)
        )

        if (regionSkin < MIN_SKIN_COVERAGE_FOR_FINE_TILING) {
            return MultiScaleTileSet(
                view = view, region = region,
                macroTiles = macro, mesoTiles = emptyList(), microTiles = emptyList(),
                regionSkinCoverage = regionSkin, regionHighConfidenceSkinCoverage = regionHigh, regionExcludedCoverage = regionExcl,
                fineTilingSkippedReason = "LOW_USABLE_SKIN_COVERAGE_BELOW_${MIN_SKIN_COVERAGE_FOR_FINE_TILING}_PERCENT"
            )
        }

        val meso = buildOverlappingTiles(view, region, AnalysisScale.MESO, nLeft, nTop, nRight, nBottom, MESO_DIVISIONS, MESO_OVERLAP_FRACTION, geom, regionPolygon.confidence, cells, grid)
        val micro = buildOverlappingTiles(view, region, AnalysisScale.MICRO, nLeft, nTop, nRight, nBottom, MICRO_DIVISIONS, MICRO_OVERLAP_FRACTION, geom, regionPolygon.confidence, cells, grid)

        return MultiScaleTileSet(
            view = view, region = region,
            macroTiles = macro, mesoTiles = meso, microTiles = micro,
            regionSkinCoverage = regionSkin, regionHighConfidenceSkinCoverage = regionHigh, regionExcludedCoverage = regionExcl,
            fineTilingSkippedReason = null
        )
    }

    /** Runs [extract] for every mapped region in [regionSet], pairing each with its RegionSkinReport by region when present. */
    fun extractAll(
        view: String,
        regionSet: RegionSet,
        regionSkinReports: List<RegionSkinReport>,
        geom: FaceGeometryResult,
        cells: List<PatternMapCell>,
        grid: Int
    ): List<MultiScaleTileSet> {
        if (cells.isEmpty() || regionSet.regions.isEmpty()) return emptyList()
        val reportsByRegion = regionSkinReports.associateBy { it.region }
        return regionSet.regions.map { rp ->
            extract(view, rp, reportsByRegion[rp.region], geom, cells, grid)
        }
    }

    fun json(sets: List<MultiScaleTileSet>): String {
        fun tileJson(t: AnalysisTile) =
            """{"tile_id":"${t.tileId}","region":"${t.region}","scale":"${t.scale}","source_x":${t.sourceX},"source_y":${t.sourceY},"width":${t.width},"height":${t.height},"original_image_width":${t.originalImageWidth ?: "null"},"original_image_height":${t.originalImageHeight ?: "null"},"original_coordinates_available":${t.originalCoordinatesAvailable},"skin_coverage":${t.skinCoverage},"high_confidence_skin_coverage":${t.highConfidenceSkinCoverage},"excluded_coverage":${t.excludedCoverage},"geometry_confidence":${t.geometryConfidence}}"""
        val setsJson = sets.joinToString(",") { s ->
            """{"region":"${s.region}","region_skin_coverage":${s.regionSkinCoverage},"region_high_confidence_skin_coverage":${s.regionHighConfidenceSkinCoverage},"region_excluded_coverage":${s.regionExcludedCoverage},"fine_tiling_skipped_reason":${if (s.fineTilingSkippedReason == null) "null" else "\"${s.fineTilingSkippedReason}\""},"tile_count":${s.allTiles().size},"macro_tiles":[${s.macroTiles.joinToString(",") { tileJson(it) }}],"meso_tiles":[${s.mesoTiles.joinToString(",") { tileJson(it) }}],"micro_tiles":[${s.microTiles.joinToString(",") { tileJson(it) }}]}"""
        }
        val view = sets.firstOrNull()?.view ?: "UNKNOWN"
        return """{"method":"$VERSION","view":"$view","region_tile_sets":[$setsJson]}"""
    }
}

/**
 * Candidate feature-type vocabulary — originally defined (Batch 4D-C, step_7) as an unused
 * architecture hook. Batch 4D-D (`VisualFeatureCandidateEngine` and its detectors) is the first
 * code in this project that actually constructs values of this enum, via [FeatureCandidateRegion]
 * / [VisualFeatureCandidate] (see `VisualFeatureCandidateModels.kt`). `UNKNOWN_CANDIDATE` and
 * `BUMP_OR_STRUCTURE_CANDIDATE` were added in Batch 4D-D: the former is the explicit
 * "don't force classification" state step_1 requires; the latter is the P1 bump/surface-structure
 * hook from step_10, defined here alongside its siblings but — like `SHINE_REGION` below it,
 * also P1 — not yet populated by any detector this batch (kept honest in PROJECT_STATUS.md).
 */
enum class FeatureCandidateType {
    PORE_OR_FOLLICULAR_CANDIDATE, HAIR_OR_STUBBLE_CANDIDATE, DARK_MARK_CANDIDATE,
    BLEMISH_LIKE_CANDIDATE, TEXTURE_IRREGULARITY_CANDIDATE, REDNESS_REGION, SHINE_REGION,
    BUMP_OR_STRUCTURE_CANDIDATE, UNKNOWN_CANDIDATE
}

data class FeatureCandidateRegion(
    val type: FeatureCandidateType,
    /** Original-image coordinates of the candidate's location. */
    val sourceX: Int,
    val sourceY: Int,
    val width: Int,
    val height: Int,
    val scale: AnalysisScale,
    val confidence: Double,
    val supportingTileId: String,
    val supportingRegion: AnatomicalRegion
)

/**
 * Integration contract for the future feature-engine batch — step_11. Deliberately just two
 * data classes (not executable logic): [TileAnalysisInput] documents exactly what a future
 * classifier receives per tile (all of it already produced by this batch or earlier ones, never
 * duplicated), and [FeatureCandidateOutput] documents exactly what it is expected to hand back —
 * matching [FeatureCandidateRegion]'s shape plus the identifying fields step_11 asked for
 * explicitly (candidate feature/location/scale/confidence/supporting tile/supporting region).
 */
data class TileAnalysisInput(
    val tile: AnalysisTile,
    val view: String,
    val region: AnatomicalRegion,
    val skinConfidenceHigh: Double,
    val skinConfidenceTotal: Double,
    val excludedCoverage: Double,
    val scale: AnalysisScale
)

data class FeatureCandidateOutput(
    val candidateFeature: FeatureCandidateType,
    val sourceX: Int,
    val sourceY: Int,
    val width: Int,
    val height: Int,
    val candidateScale: AnalysisScale,
    val candidateConfidence: Double,
    val supportingTileId: String,
    val supportingRegion: AnatomicalRegion
)

/**
 * Diagnostic data — step_12. "Only report values that are actually computed": every field below
 * is read directly off already-built [MultiScaleTileSet]s, nothing is estimated or re-derived.
 */
object TileDiagnostics {
    data class SessionTileDiagnostics(
        val view: String,
        val regionsMapped: Int,
        val regionsFineTiled: Int,
        val regionsSkippedFineTiling: Int,
        val totalMacroTiles: Int,
        val totalMesoTiles: Int,
        val totalMicroTiles: Int,
        val normalizedImageWidth: Int,
        val normalizedImageHeight: Int,
        val originalImageWidth: Int?,
        val originalImageHeight: Int?
    )

    fun summarize(view: String, sets: List<MultiScaleTileSet>, geom: FaceGeometryResult): SessionTileDiagnostics =
        SessionTileDiagnostics(
            view = view,
            regionsMapped = sets.size,
            regionsFineTiled = sets.count { it.fineTilingSkippedReason == null },
            regionsSkippedFineTiling = sets.count { it.fineTilingSkippedReason != null },
            totalMacroTiles = sets.sumOf { it.macroTiles.size },
            totalMesoTiles = sets.sumOf { it.mesoTiles.size },
            totalMicroTiles = sets.sumOf { it.microTiles.size },
            normalizedImageWidth = geom.normalizedImageWidth,
            normalizedImageHeight = geom.normalizedImageHeight,
            originalImageWidth = geom.originalImageWidth,
            originalImageHeight = geom.originalImageHeight
        )

    fun json(d: SessionTileDiagnostics): String =
        """{"view":"${d.view}","regions_mapped":${d.regionsMapped},"regions_fine_tiled":${d.regionsFineTiled},"regions_skipped_fine_tiling":${d.regionsSkippedFineTiling},"total_macro_tiles":${d.totalMacroTiles},"total_meso_tiles":${d.totalMesoTiles},"total_micro_tiles":${d.totalMicroTiles},"normalized_image_width":${d.normalizedImageWidth},"normalized_image_height":${d.normalizedImageHeight},"original_image_width":${d.originalImageWidth ?: "null"},"original_image_height":${d.originalImageHeight ?: "null"}}"""
}
