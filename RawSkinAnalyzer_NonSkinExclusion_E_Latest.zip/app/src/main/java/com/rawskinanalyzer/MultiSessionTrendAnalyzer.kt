package com.rawskinanalyzer

enum class TrendDirection { SUSTAINED_IMPROVEMENT, STABLE_TREND, SUSTAINED_WORSENING, MIXED_TREND, INSUFFICIENT_TREND_DATA }

data class FeatureTrend(val feature: String, val values: List<Double>, val averageDelta: Double, val direction: TrendDirection)
data class MultiSessionTrendResult(val features: List<FeatureTrend>, val overallDirection: TrendDirection, val trendConfidence: String, val sessionsUsed: Int)

object MultiSessionTrendAnalyzer {
    private const val THRESHOLD = 3.0

    fun analyze(sessions: List<SkinProgressSnapshot>, maxSessions: Int = 5): MultiSessionTrendResult {
        val recent = sessions.takeLast(maxSessions)
        if (recent.size < 3) return MultiSessionTrendResult(emptyList(), TrendDirection.INSUFFICIENT_TREND_DATA, "INSUFFICIENT_SESSIONS", recent.size)

        fun trend(name: String, values: List<Double>): FeatureTrend {
            val deltas = values.zipWithNext { a, b -> b - a }
            val avg = deltas.average()
            val direction = when {
                deltas.all { it <= -THRESHOLD } -> TrendDirection.SUSTAINED_IMPROVEMENT
                deltas.all { it >= THRESHOLD } -> TrendDirection.SUSTAINED_WORSENING
                kotlin.math.abs(avg) < THRESHOLD -> TrendDirection.STABLE_TREND
                else -> TrendDirection.MIXED_TREND
            }
            return FeatureTrend(name, values, avg, direction)
        }

        val features = listOf(
            trend("PIGMENTATION_OR_TONE_VARIATION", recent.map { it.pigmentationScore }),
            trend("DARK_MARK_SIGNAL", recent.map { it.darkMarkScore }),
            trend("BLEMISH_LIKE_FEATURES", recent.map { it.blemishLikeScore }),
            trend("REDNESS", recent.map { it.rednessScore }),
            trend("PORE_LIKE_FEATURES", recent.map { it.poreLikeScore }),
            trend("SURFACE_SHINE_SIGNAL", recent.map { it.shineScore }),
            trend("TEXTURE_IRREGULARITY", recent.map { it.textureScore }),
            trend("DRYNESS_RELATED_SURFACE_SIGNAL", recent.map { it.drynessScore })
        )
        val improving = features.count { it.direction == TrendDirection.SUSTAINED_IMPROVEMENT }
        val worsening = features.count { it.direction == TrendDirection.SUSTAINED_WORSENING }
        val overall = when {
            improving > worsening -> TrendDirection.SUSTAINED_IMPROVEMENT
            worsening > improving -> TrendDirection.SUSTAINED_WORSENING
            features.all { it.direction == TrendDirection.STABLE_TREND } -> TrendDirection.STABLE_TREND
            else -> TrendDirection.MIXED_TREND
        }
        return MultiSessionTrendResult(
            features, overall,
            if (recent.size >= 5) "HIGH_TREND_CONFIDENCE" else "MODERATE_TREND_CONFIDENCE",
            recent.size
        )
    }
}