package com.rawskinanalyzer

data class FusedSkinViewData(
    val view:String,
    val usable:Boolean,
    val skinCoverage:Double,
    val meanLuma:Double,
    val redness:Double,
    val texture:Double,
    val darkAreaConcentration:Double,
    val localizedFeatureDensity:Double,
    val hotspotCount:Int
)

data class MultiViewSkinData(
    val overallStatus:String,
    val usableViews:Int,
    val fusedMeanLuma:Double,
    val fusedRedness:Double,
    val fusedTexture:Double,
    val fusedDarkAreaConcentration:Double,
    val fusedLocalizedFeatureDensity:Double,
    val crossViewSupport:String,
    val views:List<FusedSkinViewData>
)

object MultiViewSkinDataFusionAnalyzer {
    private fun averageOrZero(values:List<Double>)=if(values.isEmpty()) 0.0 else values.average()

    private fun viewData(name:String, cells:List<PatternMapCell>):FusedSkinViewData {
        val skin=cells.filter{it.skinPercent>=10.0}
        val coverage=if(cells.isEmpty()) 0.0 else skin.size*100.0/cells.size
        val luma=averageOrZero(skin.map{it.meanLuma})
        val redness=averageOrZero(skin.map{it.redness})
        val texture=averageOrZero(skin.map{it.texture})
        val dark=if(skin.isEmpty()) 0.0 else skin.count{it.meanLuma < luma-18.0}*100.0/skin.size
        val hotspots=PatternHotspotAnalyzer.analyze(cells)
        val density=if(skin.isEmpty()) 0.0 else hotspots.size*100.0/skin.size
        val usable=skin.size>=4 && coverage>=20.0
        return FusedSkinViewData(name,usable,coverage,luma,redness,texture,dark,density,hotspots.size)
    }

    fun analyze(front:List<PatternMapCell>, left:List<PatternMapCell>, right:List<PatternMapCell>):MultiViewSkinData {
        val views=listOf(
            viewData("FRONT_FACE",front),
            viewData("LEFT_CHEEK",left),
            viewData("RIGHT_CHEEK",right)
        )
        val usable=views.filter{it.usable}
        val spatial=CrossViewSpatialAgreementAnalyzer.analyze(front,left,right).result
        val support=when {
            usable.size<2 -> "INSUFFICIENT_CROSS_VIEW_SUPPORT"
            spatial=="HIGH_SPATIAL_AGREEMENT" -> "HIGH_CROSS_VIEW_SUPPORT"
            spatial=="MODERATE_SPATIAL_AGREEMENT" -> "MODERATE_CROSS_VIEW_SUPPORT"
            spatial=="LOW_SPATIAL_AGREEMENT" -> "LIMITED_CROSS_VIEW_SUPPORT"
            else -> "CROSS_VIEW_SUPPORT_UNCERTAIN"
        }
        val status=when {
            usable.size==3 -> "FULL_MULTI_VIEW_SKIN_DATA"
            usable.size>=2 -> "PARTIAL_MULTI_VIEW_SKIN_DATA"
            else -> "INSUFFICIENT_MULTI_VIEW_SKIN_DATA"
        }
        return MultiViewSkinData(
            status,usable.size,
            averageOrZero(usable.map{it.meanLuma}),
            averageOrZero(usable.map{it.redness}),
            averageOrZero(usable.map{it.texture}),
            averageOrZero(usable.map{it.darkAreaConcentration}),
            averageOrZero(usable.map{it.localizedFeatureDensity}),
            support,views
        )
    }

    fun json(x:MultiViewSkinData):String {
        val views=x.views.joinToString(","){v ->
            """{"view":"${v.view}","usable":${v.usable},"skin_coverage":${v.skinCoverage},"mean_luma":${v.meanLuma},"redness":${v.redness},"texture":${v.texture},"dark_area_concentration":${v.darkAreaConcentration},"localized_feature_density":${v.localizedFeatureDensity},"hotspot_count":${v.hotspotCount}}"""
        }
        return """{"overall_status":"${x.overallStatus}","usable_views":${x.usableViews},"fused_mean_luma":${x.fusedMeanLuma},"fused_redness":${x.fusedRedness},"fused_texture":${x.fusedTexture},"fused_dark_area_concentration":${x.fusedDarkAreaConcentration},"fused_localized_feature_density":${x.fusedLocalizedFeatureDensity},"cross_view_support":"${x.crossViewSupport}","views":[$views],"method":"multi_view_skin_data_fusion_v1","medical_diagnosis":false}"""
    }
}
