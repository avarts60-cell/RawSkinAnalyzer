package com.rawskinanalyzer

data class MultiViewSkinFeatureProfile(
    val toneColorCharacteristic:String,
    val textureCharacteristic:String,
    val localizedCharacteristic:String,
    val dominantFeatureDomain:String,
    val secondaryFeatureDomain:String,
    val toneColorStrength:Double,
    val textureStrength:Double,
    val localizedStrength:Double,
    val overallFeatureSignal:String,
    val confidence:String
)

object MultiViewSkinFeatureFusionAnalyzer {
    private fun domainName(domain:String)=when(domain) {
        "TONE_COLOR" -> "TONE_COLOR"
        "TEXTURE" -> "TEXTURE"
        else -> "LOCALIZED_FEATURES"
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):MultiViewSkinFeatureProfile {
        val tone=ToneColorFeatureAnalyzer.analyze(front,left,right)
        val texture=TextureCharacterizationAnalyzer.analyze(front,left,right)
        val localized=LocalizedFeatureAnalyzer.analyze(front,left,right)

        val toneStrength=((tone.toneVariationScore + tone.rednessScore + tone.darkAreaScore) / 3.0)
            .coerceIn(0.0,100.0)
        val textureStrength=texture.textureVariationScore.coerceIn(0.0,100.0)
        val localizedStrength=((localized.hotspotDensity * 0.6) +
            when(localized.concentration) {
                "HIGH_LOCALIZED_FEATURE_CONCENTRATION" -> 35.0
                "MODERATE_LOCALIZED_FEATURE_CONCENTRATION" -> 20.0
                "LOW_LOCALIZED_FEATURE_CONCENTRATION" -> 10.0
                else -> 3.0
            }).coerceIn(0.0,100.0)

        val ranked=listOf(
            "TONE_COLOR" to toneStrength,
            "TEXTURE" to textureStrength,
            "LOCALIZED_FEATURES" to localizedStrength
        ).sortedByDescending { it.second }

        val dominant=ranked[0].first
        val secondary=ranked[1].first
        val top=ranked[0].second
        val second=ranked[1].second

        val overall=when {
            top >= 25.0 && second >= 18.0 -> "MULTI_DOMAIN_SKIN_FEATURE_VARIATION"
            top >= 25.0 -> "DOMINANT_${domainName(dominant)}_FEATURE_VARIATION"
            top >= 12.0 -> "MODERATE_${domainName(dominant)}_FEATURE_VARIATION"
            else -> "LIMITED_STRONG_SKIN_FEATURE_SIGNAL"
        }

        val confidences=listOf(tone.confidence,texture.confidence,localized.confidence)
        val confidence=when {
            confidences.all { it=="HIGH" } -> "HIGH"
            confidences.count { it=="LOW" } >= 2 -> "LOW"
            else -> "MODERATE"
        }

        return MultiViewSkinFeatureProfile(
            tone.overallToneColorCharacteristic,
            texture.dominantTextureCharacteristic,
            localized.dominantLocalizedCharacteristic,
            dominant,secondary,toneStrength,textureStrength,localizedStrength,
            overall,confidence
        )
    }

    fun json(x:MultiViewSkinFeatureProfile)=
        """{"tone_color_characteristic":"${x.toneColorCharacteristic}","texture_characteristic":"${x.textureCharacteristic}","localized_characteristic":"${x.localizedCharacteristic}","dominant_feature_domain":"${x.dominantFeatureDomain}","secondary_feature_domain":"${x.secondaryFeatureDomain}","tone_color_strength":${x.toneColorStrength},"texture_strength":${x.textureStrength},"localized_strength":${x.localizedStrength},"overall_feature_signal":"${x.overallFeatureSignal}","confidence":"${x.confidence}","method":"multi_view_skin_feature_fusion_v1","medical_diagnosis":false}"""
}
