package com.rawskinanalyzer

data class PatternEvidenceSummary(
    val status:String,
    val signal:String,
    val confidenceLevel:String,
    val confidenceScore:Double,
    val spatialAgreement:String,
    val usableViews:Int,
    val totalHotspots:Int,
    val limitations:List<String>
)

object PatternEvidenceSummaryAnalyzer {
    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>,
        spatial:SpatialAgreementResult,
        confidence:SessionPatternConfidence
    ):PatternEvidenceSummary {
        val maps=listOf(front,left,right)
        val hotspots=maps.sumOf{ PatternHotspotAnalyzer.analyze(it).size }
        val limitations=mutableListOf<String>()
        if(confidence.viewsWithUsableData<3) limitations+="INCOMPLETE_USABLE_VIEW_COVERAGE"
        if(spatial.result=="LOW_SPATIAL_AGREEMENT") limitations+="LOW_SPATIAL_AGREEMENT"
        if(spatial.result=="INSUFFICIENT_SPATIAL_DATA") limitations+="INSUFFICIENT_SPATIAL_DATA"
        if(!confidence.hotspotEvidence) limitations+="NO_LOCALIZED_HOTSPOT_SIGNAL"
        val status=when {
            confidence.level=="INSUFFICIENT_EVIDENCE" -> "INSUFFICIENT_EVIDENCE"
            confidence.level=="HIGH" && spatial.result=="HIGH_SPATIAL_AGREEMENT" ->
                "STRONG_MULTI_VIEW_EVIDENCE"
            confidence.viewsWithUsableData>=2 -> "PARTIAL_MULTI_VIEW_EVIDENCE"
            else -> "VIEW_SPECIFIC_EVIDENCE"
        }
        val signal=when {
            hotspots==0 -> "NO_LOCALIZED_SIGNAL"
            status=="STRONG_MULTI_VIEW_EVIDENCE" -> "MULTI_VIEW_SUPPORTED"
            status=="PARTIAL_MULTI_VIEW_EVIDENCE" -> "PARTIALLY_SUPPORTED"
            else -> "LIMITED_SUPPORT"
        }
        return PatternEvidenceSummary(status,signal,confidence.level,confidence.score,
            spatial.result,confidence.viewsWithUsableData,hotspots,limitations)
    }

    fun json(x:PatternEvidenceSummary):String {
        val limits=x.limitations.joinToString(","){"\"$it\""}
        return """{"status":"${x.status}","pattern_signal":"${x.signal}","confidence_level":"${x.confidenceLevel}","confidence_score":${x.confidenceScore},"spatial_agreement":"${x.spatialAgreement}","usable_views":${x.usableViews},"total_hotspots":${x.totalHotspots},"limitations":[$limits],"method":"pattern_evidence_summary_v1","medical_diagnosis":false}"""
    }
}
