package com.rawskinanalyzer

data class PatternHotspot(
    val row:Int,val col:Int,val type:String,val strength:Double
)

object PatternHotspotAnalyzer {
    fun analyze(cells:List<PatternMapCell>):List<PatternHotspot>{
        val usable=cells.filter{it.skinPercent>=10.0}
        if(usable.isEmpty()) return emptyList()
        val meanRed=usable.map{it.redness}.average()
        val meanLuma=usable.map{it.meanLuma}.average()
        val meanTex=usable.map{it.texture}.average()
        val out=mutableListOf<PatternHotspot>()
        for(c in usable){
            if(c.redness>meanRed+8) out+=PatternHotspot(c.row,c.col,"ELEVATED_REDNESS",c.redness-meanRed)
            if(c.meanLuma<meanLuma-18) out+=PatternHotspot(c.row,c.col,"DARKER_AREA",meanLuma-c.meanLuma)
            if(c.texture>meanTex+12) out+=PatternHotspot(c.row,c.col,"ELEVATED_TEXTURE_VARIATION",c.texture-meanTex)
        }
        return out.sortedByDescending{it.strength}
    }
    fun json(x:List<PatternHotspot>)="""{"hotspots":[${x.joinToString(","){"""{"row":${it.row},"col":${it.col},"type":"${it.type}","strength":${it.strength}}"""}}],"method":"pattern_hotspot_detection_v1","medical_diagnosis":false}"""
}
