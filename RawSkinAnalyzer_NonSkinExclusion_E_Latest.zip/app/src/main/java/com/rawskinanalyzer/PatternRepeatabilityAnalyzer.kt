package com.rawskinanalyzer

data class PatternRepeatabilityResult(
    val result:String,
    val usableViews:Int,
    val repeatedTypes:Int,
    val totalTypes:Int,
    val repeatedCellRegions:Int,
    val score:Double
)

object PatternRepeatabilityAnalyzer {
    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):PatternRepeatabilityResult {
        val maps=listOf(front,left,right)
        val usableViews=maps.count { m -> m.count{it.skinPercent>=10.0}>=4 }
        if(usableViews<2) return PatternRepeatabilityResult(
            "INSUFFICIENT_REPEATABILITY_DATA",usableViews,0,0,0,0.0
        )

        val hotspotLists=maps.map { PatternHotspotAnalyzer.analyze(it) }
        val allTypes=hotspotLists.flatMap{it.map{h->h.type}}.toSet()
        val repeatedTypes=allTypes.count { type ->
            hotspotLists.count { list -> list.any{it.type==type} } >= 2
        }

        var repeatedCells=0
        val n=maps.minOf{it.size}
        for(i in 0 until n) {
            val signatures=maps.map { m ->
                val c=m[i]
                if(c.skinPercent<10.0) emptySet()
                else setOf(
                    if(c.redness > m.filter{it.skinPercent>=10.0}.map{it.redness}.average()+8) "R" else "",
                    if(c.meanLuma < m.filter{it.skinPercent>=10.0}.map{it.meanLuma}.average()-18) "D" else "",
                    if(c.texture > m.filter{it.skinPercent>=10.0}.map{it.texture}.average()+12) "T" else ""
                ).filter{it.isNotEmpty()}.toSet()
            }
            if(signatures.count{it.isNotEmpty()}>=2) {
                val shared=signatures.flatMap{it}.groupingBy{it}.eachCount().any{it.value>=2}
                if(shared) repeatedCells++
            }
        }

        val typeScore=if(allTypes.isEmpty()) 0.0 else repeatedTypes*50.0/allTypes.size
        val cellScore=(repeatedCells.toDouble()/maxOf(1,n)*50.0).coerceAtMost(50.0)
        val score=(typeScore+cellScore).coerceIn(0.0,100.0)
        val result=when {
            score>=70.0 -> "HIGH_REPEATABILITY"
            score>=35.0 -> "MODERATE_REPEATABILITY"
            else -> "LOW_REPEATABILITY"
        }
        return PatternRepeatabilityResult(result,usableViews,repeatedTypes,allTypes.size,repeatedCells,score)
    }

    fun json(x:PatternRepeatabilityResult)=
        """{"result":"${x.result}","usable_views":${x.usableViews},"repeated_types":${x.repeatedTypes},"total_types":${x.totalTypes},"repeated_cell_regions":${x.repeatedCellRegions},"score":${x.score},"method":"pattern_repeatability_analysis_v1","medical_diagnosis":false}"""
}
