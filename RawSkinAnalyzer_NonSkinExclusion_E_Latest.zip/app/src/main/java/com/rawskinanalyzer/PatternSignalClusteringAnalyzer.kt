package com.rawskinanalyzer

data class PatternSignalCluster(
    val type:String,
    val cellCount:Int,
    val averageStrength:Double,
    val supportingViews:Int,
    val classification:String
)

data class PatternSignalClusteringResult(val clusters:List<PatternSignalCluster>)

object PatternSignalClusteringAnalyzer {
    fun analyze(front:List<PatternMapCell>, left:List<PatternMapCell>, right:List<PatternMapCell>):PatternSignalClusteringResult {
        val maps=listOf(front,left,right)
        val byType=linkedMapOf<String, MutableList<PatternHotspot>>()
        val views=linkedMapOf<String, MutableSet<Int>>()
        maps.forEachIndexed { view, map ->
            PatternHotspotAnalyzer.analyze(map).forEach { h ->
                byType.getOrPut(h.type){mutableListOf()}.add(h)
                views.getOrPut(h.type){mutableSetOf()}.add(view)
            }
        }
        val clusters=byType.map { (type, hits) ->
            val avg=hits.map{it.strength}.average()
            val support=views[type]?.size ?: 0
            val cls=when {
                hits.size>=6 && support>=2 && avg>=50.0 -> "STRONG_LOCALIZED_CLUSTER"
                hits.size>=3 && (support>=2 || avg>=35.0) -> "MODERATE_LOCALIZED_CLUSTER"
                hits.size>=2 -> "WEAK_LOCALIZED_CLUSTER"
                else -> "ISOLATED_SIGNAL"
            }
            PatternSignalCluster(type,hits.size,avg,support,cls)
        }.sortedWith(compareByDescending<PatternSignalCluster>{it.supportingViews}
            .thenByDescending{it.cellCount}.thenByDescending{it.averageStrength})
        return PatternSignalClusteringResult(clusters)
    }

    fun json(x:PatternSignalClusteringResult):String {
        val items=x.clusters.joinToString(","){c ->
            """{"type":"${c.type}","cell_count":${c.cellCount},"average_strength":${c.averageStrength},"supporting_views":${c.supportingViews},"classification":"${c.classification}"}"""
        }
        return """{"cluster_count":${x.clusters.size},"clusters":[$items],"method":"pattern_signal_clustering_v1","medical_diagnosis":false}"""
    }
}
