package com.rawskinanalyzer

data class RankedPatternSignal(
    val type:String,
    val supportScore:Double,
    val classification:String,
    val supportingViews:Int
)

data class PatternSignalRankingResult(
    val signals:List<RankedPatternSignal>,
    val topClassification:String
)

object PatternSignalRankingAnalyzer {
    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):PatternSignalRankingResult {
        val maps=listOf(front,left,right)
        val hotspotLists=maps.map { PatternHotspotAnalyzer.analyze(it) }
        val types=hotspotLists.flatMap{list->list.map{it.type}}.toSet()
        val spatial=CrossViewSpatialAgreementAnalyzer.analyze(front,left,right)
        val confidence=SessionPatternConfidenceAnalyzer.analyze(front,left,right,spatial)
        val stability=PatternStabilityAnalyzer.analyze(front,left,right)
        val repeatability=PatternRepeatabilityAnalyzer.analyze(front,left,right)

        val ranked=types.map { type ->
            val supporting=hotspotLists.count { list -> list.any{it.type==type} }
            val strengthValues=hotspotLists.flatMap { list ->
                list.filter{it.type==type}.map{it.strength}
            }
            val strength=if(strengthValues.isEmpty()) 0.0 else strengthValues.average().coerceIn(0.0,100.0)
            val viewScore=supporting/3.0*25.0
            val spatialScore=when(spatial.result){
                "HIGH_SPATIAL_AGREEMENT"->15.0
                "MODERATE_SPATIAL_AGREEMENT"->10.0
                "LOW_SPATIAL_AGREEMENT"->3.0
                else->0.0
            }
            val confidenceScore=confidence.score*0.20
            val stabilityScore=when(stability.result){
                "HIGH_PATTERN_STABILITY"->10.0
                "MODERATE_PATTERN_STABILITY"->6.0
                else->2.0
            }
            val repeatScore=repeatability.score*0.10
            val strengthScore=strength*0.20
            val score=(viewScore+spatialScore+confidenceScore+
                    stabilityScore+repeatScore+strengthScore).coerceIn(0.0,100.0)
            val classification=when {
                supporting<2 && score<35.0 -> "UNSUPPORTED_SIGNAL"
                score>=70.0 -> "HIGH_PRIORITY_SIGNAL"
                score>=40.0 -> "MODERATE_PRIORITY_SIGNAL"
                else -> "LOW_PRIORITY_SIGNAL"
            }
            RankedPatternSignal(type,score,classification,supporting)
        }.sortedByDescending{it.supportScore}

        val top=ranked.firstOrNull()?.classification ?: "UNSUPPORTED_SIGNAL"
        return PatternSignalRankingResult(ranked,top)
    }

    fun json(x:PatternSignalRankingResult):String {
        val items=x.signals.joinToString(","){s ->
            """{"type":"${s.type}","support_score":${s.supportScore},"classification":"${s.classification}","supporting_views":${s.supportingViews}}"""
        }
        return """{"top_classification":"${x.topClassification}","signal_count":${x.signals.size},"signals":[$items],"method":"pattern_signal_ranking_v1","medical_diagnosis":false}"""
    }
}
