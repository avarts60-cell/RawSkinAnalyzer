package com.rawskinanalyzer

import kotlin.math.sqrt

data class PatternStabilityResult(
    val result:String,
    val lumaVariation:Double,
    val rednessVariation:Double,
    val textureVariation:Double,
    val hotspotStrengthVariation:Double,
    val evidenceViews:Int
)

object PatternStabilityAnalyzer {
    private fun sd(values:List<Double>):Double {
        if(values.size<2) return 0.0
        val mean=values.average()
        return sqrt(values.sumOf{(it-mean)*(it-mean)}/values.size)
    }
    private fun usable(m:List<PatternMapCell>)=m.filter{it.skinPercent>=10.0}

    fun analyze(front:List<PatternMapCell>, left:List<PatternMapCell>, right:List<PatternMapCell>):PatternStabilityResult {
        val maps=listOf(front,left,right).map(::usable)
        val valid=maps.filter{it.isNotEmpty()}
        if(valid.size<2) return PatternStabilityResult("INSUFFICIENT_STABILITY_DATA",0.0,0.0,0.0,0.0,valid.size)
        val luma=valid.map{it.map{c->c.meanLuma}.average()}
        val red=valid.map{it.map{c->c.redness}.average()}
        val texture=valid.map{it.map{c->c.texture}.average()}
        val hotspot=valid.map{m->PatternHotspotAnalyzer.analyze(m).map{it.strength}.average().let{if(it.isNaN())0.0 else it}}
        val lv=sd(luma); val rv=sd(red); val tv=sd(texture); val hv=sd(hotspot)
        val result=when {
            lv<=12.0 && rv<=6.0 && tv<=10.0 && hv<=8.0 -> "HIGH_PATTERN_STABILITY"
            lv<=25.0 && rv<=12.0 && tv<=20.0 && hv<=16.0 -> "MODERATE_PATTERN_STABILITY"
            else -> "LOW_PATTERN_STABILITY"
        }
        return PatternStabilityResult(result,lv,rv,tv,hv,valid.size)
    }

    fun json(x:PatternStabilityResult)=
        """{"result":"${x.result}","luma_variation":${x.lumaVariation},"redness_variation":${x.rednessVariation},"texture_variation":${x.textureVariation},"hotspot_strength_variation":${x.hotspotStrengthVariation},"evidence_views":${x.evidenceViews},"method":"pattern_stability_analysis_v1","medical_diagnosis":false}"""
}
