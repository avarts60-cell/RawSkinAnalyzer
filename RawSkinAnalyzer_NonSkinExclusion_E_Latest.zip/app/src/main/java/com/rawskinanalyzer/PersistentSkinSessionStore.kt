package com.rawskinanalyzer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class PersistentSkinSessionStore(context: Context) : SkinSessionStore {
    private val preferences =
        context.getSharedPreferences("raw_skin_analysis_sessions", Context.MODE_PRIVATE)

    @Volatile
    var lastIntegrityTelemetry: SkinSessionIntegrityTelemetry =
        SkinSessionIntegrityTelemetry(
            status = SkinSessionIntegrityStatus.SESSION_DATA_VALID,
            validSessionCount = 0,
            rejectedEntryCount = 0,
            recoveryApplied = false,
            safeHistoryAvailable = false
        )
        private set

    override fun save(session: StoredSkinSession) {
        val sessions = loadAll().toMutableList()
        sessions.removeAll { it.sessionId == session.sessionId }
        sessions += session
        preferences.edit().putString(KEY_SESSIONS, serialize(sessions)).apply()
    }

    // UI-1B fix: the interface method is `latestCompatible(currentAnalysisVersion)` (see
    // SkinSessionRepository.kt / InMemorySkinSessionStore), filtered by analysis version so a
    // progress/trend comparison never mixes snapshots from an incompatible scoring version.
    // This file previously declared `override fun latest()`, which does not override anything
    // on `SkinSessionStore` and would not compile against the real interface — a real defect,
    // not a redesign; fixed to match the interface exactly, same semantics as the in-memory
    // implementation.
    override fun latestCompatible(currentAnalysisVersion: String): StoredSkinSession? =
        loadAll()
            .filter { it.analysisVersion == currentAnalysisVersion }
            .maxByOrNull { it.createdAtEpochMillis }

    override fun history(): List<StoredSkinSession> =
        loadAll().sortedBy { it.createdAtEpochMillis }

    override fun replaceAll(sessions: List<StoredSkinSession>) {
        preferences.edit().putString(KEY_SESSIONS, serialize(sessions)).apply()
    }

    private fun loadAll(): List<StoredSkinSession> {
        val raw = preferences.getString(KEY_SESSIONS, null) ?: return emptyList()
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: run {
            preferences.edit().remove(KEY_SESSIONS).apply()
            val recovery = SkinSessionRecoveryResult(
                validSessions = emptyList(),
                rejectedEntries = 1,
                recoveryStatus = "SESSION_DATA_RECOVERY_FAILED"
            )
            lastIntegrityTelemetry =
                SkinSessionIntegrityTelemetryReporter.from(recovery)
            return emptyList()
        }

        var malformedEntries = 0
        val parsed = buildList {
            for (index in 0 until array.length()) {
                runCatching { parse(array.getJSONObject(index)) }
                    .onSuccess { add(it) }
                    .onFailure { malformedEntries++ }
            }
        }

        val recovery = SkinSessionIntegrityValidator.recover(parsed, malformedEntries)

        if (recovery.rejectedEntries > 0) {
            preferences.edit()
                .putString(KEY_SESSIONS, serialize(recovery.validSessions))
                .apply()
        }

        lastIntegrityTelemetry =
            SkinSessionIntegrityTelemetryReporter.from(recovery)

        return recovery.validSessions
    }

    private fun serialize(sessions: List<StoredSkinSession>): String {
        val array = JSONArray()
        sessions.forEach { session ->
            array.put(JSONObject().apply {
                put("session_id", session.sessionId)
                put("created_at_epoch_millis", session.createdAtEpochMillis)
                put("analysis_version", session.analysisVersion)
                put("snapshot", snapshotJson(session.snapshot))
                // BATCH 4A — STEP 1: round-trip the new capture-context field the same way
                // `confidence` was fixed to round-trip in UI-1B (see comment above on
                // `snapshotJson`) — write it when present, omit it when null so the stored
                // JSON for a session with unknown capture context is unchanged from before
                // this field existed.
                session.captureContext?.let { put("capture_context", captureContextJson(it)) }
                // BATCH 4D-H — STEP 1: round-trip stored feature-identity records the same
                // additive way — write the array (even if empty, since empty is a real,
                // meaningful state once `featureEvidenceCaptureQuality` says evidence WAS
                // recorded) and the capture-quality marker; omit both when quality is null so a
                // session saved before this batch (or by any older code path) still serializes
                // to byte-identical JSON for every field that existed before this batch.
                session.featureEvidenceCaptureQuality?.let { quality ->
                    put("feature_evidence_capture_quality", featureEvidenceCaptureQualityJson(quality))
                    put("feature_identity_records", featureIdentityRecordsJson(session.featureIdentityRecords))
                }
            })
        }
        return array.toString()
    }

    private fun captureContextJson(c: SessionCaptureContext): JSONObject = JSONObject().apply {
        put("capture_condition_consistency", c.captureConditionConsistency ?: JSONObject.NULL)
        put("capture_quality_reliability", c.captureQualityReliability.name)
        put("usable_view_count", c.usableViewCount ?: JSONObject.NULL)
    }

    private fun parseCaptureContext(json: JSONObject?): SessionCaptureContext? {
        if (json == null) return null
        return SessionCaptureContext(
            captureConditionConsistency = if (json.isNull("capture_condition_consistency")) null
                else json.optString("capture_condition_consistency", null),
            captureQualityReliability = runCatching {
                CaptureQualityReliability.valueOf(json.getString("capture_quality_reliability"))
            }.getOrDefault(CaptureQualityReliability.RELIABLE),
            usableViewCount = if (json.isNull("usable_view_count")) null
                else json.optInt("usable_view_count", -1).takeIf { it >= 0 }
        )
    }

    private fun parse(json: JSONObject): StoredSkinSession =
        StoredSkinSession(
            sessionId = json.getString("session_id"),
            createdAtEpochMillis = json.getLong("created_at_epoch_millis"),
            analysisVersion = json.getString("analysis_version"),
            snapshot = parseSnapshot(json.getJSONObject("snapshot")),
            // Absent in every session persisted before this batch — parsed as null
            // ("unknown"), never fabricated, exactly like every other optional-field
            // backward-compatibility case already established in this file (see the
            // `confidence` field's `optString` default below).
            captureContext = parseCaptureContext(json.optJSONObject("capture_context")),
            // BATCH 4D-H — STEP 1: absent in every session persisted before this batch —
            // `featureEvidenceCaptureQuality` parses to null (never fabricated as "available"),
            // and `featureIdentityRecords` defaults to empty in that case, exactly mirroring the
            // `captureContext` backward-compatibility pattern immediately above.
            featureEvidenceCaptureQuality = parseFeatureEvidenceCaptureQuality(
                json.optJSONObject("feature_evidence_capture_quality")
            ),
            featureIdentityRecords = parseFeatureIdentityRecords(
                json.optJSONArray("feature_identity_records")
            )
        )

    private fun featureEvidenceCaptureQualityJson(q: FeatureEvidenceCaptureQuality): JSONObject = JSONObject().apply {
        put("feature_evidence_available", q.featureEvidenceAvailable)
        put("capture_condition_consistency", q.captureConditionConsistency ?: JSONObject.NULL)
        put("usable_view_count", q.usableViewCount ?: JSONObject.NULL)
    }

    private fun parseFeatureEvidenceCaptureQuality(json: JSONObject?): FeatureEvidenceCaptureQuality? {
        if (json == null) return null
        return FeatureEvidenceCaptureQuality(
            featureEvidenceAvailable = json.optBoolean("feature_evidence_available", false),
            captureConditionConsistency = if (json.isNull("capture_condition_consistency")) null
                else json.optString("capture_condition_consistency", null),
            usableViewCount = if (json.isNull("usable_view_count")) null
                else json.optInt("usable_view_count", -1).takeIf { it >= 0 }
        )
    }

    private fun featureIdentityRecordsJson(records: List<FeatureIdentityRecord>): JSONArray {
        val array = JSONArray()
        records.forEach { r ->
            array.put(JSONObject().apply {
                put("feature_type", r.featureType.name)
                put("anatomical_region", r.anatomicalRegion.name)
                put("normalized_location", JSONObject().apply {
                    put("nx", r.normalizedLocation.nx)
                    put("ny", r.normalizedLocation.ny)
                    put("method", r.normalizedLocation.method)
                    put("out_of_bounds", r.normalizedLocation.outOfBounds)
                })
                put("apparent_size", r.apparentSize)
                put("feature_confidence", r.featureConfidence)
                put("source_view", r.sourceView)
                put("session_id", r.sessionId)
                put("capture_quality", r.captureQuality ?: JSONObject.NULL)
                put("comparability_state", r.comparabilityState)
            })
        }
        return array
    }

    private fun parseFeatureIdentityRecords(array: JSONArray?): List<FeatureIdentityRecord> {
        if (array == null) return emptyList()
        val out = mutableListOf<FeatureIdentityRecord>()
        for (index in 0 until array.length()) {
            runCatching {
                val o = array.getJSONObject(index)
                val loc = o.getJSONObject("normalized_location")
                FeatureIdentityRecord(
                    featureType = SpecializedFeatureType.valueOf(o.getString("feature_type")),
                    anatomicalRegion = AnatomicalRegion.valueOf(o.getString("anatomical_region")),
                    normalizedLocation = NormalizedPosition(
                        nx = loc.getDouble("nx"),
                        ny = loc.getDouble("ny"),
                        method = loc.getString("method"),
                        outOfBounds = loc.optBoolean("out_of_bounds", false)
                    ),
                    apparentSize = o.getDouble("apparent_size"),
                    featureConfidence = o.getDouble("feature_confidence"),
                    sourceView = o.getString("source_view"),
                    sessionId = o.getString("session_id"),
                    captureQuality = if (o.isNull("capture_quality")) null else o.optString("capture_quality", null),
                    comparabilityState = o.getString("comparability_state")
                )
            }.onSuccess { out.add(it) }
            // A malformed individual feature-identity record is skipped, not fatal to the whole
            // session — this mirrors the outer `loadAll()`'s own per-entry `runCatching` policy;
            // one corrupt feature record must never make an entire session unreadable.
        }
        return out
    }

    private fun snapshotJson(s: SkinProgressSnapshot): JSONObject = JSONObject().apply {
        put("pigmentation", s.pigmentationScore)
        put("dark_mark", s.darkMarkScore)
        put("blemish", s.blemishLikeScore)
        put("redness", s.rednessScore)
        put("pore", s.poreLikeScore)
        put("shine", s.shineScore)
        put("texture", s.textureScore)
        put("dryness", s.drynessScore)
        // UI-1B fix: SkinProgressSnapshot.confidence has no default value, so omitting it here
        // meant parseSnapshot below could never legally reconstruct a snapshot from storage —
        // a real defect (this field was added to the data class in an earlier session but this
        // store was not updated to match), fixed by round-tripping it like every other field.
        put("confidence", s.confidence)
    }

    private fun parseSnapshot(j: JSONObject): SkinProgressSnapshot =
        SkinProgressSnapshot(
            pigmentationScore = j.getDouble("pigmentation"),
            darkMarkScore = j.getDouble("dark_mark"),
            blemishLikeScore = j.getDouble("blemish"),
            rednessScore = j.getDouble("redness"),
            poreLikeScore = j.getDouble("pore"),
            shineScore = j.getDouble("shine"),
            textureScore = j.getDouble("texture"),
            drynessScore = j.getDouble("dryness"),
            confidence = j.optString("confidence", "MODERATE")
        )

    private companion object { const val KEY_SESSIONS = "sessions" }
}
