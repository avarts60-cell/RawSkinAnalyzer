package com.rawskinanalyzer

import android.content.Context
import org.json.JSONObject

/**
 * Real persisted `ToleranceStateRepository`. Mirrors `PersistentSkinSessionStore`'s
 * SharedPreferences + JSON pattern rather than introducing a new persistence mechanism
 * (no Room DB, no cloud service — same constraint this project has followed since Batch 1).
 * A malformed/missing entry for a given ingredient falls back to a fresh UNKNOWN record rather
 * than throwing, consistent with this project's existing recovery-over-crash convention in
 * `PersistentSkinSessionStore`.
 */
class PersistentToleranceStateStore(context: Context) : ToleranceStateRepository {
    private val preferences =
        context.getSharedPreferences("raw_skin_analysis_tolerance_state", Context.MODE_PRIVATE)

    override fun get(ingredientName: String): IngredientToleranceRecord {
        val raw = preferences.getString(key(ingredientName), null)
            ?: return IngredientToleranceRecord(
                ingredientName = ingredientName,
                state = ToleranceState.UNKNOWN,
                sessionsAtCurrentState = 0,
                reason = "No prior tolerance record; defaulting to UNKNOWN rather than assuming safety."
            )

        return runCatching {
            val obj = JSONObject(raw)
            IngredientToleranceRecord(
                ingredientName = ingredientName,
                state = ToleranceState.valueOf(obj.getString("state")),
                sessionsAtCurrentState = obj.getInt("sessionsAtCurrentState"),
                reason = obj.getString("reason")
            )
        }.getOrElse {
            // Malformed entry: do not crash, do not assume tolerated — recover to UNKNOWN, same
            // "prefer safe recovery over silent corruption" convention as session storage.
            IngredientToleranceRecord(
                ingredientName = ingredientName,
                state = ToleranceState.UNKNOWN,
                sessionsAtCurrentState = 0,
                reason = "Stored tolerance record was unreadable; recovered to UNKNOWN."
            )
        }
    }

    override fun save(record: IngredientToleranceRecord) {
        val obj = JSONObject()
            .put("state", record.state.name)
            .put("sessionsAtCurrentState", record.sessionsAtCurrentState)
            .put("reason", record.reason)
        preferences.edit().putString(key(record.ingredientName), obj.toString()).apply()
    }

    private fun key(ingredientName: String) = "tolerance:$ingredientName"
}
