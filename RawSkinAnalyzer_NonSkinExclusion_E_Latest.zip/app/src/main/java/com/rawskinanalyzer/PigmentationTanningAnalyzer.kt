package com.rawskinanalyzer

data class PigmentationViewResult(
    val view:String,
    val skinCells:Int,
    val meanLuma:Double,
    val lumaVariation:Double,
    val darkerAreaPercent:Double
)

data class PigmentationTanningResult(
    val pigmentationVariationScore:Double,
    val pigmentationLevel:String,
    val broadToneShiftSignal:String,
    val localizedDarkMarkSignal:String,
    val darkerAreaPercent:Double,
    val distribution:String,
    val crossViewConsistency:String,
    val confidence:String,
    val views:List<PigmentationViewResult>
)

object PigmentationTanningAnalyzer {
    private fun std(values:List<Double>):Double {
        if(values.isEmpty()) return 0.0
        val mean=values.average()
        return kotlin.math.sqrt(values.sumOf{(it-mean)*(it-mean)}/values.size)
    }

    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_PIGMENTATION_VARIATION_SIGNAL"
        score>=30.0 -> "MODERATE_PIGMENTATION_VARIATION_SIGNAL"
        score>=12.0 -> "LOW_PIGMENTATION_VARIATION_SIGNAL"
        else -> "MINIMAL_PIGMENTATION_VARIATION_SIGNAL"
    }

    private fun analyzeView(name:String,cells:List<PatternMapCell>):PigmentationViewResult {
        val skin=cells.filter{it.skinPercent>=10.0}
        val values=skin.map{it.meanLuma}
        val mean=if(values.isEmpty()) 0.0 else values.average()
        val variation=std(values)
        val darkThreshold=mean-variation
        val darker=if(values.isEmpty()) 0.0
            else values.count{it<=darkThreshold}*100.0/values.size
        return PigmentationViewResult(name,skin.size,mean,variation,darker)
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):PigmentationTanningResult {
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val tone=ToneColorFeatureAnalyzer.analyze(front,left,right)
        val views=listOf(
            analyzeView("FRONT_FACE",front),
            analyzeView("LEFT_CHEEK",left),
            analyzeView("RIGHT_CHEEK",right)
        ).filter{it.skinCells>0}

        if(views.isEmpty()) return PigmentationTanningResult(
            0.0,"INSUFFICIENT_PIGMENTATION_DATA","INSUFFICIENT_DATA",
            "INSUFFICIENT_DATA",0.0,"INSUFFICIENT_DATA",
            "INSUFFICIENT_CROSS_VIEW_DATA","LOW",emptyList()
        )

        val darkerPercent=views.map{it.darkerAreaPercent}.average()
        val withinVariation=views.map{it.lumaVariation}.average()
        val score=SkinScoreCalibration.pigmentationVariation(
            toneVariation=q.toneVariation,
            withinViewLumaVariation=withinVariation,
            darkAreaScore=tone.darkAreaScore,
            darkerAreaPercent=darkerPercent
        ).calibratedScore

        val viewSpread=std(views.map{it.meanLuma})
        val consistency=when {
            views.size<2 -> "SINGLE_VIEW_TONE_SIGNAL"
            viewSpread<=6.0 -> "HIGH_CROSS_VIEW_TONE_CONSISTENCY"
            viewSpread<=14.0 -> "MODERATE_CROSS_VIEW_TONE_CONSISTENCY"
            else -> "LOW_CROSS_VIEW_TONE_CONSISTENCY"
        }

        val broadToneShift=when {
            score>=30.0 && darkerPercent>=15.0 && consistency.startsWith("HIGH") ->
                "BROAD_TONE_SHIFT_SIGNAL"
            score>=18.0 -> "MODERATE_BROAD_TONE_VARIATION_SIGNAL"
            else -> "LIMITED_BROAD_TONE_SHIFT_SIGNAL"
        }

        val localizedDark=when {
            tone.darkAreaScore>=60.0 || darkerPercent>=30.0 -> "HIGH_LOCALIZED_DARK_MARK_SIGNAL"
            tone.darkAreaScore>=30.0 || darkerPercent>=15.0 -> "MODERATE_LOCALIZED_DARK_MARK_SIGNAL"
            tone.darkAreaScore>=12.0 -> "LOW_LOCALIZED_DARK_MARK_SIGNAL"
            else -> "MINIMAL_LOCALIZED_DARK_MARK_SIGNAL"
        }

        val distribution=when {
            consistency.startsWith("HIGH") && darkerPercent>=15.0 -> "MULTI_VIEW_DISTRIBUTED_TONE_VARIATION"
            darkerPercent>=15.0 -> "MULTI_AREA_TONE_VARIATION"
            darkerPercent>0.0 -> "LOCALIZED_TONE_VARIATION"
            else -> "LIMITED_TONE_VARIATION"
        }

        val confidence=when {
            views.size==3 && consistency=="HIGH_CROSS_VIEW_TONE_CONSISTENCY" && q.confidence=="HIGH" -> "HIGH"
            views.size>=2 -> "MODERATE"
            else -> "LOW"
        }

        return PigmentationTanningResult(
            score,level(score),broadToneShift,localizedDark,darkerPercent,
            distribution,consistency,confidence,views
        )
    }

    fun json(x:PigmentationTanningResult):String {
        val views=x.views.joinToString(","){v ->
            """{"view":"${v.view}","skin_cells":${v.skinCells},"mean_luma":${v.meanLuma},"luma_variation":${v.lumaVariation},"darker_area_percent":${v.darkerAreaPercent}}"""
        }
        return """{"pigmentation_variation_score":${x.pigmentationVariationScore},"pigmentation_level":"${x.pigmentationLevel}","broad_tone_shift_signal":"${x.broadToneShiftSignal}","localized_dark_mark_signal":"${x.localizedDarkMarkSignal}","darker_area_percent":${x.darkerAreaPercent},"distribution":"${x.distribution}","cross_view_consistency":"${x.crossViewConsistency}","confidence":"${x.confidence}","views":[$views],"method":"pigmentation_tanning_analysis_v1","medical_diagnosis":false}"""
    }
}
