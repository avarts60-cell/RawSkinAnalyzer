package com.rawskinanalyzer

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * PostAcneSpatialAssociationEngine
 *
 * Batch 4D-F2, step_3 (P0). Operates on the [SpecializedFeatureEvidence] list
 * `SpecializedFeatureEvidenceAssembler.assemble` already produces — every field this step's
 * `association_signals` asks for (normalized regional location, distance, candidate area, shape,
 * color relationship via feature-type family, skin confidence) is already carried on that
 * unified evidence record, so this engine performs the actual join `SpecializedFeatureClassifiers
 * .classifyDarkFeatures`'s own doc comment explicitly flagged as missing ("that spatial join is
 * not performed here... approximated as the overlap of moderate pigmentation AND moderate
 * redness"), rather than re-deriving a second proxy.
 *
 * Normalization: as of Batch 4D-G, step_2, this engine uses true region-BOUNDARY-relative
 * normalization via [RegionalNormalizationEngine] whenever the caller supplies the actual
 * [RegionSet] for a candidate's source view (see [associate]'s `regionSetsByView` parameter).
 * When that geometry is unavailable for a given (view, region) — an omitted map entry, a region
 * present in `RegionSet.skippedRegions`, or geometry too thin to normalize against — this engine
 * falls back to its ORIGINAL Batch 4D-F2 proxy: the observed bounding extent of ALL evidence
 * actually present in that (view, region) pair this session, used as the normalization
 * denominator for centroid distance. That proxy is real (a genuine geometric computation, not a
 * fabricated constant) but region-CONTENT-relative, not region-BOUNDARY-relative — recorded via
 * [PostAcneSpatialAssociation]'s own evidence reasons on the associations that actually used it,
 * not silently presented as equivalent to the true-geometry path.
 */
object PostAcneSpatialAssociationEngine {
    const val VERSION = "post_acne_spatial_association_engine_v2_true_normalization"

    private fun clamp01(v: Double) = max(0.0, min(1.0, v))

    private val darkFeatureFamily = setOf(
        SpecializedFeatureType.DARK_MARK_LIKE, SpecializedFeatureType.PIGMENTATION_LIKE,
        SpecializedFeatureType.RED_MARK_LIKE, SpecializedFeatureType.POST_ACNE_MARK_LIKE
    )
    private val blemishFamily = setOf(
        SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.BLACKHEAD_LIKE, SpecializedFeatureType.WHITEHEAD_LIKE,
        SpecializedFeatureType.PAPULE_LIKE_VISUAL, SpecializedFeatureType.PUSTULE_LIKE_VISUAL, SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE
    )

    /** Real (not fabricated) color/mechanism compatibility between a dark-feature type and a
     * blemish type, grounded in what each type's OWN classifier (`SpecializedFeatureClassifiers`)
     * already used to assign it: red-leaning dark-feature types pair with red-leaning blemish
     * types (an inflamed lesion leaving a red-leaning mark), dark/pigmentation-leaning types pair
     * with blackhead/compact-dark blemish types (a resolved comedonal lesion leaving a pigmented
     * mark) — matching the SAME redness-vs-darkness split those classifiers already applied. */
    private fun typeCompatibility(dark: SpecializedFeatureType, blemish: SpecializedFeatureType): Double = when (dark) {
        SpecializedFeatureType.RED_MARK_LIKE, SpecializedFeatureType.POST_ACNE_MARK_LIKE -> when (blemish) {
            SpecializedFeatureType.PAPULE_LIKE_VISUAL, SpecializedFeatureType.PUSTULE_LIKE_VISUAL -> 0.9
            SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE -> 0.6
            else -> 0.35
        }
        SpecializedFeatureType.PIGMENTATION_LIKE, SpecializedFeatureType.DARK_MARK_LIKE -> when (blemish) {
            SpecializedFeatureType.BLACKHEAD_LIKE, SpecializedFeatureType.WHITEHEAD_LIKE -> 0.9
            SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE -> 0.6
            else -> 0.35
        }
        else -> 0.3
    }

    private fun shapeCompatibility(a: String, b: String): Double = when {
        a == b -> 1.0
        a == "IRREGULAR" || b == "IRREGULAR" -> 0.55
        else -> 0.3
    }

    private fun areaCompatibility(areaA: Int, areaB: Int): Double {
        if (areaA <= 0 || areaB <= 0) return 0.0
        val ratio = min(areaA, areaB).toDouble() / max(areaA, areaB).toDouble()
        return clamp01(ratio)
    }

    private fun centroidDistance(a: SpecializedFeatureEvidence, b: SpecializedFeatureEvidence): Double {
        val dx = (a.sourceCoordinates.first - b.sourceCoordinates.first).toDouble()
        val dy = (a.sourceCoordinates.second - b.sourceCoordinates.second).toDouble()
        return sqrt(dx * dx + dy * dy)
    }

    /** The honestly-labeled region-content-relative normalization denominator described in this
     * file's class doc comment — the observed centroid spread of every evidence item present in
     * this (view, region) group this session, floored so a region with near-coincident candidates
     * doesn't produce a near-zero (and therefore always-"far") denominator. */
    private fun regionSpan(groupEvidence: List<SpecializedFeatureEvidence>): Double {
        if (groupEvidence.size < 2) return 200.0 // no spread information available; a fixed, documented fallback rather than a divide-by-zero or a fabricated precise value
        val xs = groupEvidence.map { it.sourceCoordinates.first }
        val ys = groupEvidence.map { it.sourceCoordinates.second }
        val spanX = (xs.max() - xs.min()).toDouble()
        val spanY = (ys.max() - ys.min()).toDouble()
        return max(50.0, sqrt(spanX * spanX + spanY * spanY))
    }

    private const val MAX_NORMALIZED_DISTANCE = 0.4
    /** True-geometry distances live in a real [0, ~1.4] unit-square metric, not the old proxy's
     * roughly-comparable-by-construction range — a separate, slightly tighter threshold, chosen
     * because a true region-boundary-relative 0.4 covers noticeably more of a region than the old
     * content-relative 0.4 did. */
    private const val MAX_TRUE_NORMALIZED_DISTANCE = 0.3

    /**
     * [evidence] should be one session's full [SpecializedFeatureEvidence] list (all views, all
     * regions) — grouping by (view, region) happens internally, mirroring how every other
     * regional-rollup step in this project takes the full list and groups itself rather than
     * requiring the caller to pre-partition it.
     *
     * [regionSetsByView], added in Batch 4D-G step_2, maps a `sourceView` label (e.g. "FRONT
     * FACE" — `MainActivity.SessionStep.label`) to that view's own [RegionSet]. When a
     * (view, region) pair has usable geometry there, true [RegionalNormalizationEngine] distance
     * is used; otherwise this falls back unchanged to the original Batch 4D-F2 content-relative
     * proxy. Omitting the parameter entirely (the default) reproduces Batch 4D-F2's exact
     * behavior, so existing callers/tests are unaffected unless they opt in.
     */
    fun associate(
        evidence: List<SpecializedFeatureEvidence>,
        regionSetsByView: Map<String, RegionSet> = emptyMap()
    ): List<PostAcneSpatialAssociation> {
        val out = mutableListOf<PostAcneSpatialAssociation>()
        val grouped = evidence.groupBy { it.sourceView to it.anatomicalRegion }
        var seq = 0

        for ((key, groupList) in grouped) {
            val (view, region) = key
            val darkFeatures = groupList.filter { it.featureType in darkFeatureFamily }
            val blemishes = groupList.filter { it.featureType in blemishFamily }
            if (darkFeatures.isEmpty() || blemishes.isEmpty()) continue
            val span = regionSpan(groupList)
            val regionSet = regionSetsByView[view]

            for (d in darkFeatures) {
                // Associate with EVERY compatible nearby blemish above threshold (step_3: "associate
                // only compatible nearby candidates", not "pick exactly one") rather than a single
                // best-match, since a resolved lesion can legitimately have more than one plausible
                // originating blemish reading nearby (e.g. an overlapping blackhead + blemish_like
                // pair from Batch 4D-D's own coarser primary/secondary classification).
                for (b in blemishes) {
                    val distance = centroidDistance(d, b)

                    // True region-relative normalization when both candidates' positions resolve
                    // to real RegionPolygon geometry; otherwise the original content-relative proxy.
                    val dNorm = RegionalNormalizationEngine.normalize(regionSet, region, d.sourceCoordinates.first, d.sourceCoordinates.second)
                    val bNorm = RegionalNormalizationEngine.normalize(regionSet, region, b.sourceCoordinates.first, b.sourceCoordinates.second)
                    val usingTrueGeometry = dNorm.method == RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE &&
                        bNorm.method == RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE
                    val normalizedDistance: Double
                    val maxAllowed: Double
                    if (usingTrueGeometry) {
                        normalizedDistance = RegionalNormalizationEngine.distance(dNorm, bNorm)
                        maxAllowed = MAX_TRUE_NORMALIZED_DISTANCE
                    } else {
                        normalizedDistance = distance / span
                        maxAllowed = MAX_NORMALIZED_DISTANCE
                    }
                    if (normalizedDistance > maxAllowed) continue

                    val typeCompat = typeCompatibility(d.featureType, b.featureType)
                    if (typeCompat < 0.3) continue
                    val areaCompat = areaCompatibility(d.area, b.area)
                    val shapeCompat = shapeCompatibility(d.shape, b.shape)
                    val distanceFactor = clamp01(1.0 - normalizedDistance / maxAllowed)

                    val confidence = clamp01(
                        (0.35 * distanceFactor + 0.25 * typeCompat + 0.20 * areaCompat + 0.20 * shapeCompat) *
                            min(d.primaryConfidence, b.primaryConfidence).coerceAtLeast(0.2)
                    )
                    if (confidence < 0.2) continue

                    val reasons = mutableListOf<String>()
                    if (usingTrueGeometry) {
                        reasons.add("region-boundary-relative distance ${"%.2f".format(normalizedDistance)} (true RegionPolygon geometry; raw centroid distance ${"%.0f".format(distance)}px)")
                    } else {
                        reasons.add("centroid distance ${"%.0f".format(distance)}px (normalized ${"%.2f".format(normalizedDistance)} of observed regional spread; true region geometry unavailable for this view/region)")
                    }
                    reasons.add("type relationship: ${d.featureType} near ${b.featureType} (compatibility=${"%.2f".format(typeCompat)})")
                    if (areaCompat > 0.5) reasons.add("comparable candidate area")
                    if (shapeCompat >= 0.55) reasons.add("compatible shape (${d.shape} / ${b.shape})")

                    out.add(
                        PostAcneSpatialAssociation(
                            associationId = "${view}_${region}_assoc${seq++}",
                            view = view, region = region,
                            darkFeatureCandidateId = d.candidateId, blemishCandidateId = b.candidateId,
                            darkFeatureType = d.featureType, blemishType = b.featureType,
                            distancePixels = distance, normalizedDistance = normalizedDistance,
                            areaCompatibility = areaCompat, shapeCompatibility = shapeCompat, colorCompatibility = typeCompat,
                            associationConfidence = confidence, evidenceReasons = reasons
                        )
                    )
                }
            }
        }
        return out
    }

    fun json(associations: List<PostAcneSpatialAssociation>): String {
        val assocJson = associations.joinToString(",") { SpecializedFeatureJson.postAcneAssociationJson(it) }
        return """{"method":"$VERSION","association_count":${associations.size},"associations":[$assocJson]}"""
    }
}
