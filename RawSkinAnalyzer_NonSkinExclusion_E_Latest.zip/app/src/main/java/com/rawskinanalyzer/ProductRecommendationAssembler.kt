package com.rawskinanalyzer

data class ProductRecommendation(
    val productId: String,
    val concern: SkinConcernCategory,
    val targetIngredient: String,
    val routinePhase: String,
    val matchScore: Int,
    val matchReasons: List<String>,
    val recommendationStatus: String,
    val explanation: String,
    val caution: String?
)

object ProductRecommendationAssembler {
    fun assemble(
        requirements: List<ProductRequirement>,
        matches: List<ProductMatch>,
        usePlans: List<IngredientUsePlan>
    ): List<ProductRecommendation> {
        val requirementByIngredient = requirements.associateBy { it.targetIngredient }
        val usePlanByIngredient = usePlans.associateBy { it.ingredientName }

        return matches
            .filter { it.accepted }
            .mapNotNull { match ->
                val requirement = requirementByIngredient[match.targetIngredient]
                    ?: return@mapNotNull null
                val usePlan = usePlanByIngredient[match.targetIngredient]

                ProductRecommendation(
                    productId = match.productId,
                    concern = requirement.concern,
                    targetIngredient = match.targetIngredient,
                    routinePhase = requirement.routinePhase,
                    matchScore = match.score,
                    matchReasons = match.reasons,
                    recommendationStatus = if (usePlan?.caution != null)
                        "MATCHED_WITH_CAUTION" else "MATCHED",
                    explanation = buildExplanation(requirement, match),
                    caution = usePlan?.caution
                )
            }
            .sortedByDescending { it.matchScore }
    }

    private fun buildExplanation(
        requirement: ProductRequirement,
        match: ProductMatch
    ): String =
        "Matched to ${requirement.concern} through ${requirement.targetIngredient}; " +
        "routine phase ${requirement.routinePhase}; score ${match.score}."
}
