package com.rawskinanalyzer

data class ProductRequirement(
    val concern: SkinConcernCategory,
    val targetIngredient: String,
    val routinePhase: String,
    val desiredStrength: String,
    val desiredFrequency: String,
    val requiredAttributes: List<String>,
    val excludedAttributes: List<String>
)

data class ProductCandidate(
    val productId: String,
    val ingredientNames: Set<String>,
    val attributes: Set<String>,
    val routinePhases: Set<String>
)

data class ProductMatch(
    val productId: String,
    val targetIngredient: String,
    val score: Int,
    val accepted: Boolean,
    val reasons: List<String>
)

object ProductSelectionPlanner {
    fun requirements(plans: List<IngredientUsePlan>): List<ProductRequirement> =
        plans.map { plan ->
            ProductRequirement(
                concern = plan.concern,
                targetIngredient = plan.ingredientName,
                routinePhase = plan.routinePhase,
                desiredStrength = plan.concentrationGuidance,
                desiredFrequency = plan.frequencyGuidance,
                requiredAttributes = listOf("INGREDIENT_MATCH", "ROUTINE_PHASE_COMPATIBLE"),
                excludedAttributes = if (plan.caution != null)
                    listOf("UNREVIEWED_HIGH_INTENSITY_COMBINATION")
                else emptyList()
            )
        }

    fun rank(
        requirements: List<ProductRequirement>,
        candidates: List<ProductCandidate>
    ): List<ProductMatch> = requirements.flatMap { requirement ->
        candidates.map { candidate ->
            val reasons = mutableListOf<String>()
            var score = 0

            if (requirement.targetIngredient in candidate.ingredientNames) {
                score += 70
                reasons += "TARGET_INGREDIENT_MATCH"
            } else reasons += "TARGET_INGREDIENT_MISSING"

            if (requirement.routinePhase == "AM_OR_PM" ||
                requirement.routinePhase in candidate.routinePhases) {
                score += 20
                reasons += "ROUTINE_PHASE_COMPATIBLE"
            } else reasons += "ROUTINE_PHASE_MISMATCH"

            val excluded = requirement.excludedAttributes.any {
                it in candidate.attributes
            }
            if (excluded) reasons += "EXCLUSION_RULE_TRIGGERED"
            else score += 10

            ProductMatch(
                productId = candidate.productId,
                targetIngredient = requirement.targetIngredient,
                score = score,
                accepted = score >= 80 && !excluded,
                reasons = reasons
            )
        }
    }.sortedByDescending { it.score }
}
