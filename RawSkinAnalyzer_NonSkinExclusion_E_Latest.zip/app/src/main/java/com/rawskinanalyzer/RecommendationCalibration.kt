package com.rawskinanalyzer

/**
 * BATCH 3 — ROUTINE AND RECOMMENDATION INTELLIGENCE CALIBRATION
 * Step 3: Objective Strength Calibration.
 *
 * Before this file existed, SkinObjectivePlanner.plan() derived SkinObjectiveType from
 * `concern.score` alone (see the threshold ladder previously inlined there: >=60 ->
 * IMPROVE_VISIBLE_APPEARANCE, >=30 -> SUPPORT_BALANCE, >=12 -> MAINTAIN_CURRENT_STATE, else
 * MONITOR). Every per-characteristic analyzer already computes a `confidence` value (HIGH /
 * MODERATE / LOW) alongside its score, and FinalSkinAnalysisProfile already computes a
 * session-level `analysisConfidence` (the minimum across every analyzer, via
 * FinalSkinAnalysisProfileAnalyzer.minConfidence) — but neither ever reached the objective
 * stage: SkinConcernInterpreter.fromFinalProfile() dropped `finding.confidence` at the exact
 * conversion step that produced SkinConcern, so a HIGH-score/LOW-confidence finding and a
 * HIGH-score/HIGH-confidence finding produced an identical objective. This is precisely the
 * "high score with weak confidence should remain conservative" gap Batch 3 targets.
 *
 * This file adds one deterministic, table-based policy for turning
 * (score, per-finding confidence, session-level confidence, priority) into a SkinObjectiveType
 * plus an explicit, human-readable reason for why that tier was — or was not — reached. It
 * does not touch score, confidence, or priority themselves (those remain Brain 1 / earlier
 * Brain 2 outputs); it only decides how strongly a finding may be expressed as an objective.
 */

/** The four SkinObjectiveType values ordered by strength, weakest first. Used only for
 *  min()-style tier comparisons inside this file — never exposed or serialized directly. */
private val OBJECTIVE_TIER_ORDER = listOf(
    SkinObjectiveType.MONITOR,
    SkinObjectiveType.MAINTAIN_CURRENT_STATE,
    SkinObjectiveType.SUPPORT_BALANCE,
    SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE
)

data class CalibratedObjectiveStrength(
    val objectiveType: SkinObjectiveType,
    val scoreBasedTier: SkinObjectiveType,
    val wasCapped: Boolean,
    val reason: String
)

object ObjectiveStrengthPolicy {
    const val VERSION = "OBJECTIVE_STRENGTH_POLICY_V1"

    private fun tierIndex(type: SkinObjectiveType) = OBJECTIVE_TIER_ORDER.indexOf(type)
    private fun tierAt(index: Int) = OBJECTIVE_TIER_ORDER[index]

    private fun scoreBasedTier(score: Double): SkinObjectiveType = when {
        score >= 60.0 -> SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE
        score >= 30.0 -> SkinObjectiveType.SUPPORT_BALANCE
        score >= 12.0 -> SkinObjectiveType.MAINTAIN_CURRENT_STATE
        else -> SkinObjectiveType.MONITOR
    }

    /** A single finding's own confidence caps how strongly it alone may be expressed. HIGH
     *  confidence applies no cap (the score-based tier stands); MODERATE caps at
     *  SUPPORT_BALANCE; LOW (or any other/unexpected value, treated conservatively) caps at
     *  MAINTAIN_CURRENT_STATE — a low-confidence finding may never, by itself, justify
     *  IMPROVE_VISIBLE_APPEARANCE-level prioritization. */
    private fun findingConfidenceCap(confidence: String): SkinObjectiveType = when (confidence) {
        "HIGH" -> SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE
        "MODERATE" -> SkinObjectiveType.SUPPORT_BALANCE
        else -> SkinObjectiveType.MAINTAIN_CURRENT_STATE
    }

    /** The whole-session confidence (FinalSkinAnalysisProfile.analysisConfidence, the minimum
     *  across every analyzer this session) is a session-wide analysis limitation, not a
     *  per-finding one — it caps every objective this session produces, on top of whatever
     *  that finding's own confidence allows. A session where at least one analyzer reported
     *  LOW confidence should not let any other finding reach the top tier either. */
    private fun sessionConfidenceCap(analysisConfidence: String): SkinObjectiveType = when (analysisConfidence) {
        "HIGH" -> SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE
        "MODERATE" -> SkinObjectiveType.SUPPORT_BALANCE
        else -> SkinObjectiveType.MAINTAIN_CURRENT_STATE
    }

    /** Only the top two ranked findings (priority 1 and 2 — primary and secondary) may reach
     *  the top tier. Every lower-priority finding is capped at SUPPORT_BALANCE so a long tail
     *  of minor findings cannot each be expressed as strongly as the primary objective. */
    private fun priorityCap(priority: Int): SkinObjectiveType =
        if (priority <= 2) SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE else SkinObjectiveType.SUPPORT_BALANCE

    fun calibrate(
        score: Double,
        findingConfidence: String,
        sessionAnalysisConfidence: String,
        priority: Int
    ): CalibratedObjectiveStrength {
        val base = scoreBasedTier(score)
        val caps = listOf(
            "finding_confidence=$findingConfidence" to findingConfidenceCap(findingConfidence),
            "session_confidence=$sessionAnalysisConfidence" to sessionConfidenceCap(sessionAnalysisConfidence),
            "priority=$priority" to priorityCap(priority)
        )

        var finalIndex = tierIndex(base)
        val bindingCaps = mutableListOf<String>()
        caps.forEach { (label, capType) ->
            val capIndex = tierIndex(capType)
            if (capIndex < finalIndex) {
                finalIndex = capIndex
                bindingCaps.clear()
                bindingCaps += label
            } else if (capIndex == finalIndex && finalIndex < tierIndex(base)) {
                bindingCaps += label
            }
        }
        val final = tierAt(finalIndex)
        val capped = final != base

        val reason = if (!capped) {
            "Score $score (${base.name}) reached without conservatism adjustment; " +
                "finding and session confidence were sufficient and priority was $priority."
        } else {
            "Score $score alone would justify ${base.name}, but reduced to ${final.name} because of: " +
                bindingCaps.joinToString("; ") + "."
        }

        return CalibratedObjectiveStrength(final, base, capped, reason)
    }
}
