package com.rawskinanalyzer

data class RednessViewResult(
    val view:String,
    val skinCells:Int,
    val meanRedness:Double,
    val rednessVariation:Double,
    val elevatedRednessPercent:Double
)

data class RednessAnalysisResult(
    val overallRednessScore:Double,
    val rednessLevel:String,
    val distribution:String,
    val crossViewConsistency:String,
    val elevatedAreaPercent:Double,
    val confidence:String,
    val views:List<RednessViewResult>
)

object RednessAnalysisAnalyzer {
    private fun std(values:List<Double>):Double {
        if(values.isEmpty()) return 0.0
        val mean=values.average()
        return kotlin.math.sqrt(values.sumOf{(it-mean)*(it-mean)}/values.size)
    }

    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_VISIBLE_REDNESS_SIGNAL"
        score>=30.0 -> "MODERATE_VISIBLE_REDNESS_SIGNAL"
        score>=12.0 -> "LOW_VISIBLE_REDNESS_SIGNAL"
        else -> "MINIMAL_VISIBLE_REDNESS_SIGNAL"
    }

    private fun analyzeView(name:String,cells:List<PatternMapCell>):RednessViewResult {
        val skin=cells.filter{it.skinPercent>=10.0}
        val values=skin.map{it.redness}
        val mean=if(values.isEmpty()) 0.0 else values.average()
        val variation=std(values)
        val threshold=mean+variation
        val elevated=if(values.isEmpty()) 0.0
            else values.count{it>=threshold && it>0.0}*100.0/values.size
        return RednessViewResult(name,skin.size,mean,variation,elevated)
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):RednessAnalysisResult {
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val views=listOf(
            analyzeView("FRONT_FACE",front),
            analyzeView("LEFT_CHEEK",left),
            analyzeView("RIGHT_CHEEK",right)
        ).filter{it.skinCells>0}

        if(views.isEmpty()) return RednessAnalysisResult(
            0.0,"INSUFFICIENT_REDNESS_DATA","INSUFFICIENT_REDNESS_DATA",
            "INSUFFICIENT_CROSS_VIEW_DATA",0.0,"LOW",emptyList()
        )

        val meanRedness=views.map{it.meanRedness}.average()
        val withinVariation=views.map{it.rednessVariation}.average()
        val elevated=views.map{it.elevatedRednessPercent}.average()
        val score=SkinScoreCalibration.redness(
            localizedRedness=q.localizedRedness,
            withinViewVariation=withinVariation,
            elevatedAreaPercent=elevated
        ).calibratedScore

        val viewSpread=std(views.map{it.meanRedness})
        val consistency=when {
            views.size<2 -> "SINGLE_VIEW_REDNESS_SIGNAL"
            viewSpread<=3.0 -> "HIGH_CROSS_VIEW_REDNESS_CONSISTENCY"
            viewSpread<=8.0 -> "MODERATE_CROSS_VIEW_REDNESS_CONSISTENCY"
            else -> "LOW_CROSS_VIEW_REDNESS_CONSISTENCY"
        }

        val distribution=when {
            elevated>=30.0 && consistency.startsWith("HIGH") -> "WIDESPREAD_REDNESS_SIGNAL"
            elevated>=15.0 -> "MULTI_AREA_REDNESS_SIGNAL"
            elevated>0.0 -> "LOCALIZED_REDNESS_SIGNAL"
            else -> "LIMITED_REDNESS_SIGNAL"
        }

        val confidence=when {
            views.size==3 && consistency=="HIGH_CROSS_VIEW_REDNESS_CONSISTENCY" &&
                q.confidence=="HIGH" -> "HIGH"
            views.size>=2 -> "MODERATE"
            else -> "LOW"
        }

        return RednessAnalysisResult(
            score,level(score),distribution,consistency,elevated,confidence,views
        )
    }

    fun json(x:RednessAnalysisResult):String {
        val views=x.views.joinToString(","){v ->
            """{"view":"${v.view}","skin_cells":${v.skinCells},"mean_redness":${v.meanRedness},"redness_variation":${v.rednessVariation},"elevated_redness_percent":${v.elevatedRednessPercent}}"""
        }
        return """{"overall_redness_score":${x.overallRednessScore},"redness_level":"${x.rednessLevel}","distribution":"${x.distribution}","cross_view_consistency":"${x.crossViewConsistency}","elevated_area_percent":${x.elevatedAreaPercent},"confidence":"${x.confidence}","views":[$views],"method":"redness_analysis_v1","medical_diagnosis":false}"""
    }
}
