package com.rawskinanalyzer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * RegionOfInterestExtractor
 *
 * Batch 4D-C, step_1 + step_2. Audit finding (step_1): the original-image coordinate mapping
 * this batch is told to reuse already exists and is already correct —
 * `FaceGeometryAnalyzer.GeometryPoint` carries both `normalizedX/Y` and `originalX/Y` on every
 * landmark/contour point, computed from the sibling `capture.jpg`'s real decoded bounds (never
 * assumed to be a fixed 4080x3060); `AnatomicalRegionMapper.RegionPolygon` and
 * `FaceConstrainedSkinAnalyzer.RegionSkinReport` both already carry that same original-coordinate
 * information through. There was, however, no reusable layer that turns those coordinates into
 * an actual bounded, safely-clamped pixel crop request, and nothing anywhere in the project uses
 * `BitmapRegionDecoder` — every existing analyzer decodes a whole (already-downscaled)
 * `analysis_normalized.jpg` file with `BitmapFactory.decodeFile`. That gap is what this file
 * closes. Nothing in `FaceGeometryAnalyzer`/`AnatomicalRegionMapper`/`FaceConstrainedSkinAnalyzer`
 * is modified — this is a new, additive layer built on their existing output.
 *
 * Two responsibilities, kept deliberately separate:
 *  1. [computeCrop] — pure geometry. Turns a region's (or any) bounding box, given in
 *     normalized-image coordinates plus the same normalized->original scale factor
 *     `FaceGeometryAnalyzer` already computed, into a [RegionCrop]: an original-image pixel
 *     rectangle with configurable padding, safely clamped at the image edges. This never
 *     touches a bitmap and is cheap to call for every region/tile.
 *  2. [decodeCrop] — the only place in this file (and, after this batch, the only place in the
 *     project) a crop is actually turned into pixels, and only when a caller explicitly asks
 *     for one (e.g. a future micro-detail feature classifier). Uses `BitmapRegionDecoder`, which
 *     decodes only the requested rectangle of the source JPEG rather than the whole file — this
 *     is the "prefer region-specific decoding" requirement satisfied literally, not just
 *     approximated by cropping an already-fully-decoded bitmap. An optional `maxDimension`
 *     computes a power-of-two `inSampleSize` so a caller that only needs, say, a 512px preview
 *     of a crop never pays for a full-resolution decode it would immediately downscale anyway.
 *
 * This batch's tile *metadata* generation (`MultiScaleTileExtractor`) deliberately does NOT call
 * [decodeCrop] for every tile it enumerates — per step_9's "avoid decoding the entire image
 * repeatedly" and "bound memory usage", tile skin-coverage/exclusion metadata is derived entirely
 * from the already-in-memory `PatternMapCell` grid (see that file). [decodeCrop] exists for the
 * genuinely pixel-needing consumers this batch's step_11 contract anticipates (a future
 * pore/blemish/texture classifier that needs the actual high-resolution pixels of one selected
 * tile or candidate location), which is exactly where lazy, on-demand decoding belongs.
 */

/**
 * A single original-image pixel rectangle, ready to decode (or already just geometry, before
 * any decode happens). [region] is null for a crop that isn't tied to one anatomical region
 * (e.g. a micro-detail crop centered on a candidate point — see step_8 / [MicroDetailCropExtractor]).
 */
data class RegionCrop(
    val region: AnatomicalRegion?,
    val view: String,
    val sourceX: Int,
    val sourceY: Int,
    val width: Int,
    val height: Int,
    /** original-image pixels per normalized-image pixel, i.e. `originalImageWidth / normalizedImageWidth`. Null if the original capture's dimensions were unavailable (see FaceGeometryResult.originalScaleAvailable). */
    val scale: Float?,
    val originalImageWidth: Int?,
    val originalImageHeight: Int?,
    /** True if the requested (padded) bounds extended past the source image and had to be clamped — callers doing symmetric padding around a candidate point should know their crop may be asymmetric near an edge. */
    val clampedAtEdge: Boolean
)

object RegionOfInterestExtractor {
    const val VERSION = "region_of_interest_extractor_v1"

    /**
     * [nLeft]/[nTop]/[nRight]/[nBottom] are a bounding box in normalized-image coordinates
     * (the same space every [GeometryPoint.normalizedX]/`Y` and every [PatternMapCell]
     * row/col cell is defined in). [geom] supplies the scale factor and original image
     * dimensions already computed for this view — no second scale estimate is made here.
     * [paddingFraction] expands the box symmetrically by that fraction of its own
     * width/height before converting to original coordinates and clamping (default 8%, a
     * small context margin — not an arbitrary crop-to-fit).
     */
    fun computeCrop(
        region: AnatomicalRegion?,
        view: String,
        nLeft: Float, nTop: Float, nRight: Float, nBottom: Float,
        geom: FaceGeometryResult,
        paddingFraction: Double = 0.08
    ): RegionCrop {
        val padX = (nRight - nLeft) * paddingFraction.toFloat()
        val padY = (nBottom - nTop) * paddingFraction.toFloat()
        val pLeft = nLeft - padX; val pRight = nRight + padX
        val pTop = nTop - padY; val pBottom = nBottom + padY

        val scaleAvailable = geom.originalScaleAvailable && geom.originalImageWidth != null && geom.originalImageHeight != null
        if (!scaleAvailable) {
            // No original-coordinate scale available for this view — report the crop in
            // normalized-image pixel space instead of silently assuming 1:1, per this batch's
            // "do not fabricate physical measurements" rule applied to coordinate scale too.
            val left = max(0, pLeft.roundToInt()); val top = max(0, pTop.roundToInt())
            val right = min(geom.normalizedImageWidth, pRight.roundToInt())
            val bottom = min(geom.normalizedImageHeight, pBottom.roundToInt())
            val clamped = left > pLeft.roundToInt() || top > pTop.roundToInt() ||
                right < pRight.roundToInt() || bottom < pBottom.roundToInt()
            return RegionCrop(
                region = region, view = view,
                sourceX = left, sourceY = top,
                width = max(0, right - left), height = max(0, bottom - top),
                scale = null,
                originalImageWidth = null, originalImageHeight = null,
                clampedAtEdge = clamped
            )
        }

        val scaleX = geom.originalImageWidth!!.toFloat() / geom.normalizedImageWidth.toFloat()
        val scaleY = geom.originalImageHeight!!.toFloat() / geom.normalizedImageHeight.toFloat()
        val oLeftRaw = pLeft * scaleX; val oRightRaw = pRight * scaleX
        val oTopRaw = pTop * scaleY; val oBottomRaw = pBottom * scaleY

        val oLeft = max(0, oLeftRaw.roundToInt())
        val oTop = max(0, oTopRaw.roundToInt())
        val oRight = min(geom.originalImageWidth, oRightRaw.roundToInt())
        val oBottom = min(geom.originalImageHeight, oBottomRaw.roundToInt())
        val clamped = oLeft.toFloat() > oLeftRaw + 0.5f || oTop.toFloat() > oTopRaw + 0.5f ||
            oRight.toFloat() < oRightRaw - 0.5f || oBottom.toFloat() < oBottomRaw - 0.5f

        return RegionCrop(
            region = region, view = view,
            sourceX = oLeft, sourceY = oTop,
            width = max(0, oRight - oLeft), height = max(0, oBottom - oTop),
            scale = scaleX,
            originalImageWidth = geom.originalImageWidth, originalImageHeight = geom.originalImageHeight,
            clampedAtEdge = clamped
        )
    }

    /** Convenience overload building a crop directly from a region polygon's own bounding box. */
    fun computeCrop(regionPolygon: RegionPolygon, view: String, geom: FaceGeometryResult, paddingFraction: Double = 0.08): RegionCrop {
        val pts = regionPolygon.points
        return computeCrop(
            region = regionPolygon.region, view = view,
            nLeft = pts.minOf { it.normalizedX }, nTop = pts.minOf { it.normalizedY },
            nRight = pts.maxOf { it.normalizedX }, nBottom = pts.maxOf { it.normalizedY },
            geom = geom, paddingFraction = paddingFraction
        )
    }

    /**
     * Decodes only the pixels inside [crop] from [originalFile], using [BitmapRegionDecoder] so
     * the rest of the (potentially much larger) source image is never held in memory. Returns
     * null (never throws) if the file is missing, unreadable, or the crop has zero area — a
     * caller failing to get a bitmap for one candidate crop should not crash the analysis
     * pipeline, consistent with every other analyzer's try/catch-and-record-failure convention
     * in this project.
     *
     * [maxDimension], if provided, computes a power-of-two `inSampleSize` so the decode itself
     * (not just a later resize) produces roughly that size — genuine memory bounding for a
     * caller that only needs a smaller preview, not a full-resolution decode followed by a
     * discarded downscale.
     */
    fun decodeCrop(originalFile: File, crop: RegionCrop, maxDimension: Int? = null): Bitmap? {
        if (crop.width <= 0 || crop.height <= 0) return null
        if (!originalFile.exists()) return null
        return try {
            val decoder = if (android.os.Build.VERSION.SDK_INT >= 31) {
                BitmapRegionDecoder.newInstance(originalFile.absolutePath)
            } else {
                @Suppress("DEPRECATION")
                BitmapRegionDecoder.newInstance(originalFile.absolutePath, false)
            } ?: return null
            try {
                val rect = Rect(crop.sourceX, crop.sourceY, crop.sourceX + crop.width, crop.sourceY + crop.height)
                val opts = BitmapFactory.Options()
                if (maxDimension != null && maxDimension > 0) {
                    var sample = 1
                    while (crop.width / (sample * 2) >= maxDimension && crop.height / (sample * 2) >= maxDimension) sample *= 2
                    opts.inSampleSize = sample
                }
                decoder.decodeRegion(rect, opts)
            } finally {
                decoder.recycle()
            }
        } catch (e: Exception) {
            null
        }
    }

    fun json(crop: RegionCrop): String =
        """{"method":"$VERSION","region":${if (crop.region == null) "null" else "\"${crop.region}\""},"view":"${crop.view}","source_x":${crop.sourceX},"source_y":${crop.sourceY},"width":${crop.width},"height":${crop.height},"scale":${crop.scale ?: "null"},"original_image_width":${crop.originalImageWidth ?: "null"},"original_image_height":${crop.originalImageHeight ?: "null"},"clamped_at_edge":${crop.clampedAtEdge}}"""
}

/**
 * MicroDetailCropExtractor — step_8. A thin, named wrapper around [RegionOfInterestExtractor]
 * for the one distinct use case step_8 calls out: a small, padded crop around a single
 * *candidate location* (a point, not a whole region) for a future feature classifier to inspect
 * at native resolution. Deliberately not a separate implementation — reuses
 * [RegionOfInterestExtractor.computeCrop]/`decodeCrop` exactly, per this batch's "reuse the
 * existing... coordinate mapping instead of creating another coordinate system" rule.
 */
object MicroDetailCropExtractor {
    /**
     * [normalizedX]/[normalizedY] is the candidate point in normalized-image coordinates.
     * [paddingPixelsNormalized] is a symmetric half-width/half-height, in normalized-image
     * pixels, around that point (default 24px — a small, fixed context window; not a physical
     * measurement, per this batch's "do not fabricate physical measurements" rule — this is a
     * pixel-space configuration value, not a claimed millimeter size).
     */
    fun crop(
        region: AnatomicalRegion?,
        view: String,
        normalizedX: Float, normalizedY: Float,
        geom: FaceGeometryResult,
        paddingPixelsNormalized: Float = 24f
    ): RegionCrop = RegionOfInterestExtractor.computeCrop(
        region = region, view = view,
        nLeft = normalizedX - paddingPixelsNormalized, nTop = normalizedY - paddingPixelsNormalized,
        nRight = normalizedX + paddingPixelsNormalized, nBottom = normalizedY + paddingPixelsNormalized,
        geom = geom,
        paddingFraction = 0.0 // the window above IS the padding; do not pad twice
    )
}
