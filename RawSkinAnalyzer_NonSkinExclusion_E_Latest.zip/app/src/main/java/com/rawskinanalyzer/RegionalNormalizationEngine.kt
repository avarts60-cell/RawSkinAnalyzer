package com.rawskinanalyzer

import kotlin.math.sqrt

/**
 * RegionalNormalizationEngine
 *
 * Batch 4D-G, step_2 (P0). Replaces `PostAcneSpatialAssociationEngine`'s documented
 * content-relative proxy ("the observed bounding extent of ALL evidence actually present in
 * that (view, region) pair this session... region-CONTENT-relative, not region-BOUNDARY-
 * relative") with a real region-BOUNDARY-relative computation, using the ACTUAL
 * [RegionPolygon] geometry [AnatomicalRegionMapper] already builds per view — no new geometry is
 * invented; where that geometry isn't available for a given point, this engine says so via
 * [NormalizedPosition.method] rather than silently reusing the old proxy under a new name.
 *
 * Method: for a region's [RegionPolygon], use the ORIGINAL-image-coordinate bounding box of its
 * own boundary points (`GeometryPoint.originalX/originalY`, precomputed once by
 * `FaceGeometryAnalyzer` from the same normalized->original scale every other stage in this
 * project already trusts — see that class's doc comment). A point's normalized position within
 * the region is then just its own fractional position inside that boundary box:
 *   nx = (x - minX) / (maxX - minX), ny = (y - minY) / (maxY - minY)
 * This is deliberately a bounding-box normalization, not a polygon-interior parameterization (the
 * region polygons `AnatomicalRegionMapper` builds are quads/simple outlines, not the kind of
 * shape a nonlinear boundary-fitted parameterization would meaningfully improve on for this
 * project's purposes) — a real, simple, and honestly-scoped choice, not a claim of geodesic
 * anatomical mapping.
 *
 * "Handle candidates near region boundaries safely" (step_2's own requirement): a raw (nx,ny) can
 * land outside [0,1] since region ASSIGNMENT (upstream, at candidate-detection time) and this
 * BOUNDARY BOX here are not guaranteed to agree at the margins — that is recorded via
 * [NormalizedPosition.outOfBounds] rather than hidden, and the returned (nx,ny) is always clamped
 * into [0,1] so downstream distance math never produces a negative or >1 contribution from it.
 */
object RegionalNormalizationEngine {
    const val VERSION = "regional_normalization_engine_v1"

    const val METHOD_REGION_POLYGON_RELATIVE = "REGION_POLYGON_RELATIVE"
    const val METHOD_UNAVAILABLE_FALLBACK = "REGION_GEOMETRY_UNAVAILABLE_CENTER_FALLBACK"

    private const val MIN_BOX_SPAN_PX = 4.0

    /**
     * [regionSet] should be the [RegionSet] for the SAME view/capture the (x,y) point was
     * measured in — normalizing against a different view's region geometry would silently
     * reintroduce the "compare raw coordinates across independent captures" mistake this whole
     * batch exists to avoid, just one level removed.
     */
    fun normalize(regionSet: RegionSet?, region: AnatomicalRegion, originalX: Int, originalY: Int): NormalizedPosition {
        val poly = regionSet?.region(region)
        if (poly != null) {
            val pts = poly.points.filter { it.originalX != null && it.originalY != null }
            if (pts.size >= 3) {
                val minX = pts.minOf { it.originalX!! }
                val maxX = pts.maxOf { it.originalX!! }
                val minY = pts.minOf { it.originalY!! }
                val maxY = pts.maxOf { it.originalY!! }
                val w = (maxX - minX).toDouble()
                val h = (maxY - minY).toDouble()
                if (w >= MIN_BOX_SPAN_PX && h >= MIN_BOX_SPAN_PX) {
                    val rawNx = (originalX - minX) / w
                    val rawNy = (originalY - minY) / h
                    val outOfBounds = rawNx < 0.0 || rawNx > 1.0 || rawNy < 0.0 || rawNy > 1.0
                    return NormalizedPosition(
                        nx = rawNx.coerceIn(0.0, 1.0),
                        ny = rawNy.coerceIn(0.0, 1.0),
                        method = METHOD_REGION_POLYGON_RELATIVE,
                        outOfBounds = outOfBounds
                    )
                }
            }
        }
        // No usable region geometry for this (view, region) — e.g. the region was in
        // regionSet.skippedRegions, or its geometry had too little original-coordinate scale
        // information. A fixed center position rather than a fabricated precise one; callers
        // treat this method value as "position unknown, do not trust for fine-grained matching".
        return NormalizedPosition(nx = 0.5, ny = 0.5, method = METHOD_UNAVAILABLE_FALLBACK, outOfBounds = false)
    }

    /** Straight-line distance between two region-relative positions. Only meaningful when both
     * used [METHOD_REGION_POLYGON_RELATIVE] — callers should check that themselves (this function
     * does not refuse to compute a number for the fallback case, since 0.5/0.5 vs 0.5/0.5 == 0.0
     * would otherwise silently look like "same position" for two genuinely unknown points; see
     * call sites for how they guard against that instead). */
    fun distance(a: NormalizedPosition, b: NormalizedPosition): Double {
        val dx = a.nx - b.nx
        val dy = a.ny - b.ny
        return sqrt(dx * dx + dy * dy)
    }
}
