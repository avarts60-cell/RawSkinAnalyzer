package com.rawskinanalyzer

enum class RoutineAdaptationAction {
    MAINTAIN_CURRENT_ROUTINE,
    SIMPLIFY_ROUTINE,
    REVIEW_AND_MONITOR,
    CONSIDER_ROUTINE_ADJUSTMENT
}

data class RoutineAdaptationResult(
    val action: RoutineAdaptationAction,
    val reasons: List<String>,
    val affectedFeatures: List<String>,
    val adaptationConfidence: String
)

object RoutineAdaptationEngine {
    fun evaluate(progress: SkinProgressResult): RoutineAdaptationResult {
        if (progress.overallDirection == ProgressDirection.INSUFFICIENT_COMPARISON_DATA) {
            return RoutineAdaptationResult(
                action = RoutineAdaptationAction.REVIEW_AND_MONITOR,
                reasons = listOf("INSUFFICIENT_LONGITUDINAL_DATA"),
                affectedFeatures = emptyList(),
                adaptationConfidence = "INSUFFICIENT_FOR_ADAPTATION"
            )
        }

        val improved = progress.features.filter {
            it.direction == ProgressDirection.IMPROVED
        }.map { it.feature }

        val worsened = progress.features.filter {
            it.direction == ProgressDirection.WORSENED
        }.map { it.feature }

        val stable = progress.features.filter {
            it.direction == ProgressDirection.STABLE
        }.map { it.feature }

        val action = when {
            worsened.size >= 3 -> RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT
            worsened.isNotEmpty() -> RoutineAdaptationAction.REVIEW_AND_MONITOR
            improved.size >= 3 -> RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE
            improved.isNotEmpty() && stable.isNotEmpty() -> RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE
            stable.size >= 6 -> RoutineAdaptationAction.REVIEW_AND_MONITOR
            else -> RoutineAdaptationAction.REVIEW_AND_MONITOR
        }

        val reasons = mutableListOf<String>()
        if (improved.isNotEmpty()) reasons += "FEATURE_IMPROVEMENT_DETECTED"
        if (stable.isNotEmpty()) reasons += "FEATURE_STABILITY_DETECTED"
        if (worsened.isNotEmpty()) reasons += "FEATURE_WORSENING_DETECTED"
        if (progress.comparisonConfidence != "HIGH_COMPARISON_CONFIDENCE") {
            reasons += "LIMITED_COMPARISON_CONFIDENCE"
        }

        return RoutineAdaptationResult(
            action = action,
            reasons = reasons,
            affectedFeatures = (improved + worsened).distinct(),
            adaptationConfidence = when {
                progress.comparisonConfidence == "HIGH_COMPARISON_CONFIDENCE" &&
                    progress.features.size >= 8 -> "HIGH"
                progress.features.isNotEmpty() -> "MODERATE"
                else -> "LOW"
            }
        )
    }
}
