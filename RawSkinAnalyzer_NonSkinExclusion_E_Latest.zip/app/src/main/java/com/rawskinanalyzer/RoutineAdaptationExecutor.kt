package com.rawskinanalyzer

data class RoutineAdaptationExecution(
    val action: RoutineAdaptationAction,
    val morningRoutine: List<String>,
    val eveningRoutine: List<String>,
    val alternatingPlan: List<String>,
    val ingredientPlan: List<String>,
    val appliedChanges: List<String>,
    val reviewFlags: List<String>,
    val executionStatus: String
)

object RoutineAdaptationExecutor {
    fun execute(
        decision: RoutineAdaptationResult,
        current: FinalRoutineResult
    ): RoutineAdaptationExecution {
        val morning = current.morningRoutine.toMutableList()
        val evening = current.eveningRoutine.toMutableList()
        val alternating = current.alternatingPlan.toMutableList()
        val ingredients = current.ingredientPlan.toMutableList()
        val changes = mutableListOf<String>()
        val reviewFlags = mutableListOf<String>()

        when (decision.action) {
            RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE -> {
                changes += "CURRENT_ROUTINE_PRESERVED"
            }

            RoutineAdaptationAction.SIMPLIFY_ROUTINE -> {
                if (alternating.isNotEmpty()) {
                    alternating.removeLast()
                    changes += "ONE_ALTERNATING_STEP_REMOVED"
                } else {
                    reviewFlags += "NO_ALTERNATING_STEP_AVAILABLE_FOR_SIMPLIFICATION"
                }
            }

            RoutineAdaptationAction.REVIEW_AND_MONITOR -> {
                reviewFlags += "NO_AUTOMATIC_INTENSIFICATION"
                reviewFlags += "CONTINUE_MONITORING"
            }

            RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT -> {
                reviewFlags += "MANUAL_REVIEW_REQUIRED_BEFORE_ROUTINE_CHANGE"
                reviewFlags += "COMPATIBILITY_AND_TOLERANCE_RECHECK_REQUIRED"
            }
        }

        if (decision.adaptationConfidence != "HIGH") {
            reviewFlags += "LIMITED_ADAPTATION_CONFIDENCE"
        }

        return RoutineAdaptationExecution(
            action = decision.action,
            morningRoutine = morning,
            eveningRoutine = evening,
            alternatingPlan = alternating,
            ingredientPlan = ingredients,
            appliedChanges = changes,
            reviewFlags = reviewFlags.distinct(),
            executionStatus = when {
                decision.action == RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT ->
                    "REVIEW_REQUIRED"
                changes.isNotEmpty() ->
                    "ADAPTATION_APPLIED"
                else ->
                    "ROUTINE_PRESERVED"
            }
        )
    }
}
