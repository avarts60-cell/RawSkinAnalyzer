package com.rawskinanalyzer

enum class AdjustmentCandidateStatus {
    APPROVED,
    REJECTED,
    REVIEW_REQUIRED
}

data class ActivatedAdjustmentCandidate(
    val concern: String,
    val targetIngredient: String,
    val proposedFrequency: String,
    val status: AdjustmentCandidateStatus,
    val reason: String
)

data class ControlledRoutineRevision(
    val status: String,
    val approvedCandidates: List<ActivatedAdjustmentCandidate>,
    val rejectedCandidates: List<ActivatedAdjustmentCandidate>,
    val revisedMorningRoutine: List<String>,
    val revisedEveningRoutine: List<String>,
    val revisedAlternatingPlan: List<String>,
    val changeLog: List<String>,
    val reviewFlags: List<String>
)

object RoutineAdjustmentCandidateActivator {

    fun activate(
        adjustment: TrendAwareRoutineAdjustment,
        ingredientPlans: List<IngredientUsePlan>,
        currentRoutine: FinalRoutineResult,
        // Batch 3B: tolerance is a hard gate on trend-driven escalation, independent of and in
        // addition to the pre-existing static-caution check below. Defaults to empty so every
        // pre-existing call site/test keeps its previous behavior unless it opts in.
        toleranceByIngredient: Map<String, IngredientToleranceRecord> = emptyMap()
    ): ControlledRoutineRevision {
        val approved = mutableListOf<ActivatedAdjustmentCandidate>()
        val rejected = mutableListOf<ActivatedAdjustmentCandidate>()
        val reviewFlags = mutableListOf<String>()
        val changeLog = mutableListOf<String>()

        adjustment.candidates.forEach { candidate ->
            val plan = ingredientPlans.firstOrNull {
                it.concern.name == candidate.concern &&
                    it.ingredientName == candidate.targetIngredient
            }
            val tolerance = toleranceByIngredient[candidate.targetIngredient]?.state

            when {
                plan == null -> rejected += ActivatedAdjustmentCandidate(
                    candidate.concern,
                    candidate.targetIngredient,
                    candidate.proposedFrequency,
                    AdjustmentCandidateStatus.REJECTED,
                    "NO_MATCHING_INGREDIENT_PLAN"
                )

                // A PAUSED/CAUTION ingredient must not be escalated by the trend system, even
                // when it has no static `caution` text — this is the real, per-user connection
                // between tolerance and trend-driven adjustment ("PAUSED components are not
                // silently reintroduced" / "CAUTION limits escalation").
                tolerance == ToleranceState.PAUSED -> rejected += ActivatedAdjustmentCandidate(
                    candidate.concern,
                    candidate.targetIngredient,
                    candidate.proposedFrequency,
                    AdjustmentCandidateStatus.REJECTED,
                    "PAUSED_DUE_TO_CAUTION"
                )

                tolerance == ToleranceState.CAUTION -> rejected += ActivatedAdjustmentCandidate(
                    candidate.concern,
                    candidate.targetIngredient,
                    candidate.proposedFrequency,
                    AdjustmentCandidateStatus.REJECTED,
                    "LIMITED_BY_TOLERANCE"
                )

                tolerance == ToleranceState.UNKNOWN || tolerance == ToleranceState.INTRODUCING ->
                    rejected += ActivatedAdjustmentCandidate(
                        candidate.concern,
                        candidate.targetIngredient,
                        candidate.proposedFrequency,
                        AdjustmentCandidateStatus.REJECTED,
                        "CONSERVATIVE_INTRODUCTION"
                    )

                plan.caution != null -> rejected += ActivatedAdjustmentCandidate(
                    candidate.concern,
                    candidate.targetIngredient,
                    candidate.proposedFrequency,
                    AdjustmentCandidateStatus.REJECTED,
                    "DIRECT_CAUTION_PRESENT"
                )

                candidate.proposedFrequency != "REVIEW_EXISTING_FREQUENCY_BEFORE_ESCALATION" ->
                    rejected += ActivatedAdjustmentCandidate(
                        candidate.concern,
                        candidate.targetIngredient,
                        candidate.proposedFrequency,
                        AdjustmentCandidateStatus.REJECTED,
                        "UNSUPPORTED_AUTOMATIC_FREQUENCY_CHANGE"
                    )

                else -> approved += ActivatedAdjustmentCandidate(
                    candidate.concern,
                    candidate.targetIngredient,
                    candidate.proposedFrequency,
                    AdjustmentCandidateStatus.APPROVED,
                    "EXISTING_COMPATIBLE_PLAN_RETAINED_FOR_CONTROLLED_REVISION"
                )
            }
        }

        val revisedMorning = currentRoutine.morningRoutine.toMutableList()
        val revisedEvening = currentRoutine.eveningRoutine.toMutableList()
        val revisedAlternating = currentRoutine.alternatingPlan.toMutableList()

        approved.forEach { candidate ->
            val marker = "ADJUSTMENT_CANDIDATE: ${candidate.targetIngredient} — ${candidate.proposedFrequency}"
            if (revisedAlternating.none { it.contains(candidate.targetIngredient, ignoreCase = true) }) {
                revisedAlternating += marker
                changeLog += "APPROVED_CANDIDATE_ADDED_TO_CONTROLLED_ALTERNATING_PLAN:${candidate.targetIngredient}"
            } else {
                changeLog += "APPROVED_CANDIDATE_ALREADY_REPRESENTED:${candidate.targetIngredient}"
            }
        }

        if (approved.isEmpty()) reviewFlags += "NO_CANDIDATE_ACTIVATED"
        if (rejected.isNotEmpty()) reviewFlags += "REJECTED_CANDIDATES_PRESENT"
        if (adjustment.reviewFlags.isNotEmpty()) reviewFlags += adjustment.reviewFlags

        return ControlledRoutineRevision(
            status = when {
                approved.isNotEmpty() && rejected.isEmpty() -> "CONTROLLED_REVISION_APPLIED"
                approved.isNotEmpty() -> "PARTIAL_CONTROLLED_REVISION_APPLIED"
                else -> "NO_CONTROLLED_REVISION_APPLIED"
            },
            approvedCandidates = approved,
            rejectedCandidates = rejected,
            revisedMorningRoutine = revisedMorning,
            revisedEveningRoutine = revisedEvening,
            revisedAlternatingPlan = revisedAlternating,
            changeLog = changeLog,
            reviewFlags = reviewFlags.distinct()
        )
    }
}
