package com.rawskinanalyzer

enum class RoutineCompatibilityAction {
    INCLUDE,
    ALTERNATE,
    SEPARATE_SESSION,
    REVIEW_REQUIRED
}

data class RoutineCompatibilityDecision(
    val ingredientCategory: String,
    val routinePhase: String,
    val action: RoutineCompatibilityAction,
    val reason: String
)

data class RoutineAssembly(
    val morning: List<RoutineCompatibilityDecision>,
    val evening: List<RoutineCompatibilityDecision>,
    val alternating: List<RoutineCompatibilityDecision>
)

object RoutineCompatibilityPlanner {
    fun plan(items: List<IngredientStrategyItem>): RoutineAssembly {
        val decisions = items.map { item ->
            val action = when {
                item.role == IngredientRole.CAUTION ->
                    RoutineCompatibilityAction.REVIEW_REQUIRED
                item.ingredientCategory.contains("EXFOLIAT", ignoreCase = true) ->
                    RoutineCompatibilityAction.ALTERNATE
                item.ingredientCategory.contains("STRONG", ignoreCase = true) ->
                    RoutineCompatibilityAction.SEPARATE_SESSION
                else ->
                    RoutineCompatibilityAction.INCLUDE
            }
            RoutineCompatibilityDecision(
                ingredientCategory = item.ingredientCategory,
                routinePhase = item.routinePhase,
                action = action,
                reason = reasonFor(item, action)
            )
        }

        return RoutineAssembly(
            morning = decisions.filter {
                it.routinePhase == "AM" || it.routinePhase == "AM_OR_PM"
            },
            evening = decisions.filter {
                it.routinePhase == "PM" || it.routinePhase == "AM_OR_PM"
            },
            alternating = decisions.filter {
                it.action == RoutineCompatibilityAction.ALTERNATE ||
                it.action == RoutineCompatibilityAction.SEPARATE_SESSION ||
                it.action == RoutineCompatibilityAction.REVIEW_REQUIRED
            }
        )
    }

    private fun reasonFor(
        item: IngredientStrategyItem,
        action: RoutineCompatibilityAction
    ): String = when (action) {
        RoutineCompatibilityAction.INCLUDE ->
            "Category may be considered for its assigned routine phase within this strategy framework."
        RoutineCompatibilityAction.ALTERNATE ->
            "Category should not be automatically stacked; use an alternating schedule rule."
        RoutineCompatibilityAction.SEPARATE_SESSION ->
            "Category should be placed in a separate routine session rather than automatically combined."
        RoutineCompatibilityAction.REVIEW_REQUIRED ->
            "Marked as caution by the ingredient strategy and requires compatibility review before routine inclusion."
    }
}

// ---------------------------------------------------------------------------------------------
// BATCH 3B: candidate-level (named-ingredient) compatibility.
// AUDIT FINDING (recorded in full in PROJECT_STATUS.md): the `plan()` function above operates
// on `IngredientStrategyItem` — i.e. ingredient *categories* ("OBJECTIVE_TARGETED_SUPPORT" etc.)
// from the full, unfiltered `ingredientStrategy` list. It was never connected to the actual
// named ingredients Batch 3A selects (`CandidateSelectionDecision`/`SpecificIngredientOption`).
// Its category-substring rules ("EXFOLIAT"/"STRONG") also never match any category string this
// project actually produces, so `ALTERNATE`/`SEPARATE_SESSION` were dead code in production —
// only `REVIEW_REQUIRED` (from the CAUTION role) or `INCLUDE` could ever be produced. This
// section does not replace `plan()` (still used for the category-level schedule skeleton) — it
// adds the missing named-ingredient layer and is what `FinalSkinAnalysisProfileAnalyzer` now
// actually filters selected candidates through before they reach routine assembly.
// ---------------------------------------------------------------------------------------------

data class CandidateCompatibilityDecision(
    val concern: SkinConcernCategory,
    val ingredientName: String,
    val role: IngredientSelectionRole,
    val routinePhase: String,
    val action: RoutineCompatibilityAction,
    val reason: String
)

object CandidateCompatibilityPolicy {
    const val VERSION = "CANDIDATE_COMPATIBILITY_POLICY_V1"

    // Deterministic, non-fabricated: both of these ingredients already carry an explicit
    // caution string inside SpecificIngredientMapper ("avoid automatic stacking with multiple
    // intensive exfoliating steps" / "compatibility and tolerance review required"). This table
    // is what makes those two existing textual cautions machine-actionable instead of only
    // human-readable — no new ingredient claim is introduced here.
    private val exfoliatingActives = setOf("Salicylic acid")
    private val reviewRequiredActives = setOf("Azelaic acid")

    /**
     * Checks selected candidates (already filtered to SELECTED by EvidenceAwareCandidateSelectionPolicy
     * — this function does not re-derive selection, it only decides whether two already-selected
     * named ingredients can share a routine phase.
     */
    fun plan(selected: List<SpecificIngredientOption>): List<CandidateCompatibilityDecision> {
        val byPhaseName = selected.groupBy { it.routinePhase }

        return selected.map { candidate ->
            val samePhase = byPhaseName[candidate.routinePhase].orEmpty()
            val otherNamesSamePhase = samePhase
                .filter { it.ingredientName != candidate.ingredientName }
                .map { it.ingredientName }
                .toSet()

            val duplicateRoleElsewhere = selected.any {
                it.ingredientName == candidate.ingredientName &&
                    it.concern != candidate.concern &&
                    it.role == candidate.role
            }

            val (action, reason) = when {
                // Two ingredients this session's own cautions flag as needing separation, both
                // selected in the same phase: known configured conflict.
                candidate.ingredientName in exfoliatingActives &&
                    otherNamesSamePhase.any { it in reviewRequiredActives } ->
                    RoutineCompatibilityAction.SEPARATE_SESSION to "CONFLICT_WITH_CANDIDATE"
                candidate.ingredientName in reviewRequiredActives &&
                    otherNamesSamePhase.any { it in exfoliatingActives } ->
                    RoutineCompatibilityAction.SEPARATE_SESSION to "CONFLICT_WITH_CANDIDATE"
                // Two different exfoliating/review-required actives of our own that would
                // otherwise stack in the same phase.
                candidate.ingredientName in reviewRequiredActives &&
                    otherNamesSamePhase.any { it in reviewRequiredActives && it != candidate.ingredientName } ->
                    RoutineCompatibilityAction.ALTERNATE to "CONFLICT_WITH_CANDIDATE"
                duplicateRoleElsewhere ->
                    RoutineCompatibilityAction.INCLUDE to "DUPLICATE_ROLE"
                candidate.caution != null ->
                    RoutineCompatibilityAction.REVIEW_REQUIRED to "INSUFFICIENT_COMPATIBILITY_INFORMATION"
                else ->
                    RoutineCompatibilityAction.INCLUDE to "ALLOWED_COMPATIBLE_COMBINATION"
            }

            CandidateCompatibilityDecision(
                concern = candidate.concern,
                ingredientName = candidate.ingredientName,
                role = candidate.role,
                routinePhase = candidate.routinePhase,
                action = action,
                reason = reason
            )
        }
    }
}
