package com.rawskinanalyzer

/**
 * BATCH 3B — ROUTINE INTENSITY CALIBRATION (step 6).
 *
 * No existing routine-intensity model was found (audited `UserRoutineContext`,
 * `IngredientUsePlanner`, `RoutineSchedulePlanner` — none expose an intensity concept beyond
 * the static, session-level `ActiveIntensityPreference.LOW/MODERATE/UNSPECIFIED` user setting,
 * which — like `TolerancePreference` — is a stated preference, not a computed-per-candidate
 * decision). This is new, deterministic, and reads only already-computed values: it does not
 * recompute score, confidence, evidence, compatibility, or tolerance — those keep meaning
 * "own thing" per the batch's critical_separation rules; this only combines their *outputs*.
 */
enum class RoutineIntensityLevel { MINIMAL, CONSERVATIVE, STANDARD, CAUTIOUS_ESCALATION }

data class RoutineIntensityDecision(
    val ingredientName: String,
    val level: RoutineIntensityLevel,
    val reason: String
)

object RoutineIntensityPolicy {
    const val VERSION = "ROUTINE_INTENSITY_POLICY_V1"

    /**
     * @param objectiveType the calibrated objective strength for this candidate's concern.
     * @param confidence the concern's own finding confidence (LOW/MODERATE/HIGH), read only for
     *   reporting/gating — never used alone to justify escalation (see below).
     * @param compatibility this candidate's `RoutineCompatibilityAction` from
     *   `CandidateCompatibilityPolicy`.
     * @param tolerance this candidate's current `ToleranceState`.
     */
    fun calibrate(
        ingredientName: String,
        objectiveType: SkinObjectiveType,
        confidence: String,
        compatibility: RoutineCompatibilityAction,
        tolerance: ToleranceState
    ): RoutineIntensityDecision {
        val (level, reason) = when {
            // Tolerance and compatibility are hard ceilings — neither strong objective nor high
            // confidence can override them. "HIGH CONFIDENCE != AUTOMATICALLY AGGRESSIVE".
            tolerance == ToleranceState.CAUTION || compatibility == RoutineCompatibilityAction.REVIEW_REQUIRED ->
                RoutineIntensityLevel.MINIMAL to "LIMITED_BY_TOLERANCE"
            compatibility == RoutineCompatibilityAction.SEPARATE_SESSION || compatibility == RoutineCompatibilityAction.ALTERNATE ->
                RoutineIntensityLevel.MINIMAL to "BLOCKED_BY_COMPATIBILITY"
            tolerance == ToleranceState.UNKNOWN || tolerance == ToleranceState.INTRODUCING ->
                RoutineIntensityLevel.CONSERVATIVE to "CONSERVATIVE_INTRODUCTION"
            // Escalation beyond STANDARD requires the full stack to agree: objective strong
            // enough, finding confidence HIGH (not just present), tolerance already proven
            // (TOLERATED), and compatibility fully clear. "STRONG EVIDENCE != AUTOMATICALLY
            // HIGH FREQUENCY" — evidence/role is not even consulted here, only these four.
            tolerance == ToleranceState.TOLERATED &&
                compatibility == RoutineCompatibilityAction.INCLUDE &&
                confidence == "HIGH" &&
                objectiveType == SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE ->
                RoutineIntensityLevel.CAUTIOUS_ESCALATION to "MAINTAINED_DUE_TO_IMPROVEMENT"
            tolerance == ToleranceState.TOLERATED && compatibility == RoutineCompatibilityAction.INCLUDE ->
                RoutineIntensityLevel.STANDARD to "ALLOWED_COMPATIBLE_COMBINATION"
            confidence == "LOW" ->
                RoutineIntensityLevel.CONSERVATIVE to "LIMITED_BY_LOW_CONFIDENCE"
            else ->
                RoutineIntensityLevel.STANDARD to "ALLOWED_COMPATIBLE_COMBINATION"
        }
        return RoutineIntensityDecision(ingredientName, level, reason)
    }
}

// Batch 3B step 7-8 (routine change representation) audit finding: `AdjustmentCandidateStatus`
// (APPROVED/REJECTED/REVIEW_REQUIRED) + `ActivatedAdjustmentCandidate` + `changeLog` in
// RoutineAdjustmentCandidateActivator.kt already are this project's routine-change
// representation, wired into the real trend-adjustment production path. Rather than add a
// second, parallel MAINTAIN/ADD/REMOVE/PAUSE/RESUME/... model, this session extended that
// existing activator directly to also consult tolerance state (see the diff in
// RoutineAdjustmentCandidateActivator.kt) — the previous version only checked whether an
// ingredient plan had any static `caution` text at all, with no PAUSED/CAUTION-state gating.
