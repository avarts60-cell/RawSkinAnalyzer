package com.rawskinanalyzer

enum class RoutineTime { AM, PM }

data class ScheduledRoutineStep(
    val time: RoutineTime,
    val category: String,
    val role: String,
    val schedule: String,
    val rationale: String
)

data class RoutineSchedule(
    val morningSteps: List<ScheduledRoutineStep>,
    val eveningBaseSteps: List<ScheduledRoutineStep>,
    val alternatingNightSteps: List<ScheduledRoutineStep>,
    val weeklyPattern: List<String>
)

object RoutineSchedulePlanner {
    fun plan(
        strategy: RoutineStrategy,
        compatibility: RoutineAssembly
    ): RoutineSchedule {
        val include = (compatibility.morning + compatibility.evening)
            .filter { it.action == RoutineCompatibilityAction.INCLUDE }
            .distinctBy { "${it.ingredientCategory}:${it.routinePhase}" }

        val morning = include
            .filter { it.routinePhase == "AM" || it.routinePhase == "AM_OR_PM" }
            .map {
                ScheduledRoutineStep(
                    RoutineTime.AM,
                    it.ingredientCategory,
                    "COMPATIBLE_SUPPORT",
                    "DAILY_OR_AS_NEEDED",
                    it.reason
                )
            }

        val evening = include
            .filter { it.routinePhase == "PM" || it.routinePhase == "AM_OR_PM" }
            .map {
                ScheduledRoutineStep(
                    RoutineTime.PM,
                    it.ingredientCategory,
                    "COMPATIBLE_SUPPORT",
                    "DAILY_OR_AS_NEEDED",
                    it.reason
                )
            }

        val alternating = compatibility.alternating
            .filter { it.action != RoutineCompatibilityAction.REVIEW_REQUIRED }
            .distinctBy { it.ingredientCategory }
            .mapIndexed { index, decision ->
                ScheduledRoutineStep(
                    RoutineTime.PM,
                    decision.ingredientCategory,
                    if (decision.action == RoutineCompatibilityAction.ALTERNATE)
                        "ALTERNATING_TARGET" else "SEPARATE_SESSION_TARGET",
                    "NIGHT_SLOT_${index + 1}",
                    decision.reason
                )
            }

        val weekly = mutableListOf<String>()
        weekly += "AM: BASE_ROUTINE + COMPATIBLE_MORNING_SUPPORT"
        if (alternating.isEmpty()) {
            weekly += "PM: BASE_ROUTINE + COMPATIBLE_EVENING_SUPPORT"
        } else {
            alternating.forEachIndexed { index, step ->
                weekly += "PM NIGHT SLOT ${index + 1}: ${step.category}"
            }
            weekly += "PM REMAINING NIGHTS: BASE_ROUTINE + COMPATIBLE_EVENING_SUPPORT"
        }

        return RoutineSchedule(morning, evening, alternating, weekly)
    }
}
