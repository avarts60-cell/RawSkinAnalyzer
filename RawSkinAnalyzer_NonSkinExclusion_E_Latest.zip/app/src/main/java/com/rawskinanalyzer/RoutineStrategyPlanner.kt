package com.rawskinanalyzer

enum class RoutineTargetRole { PRIMARY, SECONDARY, MAINTENANCE }

data class RoutineTarget(
    val role: RoutineTargetRole,
    val concern: SkinConcernCategory,
    val objective: String,
    val rationale: String,
    // Batch 3A: the real calibrated SkinObjectiveType (from ObjectiveStrengthPolicy via
    // SkinObjectivePlanner), distinct from `role` above. `role` is derived only from this
    // target's position in the priority-sorted list (index 0/1/rest), never from the actual
    // score/confidence-calibrated strength — it was a display-order label, not a strength
    // signal. `objectiveType` is the real calibrated strength and is what downstream
    // evidence-aware candidate selection gates on. Both fields are kept because `role` is
    // still used for existing morning/evening framework text elsewhere.
    val objectiveType: SkinObjectiveType,
    val strengthReason: String
)

data class RoutineStrategy(
    val targets: List<RoutineTarget>,
    val morningFramework: List<String>,
    val eveningFramework: List<String>,
    val strategyNote: String
)

object RoutineStrategyPlanner {
    fun plan(objectives: List<SkinObjective>): RoutineStrategy {
        val ordered = objectives.sortedBy { it.priority }
        val targets = ordered.mapIndexed { index, objective ->
            val role = when (index) {
                0 -> RoutineTargetRole.PRIMARY
                1 -> RoutineTargetRole.SECONDARY
                else -> RoutineTargetRole.MAINTENANCE
            }
            RoutineTarget(
                role = role,
                concern = objective.concern,
                objective = objective.title,
                rationale = objective.rationale,
                objectiveType = objective.objectiveType,
                strengthReason = objective.strengthReason
            )
        }

        return RoutineStrategy(
            targets = targets,
            morningFramework = listOf(
                "GENTLE_CLEANSING_AS_NEEDED",
                "OBJECTIVE_COMPATIBLE_SUPPORT_STEP",
                "MOISTURIZING_SUPPORT_AS_NEEDED",
                "DAYTIME_PHOTOPROTECTION"
            ),
            eveningFramework = listOf(
                "GENTLE_CLEANSING",
                "OBJECTIVE_TARGETED_SUPPORT_STEP",
                "MOISTURIZING_SUPPORT"
            ),
            strategyNote = "Framework derived from image-based appearance objectives; ingredient, frequency, contraindication, and product selection are not yet determined."
        )
    }
}
