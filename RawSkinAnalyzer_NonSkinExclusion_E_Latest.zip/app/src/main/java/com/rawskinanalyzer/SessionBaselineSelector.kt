package com.rawskinanalyzer

/**
 * BATCH 4A — STEP 5: baseline selection.
 *
 * Audit finding: the existing architecture has no "baseline" concept at all. What
 * `ProgressScreen`/`SkinProgressTracker` call the comparison is always against
 * `SkinSessionRepository.previousSnapshot()` — the single most recent compatible session — a
 * rolling session-to-session comparison, not a fixed anchor point. That rolling comparison is
 * left completely untouched by this file (it is still exactly how session-to-session
 * `SkinProgressResult`/`LongitudinalChangeResult` above are computed). This file adds a
 * separate, additive "since baseline" comparison, answering a different question ("how does
 * today compare to where this person started tracking") without displacing the existing one.
 *
 * "Do not automatically choose a poor-quality session" / "do not silently replace a user's
 * meaningful baseline": the strategy below is deterministic and stable — given the same
 * history, it always picks the same baseline — and never changes retroactively just because a
 * later, higher-quality session appears. It only widens its candidate pool forward in time
 * (i.e. it always prefers the earliest qualifying session), so a previously-selected baseline
 * for a given history is never dethroned by something recorded after it.
 */
data class SessionBaselineSelection(
    val baseline: StoredSkinSession?,
    val quality: SessionComparabilityStatus,
    val reason: String
)

object SessionBaselineSelector {

    /**
     * [history] must already be filtered to one analysis version (e.g.
     * `SkinSessionRepository.history()` filtered by `analysisVersion`) and does not need to be
     * pre-sorted. Selection order: earliest session with a fully reliable, complete capture
     * context; if none qualifies, the earliest session with at least a non-LOW-reliability,
     * non-legacy capture context; if still none, the earliest session available at all (marked
     * with reduced baseline quality rather than left unset, since a session with unknown
     * capture context is still real, usable score data).
     */
    fun select(history: List<StoredSkinSession>): SessionBaselineSelection {
        if (history.isEmpty()) {
            return SessionBaselineSelection(null, SessionComparabilityStatus.NOT_COMPARABLE, "NO_SESSIONS_AVAILABLE")
        }
        val ordered = history.sortedBy { it.createdAtEpochMillis }

        val fullyReliable = ordered.firstOrNull {
            val ctx = it.captureContext
            ctx != null &&
                ctx.captureQualityReliability == CaptureQualityReliability.RELIABLE &&
                (ctx.usableViewCount == null || ctx.usableViewCount == 3)
        }
        if (fullyReliable != null) {
            return SessionBaselineSelection(
                fullyReliable,
                SessionComparabilityStatus.HIGHLY_COMPARABLE,
                "EARLIEST_FULLY_RELIABLE_COMPLETE_SESSION_SELECTED_AS_BASELINE"
            )
        }

        val notLow = ordered.firstOrNull {
            it.captureContext?.captureQualityReliability != CaptureQualityReliability.LOW
        }
        if (notLow != null) {
            return SessionBaselineSelection(
                notLow,
                SessionComparabilityStatus.COMPARABLE,
                "NO_FULLY_RELIABLE_SESSION_AVAILABLE_EARLIEST_ACCEPTABLE_SESSION_SELECTED_AS_BASELINE"
            )
        }

        return SessionBaselineSelection(
            ordered.first(),
            SessionComparabilityStatus.LIMITED_COMPARABILITY,
            "ONLY_LOW_RELIABILITY_SESSIONS_AVAILABLE_EARLIEST_SESSION_SELECTED_WITH_REDUCED_CONFIDENCE"
        )
    }
}
