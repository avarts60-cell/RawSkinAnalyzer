package com.rawskinanalyzer

/**
 * BATCH 4A — STEP 1/4: capture-condition metadata carried alongside a stored session.
 *
 * Audit finding: `StoredSkinSession` (SkinSessionRepository.kt) persisted only the eight
 * `SkinProgressSnapshot` scores plus the session-level `confidence` string. Nothing about
 * *how* that session was captured — capture-condition consistency
 * (`ThreeViewCaptureConditionAnalyzer`), the derived capture-quality reliability
 * (`CaptureQualityReliabilityGate`), or how many of the three required views were usable
 * (`MultiViewSkinDataFusionAnalyzer.usableViews`) — was ever written to storage. That data is
 * computed once per session, at capture time, and then discarded. A later comparison against
 * an old session had no way to know whether that old session's lighting was reliable or how
 * complete its view coverage was, which is exactly the confound Batch 4A step 4 exists to
 * prevent ("lighting differences must not automatically become pigmentation changes").
 *
 * This file adds the missing structural record. It does not compute anything new — every
 * field is a value an existing analyzer already produces at capture time
 * (`ThreeViewCaptureConditionAnalyzer.consistency`, `CaptureQualityReliabilityGate.classify`,
 * `MultiViewSkinDataFusionAnalyzer.usableViews`). `null`/absent means "not available for this
 * session" (e.g. a session stored before this field existed) and must be treated as reduced
 * information, never silently treated as ideal capture conditions.
 */
data class SessionCaptureContext(
    val captureConditionConsistency: String?,
    val captureQualityReliability: CaptureQualityReliability,
    val usableViewCount: Int?
) {
    companion object {
        /** Used only when a session predates this field's existence (legacy stored data). */
        fun unknown(): SessionCaptureContext =
            SessionCaptureContext(
                captureConditionConsistency = null,
                captureQualityReliability = CaptureQualityReliability.RELIABLE, // matches
                // CaptureQualityReliabilityGate.classify(null)'s existing "don't penalize
                // callers without the signal" convention — see that file's comment. The
                // absence is still tracked explicitly via usableViewCount == null and is
                // surfaced as reduced comparability by SessionComparabilityEvaluator below,
                // not silently ignored.
                usableViewCount = null
            )

        fun from(
            captureConditionConsistency: String?,
            usableViewCount: Int?
        ): SessionCaptureContext =
            SessionCaptureContext(
                captureConditionConsistency = captureConditionConsistency,
                captureQualityReliability = CaptureQualityReliabilityGate.classify(captureConditionConsistency),
                usableViewCount = usableViewCount
            )
    }
}
