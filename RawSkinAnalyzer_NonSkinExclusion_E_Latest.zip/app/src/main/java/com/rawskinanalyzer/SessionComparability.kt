package com.rawskinanalyzer

/**
 * BATCH 4A — STEP 2: session comparability model.
 *
 * Audit finding: nothing in the existing codebase asked "are these two sessions even
 * comparable" before comparing them. `SkinProgressTracker.compare()` and
 * `MultiSessionTrendAnalyzer.analyze()` both compare/trend raw scores across sessions
 * unconditionally (their only gate is `analysisVersion` equality, enforced upstream by
 * `SkinSessionRepository.compatibleHistory`/`latestCompatible`). Capture-condition
 * consistency, capture-quality reliability, and view-completeness were never part of that
 * decision. This file adds that missing structural gate, deliberately kept independent of
 * score severity per the batch's architecture rules.
 *
 * This does not replace analysis-version filtering (still the first, existing gate — see
 * `SkinSessionRepository`) — it is an additional, finer-grained signal evaluated once both
 * sessions are already the same analysis version.
 */
enum class SessionComparabilityStatus {
    HIGHLY_COMPARABLE,
    COMPARABLE,
    LIMITED_COMPARABILITY,
    NOT_COMPARABLE
}

data class SessionComparabilityResult(
    val status: SessionComparabilityStatus,
    val reasons: List<String>
)

object SessionComparabilityEvaluator {

    /**
     * Evaluates whether [previous] and the current session (described by [currentContext] /
     * [currentAnalysisVersion]) are sufficiently comparable. Only ever downgrades from
     * HIGHLY_COMPARABLE — there is no path that upgrades comparability based on score
     * similarity, since comparability must stay independent of score severity.
     */
    fun evaluate(
        previous: StoredSkinSession,
        currentContext: SessionCaptureContext,
        currentAnalysisVersion: String
    ): SessionComparabilityResult {
        val reasons = mutableListOf<String>()

        if (previous.analysisVersion != currentAnalysisVersion) {
            return SessionComparabilityResult(
                SessionComparabilityStatus.NOT_COMPARABLE,
                listOf("ANALYSIS_PIPELINE_VERSION_MISMATCH")
            )
        }

        val previousContext = previous.captureContext
        if (previousContext == null) {
            reasons += "PREVIOUS_SESSION_CAPTURE_METADATA_UNAVAILABLE"
        }

        val previousViews = previousContext?.usableViewCount
        val currentViews = currentContext.usableViewCount

        // View completeness: a session with fewer than 2 usable views was already excluded
        // from `analysisEligible` upstream (see `SkinDataStateResolver`), but a session with
        // exactly 2/3 usable views is analysis-eligible while still being a materially
        // different capture footprint than a full 3/3 session — treat that as reduced, not
        // blocked, comparability.
        val eitherIncomplete = (previousViews != null && previousViews < 3) ||
            (currentViews != null && currentViews < 3)
        val eitherInsufficient = (previousViews != null && previousViews < 2) ||
            (currentViews != null && currentViews < 2)
        if (eitherInsufficient) {
            return SessionComparabilityResult(
                SessionComparabilityStatus.NOT_COMPARABLE,
                reasons + "INSUFFICIENT_USABLE_VIEWS_FOR_COMPARISON"
            )
        }
        if (eitherIncomplete) reasons += "THREE_VIEW_COMPLETENESS_NOT_MET_BY_BOTH_SESSIONS"

        val reliabilities = listOfNotNull(
            previousContext?.captureQualityReliability,
            currentContext.captureQualityReliability
        )
        val anyLow = reliabilities.any { it == CaptureQualityReliability.LOW }
        val anyReduced = reliabilities.any { it == CaptureQualityReliability.REDUCED }
        if (anyLow) reasons += "CAPTURE_QUALITY_LOW_RELIABILITY_SESSION_INVOLVED"
        else if (anyReduced) reasons += "CAPTURE_QUALITY_REDUCED_RELIABILITY_SESSION_INVOLVED"

        val status = when {
            anyLow -> SessionComparabilityStatus.LIMITED_COMPARABILITY
            previousContext == null -> SessionComparabilityStatus.LIMITED_COMPARABILITY
            anyReduced || eitherIncomplete -> SessionComparabilityStatus.COMPARABLE
            else -> SessionComparabilityStatus.HIGHLY_COMPARABLE
        }

        return SessionComparabilityResult(status, reasons)
    }

    fun json(x: SessionComparabilityResult): String {
        val r = x.reasons.joinToString(",") { "\"$it\"" }
        return """{"status":"${x.status}","reasons":[$r],"medical_diagnosis":false}"""
    }
}
