package com.rawskinanalyzer

data class SessionPatternConfidence(
    val level:String,
    val score:Double,
    val viewsWithUsableData:Int,
    val spatialAgreement:String,
    val hotspotEvidence:Boolean
)

object SessionPatternConfidenceAnalyzer {
    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>,
        spatial:SpatialAgreementResult
    ):SessionPatternConfidence {
        val maps=listOf(front,left,right)
        val usable=maps.count { m -> m.count{it.skinPercent>=10.0}>=4 }
        val coverage=maps.map { m -> m.map{it.skinPercent}.average() }.average().coerceIn(0.0,100.0)
        val hotspotCount=maps.sumOf { m ->
            PatternHotspotAnalyzer.analyze(m).size
        }
        val spatialScore=when(spatial.result){
            "HIGH_SPATIAL_AGREEMENT" -> 30.0
            "MODERATE_SPATIAL_AGREEMENT" -> 20.0
            "LOW_SPATIAL_AGREEMENT" -> 8.0
            else -> 0.0
        }
        val completeness=usable/3.0*30.0
        val coverageScore=coverage/100.0*20.0
        val hotspotScore=if(hotspotCount>0)20.0 else 10.0
        val score=(completeness+coverageScore+hotspotScore+spatialScore).coerceIn(0.0,100.0)
        val level=when {
            usable<2 -> "INSUFFICIENT_EVIDENCE"
            score>=75.0 -> "HIGH"
            score>=45.0 -> "MODERATE"
            else -> "LOW"
        }
        return SessionPatternConfidence(level,score,usable,spatial.result,hotspotCount>0)
    }

    fun json(x:SessionPatternConfidence)=
        """{"level":"${x.level}","score":${x.score},"views_with_usable_data":${x.viewsWithUsableData},"spatial_agreement":"${x.spatialAgreement}","hotspot_evidence":${x.hotspotEvidence},"method":"session_pattern_confidence_v1","medical_diagnosis":false}"""
}
