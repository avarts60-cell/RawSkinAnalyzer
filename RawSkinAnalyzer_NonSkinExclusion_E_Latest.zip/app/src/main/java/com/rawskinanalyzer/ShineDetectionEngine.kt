package com.rawskinanalyzer

import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * ShineDetectionEngine
 *
 * Batch 4D-F, step_1 (P0). Dedicated surface-shine/specular-highlight evidence, built on the
 * SAME [SignalGrid] / [ConnectedComponentExtractor] architecture `FeatureCandidateDetectors`
 * already established for dark/structural candidates — reused, not duplicated, per this batch's
 * "do not create a parallel analysis backend" rule: no new tile decode path, no new candidate
 * model family, no new coordinate system.
 *
 * This is still its own DETECTION pass (own boolean mask) rather than a re-scoring of
 * `FeatureCandidateDetectors.structuralCandidateMask`, because that mask can never fire on shine:
 * its four signals are darkness, high-contrast edge, red-shift, and texture-variance elevation —
 * none of which describe a bright, low-gradient-at-its-center, near-neutral-chroma specular
 * highlight. Scoring shineLikelihood against a mask built to find dark/textured structure would
 * silently produce zero shine candidates forever, not a smaller-but-real set (this is exactly why
 * `FeatureSeparationEngine.shineLikelihood` was truthfully recorded as always-zero in Batch 4D-E
 * rather than faked against signals that can't support it — see that file's doc comment).
 *
 * Signal basis, matching step_1's own `signals` list:
 *  - high luminance: cell luma vs. the tile's own regionMeanLuma/regionLumaStdDev — tile-relative,
 *    like every other detector in this project, not a fixed absolute brightness cutoff.
 *  - chromatic characteristics / specular-highlight evidence: cb/cr distance from neutral
 *    (128,128). A true specular highlight reflects the light source directly rather than skin's
 *    sub-surface color, so it desaturates toward neutral even where surrounding skin has normal
 *    chroma. This is the SAME criterion `SkinSegmentationEngine.classify`'s SPECULAR_HIGHLIGHT
 *    exclusion already uses ("near-white, low chroma") — reused here as a per-cell continuous
 *    score instead of that engine's binary per-pixel gate, which is this step's own explicit
 *    "use existing highlight/specular exclusion information" integration requirement.
 *  - local highlight contrast: gradient magnitude at the cell scaled against the region's own
 *    gradient/luma-std baseline — a specular highlight has a sharp falloff at its boundary against
 *    surrounding skin, unlike a broad evenly-lit area, which this alone would not flag.
 *  - compactness: circularity from [ConnectedComponentExtractor], same field every other detector
 *    in this project already reports.
 *  - surrounding-skin context: the exact same [VisualFeatureCandidateEngine.skinSupportFor]
 *    weighting every structural candidate already goes through, applied unchanged here so a shine
 *    reading over low-confidence/excluded skin is down-weighted identically to any other feature.
 */
object ShineDetectionEngine {
    const val VERSION = "shine_detection_engine_v1"

    /** Cells this many local-luma std-deviations ABOVE the tile's own mean are "locally bright" — the mirror image of FeatureCandidateDetectors.DARKNESS_STD_MULTIPLIER. */
    private const val BRIGHTNESS_STD_MULTIPLIER = 1.1
    /** Chroma distance from neutral (128,128) below which a cell is treated as desaturated/specular-leaning. Matches the visual intent of SkinSegmentationEngine's SPECULAR_HIGHLIGHT gate, expressed as a radius rather than a hard mx-mn<18 test so it composes with a continuous confidence score. */
    private const val CHROMA_NEUTRAL_RADIUS = 16.0
    private const val MIN_COMPONENT_AREA_CELLS = 2

    private fun clamp01(v: Double) = max(0.0, min(1.0, v))

    // Same rationale as FeatureCandidateDetectors.maxComponentArea: bounds a shine component to a
    // plausible local-highlight size so a large, roughly-uniform overexposed capture region isn't
    // treated as one giant "shine candidate".
    private fun maxComponentArea(totalCells: Int) = max(MIN_COMPONENT_AREA_CELLS + 1, (totalCells * 0.4).toInt())

    private fun chromaDistance(cb: Double, cr: Double): Double {
        val dCb = cb - 128.0
        val dCr = cr - 128.0
        return sqrt(dCb * dCb + dCr * dCr)
    }

    fun shineMask(grid: SignalGrid): Array<BooleanArray> {
        val brightThreshold = grid.regionMeanLuma + BRIGHTNESS_STD_MULTIPLIER * grid.regionLumaStdDev
        val mask = Array(grid.rows) { BooleanArray(grid.cols) }
        for (r in 0 until grid.rows) {
            for (c in 0 until grid.cols) {
                val isBright = grid.luma[r][c] > brightThreshold
                val isDesaturated = chromaDistance(grid.cb[r][c], grid.cr[r][c]) < CHROMA_NEUTRAL_RADIUS
                // Both conditions together, mirroring SkinSegmentationEngine's own "near-white AND
                // low chroma" specular test — either alone would also flag plain bright evenly-lit
                // skin (which has normal, non-desaturated chroma), not shine specifically.
                mask[r][c] = isBright && isDesaturated
            }
        }
        return mask
    }

    fun components(grid: SignalGrid): List<GridComponent> {
        val mask = shineMask(grid)
        val total = grid.rows * grid.cols
        return ConnectedComponentExtractor.extract(mask, grid.rows, grid.cols, MIN_COMPONENT_AREA_CELLS, maxComponentArea(total))
    }

    private fun boundingBoxOriginal(grid: SignalGrid, comp: GridComponent): IntArray {
        val topLeft = grid.cellToOriginalBox(comp.minRow, comp.minCol)
        val bottomRight = grid.cellToOriginalBox(comp.maxRow, comp.maxCol)
        val x = topLeft[0]; val y = topLeft[1]
        val width = max(1, bottomRight[2] - topLeft[0])
        val height = max(1, bottomRight[3] - topLeft[1])
        return intArrayOf(x, y, width, height)
    }

    /**
     * One region's shine candidates, drawn from the SAME already-selected MICRO tiles
     * `VisualFeatureCandidateEngine.selectTiles` uses for the P0 structural pass — shine and
     * structural candidates are always sourced from identical pixels, never a second independent
     * tile sampling over the same tile pyramid.
     *
     * [boundaryContext], added Batch 4E-D step_3, is optional (defaults to null, meaning "no
     * boundary refinement available — behave exactly as before this batch") so every existing
     * caller/test keeps compiling and keeps its exact prior output. When supplied, each shine
     * candidate's own bounding-box footprint is checked against the same [PatternMapCell] grid
     * candidate-level structural evidence already uses — see
     * [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport]. This closes the gap
     * PROJECT_STATUS.md recorded after Batch 4E-C step_2 ("shine and bumps remain un-refined at
     * the boundary level ... a real, documented gap"): shine had no candidate-level skin-support
     * concept at all until now, only the tile-wide [skinSupportFor] weighting reused below
     * unchanged for `confidence`/`skinConfidence` (this addition is purely additive diagnostic
     * precision, not a re-scoring of shine confidence itself).
     */
    fun analyzeRegion(
        originalFile: File,
        tileSet: MultiScaleTileSet,
        boundaryContext: VisualFeatureCandidateEngine.CandidateBoundaryContext? = null
    ): List<ShineCandidate> {
        val out = mutableListOf<ShineCandidate>()
        var seq = 0
        for (tile in VisualFeatureCandidateEngine.selectTiles(tileSet)) {
            val grid = try { VisualSignalGridExtractor.build(originalFile, tile) } catch (e: Exception) { null } ?: continue
            val skinSupport = VisualFeatureCandidateEngine.skinSupportFor(tile)
            if (skinSupport.skinWeight <= 0.02) continue // effectively-excluded tile contributes nothing, same gate the structural pass uses

            val comps = components(grid)
            if (comps.isEmpty()) continue

            for (comp in comps) {
                var sl = 0.0; var scb = 0.0; var scr = 0.0; var sg = 0.0
                for ((r, c) in comp.cells) {
                    sl += grid.luma[r][c]; scb += grid.cb[r][c]; scr += grid.cr[r][c]; sg += grid.gradientMagnitude[r][c]
                }
                val n = max(1, comp.cells.size).toDouble()
                val meanLuma = sl / n; val meanCb = scb / n; val meanCr = scr / n; val meanGradient = sg / n

                val relativeIntensity = if (grid.regionLumaStdDev > 0.01)
                    clamp01((meanLuma - grid.regionMeanLuma) / (grid.regionLumaStdDev * 3.0))
                else clamp01((meanLuma - grid.regionMeanLuma) / 40.0)

                val chromaDesaturation = clamp01(1.0 - (chromaDistance(meanCb, meanCr) / CHROMA_NEUTRAL_RADIUS))
                val edgeContrast = clamp01(meanGradient / max(1.0, grid.regionLumaStdDev * 1.5))
                val compactness = comp.circularity

                val reasons = mutableListOf<String>()
                if (relativeIntensity > 0.4) reasons.add("luminance elevated ~${"%.1f".format(meanLuma - grid.regionMeanLuma)} above local skin mean")
                if (chromaDesaturation > 0.4) reasons.add("chroma desaturated toward neutral, consistent with specular reflectance")
                if (edgeContrast > 0.35) reasons.add("sharp local highlight boundary against surrounding skin")
                if (compactness > 0.5) reasons.add("compact rounded highlight shape")
                if (reasons.isEmpty()) reasons.add("below shine confidence threshold")

                val confidence = clamp01(
                    (0.4 * relativeIntensity + 0.3 * chromaDesaturation + 0.2 * edgeContrast + 0.1 * compactness) * skinSupport.skinWeight
                )

                val box = boundingBoxOriginal(grid, comp)
                // Batch 4E-D, step_3: candidate-own-footprint refinement, additive diagnostic
                // precision on top of the tile-wide skinSupport already used for confidence above.
                // Reuses the exact same function/contract Batch 4E-C step_2 established for
                // structural candidates — never a second, independently-derived overlap check.
                // Returns null (never a fabricated value) whenever boundaryContext is absent, the
                // footprint has zero cell overlap, or no original/normalized scale relationship is
                // available for this view.
                val refinement = boundaryContext?.let {
                    FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
                        originalBoundingBox = box, cells = it.cells, grid = it.patternGrid,
                        normalizedImageWidth = it.geom.normalizedImageWidth,
                        normalizedImageHeight = it.geom.normalizedImageHeight,
                        geom = it.geom,
                        // Batch 4E-E, step_3: same landmark-exclusion-polygon reuse as the
                        // structural-candidate path in VisualFeatureCandidateEngine.analyzeRegion.
                        landmarkExclusionPolygons = it.regionSet?.exclusions?.map { ex -> ex.points } ?: emptyList()
                    )
                }
                out.add(
                    ShineCandidate(
                        candidateId = "${tile.view}_${tile.region}_${tile.tileId}_shine${seq++}",
                        view = tile.view, region = tile.region, tileId = tile.tileId, scale = tile.scale,
                        boundingBox = box,
                        centroidX = box[0] + box[2] / 2, centroidY = box[1] + box[3] / 2,
                        areaPixels = comp.area * grid.cellSourcePixels * grid.cellSourcePixels,
                        relativeIntensity = relativeIntensity,
                        chromaDesaturation = chromaDesaturation,
                        compactness = compactness,
                        skinConfidence = skinSupport.skinConfidenceAtLocation,
                        confidence = confidence,
                        evidenceReasons = reasons,
                        boundarySkinConfidenceAtLocation = refinement?.skinCoverage,
                        boundaryHighConfidenceSkinFraction = refinement?.let {
                            if (it.skinCoverage > 0) (it.highConfidenceSkinCoverage / it.skinCoverage).coerceIn(0.0, 1.0) else 0.0
                        },
                        boundaryExclusionOverlap = refinement?.excludedCoverage,
                        boundaryCellsOverlapped = refinement?.cellsOverlapped
                    )
                )
            }
        }
        return out
    }

    fun analyzeView(
        originalFile: File,
        tileSets: List<MultiScaleTileSet>,
        boundaryContext: VisualFeatureCandidateEngine.CandidateBoundaryContext? = null
    ): List<ShineCandidate> =
        tileSets.flatMap { analyzeRegion(originalFile, it, boundaryContext) }

    /** step_1 output: regional shine density, mirroring VisualFeatureCandidateEngine.aggregate's own sampled-cell-proxy basis so figures from the two systems are directly comparable. */
    fun regionalSummary(view: String, tileSet: MultiScaleTileSet, candidates: List<ShineCandidate>): RegionalShineSummary {
        val sampledCellsProxy = max(1, candidates.size + (tileSet.microTiles.size * 25))
        val density = (candidates.size.toDouble() / sampledCellsProxy) * 1000.0
        // Batch 4E-A: real usable-skin-area basis alongside the legacy proxy above.
        val usableArea = UsableSkinAreaCalculator.forRegion(view, tileSet)
        return RegionalShineSummary(
            view = view, region = tileSet.region,
            regionSkinCoverage = tileSet.regionSkinCoverage,
            candidateCount = candidates.size,
            totalShineAreaPixels = candidates.sumOf { it.areaPixels.toLong() },
            meanRelativeIntensity = if (candidates.isEmpty()) 0.0 else candidates.map { it.relativeIntensity }.average(),
            meanConfidence = if (candidates.isEmpty()) 0.0 else candidates.map { it.confidence }.average(),
            shineDensityPer1000Cells = density,
            usableSkinAreaPixels = usableArea.usableSkinAreaPixels,
            areaBasis = usableArea.areaBasis,
            densityPerMillionUsableSkinPixels = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidates.size, usableArea.usableSkinAreaPixels)
        )
    }

    fun json(candidates: List<ShineCandidate>, summaries: List<RegionalShineSummary>): String {
        val candJson = candidates.joinToString(",") { SpecializedFeatureJson.shineCandidateJson(it) }
        val sumJson = summaries.joinToString(",") { SpecializedFeatureJson.regionalShineSummaryJson(it) }
        return """{"method":"$VERSION","candidate_count":${candidates.size},"candidates":[$candJson],"regional_summaries":[$sumJson]}"""
    }
}
