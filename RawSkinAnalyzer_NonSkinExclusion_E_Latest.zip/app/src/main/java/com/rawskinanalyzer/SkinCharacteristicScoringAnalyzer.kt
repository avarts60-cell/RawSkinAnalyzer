package com.rawskinanalyzer

data class SkinCharacteristicScore(
    val characteristic:String,
    val score:Double,
    val level:String,
    val evidence:String,
    // Batch 4D-E, step_10: "record whether a score has high-resolution feature evidence support".
    // Defaults preserve every existing call site's behavior/output shape unchanged.
    val hasHighResolutionEvidence: Boolean = false,
    val highResolutionSupportingCandidateCount: Int = 0
)

data class SkinCharacteristicScoringResult(
    val scores:List<SkinCharacteristicScore>,
    val primaryCharacteristic:String,
    val secondaryCharacteristic:String,
    val confidence:String
)

object SkinCharacteristicScoringAnalyzer {
    private fun clamp(v:Double)=v.coerceIn(0.0,100.0)

    private fun level(score:Double)=when {
        score>=60.0 -> "HIGH_SIGNAL"
        score>=30.0 -> "MODERATE_SIGNAL"
        score>=12.0 -> "LOW_SIGNAL"
        else -> "MINIMAL_SIGNAL"
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):SkinCharacteristicScoringResult {
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val tone=ToneColorFeatureAnalyzer.analyze(front,left,right)
        val texture=TextureCharacterizationAnalyzer.analyze(front,left,right)
        val localized=LocalizedFeatureAnalyzer.analyze(front,left,right)

        val redness=clamp(tone.rednessScore)
        val pigmentation=clamp(q.toneVariation*0.65 + tone.darkAreaScore*0.35)
        val darkMarks=clamp(q.darkFeatureConcentration*0.75 + localized.hotspotDensity*0.25)
        val texturePores=clamp(texture.textureVariationScore*0.75 + texture.highTextureCellPercent*0.25)
        val blemishLike=clamp(localized.hotspotDensity*0.5 +
            when(localized.repeatedFeatureSignal) {
                "HIGH_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 40.0
                "MODERATE_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 25.0
                "LOW_REPEATED_LOCALIZED_FEATURE_SIGNAL" -> 10.0
                else -> 0.0
            }*0.5)

        val scores=listOf(
            SkinCharacteristicScore("REDNESS",redness,level(redness),"localized_redness_score"),
            SkinCharacteristicScore("TONE_PIGMENTATION_VARIATION",pigmentation,level(pigmentation),"tone_variation_and_dark_area_signal"),
            SkinCharacteristicScore("DARK_MARK_SIGNAL",darkMarks,level(darkMarks),"dark_area_and_localized_feature_signal"),
            SkinCharacteristicScore("TEXTURE_PORE_SIGNAL",texturePores,level(texturePores),"texture_variation_and_high_texture_density"),
            SkinCharacteristicScore("BLEMISH_LIKE_LOCALIZED_SIGNAL",blemishLike,level(blemishLike),"hotspot_density_and_repeat_signal")
        ).sortedByDescending { it.score }

        return SkinCharacteristicScoringResult(
            scores,
            scores.first().characteristic,
            scores.getOrElse(1){scores.first()}.characteristic,
            q.confidence
        )
    }

    // Batch 4D-E, step_10. Maps each existing coarse characteristic to the specialized feature
    // types that provide it high-resolution support. This is the only place that decides which
    // dimensions of new evidence are "about" which existing characteristic — the base scoring
    // math above (`analyze`) is untouched.
    private val highResSupportMap: Map<String, Set<SpecializedFeatureType>> = mapOf(
        "REDNESS" to setOf(SpecializedFeatureType.LOCALIZED_REDNESS_LIKE),
        "TONE_PIGMENTATION_VARIATION" to setOf(SpecializedFeatureType.PIGMENTATION_LIKE),
        "DARK_MARK_SIGNAL" to setOf(SpecializedFeatureType.DARK_MARK_LIKE, SpecializedFeatureType.POST_ACNE_MARK_LIKE, SpecializedFeatureType.RED_MARK_LIKE),
        "TEXTURE_PORE_SIGNAL" to setOf(SpecializedFeatureType.PORE_LIKE, SpecializedFeatureType.FOLLICULAR_OPENING_LIKE),
        "BLEMISH_LIKE_LOCALIZED_SIGNAL" to setOf(
            SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.BLACKHEAD_LIKE, SpecializedFeatureType.WHITEHEAD_LIKE,
            SpecializedFeatureType.PAPULE_LIKE_VISUAL, SpecializedFeatureType.PUSTULE_LIKE_VISUAL
        )
    )

    /**
     * step_10/step_11: additive precision layer over the existing [analyze]. The base score for
     * every characteristic is computed exactly as before (never replaced); this overload only
     * (a) records whether SUPPORTED high-resolution evidence exists for that characteristic, and
     * (b) applies a small, capped nudge toward the high-resolution reading when that evidence is
     * strong AND well skin-supported, per step_11's "a visually strong feature with strong
     * independent evidence should receive stronger confidence" principle. The nudge is capped at
     * [MAX_HIGH_RES_NUDGE] points specifically so this can never "blindly replace" the existing
     * calibrated score architecture (step_10's explicit requirement).
     */
    private const val MAX_HIGH_RES_NUDGE = 8.0

    fun analyzeWithHighResolutionEvidence(
        front: List<PatternMapCell>, left: List<PatternMapCell>, right: List<PatternMapCell>,
        specializedEvidence: List<SpecializedFeatureEvidence>
    ): SkinCharacteristicScoringResult {
        val base = analyze(front, left, right)
        if (specializedEvidence.isEmpty()) return base

        val supportedByType = specializedEvidence
            .filter { it.classificationState == FeatureClassificationState.SUPPORTED }
            .groupBy { it.featureType }

        val adjusted = base.scores.map { s ->
            val relevantTypes = highResSupportMap[s.characteristic] ?: return@map s
            val relevant = relevantTypes.flatMap { supportedByType[it] ?: emptyList() }
            if (relevant.isEmpty()) return@map s
            // High-res signal strength: mean confidence of supporting candidates, scaled to the
            // same 0-100 range as the base score, nudging the base score toward it rather than
            // overriding it outright.
            val highResSignal = clamp(relevant.map { it.primaryConfidence }.average() * 100.0)
            val nudge = ((highResSignal - s.score) * 0.15).coerceIn(-MAX_HIGH_RES_NUDGE, MAX_HIGH_RES_NUDGE)
            val newScore = clamp(s.score + nudge)
            s.copy(
                score = newScore,
                level = level(newScore),
                hasHighResolutionEvidence = true,
                highResolutionSupportingCandidateCount = relevant.size
            )
        }.sortedByDescending { it.score }

        return SkinCharacteristicScoringResult(
            scores = adjusted,
            primaryCharacteristic = adjusted.first().characteristic,
            secondaryCharacteristic = adjusted.getOrElse(1) { adjusted.first() }.characteristic,
            confidence = base.confidence
        )
    }

    fun json(x:SkinCharacteristicScoringResult):String {
        val values=x.scores.joinToString(","){s ->
            """{"characteristic":"${s.characteristic}","score":${s.score},"level":"${s.level}","evidence":"${s.evidence}","has_high_resolution_evidence":${s.hasHighResolutionEvidence},"high_resolution_supporting_candidate_count":${s.highResolutionSupportingCandidateCount}}"""
        }
        return """{"scores":[$values],"primary_characteristic":"${x.primaryCharacteristic}","secondary_characteristic":"${x.secondaryCharacteristic}","confidence":"${x.confidence}","method":"skin_characteristic_scoring_v1","medical_diagnosis":false}"""
    }
}
