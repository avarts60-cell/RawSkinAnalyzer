package com.rawskinanalyzer

enum class SkinConcernCategory {
    TONE_PIGMENTATION,
    DARK_MARKS,
    BLEMISH_LIKE_APPEARANCE,
    REDNESS_APPEARANCE,
    PORE_TEXTURE_APPEARANCE,
    SURFACE_SHINE,
    DRYNESS_APPEARANCE
}

data class SkinConcern(
    val category: SkinConcernCategory,
    val priority: Int,
    val score: Double,
    val level: String,
    val evidenceSource: String,
    val interpretation: String,
    // Carried forward from FinalSkinFinding.confidence (Batch 3). Previously dropped at this
    // exact conversion step, which meant no downstream Brain 2 stage could see it even though
    // the underlying per-characteristic analyzer already computed it. See ObjectiveStrengthPolicy
    // in RecommendationCalibration.kt for where this is actually used.
    val confidence: String
)

object SkinConcernInterpreter {
    fun fromFinalProfile(profile: FinalSkinAnalysisProfile): List<SkinConcern> {
        return profile.findings.mapNotNull { finding ->
            val category = when (finding.characteristic) {
                "PIGMENTATION_OR_TONE_VARIATION" -> SkinConcernCategory.TONE_PIGMENTATION
                "DARK_MARK_SIGNAL" -> SkinConcernCategory.DARK_MARKS
                "BLEMISH_LIKE_FEATURES" -> SkinConcernCategory.BLEMISH_LIKE_APPEARANCE
                "REDNESS" -> SkinConcernCategory.REDNESS_APPEARANCE
                "PORE_LIKE_FEATURES", "TEXTURE_IRREGULARITY" -> SkinConcernCategory.PORE_TEXTURE_APPEARANCE
                "SURFACE_SHINE_SIGNAL" -> SkinConcernCategory.SURFACE_SHINE
                "DRYNESS_RELATED_SURFACE_SIGNAL" -> SkinConcernCategory.DRYNESS_APPEARANCE
                else -> null
            }
            category?.let {
                SkinConcern(
                    category = it,
                    priority = finding.priority,
                    score = finding.score,
                    level = finding.level,
                    evidenceSource = FinalScoreRegistry.get(finding.characteristic)?.sourceStage
                        ?: "FINAL_PROFILE",
                    interpretation = interpretationFor(it, finding.level),
                    confidence = finding.confidence
                )
            }
        }
    }

    private fun interpretationFor(
        category: SkinConcernCategory,
        level: String
    ): String = when (category) {
        SkinConcernCategory.TONE_PIGMENTATION ->
            "Visible tone or pigmentation variation signal; not a diagnosis."
        SkinConcernCategory.DARK_MARKS ->
            "Localized darker-area signal; image-derived appearance signal only."
        SkinConcernCategory.BLEMISH_LIKE_APPEARANCE ->
            "Localized feature pattern resembling blemish-related appearance; not acne diagnosis."
        SkinConcernCategory.REDNESS_APPEARANCE ->
            "Visible redness-related color variation; not an inflammation diagnosis."
        SkinConcernCategory.PORE_TEXTURE_APPEARANCE ->
            "Visible pore or surface-texture appearance signal."
        SkinConcernCategory.SURFACE_SHINE ->
            "Visible surface reflectance or shine signal."
        SkinConcernCategory.DRYNESS_APPEARANCE ->
            "Image-derived dryness-related surface appearance signal."
    }
}
