package com.rawskinanalyzer

data class SkinViewDataQuality(
    val view:String,
    val detailQuality:String,
    val skinCoverage:String,
    val patternStability:String,
    val usable:Boolean,
    val score:Double,
    val limitations:List<String>
)

data class SkinDataQualityProfile(val views:List<SkinViewDataQuality>, val overallStatus:String)

object SkinDataQualityProfileAnalyzer {
    private fun viewQuality(
        name:String,
        cells:List<PatternMapCell>,
        stability:String,
        repeatability:String
    ):SkinViewDataQuality {
        val usableCells=cells.filter{it.skinPercent>=10.0}
        val coverage=if(cells.isEmpty()) 0.0 else usableCells.size*100.0/cells.size
        val texture=if(usableCells.isEmpty()) 0.0 else usableCells.map{it.texture}.average()
        val limitations=mutableListOf<String>()
        if(coverage<20.0) limitations+="LOW_SKIN_COVERAGE"
        if(usableCells.size<4) limitations+="LIMITED_SKIN_DATA"
        if(stability=="LOW_PATTERN_STABILITY") limitations+="LOW_PATTERN_STABILITY"
        if(repeatability=="LOW_REPEATABILITY") limitations+="LOW_REPEATABILITY"

        val detail=when {
            texture>=18.0 -> "HIGH_DETAIL"
            texture>=8.0 -> "MODERATE_DETAIL"
            else -> "LIMITED_DETAIL"
        }
        if(detail=="LIMITED_DETAIL") limitations+="LIMITED_DETAIL"

        val score=(coverage*0.55 +
                when(detail){"HIGH_DETAIL"->30.0;"MODERATE_DETAIL"->20.0;else->8.0} +
                when(stability){"HIGH_PATTERN_STABILITY"->10.0;"MODERATE_PATTERN_STABILITY"->6.0;else->2.0} +
                when(repeatability){"HIGH_REPEATABILITY"->5.0;"MODERATE_REPEATABILITY"->3.0;else->1.0})
            .coerceIn(0.0,100.0)
        val usable=coverage>=20.0 && detail!="LIMITED_DETAIL"
        val coverageLabel=when {
            coverage>=60.0 -> "HIGH_SKIN_COVERAGE"
            coverage>=20.0 -> "MODERATE_SKIN_COVERAGE"
            else -> "LOW_SKIN_COVERAGE"
        }
        return SkinViewDataQuality(name,detail,coverageLabel,stability,usable,score,limitations)
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):SkinDataQualityProfile {
        val stability=PatternStabilityAnalyzer.analyze(front,left,right).result
        val repeatability=PatternRepeatabilityAnalyzer.analyze(front,left,right).result
        val views=listOf(
            viewQuality("FRONT_FACE",front,stability,repeatability),
            viewQuality("LEFT_CHEEK",left,stability,repeatability),
            viewQuality("RIGHT_CHEEK",right,stability,repeatability)
        )
        val usable=views.count{it.usable}
        val overall=when {
            usable==3 -> "FULL_SKIN_DATA_READY"
            usable>=2 -> "PARTIAL_SKIN_DATA_READY"
            else -> "INSUFFICIENT_SKIN_DATA"
        }
        return SkinDataQualityProfile(views,overall)
    }

    fun json(x:SkinDataQualityProfile):String {
        val views=x.views.joinToString(","){v ->
            val limits=v.limitations.joinToString(","){"\"$it\""}
            """{"view":"${v.view}","detail_quality":"${v.detailQuality}","skin_coverage":"${v.skinCoverage}","pattern_stability":"${v.patternStability}","usable":${v.usable},"score":${v.score},"limitations":[$limits]}"""
        }
        return """{"overall_status":"${x.overallStatus}","views":[$views],"method":"skin_data_quality_profile_v1","medical_diagnosis":false}"""
    }
}
