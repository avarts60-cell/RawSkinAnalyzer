package com.rawskinanalyzer

data class SkinFeatureQuantification(
    val dataStatus:String,
    val usableViews:Int,
    val toneVariation:Double,
    val localizedRedness:Double,
    val textureVariation:Double,
    val darkFeatureConcentration:Double,
    val localizedFeatureDensity:Double,
    val crossViewSupport:String,
    val confidence:String
)

object SkinFeatureQuantificationAnalyzer {
    private fun clamp(v:Double)=v.coerceIn(0.0,100.0)

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):SkinFeatureQuantification {
        val fusion=MultiViewSkinDataFusionAnalyzer.analyze(front,left,right)
        val usable=listOf(front,left,right).filter{m->m.count{it.skinPercent>=10.0}>=4}
        if(usable.isEmpty()) return SkinFeatureQuantification(
            "INSUFFICIENT_MULTI_VIEW_SKIN_DATA",0,0.0,0.0,0.0,0.0,0.0,
            "INSUFFICIENT_CROSS_VIEW_SUPPORT","LOW"
        )

        fun values(selector:(PatternMapCell)->Double)=usable.flatMap{m->m.filter{it.skinPercent>=10.0}.map(selector)}
        val luma=values{it.meanLuma}
        val redness=values{it.redness}
        val texture=values{it.texture}

        val lumaMean=luma.average()
        val toneVariation=clamp(kotlin.math.sqrt(luma.sumOf{(it-lumaMean)*(it-lumaMean)}/luma.size)*2.0)

        val redMean=redness.average()
        val redSpread=kotlin.math.sqrt(redness.sumOf{(it-redMean)*(it-redMean)}/redness.size)
        val localizedRedness=clamp(redSpread*3.0)

        val texMean=texture.average()
        val texSpread=kotlin.math.sqrt(texture.sumOf{(it-texMean)*(it-texMean)}/texture.size)
        val textureVariation=clamp(texSpread*2.5)

        val dark=clamp(fusion.fusedDarkAreaConcentration)
        val density=clamp(fusion.fusedLocalizedFeatureDensity)

        val confidence=when {
            fusion.overallStatus=="FULL_MULTI_VIEW_SKIN_DATA" &&
                fusion.crossViewSupport=="HIGH_CROSS_VIEW_SUPPORT" -> "HIGH"
            fusion.usableViews>=2 -> "MODERATE"
            else -> "LOW"
        }

        return SkinFeatureQuantification(
            fusion.overallStatus,fusion.usableViews,toneVariation,localizedRedness,
            textureVariation,dark,density,fusion.crossViewSupport,confidence
        )
    }

    fun json(x:SkinFeatureQuantification)=
        """{"data_status":"${x.dataStatus}","usable_views":${x.usableViews},"tone_variation":${x.toneVariation},"localized_redness":${x.localizedRedness},"texture_variation":${x.textureVariation},"dark_feature_concentration":${x.darkFeatureConcentration},"localized_feature_density":${x.localizedFeatureDensity},"cross_view_support":"${x.crossViewSupport}","confidence":"${x.confidence}","method":"skin_feature_quantification_v1","medical_diagnosis":false}"""
}
