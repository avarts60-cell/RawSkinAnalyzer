package com.rawskinanalyzer

enum class SkinObjectiveType {
    IMPROVE_VISIBLE_APPEARANCE,
    SUPPORT_BALANCE,
    MAINTAIN_CURRENT_STATE,
    MONITOR
}

data class SkinObjective(
    val concern: SkinConcernCategory,
    val priority: Int,
    val objectiveType: SkinObjectiveType,
    val title: String,
    val rationale: String,
    val evidenceSource: String,
    // Batch 3: explicit, deterministic explanation of why this objective landed at this
    // strength — see ObjectiveStrengthPolicy. Distinct from `rationale` (which explains the
    // *topic*/evidence source) so both can be read independently.
    val strengthReason: String
)

object SkinObjectivePlanner {
    /**
     * @param sessionAnalysisConfidence FinalSkinAnalysisProfile.analysisConfidence — the
     * whole-session minimum confidence across every analyzer this run. A required parameter
     * (not defaulted) so a caller cannot silently skip session-level conservatism; see
     * ObjectiveStrengthPolicy.sessionConfidenceCap.
     */
    fun plan(concerns: List<SkinConcern>, sessionAnalysisConfidence: String): List<SkinObjective> =
        concerns
            .sortedBy { it.priority }
            .map { concern ->
                val calibrated = ObjectiveStrengthPolicy.calibrate(
                    score = concern.score,
                    findingConfidence = concern.confidence,
                    sessionAnalysisConfidence = sessionAnalysisConfidence,
                    priority = concern.priority
                )
                val objectiveType = calibrated.objectiveType

                SkinObjective(
                    concern = concern.category,
                    priority = concern.priority,
                    objectiveType = objectiveType,
                    title = titleFor(concern.category, objectiveType),
                    rationale = "Derived from ${concern.evidenceSource}; image-derived ${concern.level} signal.",
                    evidenceSource = concern.evidenceSource,
                    strengthReason = calibrated.reason
                )
            }

    private fun titleFor(
        concern: SkinConcernCategory,
        type: SkinObjectiveType
    ): String = when (concern) {
        SkinConcernCategory.TONE_PIGMENTATION ->
            if (type == SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE)
                "Improve visible tone evenness" else "Support more even-looking tone"
        SkinConcernCategory.DARK_MARKS ->
            "Support the appearance of more even-looking dark-mark areas"
        SkinConcernCategory.BLEMISH_LIKE_APPEARANCE ->
            "Support a clearer-looking skin appearance"
        SkinConcernCategory.REDNESS_APPEARANCE ->
            "Support a more balanced-looking skin appearance"
        SkinConcernCategory.PORE_TEXTURE_APPEARANCE ->
            "Support smoother-looking texture and pore appearance"
        SkinConcernCategory.SURFACE_SHINE ->
            "Support balanced-looking surface shine"
        SkinConcernCategory.DRYNESS_APPEARANCE ->
            "Support comfortable-looking skin hydration"
    }
}
