package com.rawskinanalyzer

enum class ProgressDirection {
    IMPROVED,
    STABLE,
    WORSENED,
    INSUFFICIENT_COMPARISON_DATA
}

data class SkinProgressSnapshot(
    val pigmentationScore: Double,
    val darkMarkScore: Double,
    val blemishLikeScore: Double,
    val rednessScore: Double,
    val poreLikeScore: Double,
    val shineScore: Double,
    val textureScore: Double,
    val drynessScore: Double,
    val confidence: String
)

data class FeatureProgress(
    val feature: String,
    val previousScore: Double,
    val currentScore: Double,
    val delta: Double,
    val direction: ProgressDirection
)

data class SkinProgressResult(
    val features: List<FeatureProgress>,
    val overallDirection: ProgressDirection,
    val comparisonConfidence: String
)

object SkinProgressTracker {
    private const val STABLE_THRESHOLD = 3.0

    fun compare(
        previous: SkinProgressSnapshot?,
        current: SkinProgressSnapshot
    ): SkinProgressResult {
        if (previous == null) {
            return SkinProgressResult(
                features = emptyList(),
                overallDirection = ProgressDirection.INSUFFICIENT_COMPARISON_DATA,
                comparisonConfidence = "NO_PREVIOUS_SESSION"
            )
        }

        val values = listOf(
            Triple("PIGMENTATION_OR_TONE_VARIATION", previous.pigmentationScore, current.pigmentationScore),
            Triple("DARK_MARK_SIGNAL", previous.darkMarkScore, current.darkMarkScore),
            Triple("BLEMISH_LIKE_FEATURES", previous.blemishLikeScore, current.blemishLikeScore),
            Triple("REDNESS", previous.rednessScore, current.rednessScore),
            Triple("PORE_LIKE_FEATURES", previous.poreLikeScore, current.poreLikeScore),
            Triple("SURFACE_SHINE_SIGNAL", previous.shineScore, current.shineScore),
            Triple("TEXTURE_IRREGULARITY", previous.textureScore, current.textureScore),
            Triple("DRYNESS_RELATED_SURFACE_SIGNAL", previous.drynessScore, current.drynessScore)
        )

        val features = values.map { (name, old, now) ->
            val delta = now - old
            FeatureProgress(
                feature = name,
                previousScore = old,
                currentScore = now,
                delta = delta,
                direction = when {
                    delta <= -STABLE_THRESHOLD -> ProgressDirection.IMPROVED
                    delta >= STABLE_THRESHOLD -> ProgressDirection.WORSENED
                    else -> ProgressDirection.STABLE
                }
            )
        }

        val improved = features.count { it.direction == ProgressDirection.IMPROVED }
        val worsened = features.count { it.direction == ProgressDirection.WORSENED }

        val overall = when {
            improved > worsened -> ProgressDirection.IMPROVED
            worsened > improved -> ProgressDirection.WORSENED
            else -> ProgressDirection.STABLE
        }

        return SkinProgressResult(
            features = features,
            overallDirection = overall,
            comparisonConfidence = comparisonConfidence(previous, current)
        )
    }

    private fun comparisonConfidence(
        previous: SkinProgressSnapshot,
        current: SkinProgressSnapshot
    ): String =
        if (previous.confidence == "HIGH" && current.confidence == "HIGH")
            "HIGH_COMPARISON_CONFIDENCE"
        else
            "MODERATE_OR_LOWER_COMPARISON_CONFIDENCE"
}
