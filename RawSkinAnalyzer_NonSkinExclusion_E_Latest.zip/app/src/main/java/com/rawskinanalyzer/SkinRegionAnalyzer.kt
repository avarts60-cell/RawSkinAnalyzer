package com.rawskinanalyzer

import android.graphics.BitmapFactory
import java.io.File
import kotlin.math.max

data class SkinRegionResult(
    val width:Int, val height:Int, val sampled:Int, val skinPixels:Int,
    val skinPercent:Double, val meanLuma:Double,
    val meanR:Double, val meanG:Double, val meanB:Double,
    val redness:Double, val darkPercent:Double, val texture:Double
)

object SkinRegionAnalyzer {
    /**
     * Kept for backward compatibility (called directly by SkinRoiValidator / MainActivity's
     * capture-validity gate). Now delegates to the multi-signal SkinSegmentationEngine
     * ("usable skin" = HIGH or MEDIUM confidence) instead of a single RGB threshold.
     */
    fun isSkinColor(pixel:Int): Boolean {
        val r = ((pixel shr 16) and 255).toDouble()
        val g = ((pixel shr 8) and 255).toDouble()
        val bl = (pixel and 255).toDouble()
        return SkinSegmentationEngine.isUsableSkin(r, g, bl)
    }

    fun analyze(file:File): SkinRegionResult {
        val b=BitmapFactory.decodeFile(file.absolutePath)?:throw IllegalArgumentException("Cannot decode normalized image")
        val step=max(1,max(b.width,b.height)/512)
        var n=0;var skin=0;var sl=0.0;var sr=0.0;var sg=0.0;var sb=0.0;var dark=0;var tex=0.0;var tn=0
        var prevUsable=false; var prevLuma=0.0
        for(y in 0 until b.height step step) for(x in 0 until b.width step step) {
            val p=b.getPixel(x,y); val r=(p shr 16 and 255).toDouble(); val g=(p shr 8 and 255).toDouble(); val bl=(p and 255).toDouble()
            n++
            val cls = SkinSegmentationEngine.classify(r,g,bl)
            val isSkin = cls.tier==SkinConfidenceTier.HIGH || cls.tier==SkinConfidenceTier.MEDIUM
            if(isSkin){
                skin++; val l=.2126*r+.7152*g+.0722*bl
                sl+=l;sr+=r;sg+=g;sb+=bl
                if(l<55)dark++
                // Only measure local gradient between two consecutive usable-skin samples,
                // so an excluded (shadow/highlight/hair-like) neighbor doesn't inflate texture.
                if(x>=step && prevUsable){
                    tex+=kotlin.math.abs(l-prevLuma);tn++
                }
                prevUsable=true; prevLuma=l
            } else {
                prevUsable=false
            }
        }
        val d=max(1,skin).toDouble()
        val out=SkinRegionResult(b.width,b.height,n,skin,skin*100.0/max(1,n),sl/d,sr/d,sg/d,sb/d,(sr-sg)/d,dark*100.0/d,if(tn==0)0.0 else tex/tn)
        b.recycle();return out
    }
    fun json(r:SkinRegionResult) = """{"width":${r.width},"height":${r.height},"sampled_pixels":${r.sampled},"skin_pixels":${r.skinPixels},"skin_percent":${r.skinPercent},"mean_luma":${r.meanLuma},"mean_red":${r.meanR},"mean_green":${r.meanG},"mean_blue":${r.meanB},"redness_index":${r.redness},"dark_skin_percent":${r.darkPercent},"skin_texture_score":${r.texture},"method":"${SkinSegmentationEngine.VERSION}"}"""
}