package com.rawskinanalyzer

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

data class SkinRoiValidity(
    val width:Int,
    val height:Int,
    val skinPixels:Int,
    val centralSkinFraction:Double,
    val overallSkinFraction:Double,
    val valid:Boolean,
    val reason:String
)

object SkinRoiValidator {
    fun validate(bitmap:Bitmap, isSkin:(Int)->Boolean):SkinRoiValidity {
        val w=bitmap.width
        val h=bitmap.height
        var total=0
        var central=0
        var centralArea=0
        val left=(w*0.15).toInt()
        val right=(w*0.85).toInt()
        val top=(h*0.12).toInt()
        val bottom=(h*0.92).toInt()
        for(y in 0 until h step 4) for(x in 0 until w step 4) {
            val skin=isSkin(bitmap.getPixel(x,y))
            total += if(skin) 1 else 0
            if(x in left..right && y in top..bottom) {
                centralArea++
                central += if(skin) 1 else 0
            }
        }
        val samples=max(1, ((w+3)/4)*((h+3)/4))
        val overall=total.toDouble()/samples
        val center=central.toDouble()/max(1,centralArea)
        val valid=overall in 0.05..0.95 && center>=0.08
        val reason=when {
            overall < 0.05 -> "INSUFFICIENT_SKIN_SIGNAL"
            overall > 0.95 -> "MASK_TOO_BROAD"
            center < 0.08 -> "CENTRAL_FACE_ROI_INSUFFICIENT"
            else -> "ROI_PLAUSIBILITY_PASS"
        }
        return SkinRoiValidity(w,h,total,center,overall,valid,reason)
    }
}
