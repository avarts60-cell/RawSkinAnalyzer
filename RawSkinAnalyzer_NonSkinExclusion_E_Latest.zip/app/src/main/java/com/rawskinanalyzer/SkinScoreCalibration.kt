package com.rawskinanalyzer

/**
 * BATCH 1 — CORE ANALYSIS CALIBRATION FOUNDATION
 *
 * This file introduces an explicit CALIBRATION stage into the pipeline:
 *
 *   RAW VISUAL SIGNAL -> FEATURE MEASUREMENT -> NORMALIZATION -> CALIBRATION
 *   -> CHARACTERISTIC SCORE -> CONFIDENCE -> MULTI-VIEW FUSION -> FINAL PROFILE
 *
 * Before this file existed, every characteristic-producing analyzer
 * (RednessAnalysisAnalyzer, PigmentationTanningAnalyzer, BlemishFeatureAnalyzer,
 * TexturePoreFeatureAnalyzer, SurfaceConditionAnalyzer) already took normalized
 * 0-100 signals (from SkinFeatureQuantificationAnalyzer / ToneColorFeatureAnalyzer /
 * TextureCharacterizationAnalyzer / LocalizedFeatureAnalyzer) and combined them into a
 * single 0-100 characteristic score using a hardcoded weighted sum inlined in each file.
 * That combination step IS calibration — deciding how much each normalized signal
 * contributes to a final score — but it was invisible as a pipeline stage, undocumented
 * in one place, and impossible to audit or adjust without hunting through five files.
 *
 * This file centralizes that step without changing any weight or output value from the
 * prior inline formulas — it is an extraction, not a re-tuning. Each calibration function:
 *   1. Names its normalized inputs and their weights explicitly.
 *   2. Returns a CalibratedComponent carrying the score AND the inputs that produced it.
 *   3. Registers itself in CalibrationRegistry so the calibration stage is inspectable
 *      the same way FinalScoreProvenance/FinalScoreRegistry already make the FINAL
 *      PROFILE stage inspectable.
 *
 * IMPORTANT: these are software/engineering calibration weights (how already-normalized
 * pixel-derived signals are combined into one number), not clinical calibration against
 * ground-truth skin measurements. See AnalysisScorePolicy for the equivalent disclaimer
 * on level thresholds, and PROJECT_STATUS.md for the standing "not clinically validated"
 * status of the whole pipeline.
 */

data class CalibrationInput(
    val name: String,
    val normalizedValue: Double,
    val weight: Double
) {
    val contribution: Double get() = normalizedValue * weight
}

data class CalibratedComponent(
    val characteristic: String,
    val calibratedScore: Double,
    val inputs: List<CalibrationInput>,
    val calibrationVersion: String
)

/**
 * Inspectable record of every calibration computed during the most recent analysis pass.
 * Mirrors FinalScoreRegistry's pattern (clear-per-session, register-on-compute, read-back
 * for reporting/export) one pipeline stage earlier.
 */
object CalibrationRegistry {
    private val entries = linkedMapOf<String, CalibratedComponent>()
    fun clear() = entries.clear()
    fun register(component: CalibratedComponent) {
        entries[component.characteristic] = component
    }
    fun all(): List<CalibratedComponent> = entries.values.toList()
    fun get(characteristic: String): CalibratedComponent? = entries[characteristic]
}

object SkinScoreCalibration {
    const val VERSION = "CALIBRATION_V1"

    private fun calibrate(characteristic: String, inputs: List<CalibrationInput>): CalibratedComponent {
        val score = inputs.sumOf { it.contribution }.coerceIn(0.0, 100.0)
        val component = CalibratedComponent(characteristic, score, inputs, VERSION)
        CalibrationRegistry.register(component)
        return component
    }

    /** Same weights previously inlined in RednessAnalysisAnalyzer. */
    fun redness(
        localizedRedness: Double,
        withinViewVariation: Double,
        elevatedAreaPercent: Double
    ): CalibratedComponent = calibrate(
        "REDNESS",
        listOf(
            CalibrationInput("localized_redness_normalized", localizedRedness, 0.55),
            CalibrationInput("within_view_redness_variation", withinViewVariation, 2.0),
            CalibrationInput("elevated_redness_area_percent", elevatedAreaPercent, 0.25)
        )
    )

    /** Same weights previously inlined in PigmentationTanningAnalyzer. */
    fun pigmentationVariation(
        toneVariation: Double,
        withinViewLumaVariation: Double,
        darkAreaScore: Double,
        darkerAreaPercent: Double
    ): CalibratedComponent = calibrate(
        "PIGMENTATION_OR_TONE_VARIATION",
        listOf(
            CalibrationInput("tone_variation_normalized", toneVariation, 0.55),
            CalibrationInput("within_view_luma_variation", withinViewLumaVariation, 1.5),
            CalibrationInput("dark_area_score", darkAreaScore, 0.20),
            CalibrationInput("darker_area_percent", darkerAreaPercent, 0.10)
        )
    )

    /**
     * Same weights previously inlined in BlemishFeatureAnalyzer. `repeatedFeatureBonus`
     * carries weight 1.0 because the original formula added it as an already-scaled bonus
     * (0/8/18/30) rather than a normalized-then-weighted input.
     */
    fun blemishLike(
        candidatePercent: Double,
        hotspotDensity: Double,
        repeatedFeatureBonus: Double,
        localizedRedness: Double
    ): CalibratedComponent = calibrate(
        "BLEMISH_LIKE_FEATURES",
        listOf(
            CalibrationInput("candidate_area_percent", candidatePercent, 0.55),
            CalibrationInput("hotspot_density", hotspotDensity, 0.20),
            CalibrationInput("repeated_feature_bonus", repeatedFeatureBonus, 1.0),
            CalibrationInput("localized_redness_normalized", localizedRedness, 0.10)
        )
    )

    /** Same weights previously inlined in TexturePoreFeatureAnalyzer (texture component). */
    fun textureIrregularity(
        baseTextureVariationScore: Double,
        withinViewVariation: Double,
        elevatedTexturePercent: Double
    ): CalibratedComponent = calibrate(
        "TEXTURE_IRREGULARITY",
        listOf(
            CalibrationInput("base_texture_variation_score", baseTextureVariationScore, 0.6),
            CalibrationInput("within_view_texture_variation", withinViewVariation, 1.5),
            CalibrationInput("elevated_texture_area_percent", elevatedTexturePercent, 0.15)
        )
    )

    /** Same weights previously inlined in TexturePoreFeatureAnalyzer (pore-like component). */
    fun poreLike(
        poreLikePercent: Double,
        elevatedTexturePercent: Double
    ): CalibratedComponent = calibrate(
        "PORE_LIKE_FEATURES",
        listOf(
            CalibrationInput("pore_like_area_percent", poreLikePercent, 0.7),
            CalibrationInput("elevated_texture_area_percent", elevatedTexturePercent, 0.3)
        )
    )

    /** Same weights previously inlined in SurfaceConditionAnalyzer (oiliness component). */
    fun surfaceOiliness(
        highlightPercent: Double,
        textureVariation: Double
    ): CalibratedComponent = calibrate(
        "SURFACE_SHINE_SIGNAL",
        listOf(
            CalibrationInput("highlight_area_percent", highlightPercent, 0.75),
            CalibrationInput("texture_variation", textureVariation, 0.25)
        )
    )

    /** Same weights previously inlined in SurfaceConditionAnalyzer (dryness component). */
    fun surfaceDryness(
        roughAreaPercent: Double,
        textureVariation: Double
    ): CalibratedComponent = calibrate(
        "DRYNESS_RELATED_SURFACE_SIGNAL",
        listOf(
            CalibrationInput("rough_area_percent", roughAreaPercent, 0.70),
            CalibrationInput("texture_variation", textureVariation, 0.50)
        )
    )

    fun json(x: CalibratedComponent): String {
        val inputs = x.inputs.joinToString(",") { i ->
            """{"name":"${i.name}","normalized_value":${i.normalizedValue},"weight":${i.weight},"contribution":${i.contribution}}"""
        }
        return """{"characteristic":"${x.characteristic}","calibrated_score":${x.calibratedScore},"inputs":[$inputs],"calibration_version":"${x.calibrationVersion}"}"""
    }

    fun sessionJson(components: List<CalibratedComponent>): String =
        """{"calibration_version":"$VERSION","components":[${components.joinToString(",") { json(it) }}],"medical_diagnosis":false}"""
}
