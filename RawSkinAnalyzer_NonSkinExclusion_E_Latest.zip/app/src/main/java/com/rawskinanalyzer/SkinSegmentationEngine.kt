package com.rawskinanalyzer

/**
 * SkinSegmentationEngine
 *
 * Replaces the previous single-signal RGB threshold ("probable_skin_color_mask_v1")
 * with a multi-signal, confidence-weighted classification. This does NOT add face
 * detection or facial landmarks (none exist yet in this project — see
 * PROJECT_STATUS.md "Known limitations"). What it does do:
 *
 *  - Combines three independent color-space signals (raw RGB heuristic, YCbCr chroma
 *    skin-locus, HSV hue/saturation band) instead of one, so a pixel must agree across
 *    signals to be treated as high-confidence skin. This reduces sensitivity to global
 *    warm/cool color cast versus a pure RGB gate.
 *  - Explicitly separates two systematic false-skin sources that the old gate silently
 *    absorbed into "skin": specular highlights (blown-out near-white) and shadow-crushed
 *    near-black pixels. Both are now EXCLUDED with a reason instead of being counted as
 *    dark skin.
 *  - Produces a confidence tier (HIGH / MEDIUM / LOW / EXCLUDED) with a numeric weight,
 *    so downstream aggregation can down-weight uncertain pixels instead of treating every
 *    "skin" pixel identically.
 *
 * What this is NOT: it does not detect hair/beard/stubble as a distinct structure (that
 * requires orientation/elongation morphology or a real segmentation model, neither of
 * which exists here yet), and it does not use face geometry (no landmark detector is
 * integrated). Isolated dark hair pixels on skin will generally fall out as LOW/EXCLUDED
 * via the shadow and chroma checks, which reduces contamination but is not the same as
 * true hair/stubble classification. That gap is recorded as NOT_DONE in PROJECT_STATUS.md.
 */
enum class SkinConfidenceTier { HIGH, MEDIUM, LOW, EXCLUDED }

enum class ExclusionReason {
    NONE,
    NOT_SKIN_COLOR,
    SHADOW_CRUSH,
    SPECULAR_HIGHLIGHT,
    LOW_CHROMA_UNCERTAIN
}

data class SkinPixelClassification(
    val tier: SkinConfidenceTier,
    val exclusion: ExclusionReason,
    /** Contribution weight in [0.0, 1.0] for downstream weighted aggregation. */
    val weight: Double
)

object SkinSegmentationEngine {
    const val VERSION = "multi_signal_skin_confidence_v1"

    /** Legacy single-signal RGB heuristic. Kept as one of three input signals, not the sole gate. */
    private fun rgbHeuristicSkin(r: Double, g: Double, bl: Double): Boolean {
        val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)
        return r > 45 && g > 20 && bl > 10 && (mx - mn) > 12 && r >= g && r >= bl && (r - g) > 4
    }

    /** YCbCr chroma skin-locus check. Cb/Cr are largely illumination-invariant, unlike raw RGB. */
    private fun ycbcrSkin(r: Double, g: Double, bl: Double): Boolean {
        val cb = -0.1687 * r - 0.3313 * g + 0.5 * bl + 128.0
        val cr = 0.5 * r - 0.4187 * g - 0.0813 * bl + 128.0
        return cb in 77.0..135.0 && cr in 133.0..175.0
    }

    private fun hueOf(r: Double, g: Double, b: Double): Double {
        val mx = maxOf(r, g, b); val mn = minOf(r, g, b); val d = mx - mn
        if (d <= 0.0) return 0.0
        val h = when (mx) {
            r -> 60.0 * (((g - b) / d).let { if (it < 0) it + 6.0 else it }.let { it % 6.0 })
            g -> 60.0 * (((b - r) / d) + 2.0)
            else -> 60.0 * (((r - g) / d) + 4.0)
        }
        return if (h < 0) h + 360.0 else h
    }

    /** HSV hue/saturation band check. */
    private fun hsvSkin(r: Double, g: Double, bl: Double): Boolean {
        val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)
        val sat = if (mx == 0.0) 0.0 else (mx - mn) / mx
        val hue = hueOf(r, g, bl)
        val value = mx / 255.0
        return (hue in 0.0..50.0 || hue >= 340.0) && sat in 0.10..0.68 && value in 0.20..0.98
    }

    fun classify(r: Double, g: Double, bl: Double): SkinPixelClassification {
        val luma = 0.2126 * r + 0.7152 * g + 0.0722 * bl
        val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)

        // Specular highlight: near-white, low chroma. Never usable for color/texture measurement.
        if (luma > 235.0 && (mx - mn) < 18.0) {
            return SkinPixelClassification(SkinConfidenceTier.EXCLUDED, ExclusionReason.SPECULAR_HIGHLIGHT, 0.0)
        }
        // Shadow crush: too dark for any color signal to be trustworthy.
        if (luma < 25.0) {
            return SkinPixelClassification(SkinConfidenceTier.EXCLUDED, ExclusionReason.SHADOW_CRUSH, 0.0)
        }

        val agree = listOf(rgbHeuristicSkin(r, g, bl), ycbcrSkin(r, g, bl), hsvSkin(r, g, bl)).count { it }

        return when (agree) {
            3 -> SkinPixelClassification(SkinConfidenceTier.HIGH, ExclusionReason.NONE, 1.0)
            2 -> SkinPixelClassification(SkinConfidenceTier.MEDIUM, ExclusionReason.NONE, 0.6)
            1 -> SkinPixelClassification(SkinConfidenceTier.LOW, ExclusionReason.LOW_CHROMA_UNCERTAIN, 0.25)
            else -> SkinPixelClassification(SkinConfidenceTier.EXCLUDED, ExclusionReason.NOT_SKIN_COLOR, 0.0)
        }
    }

    fun classify(pixel: Int): SkinPixelClassification {
        val r = ((pixel shr 16) and 255).toDouble()
        val g = ((pixel shr 8) and 255).toDouble()
        val bl = (pixel and 255).toDouble()
        return classify(r, g, bl)
    }

    /** True for HIGH or MEDIUM confidence tiers — i.e. "usable skin" for downstream measurement. */
    fun isUsableSkin(r: Double, g: Double, bl: Double): Boolean {
        val c = classify(r, g, bl)
        return c.tier == SkinConfidenceTier.HIGH || c.tier == SkinConfidenceTier.MEDIUM
    }
}
