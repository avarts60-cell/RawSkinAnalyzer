package com.rawskinanalyzer

enum class SkinSessionIntegrityStatus {
    SESSION_DATA_VALID,
    SESSION_DATA_PARTIALLY_RECOVERED,
    SESSION_DATA_RECOVERY_FAILED
}

data class SkinSessionIntegrityTelemetry(
    val status: SkinSessionIntegrityStatus,
    val validSessionCount: Int,
    val rejectedEntryCount: Int,
    val recoveryApplied: Boolean,
    val safeHistoryAvailable: Boolean
)

object SkinSessionIntegrityTelemetryReporter {
    fun from(
        recovery: SkinSessionRecoveryResult
    ): SkinSessionIntegrityTelemetry {
        val status = runCatching {
            SkinSessionIntegrityStatus.valueOf(recovery.recoveryStatus)
        }.getOrDefault(SkinSessionIntegrityStatus.SESSION_DATA_RECOVERY_FAILED)

        return SkinSessionIntegrityTelemetry(
            status = status,
            validSessionCount = recovery.validSessions.size,
            rejectedEntryCount = recovery.rejectedEntries,
            recoveryApplied = recovery.rejectedEntries > 0,
            safeHistoryAvailable = recovery.validSessions.isNotEmpty()
        )
    }
}
