package com.rawskinanalyzer

data class SkinSessionRecoveryResult(
    val validSessions: List<StoredSkinSession>,
    val rejectedEntries: Int,
    val recoveryStatus: String
)

object SkinSessionIntegrityValidator {
    fun validate(session: StoredSkinSession): Boolean {
        if (session.sessionId.isBlank()) return false
        if (session.createdAtEpochMillis <= 0L) return false
        if (session.analysisVersion.isBlank()) return false
        return scores(session.snapshot).all { it.isFinite() && it in 0.0..100.0 }
    }

    fun recover(sessions: List<StoredSkinSession>, rejectedEntries: Int = 0): SkinSessionRecoveryResult {
        val valid = sessions.filter(::validate)
        val rejected = rejectedEntries + (sessions.size - valid.size)
        return SkinSessionRecoveryResult(
            validSessions = valid.sortedBy { it.createdAtEpochMillis },
            rejectedEntries = rejected,
            recoveryStatus = when {
                rejected == 0 -> "SESSION_DATA_VALID"
                valid.isEmpty() -> "SESSION_DATA_RECOVERY_FAILED"
                else -> "SESSION_DATA_PARTIALLY_RECOVERED"
            }
        )
    }

    private fun scores(s: SkinProgressSnapshot): List<Double> = listOf(
        s.pigmentationScore, s.darkMarkScore, s.blemishLikeScore,
        s.rednessScore, s.poreLikeScore, s.shineScore,
        s.textureScore, s.drynessScore
    )
}
