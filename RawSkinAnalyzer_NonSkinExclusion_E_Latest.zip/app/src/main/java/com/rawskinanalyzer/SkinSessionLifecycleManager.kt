package com.rawskinanalyzer

data class SkinSessionRetentionPolicy(val maxSessions: Int = 30, val retainAnalysisVersions: Int = 2)
data class SkinSessionLifecycleResult(val retained: List<StoredSkinSession>, val removedSessionIds: List<String>, val activeAnalysisVersions: List<String>)

object SkinSessionLifecycleManager {
    fun apply(sessions: List<StoredSkinSession>, policy: SkinSessionRetentionPolicy = SkinSessionRetentionPolicy()): SkinSessionLifecycleResult {
        val ordered = sessions.sortedByDescending { it.createdAtEpochMillis }
        val versions = ordered.map { it.analysisVersion }.distinct().take(policy.retainAnalysisVersions)
        val retained = ordered.filter { it.analysisVersion in versions }.take(policy.maxSessions)
        val ids = retained.map { it.sessionId }.toSet()
        return SkinSessionLifecycleResult(
            retained.sortedBy { it.createdAtEpochMillis },
            ordered.filter { it.sessionId !in ids }.map { it.sessionId },
            versions
        )
    }
}
