package com.rawskinanalyzer

data class StoredSkinSession(
    val sessionId: String,
    val createdAtEpochMillis: Long,
    val analysisVersion: String,
    val snapshot: SkinProgressSnapshot,
    // BATCH 4A — STEP 1/4: additive, nullable so every existing/legacy stored session (and
    // every existing call site that builds a `StoredSkinSession` without this argument)
    // remains valid. Null means "unknown" (see `SessionCaptureContext.unknown()`) and is
    // treated as reduced comparability, never as ideal capture conditions, by
    // `SessionComparabilityEvaluator`.
    val captureContext: SessionCaptureContext? = null,
    // BATCH 4D-H — STEP 1: additive, nullable/defaulted-empty so every existing stored session
    // (and every existing call site building a StoredSkinSession without this argument) remains
    // valid exactly as before. This is this session's OWN fused specialized feature evidence,
    // captured as step_6's `FeatureIdentityRecord` shape (already defined in
    // LongitudinalFeatureContract.kt, Batch 4D-G) — the exact records
    // `MainActivity.runFeatureCorrespondenceAndFusion()` already builds every session but never
    // had anywhere durable to go. A session with no specialized feature evidence (or saved
    // before this batch) simply has an empty list here, never null-vs-empty ambiguity for
    // callers, and is never treated as "definitely zero features" — see
    // `FeatureCaptureQuality` below for how comparison callers distinguish "no evidence
    // recorded" from "recorded and genuinely empty".
    val featureIdentityRecords: List<FeatureIdentityRecord> = emptyList(),
    // BATCH 4D-H — STEP 1: capture-quality/comparability metadata for the feature-evidence
    // layer specifically. `captureContext` above already carries characteristic-level capture
    // metadata; this is additive and specific to whether feature-level identity records for
    // THIS session are safe to match against another session's records at all (e.g. a session
    // saved before this batch has `featureEvidenceAvailable = false`, not silently zero
    // features).
    val featureEvidenceCaptureQuality: FeatureEvidenceCaptureQuality? = null
)

/**
 * BATCH 4D-H — STEP 1. Distinguishes "this session has zero specialized-feature evidence
 * recorded" (a real, comparable empty state) from "this session predates feature-evidence
 * persistence entirely" (`featureEvidenceAvailable = false`) — collapsing those two into a bare
 * empty list would make step_2/step_3 silently treat a legacy session as if it had a confirmed
 * zero-feature reading, which is exactly the "absence is not resolution" rule this batch must not
 * violate at the storage layer.
 */
data class FeatureEvidenceCaptureQuality(
    val featureEvidenceAvailable: Boolean,
    val captureConditionConsistency: String?,
    val usableViewCount: Int?
)

interface SkinSessionStore {
    fun save(session: StoredSkinSession)
    fun latestCompatible(currentAnalysisVersion: String): StoredSkinSession?
    fun history(): List<StoredSkinSession>
    fun replaceAll(sessions: List<StoredSkinSession>)
}

class InMemorySkinSessionStore : SkinSessionStore {
    private val sessions = mutableListOf<StoredSkinSession>()

    override fun save(session: StoredSkinSession) {
        sessions.removeAll { it.sessionId == session.sessionId }
        sessions += session
        sessions.sortBy { it.createdAtEpochMillis }
    }

    override fun latestCompatible(currentAnalysisVersion: String): StoredSkinSession? =
        sessions
            .filter { it.analysisVersion == currentAnalysisVersion }
            .maxByOrNull { it.createdAtEpochMillis }

    override fun history(): List<StoredSkinSession> =
        sessions.sortedByDescending { it.createdAtEpochMillis }

    override fun replaceAll(sessions: List<StoredSkinSession>) {
        this.sessions.clear()
        this.sessions.addAll(sessions)
    }
}

object SkinSessionRepository {
    private var store: SkinSessionStore = InMemorySkinSessionStore()

    fun configure(newStore: SkinSessionStore) {
        store = newStore
    }

    fun previousSnapshot(analysisVersion: String): SkinProgressSnapshot? =
        store.latestCompatible(analysisVersion)?.snapshot

    // BATCH 4A — STEP 2/5: additive. `previousSnapshot` above only ever exposed the scores,
    // never the previous session's capture context — `SessionComparabilityEvaluator` and
    // `SessionBaselineSelector` need the full `StoredSkinSession` (id, timestamp, capture
    // context), so this exposes it without changing `previousSnapshot`'s existing contract or
    // any of its existing callers.
    fun previousSession(analysisVersion: String): StoredSkinSession? =
        store.latestCompatible(analysisVersion)

    // BATCH 4D-H — STEP 2: exposes the previous comparable session's stored feature-identity
    // records specifically, for `LongitudinalFeatureContract.compareIdentities`. A thin
    // convenience over `previousSession` (no new lookup path) so a caller that only needs the
    // feature layer doesn't need to know the session-storage shape. Returns null (not an empty
    // list) when there is no previous session at all OR the previous session predates
    // feature-evidence persistence (`featureEvidenceAvailable == false`) — callers must be able
    // to tell "nothing to compare against" apart from "compared against a confirmed empty set".
    fun previousFeatureIdentityRecords(analysisVersion: String): List<FeatureIdentityRecord>? {
        val previous = previousSession(analysisVersion) ?: return null
        val quality = previous.featureEvidenceCaptureQuality
        if (quality != null && !quality.featureEvidenceAvailable) return null
        // A session saved before this batch has no `featureEvidenceCaptureQuality` at all
        // (null) — treated the same as "not available" rather than assumed to be a confirmed
        // empty reading, for the same reason as above.
        if (quality == null) return null
        return previous.featureIdentityRecords
    }

    fun save(
        sessionId: String,
        createdAtEpochMillis: Long,
        analysisVersion: String,
        snapshot: SkinProgressSnapshot,
        retentionPolicy: SkinSessionRetentionPolicy = SkinSessionRetentionPolicy(),
        // BATCH 4A — STEP 1: additive, default null preserves every existing caller's
        // behavior exactly (a session saved without this argument is simply recorded with an
        // unknown capture context, same as before this field existed).
        captureContext: SessionCaptureContext? = null,
        // BATCH 4D-H — STEP 1: additive, default-empty/null preserves every existing caller's
        // behavior exactly. Passed straight through to StoredSkinSession — this repository
        // function does not interpret or validate feature evidence, matching every other
        // parameter here.
        featureIdentityRecords: List<FeatureIdentityRecord> = emptyList(),
        featureEvidenceCaptureQuality: FeatureEvidenceCaptureQuality? = null
    ): SkinSessionLifecycleResult {
        store.save(
            StoredSkinSession(
                sessionId = sessionId,
                createdAtEpochMillis = createdAtEpochMillis,
                analysisVersion = analysisVersion,
                snapshot = snapshot,
                captureContext = captureContext,
                featureIdentityRecords = featureIdentityRecords,
                featureEvidenceCaptureQuality = featureEvidenceCaptureQuality
            )
        )
        return applyLifecyclePolicy(retentionPolicy)
    }

    fun history(): List<StoredSkinSession> = store.history()

    fun compatibleHistory(analysisVersion: String): List<SkinProgressSnapshot> =
        store.history().filter { it.analysisVersion == analysisVersion }
            .sortedBy { it.createdAtEpochMillis }.map { it.snapshot }

    fun applyLifecyclePolicy(policy: SkinSessionRetentionPolicy = SkinSessionRetentionPolicy()): SkinSessionLifecycleResult {
        val result = SkinSessionLifecycleManager.apply(store.history(), policy)
        store.replaceAll(result.retained)
        return result
    }

    // UI-2: additive — Settings' "stored data management" needs a real way to clear persisted
    // history; nothing before this session exposed that at the repository level (only
    // `replaceAll` on the private `store`). Delegates to the exact same `replaceAll` every
    // lifecycle-policy trim already uses, just with an empty list — no new storage mechanism.
    fun clearAll() {
        store.replaceAll(emptyList())
    }

    fun integrityAwareTrendConfidence(
        telemetry: SkinSessionIntegrityTelemetry,
        existingConfidence: String
    ): IntegrityAwareTrendConfidenceResult =
        IntegrityAwareTrendConfidencePolicy.evaluate(telemetry, existingConfidence)

    fun <T> applyIntegrityAwareTrendPipeline(
        trendResult: T?,
        existingConfidence: String
    ): AutomaticIntegrityAwareTrendOutput<T> =
        AutomaticIntegrityAwareTrendPipeline.apply(
            trendResult = trendResult,
            existingConfidence = existingConfidence,
            telemetry = AutomaticIntegrityAwareTrendPipeline.telemetryFrom(store)
        )

    // BATCH 4A — STEP 5: additive. Baseline selection operates over one analysis version's
    // full stored sessions (needs capture context, not just scores), mirroring the existing
    // `compatibleHistory` filter-by-version pattern used for trend history.
    fun selectBaseline(analysisVersion: String): SessionBaselineSelection =
        SessionBaselineSelector.select(store.history().filter { it.analysisVersion == analysisVersion })

}
