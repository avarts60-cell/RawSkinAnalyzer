package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/**
 * SpecializedFeatureClassifiers
 *
 * Batch 4D-E, steps 1-4 (P0). Operates on the [VisualFeatureCandidate] list Batch 4D-D's
 * [VisualFeatureCandidateEngine] already produced. Per this batch's own architecture rule
 * ("keep candidate detection separate from classification"), nothing here re-detects structure
 * from pixels — it only re-scores/re-groups the morphology + evidence a candidate already
 * carries, using regional context (other candidates in the same view+region) that Batch 4D-D's
 * per-tile classification didn't have available.
 */
object SpecializedFeatureClassifiers {
    private fun clamp01(v: Double) = max(0.0, min(1.0, v))

    // ---------------------------------------------------------------------
    // step_1: pore-vs-follicle refinement
    // ---------------------------------------------------------------------
    fun refinePoresAndFollicles(
        candidates: List<VisualFeatureCandidate>
    ): List<PoreFollicleRefinement> {
        // Regional density context: candidates classified as pore/follicular-leaning, grouped by
        // (view, region), so "local density" and "neighboring structure pattern" (this step's own
        // signals) can be computed relative to other pore-like readings in the same area rather
        // than in isolation.
        val poreLeaning = candidates.filter {
            it.evidence.poreLikelihood > 0.15 || it.evidence.follicularLikelihood > 0.15
        }
        val byRegion = poreLeaning.groupBy { it.view to it.region }
        val maxCountByRegion = byRegion.mapValues { it.value.size }
        val overallMaxCount = max(1, maxCountByRegion.values.maxOrNull() ?: 1)

        return poreLeaning.map { c ->
            val reasons = mutableListOf<String>()
            val m = c.morphology

            // compactness/circularity already computed at detection time; here we combine with
            // hair/stubble evidence (to suppress false positives Batch 4D-D's coarse pass let
            // through) and micro-scale persistence (approximated as low elongation + small area,
            // since this candidate is already MICRO-scale by construction of Batch 4D-D's engine).
            val hairSuppression = 1.0 - 0.7 * c.evidence.hairStubbleLikelihood
            val sizeFactor = clamp01(1.0 - (m.areaPixels.toDouble() / 4000.0))
            // Note: darkness is not re-derived here from raw brightness — region-relative darkness
            // is already folded into evidence.poreLikelihood upstream (FeatureSeparationEngine),
            // and morphology.brightness alone has no reliable meaning without that region mean.

            val poreConfidence = clamp01(c.evidence.poreLikelihood * hairSuppression * (0.6 + 0.4 * sizeFactor))
            val follicularConfidence = clamp01(c.evidence.follicularLikelihood * hairSuppression)

            if (poreConfidence > 0.4) reasons.add("compact micro-scale structure with low hair/stubble overlap")
            if (follicularConfidence > 0.4) reasons.add("darkness-centered compact opening distinct from surrounding skin")
            if (c.evidence.hairStubbleLikelihood > 0.3) reasons.add("partial hair/stubble overlap reduced confidence")

            val regionKey = c.view to c.region
            val regionCount = byRegion[regionKey]?.size ?: 1
            val localDensityRank = clamp01(regionCount.toDouble() / overallMaxCount)

            val visibility = when {
                max(poreConfidence, follicularConfidence) >= 0.6 -> "HIGH_VISIBILITY"
                max(poreConfidence, follicularConfidence) >= 0.35 -> "MODERATE_VISIBILITY"
                else -> "LOW_VISIBILITY"
            }

            // Apparent diameter approximated from bounding box (image-space only, per this step's
            // explicit rule to keep apparent measurements separate from physical units).
            val apparentDiameter = (m.boundingBoxWidth + m.boundingBoxHeight) / 2.0

            PoreFollicleRefinement(
                candidateId = c.candidateId,
                poreLikeConfidence = poreConfidence,
                follicularOpeningConfidence = follicularConfidence,
                apparentDiameterPixels = apparentDiameter,
                visibility = visibility,
                localDensityRank = localDensityRank,
                supportingEvidence = if (reasons.isEmpty()) listOf("below refinement confidence threshold") else reasons
            )
        }
    }

    // ---------------------------------------------------------------------
    // step_2: hair-vs-stubble refinement
    // ---------------------------------------------------------------------
    fun refineHairAndStubble(
        candidates: List<VisualFeatureCandidate>
    ): List<HairStubbleRefinement> {
        val hairLeaning = candidates.filter { it.evidence.hairStubbleLikelihood > 0.15 }
        val byRegion = hairLeaning.groupBy { it.view to it.region }

        // Batch 4D-F2, step_2: real per-region dominant orientation, from the actual
        // gradient-derived per-candidate axis [FeatureOrientationEngine] now computes (see
        // VisualFeatureCandidateEngine.analyzeRegion) instead of the previous same-region
        // candidate-count proxy. Hair growth in a given facial region tends to share a dominant
        // direction (brow/lash direction, natural stubble growth angle); a candidate whose own
        // axis agrees with that regional mode is real "repeated orientation" evidence, not a
        // population-count guess.
        val regionalAxis: Map<Pair<String, AnatomicalRegion>, Double?> = byRegion.mapValues { (_, list) ->
            FeatureOrientationEngine.circularMeanAxisDegrees(
                list.map { FeatureOrientationEngine.OrientationEstimate(it.morphology.orientationDegrees, it.morphology.orientationCoherence) }
            )
        }

        return hairLeaning.map { c ->
            val reasons = mutableListOf<String>()
            val m = c.morphology
            val clusterSize = byRegion[c.view to c.region]?.size ?: 1

            val hasOwnAxis = m.orientationDegrees >= 0.0
            val regionAxis = regionalAxis[c.view to c.region]
            // Agreement between this candidate's own gradient-derived axis and the region's
            // dominant axis, weighted by how confidently each was estimated (structure-tensor
            // coherence) — the real replacement for the old count-only clustering proxy.
            val orientationAgreement = if (hasOwnAxis && regionAxis != null) {
                val angularDistance = FeatureOrientationEngine.axisDistanceDegrees(m.orientationDegrees, regionAxis)
                clamp01(1.0 - angularDistance / 90.0) * m.orientationCoherence
            } else 0.0
            val clusteringBoost = clamp01((clusterSize - 1) / 8.0) * 0.05 + orientationAgreement * 0.2

            // Stubble is treated as the shorter/thicker end of the same elongated-dark-structure
            // spectrum hair sits on. Length (bounding-box extent) remains the primary
            // discriminator; structure-tensor coherence now also participates directly — a real
            // hair/stubble strand has a single dominant edge direction along its length (high
            // coherence), while a rounder pore/follicular/dark-mark candidate that only weakly
            // triggered hairStubbleLikelihood has gradients pointing in many directions (low
            // coherence). This is the separation-improving signal step_2 asks for, from an
            // independent measurement (gradient direction) rather than re-weighting the same
            // darkness/elongation evidence FeatureSeparationEngine already used upstream.
            val longestSide = max(m.boundingBoxWidth, m.boundingBoxHeight).toDouble()
            val isShort = longestSide < 10.0
            val coherenceFactor = if (hasOwnAxis) (0.6 + 0.4 * m.orientationCoherence) else 0.75
            val hairLike = clamp01(c.evidence.hairStubbleLikelihood * (if (isShort) 0.5 else 1.0) * coherenceFactor + clusteringBoost)
            val stubbleLike = clamp01(c.evidence.hairStubbleLikelihood * (if (isShort) 1.0 else 0.4) * coherenceFactor + clusteringBoost)

            if (hairLike > 0.4) reasons.add("elongated dark structure with extent consistent with hair")
            if (stubbleLike > 0.4) reasons.add("short elongated dark structure consistent with stubble")
            if (hasOwnAxis) reasons.add("gradient-derived axis ~${"%.0f".format(m.orientationDegrees)}\u00b0 (coherence=${"%.2f".format(m.orientationCoherence)})")
            else reasons.add("insufficient gradient energy to estimate a reliable orientation axis; treated as ambiguous")
            if (orientationAgreement > 0.4) reasons.add("axis agrees with this region's dominant hair/stubble orientation (~${"%.0f".format(regionAxis ?: -1.0)}\u00b0)")
            if (clusterSize > 3) reasons.add("part of a $clusterSize-candidate group in this region")

            HairStubbleRefinement(
                candidateId = c.candidateId,
                hairLikeConfidence = hairLike,
                stubbleLikeConfidence = stubbleLike,
                coverageContribution = m.areaPixels.toDouble(),
                evidenceReasons = if (reasons.isEmpty()) listOf("below refinement confidence threshold") else reasons
            )
        }
    }

    // ---------------------------------------------------------------------
    // step_3: dedicated blemish-family classifier
    // ---------------------------------------------------------------------
    /**
     * Distinguishes among the blemish_like candidate_classes using shape/color/context signals
     * already present on the candidate. This is a rule-based discriminator over existing evidence,
     * not a learned/trained classifier — that distinction is preserved in evidence_reasons and in
     * PROJECT_STATUS.md rather than implied by the "classifier" naming alone.
     */
    fun classifyBlemishes(
        candidates: List<VisualFeatureCandidate>,
        hairRefinements: List<HairStubbleRefinement>
    ): List<BlemishClassificationResult> {
        val hairByCandidate = hairRefinements.associateBy { it.candidateId }
        val blemishLeaning = candidates.filter { it.evidence.blemishLikeLikelihood > 0.2 }

        return blemishLeaning.map { c ->
            val reasons = mutableListOf<String>()
            val m = c.morphology
            val hairOverlap = hairByCandidate[c.candidateId]?.let { max(it.hairLikeConfidence, it.stubbleLikeConfidence) } ?: 0.0

            // Color/contrast splits: redness-dominant -> papule/pustule-visual family (inflamed
            // appearance); darkness-dominant with high compactness -> blackhead-like; low local
            // contrast with elevated brightness relative to surrounding dark structures ->
            // whitehead-like proxy (no true sebum/keratin signal exists at pixel level, so this is
            // explicitly a "visual" class per the candidate_classes naming, never a medical one).
            val rednessDominant = c.evidence.rednessLikelihood > c.evidence.darkMarkLikelihood &&
                c.evidence.rednessLikelihood > 0.3
            val darkDominant = c.evidence.darkMarkLikelihood >= c.evidence.rednessLikelihood &&
                c.morphology.circularity > 0.55

            val scores = mutableMapOf<SpecializedFeatureType, Double>()
            scores[SpecializedFeatureType.BLEMISH_LIKE] = c.evidence.blemishLikeLikelihood * (1.0 - 0.5 * hairOverlap)

            if (darkDominant) {
                val blackhead = clamp01(c.evidence.darkMarkLikelihood * m.circularity * (1.0 - 0.6 * hairOverlap))
                scores[SpecializedFeatureType.BLACKHEAD_LIKE] = blackhead
                if (blackhead > 0.35) reasons.add("compact dark structure without redness (circularity=${"%.2f".format(m.circularity)})")
            } else {
                // Whitehead-like: compact, low-to-moderate contrast, not dominated by darkness or
                // redness — a residual "compact but neither clearly dark nor clearly red" bucket.
                val neitherDominant = c.evidence.darkMarkLikelihood < 0.35 && c.evidence.rednessLikelihood < 0.35
                val whitehead = clamp01((if (neitherDominant) 0.4 else 0.15) * m.circularity * clamp01(c.evidence.poreLikelihood + c.evidence.blemishLikeLikelihood) * (1.0 - 0.6 * hairOverlap))
                scores[SpecializedFeatureType.WHITEHEAD_LIKE] = whitehead
                if (whitehead > 0.3) reasons.add("compact structure without strong dark or red signal")
            }

            if (rednessDominant) {
                // Papule vs pustule (both "visual" only, no clinical claim): pustule-visual leans
                // on a more compact/circular boundary within the red area; papule-visual is the
                // more diffuse red case. No true sebum/pus signal exists at pixel level, so
                // circularity is the only available discriminator between the two.
                val pustule = clamp01(c.evidence.rednessLikelihood * (if (m.circularity > 0.55) 0.7 else 0.3) * (1.0 - 0.5 * hairOverlap))
                val papule = clamp01(c.evidence.rednessLikelihood * (if (m.circularity <= 0.55) 0.7 else 0.4) * (1.0 - 0.5 * hairOverlap))
                scores[SpecializedFeatureType.PUSTULE_LIKE_VISUAL] = pustule
                scores[SpecializedFeatureType.PAPULE_LIKE_VISUAL] = papule
                if (max(pustule, papule) > 0.35) reasons.add("localized redness with " + (if (m.circularity > 0.55) "compact" else "diffuse") + " boundary")
            }

            val ranked = scores.entries.sortedByDescending { it.value }
            val best = ranked.first()
            val primary = if (best.value >= 0.35) best.key else SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE
            val secondary = ranked.drop(1).filter { it.value >= 0.3 }.map { it.key }

            if (reasons.isEmpty()) reasons.add("no blemish sub-class cleared its confidence threshold; retained as uncertain")
            if (hairOverlap > 0.3) reasons.add("hair/stubble overlap reduced confidence")

            BlemishClassificationResult(
                candidateId = c.candidateId,
                primaryClass = primary,
                secondaryClasses = secondary,
                confidence = best.value,
                evidenceReasons = reasons
            )
        }
    }

    // ---------------------------------------------------------------------
    // step_4: dark-mark / post-acne-mark family classifier
    // ---------------------------------------------------------------------
    fun classifyDarkFeatures(
        candidates: List<VisualFeatureCandidate>,
        hairRefinements: List<HairStubbleRefinement>,
        poreRefinements: List<PoreFollicleRefinement>
    ): List<DarkMarkClassificationResult> {
        val hairByCandidate = hairRefinements.associateBy { it.candidateId }
        val poreByCandidate = poreRefinements.associateBy { it.candidateId }
        val darkLeaning = candidates.filter { it.evidence.darkMarkLikelihood > 0.2 }

        return darkLeaning.map { c ->
            val reasons = mutableListOf<String>()
            val m = c.morphology
            val hairOverlap = hairByCandidate[c.candidateId]?.let { max(it.hairLikeConfidence, it.stubbleLikeConfidence) } ?: 0.0
            val poreOverlap = poreByCandidate[c.candidateId]?.let { max(it.poreLikeConfidence, it.follicularOpeningConfidence) } ?: 0.0
            val relativeContrast = m.localContrast

            val scores = mutableMapOf<SpecializedFeatureType, Double>()

            // Pigmentation-like: broad, low-elongation darkness with low local contrast at its own
            // boundary (a soft-edged tone shift rather than a sharp mark).
            val pigmentation = clamp01(c.evidence.darkMarkLikelihood * (1.0 - 0.5 * clamp01(relativeContrast / 40.0)) * (1.0 - 0.6 * hairOverlap) * (1.0 - 0.5 * poreOverlap))
            scores[SpecializedFeatureType.PIGMENTATION_LIKE] = pigmentation

            // Red-mark-like: darkness co-occurring with a redness signal (a healing/inflamed mark
            // reads as both darker AND more red than surrounding skin, unlike flat pigmentation).
            val redMark = clamp01(min(c.evidence.darkMarkLikelihood, c.evidence.rednessLikelihood + 0.15) * (1.0 - 0.5 * hairOverlap))
            scores[SpecializedFeatureType.RED_MARK_LIKE] = redMark

            // Post-acne-mark-like: shares shape context with red-mark/pigmentation but sits near a
            // blemish-like candidate spatially would be the ideal signal (step_4's "blemish
            // relationship") — that spatial join is not performed here (would require per-tile
            // neighbor search not yet wired), so this is approximated as the overlap of moderate
            // pigmentation AND moderate redness, both present but neither dominant, which is the
            // closest available proxy from existing evidence. This approximation is called out
          // explicitly rather than presented as a genuine spatial-relationship classifier.
            val postAcne = clamp01(min(pigmentation, redMark) * 1.3)
            scores[SpecializedFeatureType.POST_ACNE_MARK_LIKE] = postAcne

            // Generic dark-mark-like: the residual "clearly dark, not clearly pigmentation/mark"
            // bucket — sharper-edged, more compact darkness than pigmentation.
            val darkMark = clamp01(c.evidence.darkMarkLikelihood * clamp01(relativeContrast / 30.0) * (1.0 - 0.5 * hairOverlap) * (1.0 - 0.5 * poreOverlap))
            scores[SpecializedFeatureType.DARK_MARK_LIKE] = darkMark

            val ranked = scores.entries.sortedByDescending { it.value }
            val best = ranked.first()
            val primary = if (best.value >= 0.35) best.key else SpecializedFeatureType.UNCERTAIN_DARK_FEATURE
            val secondary = ranked.drop(1).filter { it.value >= 0.3 }.map { it.key }

            if (postAcne >= 0.35 && primary == SpecializedFeatureType.POST_ACNE_MARK_LIKE)
                reasons.add("moderate co-occurring pigmentation and redness signal (post-acne-mark proxy)")
            if (redMark >= 0.35 && primary == SpecializedFeatureType.RED_MARK_LIKE)
                reasons.add("darkness co-occurring with localized redness")
            if (pigmentation >= 0.35 && primary == SpecializedFeatureType.PIGMENTATION_LIKE)
                reasons.add("broad low-contrast darkness relative to region mean")
            if (darkMark >= 0.35 && primary == SpecializedFeatureType.DARK_MARK_LIKE)
                reasons.add("compact higher-contrast darkness relative to region mean")
            if (hairOverlap > 0.3) reasons.add("hair/stubble overlap reduced confidence")
            if (poreOverlap > 0.3) reasons.add("pore/follicular overlap reduced confidence")
            if (reasons.isEmpty()) reasons.add("no dark-feature sub-class cleared its confidence threshold; retained as uncertain")

            DarkMarkClassificationResult(
                candidateId = c.candidateId,
                primaryClass = primary,
                secondaryClasses = secondary,
                confidence = best.value,
                relativeContrast = relativeContrast,
                evidenceReasons = reasons
            )
        }
    }
}
