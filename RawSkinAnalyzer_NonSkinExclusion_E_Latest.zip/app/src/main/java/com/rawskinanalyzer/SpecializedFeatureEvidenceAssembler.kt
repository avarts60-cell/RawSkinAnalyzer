package com.rawskinanalyzer

import kotlin.math.max
import kotlin.math.min

/** step_9 per-(view,region,featureType) rollup of specialized evidence, normalized by usable-skin area. */
data class SpecializedRegionalMetric(
    val view: String,
    val region: AnatomicalRegion,
    val featureType: SpecializedFeatureType,
    val rawCount: Int,
    val skinWeightedCount: Double,
    /** Legacy candidate-count-based proxy (kept unchanged for backward compatibility with any
     * existing consumer of this field's old semantics). Batch 4E-A: prefer [usableSkinAreaPixels]
     * / [densityPerMillionUsableSkinPixels] below, which are real pixel-area based instead of a
     * fabricated per-tile constant. */
    val densityPer1000Cells: Double,
    val coveragePixels: Long,
    val averageApparentSizePixels: Double,
    val meanVisibility: Double,
    val meanConfidence: Double,
    val regionSkinCoverage: Double,
    // --- Batch 4E-A additions (additive; all fields above are unchanged in meaning) ---
    /** Real usable-skin-area (HIGH+MEDIUM confidence pixels) for this (view,region), from [UsableSkinAreaCalculator]. */
    val usableSkinAreaPixels: Double,
    val areaBasis: String,
    /** Real density normalized against actual usable-skin pixel area, per ~1 megapixel of usable skin. Null when usable area is zero/unavailable — never fabricated as 0.0. */
    val densityPerMillionUsableSkinPixels: Double?,
    // --- Batch 4E-B, step_5/step_9 additions (additive; every field above is unchanged in meaning) ---
    /** Per-status counts from CandidateQualityGate over this group's raw evidence. All four sum to [rawCount]. When no candidatesById map is supplied to regionalMetrics(), the gate still runs against evidence-level fields alone (coarser: no exclusion-overlap or per-candidate geometry check) -- SUPPORTED-classification evidence can still ACCEPT, everything else typically falls to INSUFFICIENT_DATA/WEIGHT. See CandidateQualityGate.evaluate's own doc for exactly what degrades without a candidate. */
    val qualityGateAcceptedCount: Int = 0,
    val qualityGateWeightedCount: Int = 0,
    val qualityGateRejectedCount: Int = 0,
    val qualityGateInsufficientDataCount: Int = 0,
    /** Sum of CandidateQualityGate.weight across every ACCEPT/WEIGHT-status item in this group (REJECT contributes 0.0; INSUFFICIENT_DATA contributes its own weight per CandidateQualityGate, honestly reduced rather than fabricated as full confidence). Always <= rawCount. */
    val qualityWeightedTotal: Double = 0.0,
    // --- Batch 4E-C, step_1 addition (additive; every field above is unchanged in meaning) ---
    /** [densityPerMillionUsableSkinPixels]'s quality-gated counterpart: numerator is
     * [qualityWeightedTotal] (REJECTed candidates contribute 0.0, WEIGHTed candidates contribute
     * only their multiplicative weight) instead of the raw [rawCount]. Same null-when-unavailable
     * contract as [densityPerMillionUsableSkinPixels] (null exactly when that field is null, since
     * they share the same usable-area denominator) -- never fabricated as 0.0. Because
     * [qualityWeightedTotal] <= [rawCount] always, this value can never exceed
     * [densityPerMillionUsableSkinPixels], satisfying "a candidate quality gate must never
     * increase evidence." [densityPerMillionUsableSkinPixels] itself is left completely unchanged
     * by this addition, per "preserve raw density separately from quality-gated density." */
    val qualityGatedDensityPerMillionUsableSkinPixels: Double? = null
)

object SpecializedFeatureEvidenceAssembler {
    private fun clamp01(v: Double) = max(0.0, min(1.0, v))

    /**
     * Runs every step_1-5 classifier over [candidates] and assembles the unified step_8 evidence
     * list. [captureConditions] keyed by view name; missing entries are handled by
     * [IlluminationAwareRednessEngine] itself (uncertainty preserved, not fabricated).
     *
     * Batch 4D-F, step_1 integration: [shineCandidates] (default empty, so every existing call
     * site keeps its exact current behavior if it never passes any) applies shine-overlap
     * confidence suppression to pore, blemish, and dark/pigmentation evidence before it's
     * assembled — a specular highlight's blown-out chroma and sharp local contrast can otherwise
     * read as compact darkness, redness, or a pore-like opening. Per this step's own
     * "prevent contamination" (not "erase") wording, overlap only reduces confidence by up to
     * 50%, capped, and is recorded in evidence_reasons — it never zeroes a reading, since a real
     * feature can legitimately sit under or beside a highlight.
     */
    fun assemble(
        candidates: List<VisualFeatureCandidate>,
        captureConditions: Map<String, CaptureConditionProfile>,
        shineCandidates: List<ShineCandidate> = emptyList()
    ): List<SpecializedFeatureEvidence> {
        val byId = candidates.associateBy { it.candidateId }
        val pores = SpecializedFeatureClassifiers.refinePoresAndFollicles(candidates)
        val hair = SpecializedFeatureClassifiers.refineHairAndStubble(candidates)
        val blemishes = SpecializedFeatureClassifiers.classifyBlemishes(candidates, hair)
        val darkFeatures = SpecializedFeatureClassifiers.classifyDarkFeatures(candidates, hair, pores)
        val redness = IlluminationAwareRednessEngine.refine(candidates, captureConditions)

        val result = mutableListOf<SpecializedFeatureEvidence>()

        pores.forEach { p ->
            val c = byId[p.candidateId] ?: return@forEach
            val primaryType = if (p.poreLikeConfidence >= p.follicularOpeningConfidence) SpecializedFeatureType.PORE_LIKE else SpecializedFeatureType.FOLLICULAR_OPENING_LIKE
            val primaryConfRaw = max(p.poreLikeConfidence, p.follicularOpeningConfidence)
            val secondaryConfRaw = min(p.poreLikeConfidence, p.follicularOpeningConfidence)
            val (primaryConf, secondaryConf, reasons) = suppressForShine(c, shineCandidates, primaryConfRaw, secondaryConfRaw, p.supportingEvidence)
            result.add(evidenceFrom(c, primaryType, primaryConf, secondaryConf, reasons, listOf("compactness", "circularity", "apparent_size", "local_darkness", "hair_stubble_evidence")))
        }

        hair.forEach { h ->
            val c = byId[h.candidateId] ?: return@forEach
            val primaryType = if (h.hairLikeConfidence >= h.stubbleLikeConfidence) SpecializedFeatureType.HAIR_LIKE else SpecializedFeatureType.STUBBLE_LIKE
            val primaryConf = max(h.hairLikeConfidence, h.stubbleLikeConfidence)
            val secondaryConf = min(h.hairLikeConfidence, h.stubbleLikeConfidence)
            result.add(evidenceFrom(c, primaryType, primaryConf, secondaryConf, h.evidenceReasons, listOf("elongation", "thinness", "edge_structure", "local_darkness", "regional_clustering")))
        }

        blemishes.forEach { b ->
            val c = byId[b.candidateId] ?: return@forEach
            val secondaryConfRaw = 0.0 // blemish classifier already reports its own secondary CLASSES, not a single scalar secondary; kept 0.0 rather than fabricated
            val specialized = when (b.primaryClass) {
                SpecializedFeatureType.BLACKHEAD_LIKE, SpecializedFeatureType.WHITEHEAD_LIKE,
                SpecializedFeatureType.PAPULE_LIKE_VISUAL, SpecializedFeatureType.PUSTULE_LIKE_VISUAL,
                SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE -> b.primaryClass
                else -> SpecializedFeatureType.BLEMISH_LIKE
            }
            val (primaryConf, secondaryConf, reasons) = suppressForShine(c, shineCandidates, b.confidence, secondaryConfRaw, b.evidenceReasons)
            result.add(evidenceFrom(c, specialized, primaryConf, secondaryConf, reasons, listOf("size", "shape", "circularity", "local_contrast", "color_characteristics", "localized_redness")))
        }

        darkFeatures.forEach { d ->
            val c = byId[d.candidateId] ?: return@forEach
            val (primaryConf, _, reasons) = suppressForShine(c, shineCandidates, d.confidence, 0.0, d.evidenceReasons)
            result.add(evidenceFrom(c, d.primaryClass, primaryConf, 0.0, reasons, listOf("local_luminance_difference", "chromatic_difference", "shape", "area", "boundary")))
        }

        redness.forEach { r ->
            val c = byId[r.candidateId] ?: return@forEach
            result.add(evidenceFrom(c, SpecializedFeatureType.LOCALIZED_REDNESS_LIKE, r.localizedRednessConfidence, 0.0, r.evidenceReasons, listOf("capture_condition", "illuminant_classification", "local_skin_reference")))
        }

        return result
    }

    private fun boxIntersectionArea(a: IntArray, b: IntArray): Long {
        val ax2 = a[0] + a[2]; val ay2 = a[1] + a[3]
        val bx2 = b[0] + b[2]; val by2 = b[1] + b[3]
        val ix = max(0, min(ax2, bx2) - max(a[0], b[0]))
        val iy = max(0, min(ay2, by2) - max(a[1], b[1]))
        return ix.toLong() * iy.toLong()
    }

    /** Fraction (0-1) of [candidate]'s own bounding-box area that overlaps the strongest-overlapping same-(view,region) shine candidate, paired with that shine candidate's own confidence. (0.0, 0.0) when nothing overlaps.
     * Batch 4E-E continued: visibility widened from `private` to `internal` so [contaminationDiagnostics]
     * below can reuse this exact same computation for diagnostics rather than re-deriving shine
     * overlap a second way — the suppression this produces (via [suppressForShine]) and the
     * diagnostics reported on it are now guaranteed to describe the same number. */
    internal fun shineOverlap(candidate: VisualFeatureCandidate, shineCandidates: List<ShineCandidate>): Pair<Double, Double> {
        if (shineCandidates.isEmpty()) return 0.0 to 0.0
        val box = intArrayOf(candidate.morphology.boundingBoxX, candidate.morphology.boundingBoxY, candidate.morphology.boundingBoxWidth, candidate.morphology.boundingBoxHeight)
        val candidateArea = max(1, candidate.morphology.boundingBoxWidth * candidate.morphology.boundingBoxHeight)
        var bestFraction = 0.0
        var bestShineConfidence = 0.0
        for (s in shineCandidates) {
            if (s.view != candidate.view || s.region != candidate.region) continue
            val inter = boxIntersectionArea(box, s.boundingBox)
            if (inter <= 0) continue
            val fraction = inter.toDouble() / candidateArea
            if (fraction > bestFraction) { bestFraction = fraction; bestShineConfidence = s.confidence }
        }
        return clamp01(bestFraction) to clamp01(bestShineConfidence)
    }

    /** Applies shine-overlap suppression to a (primaryConfidence, secondaryConfidence, evidenceReasons) triple. Suppression is capped at 50% and only ever reduces confidence — it never adds a reading or turns a candidate uncertain outright, per step_1's "prevent contamination" (not "erase") requirement. */
    private fun suppressForShine(
        candidate: VisualFeatureCandidate,
        shineCandidates: List<ShineCandidate>,
        primaryConfidence: Double,
        secondaryConfidence: Double,
        evidenceReasons: List<String>
    ): Triple<Double, Double, List<String>> {
        val (overlapFraction, shineConfidence) = shineOverlap(candidate, shineCandidates)
        if (overlapFraction <= 0.0) return Triple(primaryConfidence, secondaryConfidence, evidenceReasons)
        val suppressionFactor = 1.0 - (0.5 * overlapFraction * shineConfidence)
        val reasons = evidenceReasons + "confidence reduced: overlaps a detected shine/highlight region (${"%.0f".format(overlapFraction * 100)}% of area)"
        return Triple(clamp01(primaryConfidence * suppressionFactor), clamp01(secondaryConfidence * suppressionFactor), reasons)
    }

    private fun evidenceFrom(
        c: VisualFeatureCandidate,
        featureType: SpecializedFeatureType,
        primaryConfidence: Double,
        secondaryConfidence: Double,
        evidenceReasons: List<String>,
        supportingSignals: List<String>
    ): SpecializedFeatureEvidence {
        val m = c.morphology
        val shape = when {
            m.elongation >= 2.5 -> "ELONGATED"
            m.circularity >= 0.6 -> "COMPACT_ROUND"
            else -> "IRREGULAR"
        }
        return SpecializedFeatureEvidence(
            featureType = featureType,
            candidateId = c.candidateId,
            primaryConfidence = clamp01(primaryConfidence),
            secondaryConfidence = clamp01(secondaryConfidence),
            sourceView = c.view,
            anatomicalRegion = c.region,
            sourceCoordinates = m.centroidX to m.centroidY,
            boundingBox = intArrayOf(m.boundingBoxX, m.boundingBoxY, m.boundingBoxWidth, m.boundingBoxHeight),
            scale = c.scale,
            area = m.areaPixels,
            shape = shape,
            skinConfidence = c.skinSupport.skinConfidenceAtLocation,
            supportingSignals = supportingSignals,
            evidenceReasons = evidenceReasons,
            classificationState = SpecializedFeatureEvidence.stateFor(primaryConfidence, c.skinSupport.skinWeight, secondaryConfidence)
        )
    }

    // ---------------------------------------------------------------------
    // step_9: regional feature metrics
    // ---------------------------------------------------------------------
    fun regionalMetrics(
        evidence: List<SpecializedFeatureEvidence>,
        tileSetsByView: Map<String, List<MultiScaleTileSet>>,
        // Batch 4E-B, step_5/step_9: optional -- every existing call site that doesn't pass these
        // (there were two before this batch, both in MainActivity) keeps computing every field
        // above exactly as before. The gate itself always runs (over evidence-level fields at
        // minimum), but without candidatesById it cannot check exclusion-overlap/candidate-level
        // confidence, so most decisions land as INSUFFICIENT_DATA/WEIGHT rather than ACCEPT --
        // see CandidateQualityGate.evaluate's own doc for exactly what degrades.
        candidatesById: Map<String, VisualFeatureCandidate> = emptyMap(),
        captureQuality: CaptureQualityReliability = CaptureQualityReliability.RELIABLE
    ): List<SpecializedRegionalMetric> {
        val grouped = evidence.groupBy { Triple(it.sourceView, it.anatomicalRegion, it.featureType) }

        return grouped.map { (key, list) ->
            val (view, region, type) = key
            val tileSet = tileSetsByView[view]?.firstOrNull { it.region == region }
            val regionSkinCoverage = tileSet?.regionSkinCoverage ?: 0.0
            val skinWeightedCount = list.sumOf { it.skinConfidence / 100.0 }
            // Sampled-cell proxy mirrors VisualFeatureCandidateEngine.aggregate's own approach
            // (candidate count plus a per-tile constant) so density figures from this step are
            // comparable to Batch 4D-D's existing densityByType rather than using an incompatible
            // basis.
            val sampledCellsProxy = max(1, list.size + (tileSet?.microTiles?.size ?: 0) * 25)
            val density = (list.size.toDouble() / sampledCellsProxy) * 1000.0
            // Batch 4E-A, step_1/step_2: real usable-skin-area basis, replacing the proxy above
            // for any consumer that wants an actual area-normalized density.
            val usableArea = tileSet?.let { UsableSkinAreaCalculator.forRegion(view, it) }

            // Batch 4E-B, step_5: CandidateQualityGate.evaluateAll never drops an item -- exactly
            // one decision per evidence item in this group, keyed by candidateId.
            val decisions = CandidateQualityGate.evaluateAll(list, candidatesById, captureQuality)
            val accepted = decisions.values.count { it.status == CandidateQualityStatus.ACCEPT }
            val weighted = decisions.values.count { it.status == CandidateQualityStatus.WEIGHT }
            val rejected = decisions.values.count { it.status == CandidateQualityStatus.REJECT }
            val insufficient = decisions.values.count { it.status == CandidateQualityStatus.INSUFFICIENT_DATA }
            val weightedTotal = decisions.values.sumOf { it.weight }

            SpecializedRegionalMetric(
                view = view,
                region = region,
                featureType = type,
                rawCount = list.size,
                skinWeightedCount = skinWeightedCount,
                densityPer1000Cells = density,
                coveragePixels = list.sumOf { it.area.toLong() },
                averageApparentSizePixels = list.map { it.area }.average(),
                meanVisibility = list.map { it.primaryConfidence }.average(),
                meanConfidence = list.map { it.primaryConfidence }.average(),
                regionSkinCoverage = regionSkinCoverage,
                usableSkinAreaPixels = usableArea?.usableSkinAreaPixels ?: 0.0,
                areaBasis = usableArea?.areaBasis ?: "UNAVAILABLE",
                densityPerMillionUsableSkinPixels = usableArea?.let {
                    UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(list.size, it.usableSkinAreaPixels)
                },
                qualityGateAcceptedCount = accepted,
                qualityGateWeightedCount = weighted,
                qualityGateRejectedCount = rejected,
                qualityGateInsufficientDataCount = insufficient,
                qualityWeightedTotal = weightedTotal,
                // Batch 4E-C, step_1: same usable-area denominator as the raw density above, but
                // REJECT contributes 0.0 and WEIGHT contributes only its own weight -- see the
                // field's own doc on SpecializedRegionalMetric.
                qualityGatedDensityPerMillionUsableSkinPixels = usableArea?.let {
                    UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(weightedTotal, it.usableSkinAreaPixels)
                }
            )
        }
    }

    fun json(evidence: List<SpecializedFeatureEvidence>, metrics: List<SpecializedRegionalMetric>): String {
        val evJson = evidence.joinToString(",") { SpecializedFeatureJson.evidenceJson(it) }
        val metricJson = metrics.joinToString(",") { m ->
            """{"view":"${m.view}","region":"${m.region}","feature_type":"${m.featureType}","raw_count":${m.rawCount},"skin_weighted_count":${m.skinWeightedCount},"density_per_1000_cells":${m.densityPer1000Cells},"coverage_pixels":${m.coveragePixels},"average_apparent_size_pixels":${m.averageApparentSizePixels},"mean_visibility":${m.meanVisibility},"mean_confidence":${m.meanConfidence},"region_skin_coverage":${m.regionSkinCoverage},"usable_skin_area_pixels":${m.usableSkinAreaPixels},"area_basis":"${m.areaBasis}","density_per_million_usable_skin_pixels":${m.densityPerMillionUsableSkinPixels ?: "null"},"quality_gate":{"accepted":${m.qualityGateAcceptedCount},"weighted":${m.qualityGateWeightedCount},"rejected":${m.qualityGateRejectedCount},"insufficient_data":${m.qualityGateInsufficientDataCount},"weighted_total":${m.qualityWeightedTotal},"quality_gated_density_per_million_usable_skin_pixels":${m.qualityGatedDensityPerMillionUsableSkinPixels ?: "null"}}}"""
        }
        return """{"method":"specialized_feature_evidence_v1","evidence_count":${evidence.size},"evidence":[$evJson],"regional_metrics":[$metricJson]}"""
    }

    // ---------------------------------------------------------------------
    // Batch 4E-E continued, EXACT REMAINING WORK item #2: numeric hair/stubble and shine
    // contamination diagnostics. Reuses the SAME shine-overlap computation `suppressForShine`
    // itself already applies to pore/blemish/dark-mark evidence (via the now-`internal`
    // [shineOverlap]) and the SAME `evidence.hairStubbleLikelihood` field
    // `SpecializedFeatureClassifiers`'s own pore/blemish/dark-mark refiners already key their own
    // same-candidate hair suppression off of -- this reports what those two contamination sources
    // are ALREADY doing to confidence, in numeric/aggregate form, rather than only as an
    // evidence-reason string. Nothing about suppression itself changes; this is read-only
    // diagnostics, same truthfulness contract as the rest of this object.
    // ---------------------------------------------------------------------
    data class ContaminationDiagnostics(
        val view: String,
        val candidateCount: Int,
        /** Candidates whose own footprint overlaps a shine/specular-highlight candidate at all (the same >0.0 trigger [suppressForShine] itself uses). */
        val candidatesWithShineOverlap: Int,
        /** Mean shine-overlap fraction (0-1) across [candidatesWithShineOverlap] only -- 0.0 when none. */
        val meanShineOverlapFraction: Double,
        /** Mean confidence of the overlapping shine candidate itself, across [candidatesWithShineOverlap] only. */
        val meanShineConfidenceWhereOverlapping: Double,
        /** Mean of the actual multiplicative suppression factor [suppressForShine] applies (1.0 = no suppression, floor 0.5 = the maximum -50% this project's rules allow), across [candidatesWithShineOverlap] only. */
        val meanShineSuppressionFactor: Double,
        /** Candidates carrying ANY hair/stubble evidence signal on their own -- the same `evidence.hairStubbleLikelihood > 0` reading `refinePoresAndFollicles`'s own `hairSuppression` term (and, via `refineHairAndStubble`, the blemish/dark-mark classifiers' `hairOverlap` term) already act on. */
        val candidatesWithHairStubbleSignal: Int,
        /** Mean `evidence.hairStubbleLikelihood` across [candidatesWithHairStubbleSignal] only -- 0.0 when none. */
        val meanHairStubbleLikelihoodWherePresent: Double
    )

    fun contaminationDiagnostics(
        view: String,
        candidates: List<VisualFeatureCandidate>,
        shineCandidates: List<ShineCandidate> = emptyList()
    ): ContaminationDiagnostics {
        val shineOverlaps = candidates.map { it to shineOverlap(it, shineCandidates) }
        val withShine = shineOverlaps.filter { (_, ov) -> ov.first > 0.0 }
        val withHair = candidates.filter { it.evidence.hairStubbleLikelihood > 0.0 }
        return ContaminationDiagnostics(
            view = view,
            candidateCount = candidates.size,
            candidatesWithShineOverlap = withShine.size,
            meanShineOverlapFraction = if (withShine.isEmpty()) 0.0 else withShine.map { it.second.first }.average(),
            meanShineConfidenceWhereOverlapping = if (withShine.isEmpty()) 0.0 else withShine.map { it.second.second }.average(),
            meanShineSuppressionFactor = if (withShine.isEmpty()) 1.0 else withShine.map { (_, ov) -> 1.0 - (0.5 * ov.first * ov.second) }.average(),
            candidatesWithHairStubbleSignal = withHair.size,
            meanHairStubbleLikelihoodWherePresent = if (withHair.isEmpty()) 0.0 else withHair.map { it.evidence.hairStubbleLikelihood }.average()
        )
    }

    fun contaminationDiagnosticsJson(d: ContaminationDiagnostics): String =
        """{"view":"${d.view}","candidate_count":${d.candidateCount},"candidates_with_shine_overlap":${d.candidatesWithShineOverlap},"mean_shine_overlap_fraction":${d.meanShineOverlapFraction},"mean_shine_confidence_where_overlapping":${d.meanShineConfidenceWhereOverlapping},"mean_shine_suppression_factor":${d.meanShineSuppressionFactor},"candidates_with_hair_stubble_signal":${d.candidatesWithHairStubbleSignal},"mean_hair_stubble_likelihood_where_present":${d.meanHairStubbleLikelihoodWherePresent}}"""
}
