package com.rawskinanalyzer

/**
 * SpecializedFeatureModels
 *
 * Batch 4D-E, step_8. This is the unified evidence representation every specialized classifier
 * in this batch (pore/follicle, hair/stubble, blemish, dark-mark) reports through, per
 * `step_8_feature_evidence_model.desired_fields`. It is deliberately a thin wrapper layer over
 * the already-existing [VisualFeatureCandidate] (Batch 4D-D) rather than a replacement — every
 * field this batch's handoff asks to "preserve" (source coordinates, anatomical region, scale,
 * skin confidence, evidence reasons) is read from the underlying candidate, not re-derived.
 *
 * `classificationState` (SUPPORTED / PARTIALLY_SUPPORTED / UNCERTAIN) is the batch's own addition:
 * it exists so a downstream consumer can tell "this is a confident reading" apart from "the
 * evidence for this candidate was thin" without re-deriving that judgment from raw confidence
 * numbers every time.
 */

enum class SpecializedFeatureType {
    PORE_LIKE, FOLLICULAR_OPENING_LIKE,
    HAIR_LIKE, STUBBLE_LIKE,
    BLEMISH_LIKE, BLACKHEAD_LIKE, WHITEHEAD_LIKE, PAPULE_LIKE_VISUAL, PUSTULE_LIKE_VISUAL, UNCERTAIN_BLEMISH_LIKE,
    DARK_MARK_LIKE, PIGMENTATION_LIKE, RED_MARK_LIKE, POST_ACNE_MARK_LIKE, UNCERTAIN_DARK_FEATURE,
    LOCALIZED_REDNESS_LIKE,
    // Batch 4D-F2, step_1
    BUMP_LIKE, SURFACE_STRUCTURE_LIKE, UNCERTAIN_SURFACE_STRUCTURE
}

enum class FeatureClassificationState { SUPPORTED, PARTIALLY_SUPPORTED, UNCERTAIN }

/** step_8's unified evidence record. One of these is produced per (candidate, specialized-dimension) pairing — a single candidate can carry more than one (e.g. a dark-mark classifier result AND a pore-refinement result) if both dimensions had something to say about it. */
data class SpecializedFeatureEvidence(
    val featureType: SpecializedFeatureType,
    val candidateId: String,
    val primaryConfidence: Double,
    val secondaryConfidence: Double,
    val sourceView: String,
    val anatomicalRegion: AnatomicalRegion,
    val sourceCoordinates: Pair<Int, Int>,
    val boundingBox: IntArray,
    val scale: AnalysisScale,
    val area: Int,
    val shape: String,
    val skinConfidence: Double,
    val supportingSignals: List<String>,
    val evidenceReasons: List<String>,
    val classificationState: FeatureClassificationState
) {
    companion object {
        /** Shared SUPPORTED/PARTIALLY_SUPPORTED/UNCERTAIN thresholding so every specialized classifier in this batch applies the same bar (step_8's own consistency requirement) instead of each inventing its own cutoffs. */
        fun stateFor(primaryConfidence: Double, skinWeight: Double, secondaryConfidence: Double): FeatureClassificationState = when {
            primaryConfidence >= 0.55 && skinWeight >= 0.5 -> FeatureClassificationState.SUPPORTED
            primaryConfidence >= 0.35 || (primaryConfidence >= 0.25 && secondaryConfidence >= 0.3) -> FeatureClassificationState.PARTIALLY_SUPPORTED
            else -> FeatureClassificationState.UNCERTAIN
        }
    }
}

/** step_1 output: pore-vs-follicle refinement for one candidate. */
data class PoreFollicleRefinement(
    val candidateId: String,
    val poreLikeConfidence: Double,
    val follicularOpeningConfidence: Double,
    val apparentDiameterPixels: Double,
    val visibility: String, // LOW_VISIBILITY / MODERATE_VISIBILITY / HIGH_VISIBILITY
    val localDensityRank: Double, // 0-1, this candidate's neighborhood density relative to its region's max
    val supportingEvidence: List<String>
)

/** step_2 output: hair-vs-stubble refinement for one candidate. */
data class HairStubbleRefinement(
    val candidateId: String,
    val hairLikeConfidence: Double,
    val stubbleLikeConfidence: Double,
    val coverageContribution: Double, // this candidate's own contribution to regional hair/stubble coverage, in original-image pixels
    val evidenceReasons: List<String>
)

/** step_3 output: dedicated blemish-family classification for one candidate. */
data class BlemishClassificationResult(
    val candidateId: String,
    val primaryClass: SpecializedFeatureType,
    val secondaryClasses: List<SpecializedFeatureType>,
    val confidence: Double,
    val evidenceReasons: List<String>
)

/** step_4 output: dark-structure family classification for one candidate. */
data class DarkMarkClassificationResult(
    val candidateId: String,
    val primaryClass: SpecializedFeatureType,
    val secondaryClasses: List<SpecializedFeatureType>,
    val confidence: Double,
    val relativeContrast: Double,
    val evidenceReasons: List<String>
)

/** step_5 output: illumination-aware localized redness for one candidate. */
data class LocalizedRednessRefinement(
    val candidateId: String,
    val localizedRednessConfidence: Double,
    val colorCastAdjustedDeltaCr: Double,
    val illuminationReliable: Boolean,
    val evidenceReasons: List<String>
)

/** Batch 4D-F, step_1 output: one detected shine/specular-highlight structure. Deliberately its
 * own model rather than reusing [SpecializedFeatureEvidence] — shine candidates come from a
 * bright/desaturated mask ([ShineDetectionEngine]), not from [VisualFeatureCandidate] the way
 * every step_1-5 (Batch 4D-E) classifier above does, so it has no underlying `candidateId` to
 * join against. `view`/`region`/`boundingBox` are still original-image-coordinate and
 * anatomical-region-tagged, so downstream consumers (contamination suppression, surface-condition
 * high-res nudge) can still match it against other evidence by location. */
data class ShineCandidate(
    val candidateId: String,
    val view: String,
    val region: AnatomicalRegion,
    val tileId: String,
    val scale: AnalysisScale,
    val boundingBox: IntArray,
    val centroidX: Int,
    val centroidY: Int,
    val areaPixels: Int,
    /** 0-1, this candidate's mean brightness above the tile's own regional mean, scaled by regional std-dev. */
    val relativeIntensity: Double,
    /** 0-1, chroma desaturation toward neutral (128,128) — the same signal SkinSegmentationEngine's SPECULAR_HIGHLIGHT exclusion uses, as a continuous score instead of a binary gate. */
    val chromaDesaturation: Double,
    /** Circularity from ConnectedComponentExtractor — compact round highlights score higher than diffuse bright patches. */
    val compactness: Double,
    val skinConfidence: Double,
    val confidence: Double,
    val evidenceReasons: List<String>,
    // --- Batch 4E-D, step_3 additions (additive; every field above is unchanged in meaning and
    // is still computed exactly as before). Mirrors CandidateSkinSupport's own boundary-refinement
    // fields (VisualFeatureCandidateModels.kt) — shine has no CandidateSkinSupport of its own
    // (skinConfidence above is a raw tile-wide Double, not that wrapper type), so the same four
    // fields are added directly here instead. Null means "not computed for this candidate" (no
    // boundary context supplied to ShineDetectionEngine, zero footprint overlap, or no
    // original/normalized scale available for this view) -- never fabricated as a copy of
    // skinConfidence above or a placeholder 0.0/100.0. See
    // FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport for how these are computed. ---
    val boundarySkinConfidenceAtLocation: Double? = null,
    val boundaryHighConfidenceSkinFraction: Double? = null,
    val boundaryExclusionOverlap: Double? = null,
    val boundaryCellsOverlapped: Int? = null
)

/** Batch 4D-F, step_1 output: per-(view, region) shine rollup, mirroring [RegionalFeatureSummary]'s density basis so figures from the two systems are directly comparable. */
data class RegionalShineSummary(
    val view: String,
    val region: AnatomicalRegion,
    val regionSkinCoverage: Double,
    val candidateCount: Int,
    val totalShineAreaPixels: Long,
    val meanRelativeIntensity: Double,
    val meanConfidence: Double,
    val shineDensityPer1000Cells: Double,
    // --- Batch 4E-A additions (additive) ---
    val usableSkinAreaPixels: Double = 0.0,
    val areaBasis: String = "UNAVAILABLE",
    val densityPerMillionUsableSkinPixels: Double? = null
)

/** Batch 4D-F2, step_1 output: one detected bump-like / surface-structure candidate, from
 * [BumpSurfaceStructureEngine]. Its own model (not a re-tag of [VisualFeatureCandidate]) because
 * bump evidence is drawn from a dedicated highlight/shadow-relief mask over the SAME [SignalGrid]
 * every other structural detector uses — mirroring how [ShineCandidate] is its own model for the
 * same reason (see that class's doc comment). */
data class BumpCandidate(
    val candidateId: String,
    val view: String,
    val region: AnatomicalRegion,
    val tileId: String,
    val scale: AnalysisScale,
    val boundingBox: IntArray,
    val centroidX: Int,
    val centroidY: Int,
    val areaPixels: Int,
    val primaryType: SpecializedFeatureType, // BUMP_LIKE, SURFACE_STRUCTURE_LIKE, or UNCERTAIN_SURFACE_STRUCTURE
    /** 0-1, normalized highlight-minus-shadow luma split within the candidate's own cells — the "shadow/highlight relationship" signal step_1 asks for. */
    val internalReliefContrast: Double,
    /** 0-1, structure-tensor coherence of the relief gradient (FeatureOrientationEngine) — a real bump has a consistent highlight->shadow axis, unlike random micro-texture noise. */
    val reliefAxisCoherence: Double,
    val compactness: Double,
    val elongation: Double,
    /** 0-1 fraction of this candidate's own area that also fell inside a detected shine mask cell — used as corroborating (not exclusive) evidence, since a genuine bump often carries a small specular highlight at its apex. */
    val shineOverlapFraction: Double,
    val skinConfidence: Double,
    val confidence: Double,
    val evidenceReasons: List<String>,
    // --- Batch 4E-D, step_3 additions (additive), same rationale/contract as ShineCandidate's
    // own boundary fields immediately above -- see that class's doc comment. ---
    val boundarySkinConfidenceAtLocation: Double? = null,
    val boundaryHighConfidenceSkinFraction: Double? = null,
    val boundaryExclusionOverlap: Double? = null,
    val boundaryCellsOverlapped: Int? = null
)

data class RegionalBumpSummary(
    val view: String,
    val region: AnatomicalRegion,
    val regionSkinCoverage: Double,
    val candidateCount: Int,
    val totalAreaPixels: Long,
    val meanInternalReliefContrast: Double,
    val meanConfidence: Double,
    val densityPer1000Cells: Double,
    // --- Batch 4E-A additions (additive) ---
    val usableSkinAreaPixels: Double = 0.0,
    val areaBasis: String = "UNAVAILABLE",
    val densityPerMillionUsableSkinPixels: Double? = null
)

/** Batch 4D-F2, step_3 output: one real spatial association between a post-acne-mark-family
 * candidate (dark-mark/pigmentation/red-mark classification) and a nearby compatible blemish
 * candidate, from [PostAcneSpatialAssociationEngine]. Replaces the confidence-only proxy
 * `SpecializedFeatureClassifiers.classifyDarkFeatures`'s own doc comment flagged as an
 * approximation ("that spatial join is not performed here"). */
data class PostAcneSpatialAssociation(
    val associationId: String,
    val view: String,
    val region: AnatomicalRegion,
    val darkFeatureCandidateId: String,
    val blemishCandidateId: String,
    val darkFeatureType: SpecializedFeatureType,
    val blemishType: SpecializedFeatureType,
    /** Euclidean centroid distance in original-image pixels. */
    val distancePixels: Double,
    /** distancePixels normalized against this (view,region)'s own observed candidate-position spread — see engine doc comment for why this proxy is used instead of true region-polygon-relative coordinates. */
    val normalizedDistance: Double,
    val areaCompatibility: Double,
    val shapeCompatibility: Double,
    val colorCompatibility: Double,
    val associationConfidence: Double,
    val evidenceReasons: List<String>
)

object SpecializedFeatureJson {
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    fun evidenceJson(e: SpecializedFeatureEvidence): String {
        val box = e.boundingBox
        return """{"feature_type":"${e.featureType}","candidate_id":"${e.candidateId}","primary_confidence":${e.primaryConfidence},"secondary_confidence":${e.secondaryConfidence},"source_view":"${esc(e.sourceView)}","anatomical_region":"${e.anatomicalRegion}","source_coordinates":{"x":${e.sourceCoordinates.first},"y":${e.sourceCoordinates.second}},"bounding_box":{"x":${box[0]},"y":${box[1]},"width":${box[2]},"height":${box[3]}},"scale":"${e.scale}","area":${e.area},"shape":"${e.shape}","skin_confidence":${e.skinConfidence},"supporting_signals":[${e.supportingSignals.joinToString(",") { "\"${esc(it)}\"" }}],"evidence_reasons":[${e.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}],"classification_state":"${e.classificationState}"}"""
    }

    fun poreFollicleJson(p: PoreFollicleRefinement): String =
        """{"candidate_id":"${p.candidateId}","pore_like_confidence":${p.poreLikeConfidence},"follicular_opening_confidence":${p.follicularOpeningConfidence},"apparent_diameter_pixels":${p.apparentDiameterPixels},"visibility":"${p.visibility}","local_density_rank":${p.localDensityRank},"supporting_evidence":[${p.supportingEvidence.joinToString(",") { "\"${esc(it)}\"" }}]}"""

    fun hairStubbleJson(h: HairStubbleRefinement): String =
        """{"candidate_id":"${h.candidateId}","hair_like_confidence":${h.hairLikeConfidence},"stubble_like_confidence":${h.stubbleLikeConfidence},"coverage_contribution":${h.coverageContribution},"evidence_reasons":[${h.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}]}"""

    fun blemishJson(b: BlemishClassificationResult): String =
        """{"candidate_id":"${b.candidateId}","primary_class":"${b.primaryClass}","secondary_classes":[${b.secondaryClasses.joinToString(",") { "\"$it\"" }}],"confidence":${b.confidence},"evidence_reasons":[${b.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}]}"""

    fun darkMarkJson(d: DarkMarkClassificationResult): String =
        """{"candidate_id":"${d.candidateId}","primary_class":"${d.primaryClass}","secondary_classes":[${d.secondaryClasses.joinToString(",") { "\"$it\"" }}],"confidence":${d.confidence},"relative_contrast":${d.relativeContrast},"evidence_reasons":[${d.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}]}"""

    fun rednessJson(r: LocalizedRednessRefinement): String =
        """{"candidate_id":"${r.candidateId}","localized_redness_confidence":${r.localizedRednessConfidence},"color_cast_adjusted_delta_cr":${r.colorCastAdjustedDeltaCr},"illumination_reliable":${r.illuminationReliable},"evidence_reasons":[${r.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}]}"""

    fun shineCandidateJson(s: ShineCandidate): String {
        val box = s.boundingBox
        // Batch 4E-D, step_3: additive boundary_refinement sub-object, null when not computed,
        // mirroring VisualFeatureJson.skinSupportJson's own boundary_refinement convention for
        // structural candidates (Batch 4E-C step_2, VisualFeatureCandidateModels.kt) so both
        // share the same diagnostic shape.
        val boundaryJson = if (s.boundarySkinConfidenceAtLocation == null) "null" else
            """{"skin_confidence_at_location":${s.boundarySkinConfidenceAtLocation},"high_confidence_skin_fraction":${s.boundaryHighConfidenceSkinFraction},"exclusion_overlap":${s.boundaryExclusionOverlap},"cells_overlapped":${s.boundaryCellsOverlapped}}"""
        return """{"candidate_id":"${s.candidateId}","view":"${esc(s.view)}","region":"${s.region}","tile_id":"${s.tileId}","scale":"${s.scale}","bounding_box":{"x":${box[0]},"y":${box[1]},"width":${box[2]},"height":${box[3]}},"centroid":{"x":${s.centroidX},"y":${s.centroidY}},"area_pixels":${s.areaPixels},"relative_intensity":${s.relativeIntensity},"chroma_desaturation":${s.chromaDesaturation},"compactness":${s.compactness},"skin_confidence":${s.skinConfidence},"confidence":${s.confidence},"evidence_reasons":[${s.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}],"boundary_refinement":$boundaryJson}"""
    }

    fun regionalShineSummaryJson(s: RegionalShineSummary): String =
        """{"view":"${esc(s.view)}","region":"${s.region}","region_skin_coverage":${s.regionSkinCoverage},"candidate_count":${s.candidateCount},"total_shine_area_pixels":${s.totalShineAreaPixels},"mean_relative_intensity":${s.meanRelativeIntensity},"mean_confidence":${s.meanConfidence},"shine_density_per_1000_cells":${s.shineDensityPer1000Cells},"usable_skin_area_pixels":${s.usableSkinAreaPixels},"area_basis":"${s.areaBasis}","density_per_million_usable_skin_pixels":${s.densityPerMillionUsableSkinPixels ?: "null"}}"""

    fun bumpCandidateJson(b: BumpCandidate): String {
        val box = b.boundingBox
        // Batch 4E-D, step_3: additive boundary_refinement sub-object — same convention as
        // shineCandidateJson immediately above (see that function's comment).
        val boundaryJson = if (b.boundarySkinConfidenceAtLocation == null) "null" else
            """{"skin_confidence_at_location":${b.boundarySkinConfidenceAtLocation},"high_confidence_skin_fraction":${b.boundaryHighConfidenceSkinFraction},"exclusion_overlap":${b.boundaryExclusionOverlap},"cells_overlapped":${b.boundaryCellsOverlapped}}"""
        return """{"candidate_id":"${b.candidateId}","view":"${esc(b.view)}","region":"${b.region}","tile_id":"${b.tileId}","scale":"${b.scale}","bounding_box":{"x":${box[0]},"y":${box[1]},"width":${box[2]},"height":${box[3]}},"centroid":{"x":${b.centroidX},"y":${b.centroidY}},"area_pixels":${b.areaPixels},"primary_type":"${b.primaryType}","internal_relief_contrast":${b.internalReliefContrast},"relief_axis_coherence":${b.reliefAxisCoherence},"compactness":${b.compactness},"elongation":${b.elongation},"shine_overlap_fraction":${b.shineOverlapFraction},"skin_confidence":${b.skinConfidence},"confidence":${b.confidence},"evidence_reasons":[${b.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}],"boundary_refinement":$boundaryJson}"""
    }

    fun regionalBumpSummaryJson(s: RegionalBumpSummary): String =
        """{"view":"${esc(s.view)}","region":"${s.region}","region_skin_coverage":${s.regionSkinCoverage},"candidate_count":${s.candidateCount},"total_area_pixels":${s.totalAreaPixels},"mean_internal_relief_contrast":${s.meanInternalReliefContrast},"mean_confidence":${s.meanConfidence},"density_per_1000_cells":${s.densityPer1000Cells},"usable_skin_area_pixels":${s.usableSkinAreaPixels},"area_basis":"${s.areaBasis}","density_per_million_usable_skin_pixels":${s.densityPerMillionUsableSkinPixels ?: "null"}}"""

    fun postAcneAssociationJson(a: PostAcneSpatialAssociation): String =
        """{"association_id":"${a.associationId}","view":"${esc(a.view)}","region":"${a.region}","dark_feature_candidate_id":"${a.darkFeatureCandidateId}","blemish_candidate_id":"${a.blemishCandidateId}","dark_feature_type":"${a.darkFeatureType}","blemish_type":"${a.blemishType}","distance_pixels":${a.distancePixels},"normalized_distance":${a.normalizedDistance},"area_compatibility":${a.areaCompatibility},"shape_compatibility":${a.shapeCompatibility},"color_compatibility":${a.colorCompatibility},"association_confidence":${a.associationConfidence},"evidence_reasons":[${a.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}]}"""
}
