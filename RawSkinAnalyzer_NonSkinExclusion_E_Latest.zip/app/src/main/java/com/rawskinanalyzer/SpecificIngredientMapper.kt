package com.rawskinanalyzer

enum class IngredientSelectionRole { PRIMARY, SUPPORTIVE, OPTIONAL }

data class SpecificIngredientOption(
    val concern: SkinConcernCategory,
    val ingredientName: String,
    val role: IngredientSelectionRole,
    val routinePhase: String,
    val sourceCategory: String,
    val caution: String?,
    // Batch 3A: carried forward from IngredientStrategyItem.objectiveType/objectiveStrengthReason
    // (which itself came from RoutineTarget, which itself came from SkinObjective — the real
    // ObjectiveStrengthPolicy-calibrated value). This is what EvidenceAwareCandidateSelectionPolicy
    // gates on; nothing about score/confidence/priority is recomputed here.
    val objectiveType: SkinObjectiveType,
    val objectiveStrengthReason: String
)

object SpecificIngredientMapper {
    fun map(
        items: List<IngredientStrategyItem>,
        context: UserRoutineContext
    ): List<SpecificIngredientOption> {
        val options = items.flatMap { item ->
            when (item.concern) {
                SkinConcernCategory.TONE_PIGMENTATION -> listOf(
                    option(item, "Niacinamide", IngredientSelectionRole.PRIMARY),
                    option(item, "Vitamin C", IngredientSelectionRole.SUPPORTIVE),
                    option(item, "Azelaic acid", IngredientSelectionRole.OPTIONAL,
                        "Introduce selectively; compatibility and tolerance review required.")
                )
                SkinConcernCategory.DARK_MARKS -> listOf(
                    option(item, "Azelaic acid", IngredientSelectionRole.PRIMARY,
                        "Compatibility and tolerance review required."),
                    option(item, "Niacinamide", IngredientSelectionRole.SUPPORTIVE),
                    option(item, "Vitamin C", IngredientSelectionRole.OPTIONAL)
                )
                SkinConcernCategory.BLEMISH_LIKE_APPEARANCE -> listOf(
                    option(item, "Salicylic acid", IngredientSelectionRole.PRIMARY,
                        "Avoid automatic stacking with multiple intensive exfoliating steps."),
                    option(item, "Niacinamide", IngredientSelectionRole.SUPPORTIVE)
                )
                SkinConcernCategory.REDNESS_APPEARANCE -> listOf(
                    option(item, "Niacinamide", IngredientSelectionRole.PRIMARY),
                    option(item, "Ceramides", IngredientSelectionRole.SUPPORTIVE)
                )
                SkinConcernCategory.PORE_TEXTURE_APPEARANCE -> listOf(
                    option(item, "Salicylic acid", IngredientSelectionRole.PRIMARY,
                        "Avoid automatic same-session stacking with other intensive exfoliating steps."),
                    option(item, "Niacinamide", IngredientSelectionRole.SUPPORTIVE)
                )
                SkinConcernCategory.SURFACE_SHINE -> listOf(
                    option(item, "Niacinamide", IngredientSelectionRole.PRIMARY),
                    option(item, "Glycerin", IngredientSelectionRole.SUPPORTIVE)
                )
                SkinConcernCategory.DRYNESS_APPEARANCE -> listOf(
                    option(item, "Glycerin", IngredientSelectionRole.PRIMARY),
                    option(item, "Ceramides", IngredientSelectionRole.SUPPORTIVE)
                )
            }
        }.distinctBy { "${it.concern}:${it.ingredientName}:${it.role}" }

        return when (context.tolerancePreference) {
            TolerancePreference.CAUTIOUS ->
                options.filter { it.role != IngredientSelectionRole.OPTIONAL }
            else -> options
        }
    }

    private fun option(
        item: IngredientStrategyItem,
        name: String,
        role: IngredientSelectionRole,
        caution: String? = null
    ) = SpecificIngredientOption(
        concern = item.concern,
        ingredientName = name,
        role = role,
        routinePhase = item.routinePhase,
        sourceCategory = item.ingredientCategory,
        caution = caution,
        objectiveType = item.objectiveType,
        objectiveStrengthReason = item.objectiveStrengthReason
    )
}
