package com.rawskinanalyzer

data class TextureCharacterizationResult(
    val overallTexture:String,
    val textureVariationScore:Double,
    val localizedTextureSignal:String,
    val highTextureCellPercent:Double,
    val textureDistribution:String,
    val dominantTextureCharacteristic:String,
    val confidence:String
)

object TextureCharacterizationAnalyzer {
    private fun clamp(v:Double)=v.coerceIn(0.0,100.0)

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):TextureCharacterizationResult {
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val usable=listOf(front,left,right).flatMap { map -> map.filter { it.skinPercent>=10.0 } }
        if(usable.isEmpty()) return TextureCharacterizationResult(
            "INSUFFICIENT_TEXTURE_DATA",0.0,"INSUFFICIENT_TEXTURE_DATA",0.0,
            "INSUFFICIENT_TEXTURE_DATA","INSUFFICIENT_TEXTURE_DATA","LOW"
        )

        val mean=usable.map{it.texture}.average()
        val highPercent=usable.count{it.texture>=mean*1.25 && it.texture>=8.0}*100.0/usable.size
        val variation=q.textureVariation
        val overall=when {
            variation>=25.0 -> "HIGH_TEXTURE_VARIATION"
            variation>=12.0 -> "MODERATE_TEXTURE_VARIATION"
            else -> "LOW_TEXTURE_VARIATION"
        }
        val localized=when {
            highPercent>=30.0 -> "HIGH_LOCALIZED_TEXTURE_SIGNAL"
            highPercent>=12.0 -> "MODERATE_LOCALIZED_TEXTURE_SIGNAL"
            else -> "LOW_LOCALIZED_TEXTURE_SIGNAL"
        }
        val distribution=when {
            highPercent>=35.0 -> "WIDESPREAD_TEXTURE_VARIATION"
            highPercent>=10.0 -> "LOCALIZED_TEXTURE_VARIATION"
            else -> "LIMITED_TEXTURE_VARIATION"
        }
        val dominant=when {
            overall=="HIGH_TEXTURE_VARIATION" && distribution=="WIDESPREAD_TEXTURE_VARIATION" ->
                "WIDESPREAD_HIGH_TEXTURE_VARIATION"
            overall!="LOW_TEXTURE_VARIATION" && localized!="LOW_LOCALIZED_TEXTURE_SIGNAL" ->
                "LOCALIZED_TEXTURE_VARIATION"
            overall=="LOW_TEXTURE_VARIATION" ->
                "MORE_UNIFORM_SURFACE_TEXTURE"
            else -> "MODERATE_SURFACE_TEXTURE_VARIATION"
        }
        return TextureCharacterizationResult(
            overall,clamp(variation),localized,highPercent,distribution,dominant,q.confidence
        )
    }

    fun json(x:TextureCharacterizationResult)=
        """{"overall_texture":"${x.overallTexture}","texture_variation_score":${x.textureVariationScore},"localized_texture_signal":"${x.localizedTextureSignal}","high_texture_cell_percent":${x.highTextureCellPercent},"texture_distribution":"${x.textureDistribution}","dominant_texture_characteristic":"${x.dominantTextureCharacteristic}","confidence":"${x.confidence}","method":"texture_characterization_v1","medical_diagnosis":false}"""
}
