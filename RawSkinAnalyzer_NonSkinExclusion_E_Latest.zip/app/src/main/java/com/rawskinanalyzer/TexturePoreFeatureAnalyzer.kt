package com.rawskinanalyzer

data class TexturePoreViewResult(
    val view:String,
    val skinCells:Int,
    val meanTexture:Double,
    val textureVariation:Double,
    val elevatedTexturePercent:Double,
    val poreLikePercent:Double
)

data class TexturePoreFeatureResult(
    val textureIrregularityScore:Double,
    val textureLevel:String,
    val poreLikeSignalScore:Double,
    val poreLikeLevel:String,
    val distribution:String,
    val crossViewConsistency:String,
    val confidence:String,
    val views:List<TexturePoreViewResult>
)

object TexturePoreFeatureAnalyzer {
    private fun std(values:List<Double>):Double {
        if(values.isEmpty()) return 0.0
        val mean=values.average()
        return kotlin.math.sqrt(values.sumOf { (it-mean)*(it-mean) } / values.size)
    }

    private fun level(score:Double, type:String)=when {
        score>=60.0 -> "HIGH_VISIBLE_${type}_SIGNAL"
        score>=30.0 -> "MODERATE_VISIBLE_${type}_SIGNAL"
        score>=12.0 -> "LOW_VISIBLE_${type}_SIGNAL"
        else -> "MINIMAL_VISIBLE_${type}_SIGNAL"
    }

    private fun analyzeView(name:String,cells:List<PatternMapCell>):TexturePoreViewResult {
        val skin=cells.filter { it.skinPercent>=10.0 }
        if(skin.isEmpty()) return TexturePoreViewResult(name,0,0.0,0.0,0.0,0.0)
        val values=skin.map { it.texture }
        val mean=values.average()
        val variation=std(values)
        val elevated=values.count { it>=mean+variation*0.5 }*100.0/values.size
        val poreLike=skin.count {
            it.texture>=mean+variation*0.75 && it.meanLuma<=skin.map { c->c.meanLuma }.average()+10.0
        }*100.0/values.size
        return TexturePoreViewResult(name,skin.size,mean,variation,elevated,poreLike)
    }

    fun analyze(front:List<PatternMapCell>,left:List<PatternMapCell>,right:List<PatternMapCell>):TexturePoreFeatureResult {
        val textureBase=TextureCharacterizationAnalyzer.analyze(front,left,right)
        val views=listOf(analyzeView("FRONT_FACE",front),analyzeView("LEFT_CHEEK",left),analyzeView("RIGHT_CHEEK",right))
            .filter { it.skinCells>0 }
        if(views.isEmpty()) return TexturePoreFeatureResult(0.0,"INSUFFICIENT_DATA",0.0,"INSUFFICIENT_DATA","INSUFFICIENT_DATA","INSUFFICIENT_DATA","LOW",emptyList())

        val variation=views.map { it.textureVariation }.average()
        val elevated=views.map { it.elevatedTexturePercent }.average()
        val poreLike=views.map { it.poreLikePercent }.average()
        val textureScore=SkinScoreCalibration.textureIrregularity(
            baseTextureVariationScore=textureBase.textureVariationScore,
            withinViewVariation=variation,
            elevatedTexturePercent=elevated
        ).calibratedScore
        val poreScore=SkinScoreCalibration.poreLike(
            poreLikePercent=poreLike,
            elevatedTexturePercent=elevated
        ).calibratedScore

        val active=views.count { it.elevatedTexturePercent>=12.0 }
        val distribution=when {
            active>=3 -> "MULTI_VIEW_TEXTURE_DISTRIBUTION"
            active==2 -> "TWO_VIEW_TEXTURE_DISTRIBUTION"
            active==1 -> "LOCALIZED_TEXTURE_DISTRIBUTION"
            else -> "LIMITED_TEXTURE_VARIATION"
        }
        val spread=std(views.map { it.meanTexture })
        val consistency=when {
            views.size<2 -> "SINGLE_VIEW_TEXTURE_SIGNAL"
            spread<=3.0 -> "HIGH_CROSS_VIEW_TEXTURE_CONSISTENCY"
            spread<=8.0 -> "MODERATE_CROSS_VIEW_TEXTURE_CONSISTENCY"
            else -> "LOW_CROSS_VIEW_TEXTURE_CONSISTENCY"
        }
        val confidence=when {
            views.size==3 && consistency=="HIGH_CROSS_VIEW_TEXTURE_CONSISTENCY" && textureBase.confidence=="HIGH" -> "HIGH"
            views.size>=2 -> "MODERATE"
            else -> "LOW"
        }
        return TexturePoreFeatureResult(textureScore,level(textureScore,"TEXTURE_IRREGULARITY"),poreScore,level(poreScore,"PORE_LIKE"),distribution,consistency,confidence,views)
    }

    fun json(x:TexturePoreFeatureResult):String {
        val views=x.views.joinToString(","){v ->
            """{"view":"${v.view}","skin_cells":${v.skinCells},"mean_texture":${v.meanTexture},"texture_variation":${v.textureVariation},"elevated_texture_percent":${v.elevatedTexturePercent},"pore_like_percent":${v.poreLikePercent}}"""
        }
        return """{"texture_irregularity_score":${x.textureIrregularityScore},"texture_level":"${x.textureLevel}","pore_like_signal_score":${x.poreLikeSignalScore},"pore_like_level":"${x.poreLikeLevel}","distribution":"${x.distribution}","cross_view_consistency":"${x.crossViewConsistency}","confidence":"${x.confidence}","views":[$views],"method":"texture_pore_feature_analysis_v1","medical_diagnosis":false}"""
    }
}
