package com.rawskinanalyzer

data class ThreeViewCaptureConditionResult(
    val lumaSpread: Double,
    val colorCastSpread: Double,
    val gainSpread: Double,
    val leftRightLumaDelta: Double,
    val leftRightColorCastDelta: Double,
    val consistency: String,
    val crossViewWarnings: List<String>
)

/**
 * Compares the three per-view CaptureConditionProfiles produced by
 * [CaptureConditionProfileAnalyzer] and represents how different the capture conditions were
 * across the required FRONT / LEFT_CHEEK / RIGHT_CHEEK session. This does not attempt to
 * correct anything — it is a structural comparison used to decide whether cross-view findings
 * (e.g. left/right deltas used elsewhere in the pipeline) should be trusted as reflecting the
 * skin, or flagged as potentially confounded by inconsistent lighting.
 */
object ThreeViewCaptureConditionAnalyzer {
    fun analyze(
        front: CaptureConditionProfile,
        left: CaptureConditionProfile,
        right: CaptureConditionProfile
    ): ThreeViewCaptureConditionResult {
        val lumas = listOf(front.meanLuma, left.meanLuma, right.meanLuma)
        val casts = listOf(front.colorCastMagnitude, left.colorCastMagnitude, right.colorCastMagnitude)
        val gains = listOf(front.suggestedExposureGain, left.suggestedExposureGain, right.suggestedExposureGain)
        fun spread(v: List<Double>) = (v.maxOrNull() ?: 0.0) - (v.minOrNull() ?: 0.0)

        val lumaSpread = spread(lumas)
        val colorCastSpread = spread(casts)
        val gainSpread = spread(gains)
        val lrLuma = kotlin.math.abs(left.meanLuma - right.meanLuma)
        val lrCast = kotlin.math.abs(left.colorCastMagnitude - right.colorCastMagnitude)

        val warnings = mutableListOf<String>()
        if (lumaSpread > 60.0) warnings += "MAJOR_LIGHTING_MISMATCH_ACROSS_VIEWS"
        else if (lumaSpread > 35.0) warnings += "MODERATE_LIGHTING_MISMATCH_ACROSS_VIEWS"
        if (colorCastSpread > 0.22) warnings += "MAJOR_COLOR_CAST_MISMATCH_ACROSS_VIEWS"
        else if (colorCastSpread > 0.12) warnings += "MODERATE_COLOR_CAST_MISMATCH_ACROSS_VIEWS"
        if (lrLuma > 45.0) warnings += "LEFT_RIGHT_LIGHTING_MISMATCH"
        val anySevereSingleView = listOf(front, left, right).any {
            "LOW_LIGHT" in it.warnings || "OVEREXPOSED" in it.warnings || "STRONG_COLOR_CAST" in it.warnings
        }
        if (anySevereSingleView && (lumaSpread > 35.0 || colorCastSpread > 0.12)) {
            warnings += "SESSION_LIGHTING_RELIABILITY_REDUCED"
        }

        val consistency = when {
            "MAJOR_LIGHTING_MISMATCH_ACROSS_VIEWS" in warnings || "MAJOR_COLOR_CAST_MISMATCH_ACROSS_VIEWS" in warnings ->
                "MAJOR_CAPTURE_CONDITION_INCONSISTENCY"
            warnings.isNotEmpty() -> "MODERATE_CAPTURE_CONDITION_VARIATION"
            else -> "HIGH_CAPTURE_CONDITION_CONSISTENCY"
        }

        return ThreeViewCaptureConditionResult(
            lumaSpread = lumaSpread,
            colorCastSpread = colorCastSpread,
            gainSpread = gainSpread,
            leftRightLumaDelta = lrLuma,
            leftRightColorCastDelta = lrCast,
            consistency = consistency,
            crossViewWarnings = warnings
        )
    }

    fun json(x: ThreeViewCaptureConditionResult): String {
        val w = x.crossViewWarnings.joinToString(",") { "\"$it\"" }
        return """{"luma_spread":${x.lumaSpread},"color_cast_spread":${x.colorCastSpread},"gain_spread":${x.gainSpread},"left_right_luma_delta":${x.leftRightLumaDelta},"left_right_color_cast_delta":${x.leftRightColorCastDelta},"consistency":"${x.consistency}","cross_view_warnings":[$w],"method":"three_view_capture_condition_v1","medical_diagnosis":false}"""
    }
}
