package com.rawskinanalyzer

import kotlin.math.abs

data class ThreeViewConsistencyResult(
    val lumaSpread:Double,
    val rednessSpread:Double,
    val textureSpread:Double,
    val leftRightRednessDelta:Double,
    val leftRightTextureDelta:Double,
    val consistency:String
)

object ThreeViewConsistencyAnalyzer {
    fun analyze(f:SkinInterpretation,l:SkinInterpretation,r:SkinInterpretation):ThreeViewConsistencyResult {
        val lumas=listOf(f.toneStd,l.toneStd,r.toneStd)
        val reds=listOf(f.rednessMean,l.rednessMean,r.rednessMean)
        val tex=listOf(f.textureVariation,l.textureVariation,r.textureVariation)
        fun spread(v:List<Double>)=v.maxOrNull()!!-v.minOrNull()!!
        val rs=spread(reds); val ts=spread(tex)
        val state=when {
            rs<10.0 && ts<15.0 -> "HIGH_CROSS_VIEW_CONSISTENCY"
            rs<20.0 && ts<30.0 -> "MODERATE_CROSS_VIEW_CONSISTENCY"
            else -> "HIGH_CROSS_VIEW_VARIATION"
        }
        return ThreeViewConsistencyResult(spread(lumas),rs,ts,abs(l.rednessMean-r.rednessMean),abs(l.textureVariation-r.textureVariation),state)
    }
    fun json(x:ThreeViewConsistencyResult)="""{"luma_spread":${x.lumaSpread},"redness_spread":${x.rednessSpread},"texture_spread":${x.textureSpread},"left_right_redness_delta":${x.leftRightRednessDelta},"left_right_texture_delta":${x.leftRightTextureDelta},"consistency":"${x.consistency}","method":"three_view_consistency_v1","medical_diagnosis":false}"""
}
