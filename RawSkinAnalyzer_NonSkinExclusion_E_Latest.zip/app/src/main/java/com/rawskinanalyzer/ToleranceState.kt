package com.rawskinanalyzer

/**
 * BATCH 3B — TOLERANCE-STATE ARCHITECTURE.
 *
 * Audit finding: no per-ingredient dynamic tolerance model exists in this project.
 * `UserRoutineContext.tolerancePreference` (`TolerancePreference`: CAUTIOUS/BALANCED/FLEXIBLE)
 * is a static, session-level *user setting* — a stated preference, not an observed, evolving
 * state per ingredient. It is intentionally left untouched and unrelated: this file's
 * `ToleranceState` tracks how a specific named ingredient has actually gone for this user over
 * time; `TolerancePreference` stays what it always was, a blanket "how cautious should defaults
 * be" dial. Per the batch's critical_separation rules, tolerance here is also kept independent
 * of analysis confidence (`SkinConcern.confidence`) and of ingredient evidence strength
 * (`CandidateSelectionDecision.evidenceStrength`) — neither is read anywhere in this file.
 */

enum class ToleranceState { UNKNOWN, INTRODUCING, TOLERATED, CAUTION, PAUSED }

/**
 * The only inputs this file's transition logic is allowed to use, per the batch's own rule
 * ("do not automatically infer tolerance solely from a skin-analysis score"): explicit user
 * feedback, or a routine-state signal (first-time inclusion, resume request). Never a score.
 */
enum class ToleranceFeedback {
    NONE,
    FIRST_TIME_INCLUDED,
    STABLE_CONTINUED_USE,
    MILD_REACTION_REPORTED,
    STRONG_REACTION_REPORTED,
    RESUME_REQUESTED
}

data class IngredientToleranceRecord(
    val ingredientName: String,
    val state: ToleranceState,
    val sessionsAtCurrentState: Int,
    val reason: String
)

interface ToleranceStateRepository {
    fun get(ingredientName: String): IngredientToleranceRecord
    fun save(record: IngredientToleranceRecord)
}

/** Non-persistent fallback (and the one used directly in unit tests). The real persisted
 *  implementation is `PersistentToleranceStateStore` (SharedPreferences-backed, same JSON
 *  pattern as `PersistentSkinSessionStore`), which requires `android.content.Context` and so
 *  lives in a separate file. */
class InMemoryToleranceStateRepository : ToleranceStateRepository {
    private val records = mutableMapOf<String, IngredientToleranceRecord>()

    override fun get(ingredientName: String): IngredientToleranceRecord =
        records[ingredientName] ?: IngredientToleranceRecord(
            ingredientName = ingredientName,
            state = ToleranceState.UNKNOWN,
            sessionsAtCurrentState = 0,
            reason = "No prior tolerance record; defaulting to UNKNOWN rather than assuming safety."
        )

    override fun save(record: IngredientToleranceRecord) {
        records[record.ingredientName] = record
    }
}

object ToleranceTransitionPolicy {
    const val VERSION = "TOLERANCE_TRANSITION_POLICY_V1"

    // A stable run of sessions with no negative feedback is required before INTRODUCING can
    // become TOLERATED — a single uncertain/positive observation must not flip the state, per
    // "avoid aggressive automatic state changes from a single uncertain observation."
    private const val SESSIONS_REQUIRED_TO_REACH_TOLERATED = 3

    /**
     * Pure, deterministic transition. Never reads score/confidence/evidence — only the
     * ingredient's current record and one explicit feedback signal for this session.
     */
    fun transition(
        current: IngredientToleranceRecord,
        feedback: ToleranceFeedback
    ): IngredientToleranceRecord {
        val (nextState, reason) = when (current.state) {
            ToleranceState.UNKNOWN -> when (feedback) {
                ToleranceFeedback.FIRST_TIME_INCLUDED ->
                    ToleranceState.INTRODUCING to "First inclusion in the routine; beginning conservative introduction."
                else -> current.state to "No routine-inclusion signal yet; remaining UNKNOWN."
            }

            ToleranceState.INTRODUCING -> when (feedback) {
                ToleranceFeedback.STRONG_REACTION_REPORTED ->
                    ToleranceState.PAUSED to "Strong reaction reported during introduction; pausing."
                ToleranceFeedback.MILD_REACTION_REPORTED ->
                    ToleranceState.CAUTION to "Mild reaction reported during introduction; limiting escalation."
                ToleranceFeedback.STABLE_CONTINUED_USE ->
                    if (current.sessionsAtCurrentState + 1 >= SESSIONS_REQUIRED_TO_REACH_TOLERATED)
                        ToleranceState.TOLERATED to "Stable use across $SESSIONS_REQUIRED_TO_REACH_TOLERATED consecutive sessions with no adverse feedback."
                    else
                        current.state to "Continuing introduction; not yet enough stable sessions to confirm tolerance."
                else -> current.state to "No new feedback; continuing introduction."
            }

            ToleranceState.TOLERATED -> when (feedback) {
                ToleranceFeedback.STRONG_REACTION_REPORTED ->
                    ToleranceState.PAUSED to "Strong reaction reported after prior tolerated use; pausing."
                ToleranceFeedback.MILD_REACTION_REPORTED ->
                    ToleranceState.CAUTION to "Mild reaction reported after prior tolerated use; limiting escalation."
                else -> current.state to "Stable tolerated use continues; preserved without unnecessary reset."
            }

            ToleranceState.CAUTION -> when (feedback) {
                ToleranceFeedback.STRONG_REACTION_REPORTED ->
                    ToleranceState.PAUSED to "Strong reaction reported while already in caution; pausing."
                ToleranceFeedback.STABLE_CONTINUED_USE ->
                    if (current.sessionsAtCurrentState + 1 >= SESSIONS_REQUIRED_TO_REACH_TOLERATED)
                        ToleranceState.TOLERATED to "Stable use across $SESSIONS_REQUIRED_TO_REACH_TOLERATED consecutive sessions resolved the earlier caution."
                    else
                        current.state to "Remaining in caution; not yet enough stable sessions to clear it."
                else -> current.state to "Remaining in caution; no new adverse or stabilizing signal."
            }

            ToleranceState.PAUSED -> when (feedback) {
                // PAUSED never clears itself automatically — only an explicit resume request,
                // per "PAUSED components are not silently reintroduced."
                ToleranceFeedback.RESUME_REQUESTED ->
                    ToleranceState.INTRODUCING to "Explicit resume requested; restarting as a fresh conservative introduction."
                else -> current.state to "Paused; requires an explicit resume request to reintroduce."
            }
        }

        val sessionsAtState = if (nextState == current.state) current.sessionsAtCurrentState + 1 else 0
        return IngredientToleranceRecord(current.ingredientName, nextState, sessionsAtState, reason)
    }
}

// -------------------------------------------------------------------------------------------
// BATCH 3B — Tolerance-aware candidate filtering (step 5). Connects ToleranceState to the real
// candidate pipeline: applied in FinalSkinAnalysisProfileAnalyzer.kt after candidate-level
// compatibility, before routine intensity.
// -------------------------------------------------------------------------------------------

enum class ToleranceFilterOutcome { INCLUDED, LIMITED, EXCLUDED }

data class ToleranceFilterDecision(
    val ingredientName: String,
    val role: IngredientSelectionRole,
    val toleranceState: ToleranceState,
    val outcome: ToleranceFilterOutcome,
    val reason: String
)

object ToleranceAwareCandidateFilter {
    /**
     * @param candidates SELECTED + compatibility-passed named ingredients for this session.
     * @param toleranceByIngredient current tolerance record per ingredient name (read from
     *   `ToleranceStateRepository` by the caller; this function itself does not touch storage).
     */
    fun apply(
        candidates: List<SpecificIngredientOption>,
        toleranceByIngredient: Map<String, IngredientToleranceRecord>
    ): List<ToleranceFilterDecision> {
        // "INTRODUCING limits unnecessary simultaneous additions" — cap how many ingredients
        // that are brand-new this session (UNKNOWN, about to start introducing) are allowed in
        // at once, per routine phase, rather than introducing everything simultaneously.
        var newIntroductionsAllowedThisSession = 1
        val introducedSoFar = mutableSetOf<String>()

        return candidates.map { candidate ->
            val record = toleranceByIngredient[candidate.ingredientName]
                ?: IngredientToleranceRecord(candidate.ingredientName, ToleranceState.UNKNOWN, 0, "No prior record.")

            when (record.state) {
                ToleranceState.PAUSED ->
                    ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.EXCLUDED, "PAUSED_DUE_TO_CAUTION")

                ToleranceState.CAUTION ->
                    if (candidate.role == IngredientSelectionRole.PRIMARY) {
                        ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.LIMITED, "LIMITED_BY_TOLERANCE")
                    } else {
                        ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.EXCLUDED, "LIMITED_BY_TOLERANCE")
                    }

                ToleranceState.UNKNOWN ->
                    if (candidate.ingredientName in introducedSoFar || newIntroductionsAllowedThisSession > 0) {
                        if (candidate.ingredientName !in introducedSoFar) {
                            newIntroductionsAllowedThisSession--
                            introducedSoFar += candidate.ingredientName
                        }
                        ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.INCLUDED, "CONSERVATIVE_INTRODUCTION")
                    } else {
                        ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.LIMITED, "CONSERVATIVE_INTRODUCTION")
                    }

                ToleranceState.INTRODUCING ->
                    ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.INCLUDED, "CONSERVATIVE_INTRODUCTION")

                ToleranceState.TOLERATED ->
                    ToleranceFilterDecision(candidate.ingredientName, candidate.role, record.state, ToleranceFilterOutcome.INCLUDED, "MAINTAINED_DUE_TO_IMPROVEMENT")
            }
        }
    }
}
