package com.rawskinanalyzer

data class ToneColorFeatureResult(
    val toneUniformity:String,
    val toneVariationScore:Double,
    val localizedColorVariation:String,
    val rednessSignal:String,
    val rednessScore:Double,
    val darkAreaSignal:String,
    val darkAreaScore:Double,
    val overallToneColorCharacteristic:String,
    val confidence:String
)

object ToneColorFeatureAnalyzer {
    private fun level(score:Double, low:Double, high:Double, labels:Array<String>)=when {
        score>=high -> labels[2]
        score>=low -> labels[1]
        else -> labels[0]
    }

    fun analyze(
        front:List<PatternMapCell>,
        left:List<PatternMapCell>,
        right:List<PatternMapCell>
    ):ToneColorFeatureResult {
        val q=SkinFeatureQuantificationAnalyzer.analyze(front,left,right)
        val tone=level(q.toneVariation,12.0,25.0,arrayOf("MORE_UNIFORM_TONE","MODERATE_TONE_VARIATION","HIGH_TONE_VARIATION"))
        val color=level(q.toneVariation,18.0,32.0,arrayOf("LOW_COLOR_VARIATION","MODERATE_COLOR_VARIATION","HIGH_COLOR_VARIATION"))
        val redness=level(q.localizedRedness,10.0,22.0,arrayOf("LOW_LOCALIZED_REDNESS_SIGNAL","MODERATE_LOCALIZED_REDNESS_SIGNAL","HIGH_LOCALIZED_REDNESS_SIGNAL"))
        val dark=level(q.darkFeatureConcentration,8.0,20.0,arrayOf("LOW_DARK_AREA_SIGNAL","MODERATE_DARK_AREA_SIGNAL","HIGH_DARK_AREA_SIGNAL"))

        val overall=when {
            q.toneVariation>=25.0 && q.localizedRedness>=22.0 -> "COMBINED_TONE_AND_REDNESS_VARIATION"
            q.toneVariation>=25.0 -> "TONE_VARIATION_DOMINANT"
            q.localizedRedness>=22.0 -> "LOCALIZED_REDNESS_DOMINANT"
            q.darkFeatureConcentration>=20.0 -> "DARK_AREA_VARIATION_DOMINANT"
            else -> "NO_STRONG_TONE_COLOR_VARIATION"
        }
        return ToneColorFeatureResult(
            tone,q.toneVariation,color,redness,q.localizedRedness,dark,
            q.darkFeatureConcentration,overall,q.confidence
        )
    }

    fun json(x:ToneColorFeatureResult)=
        """{"tone_uniformity":"${x.toneUniformity}","tone_variation_score":${x.toneVariationScore},"localized_color_variation":"${x.localizedColorVariation}","redness_signal":"${x.rednessSignal}","redness_score":${x.rednessScore},"dark_area_signal":"${x.darkAreaSignal}","dark_area_score":${x.darkAreaScore},"overall_tone_color_characteristic":"${x.overallToneColorCharacteristic}","confidence":"${x.confidence}","method":"tone_color_feature_analysis_v1","medical_diagnosis":false}"""
}
