package com.rawskinanalyzer

data class TrendAwareAdaptationResult(
    val decision: RoutineAdaptationResult,
    val trendInfluenceApplied: Boolean,
    val trendReasons: List<String>
)

object TrendAwareRoutineAdaptationPolicy {
    fun evaluate(
        shortTerm: SkinProgressResult,
        trend: MultiSessionTrendResult
    ): TrendAwareAdaptationResult {
        val base = RoutineAdaptationEngine.evaluate(shortTerm)

        if (trend.overallDirection == TrendDirection.INSUFFICIENT_TREND_DATA) {
            return TrendAwareAdaptationResult(
                decision = base,
                trendInfluenceApplied = false,
                trendReasons = listOf("INSUFFICIENT_MULTI_SESSION_TREND_DATA")
            )
        }

        val sustainedWorsening = trend.features.filter {
            it.direction == TrendDirection.SUSTAINED_WORSENING
        }.map { it.feature }

        val sustainedImprovement = trend.features.filter {
            it.direction == TrendDirection.SUSTAINED_IMPROVEMENT
        }.map { it.feature }

        val decision = when {
            sustainedWorsening.size >= 2 -> base.copy(
                action = RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT,
                reasons = (base.reasons + "SUSTAINED_MULTI_SESSION_WORSENING").distinct(),
                affectedFeatures = (base.affectedFeatures + sustainedWorsening).distinct(),
                adaptationConfidence = if (
                    trend.trendConfidence == "HIGH_TREND_CONFIDENCE"
                ) "HIGH" else "MODERATE"
            )

            sustainedImprovement.size >= 2 && sustainedWorsening.isEmpty() -> base.copy(
                action = RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE,
                reasons = (base.reasons + "SUSTAINED_MULTI_SESSION_IMPROVEMENT").distinct(),
                affectedFeatures = (base.affectedFeatures + sustainedImprovement).distinct(),
                adaptationConfidence = if (
                    trend.trendConfidence == "HIGH_TREND_CONFIDENCE"
                ) "HIGH" else "MODERATE"
            )

            else -> base.copy(
                reasons = (base.reasons + "MULTI_SESSION_TREND_REVIEWED").distinct()
            )
        }

        return TrendAwareAdaptationResult(
            decision = decision,
            trendInfluenceApplied = true,
            trendReasons = buildList {
                if (sustainedImprovement.isNotEmpty()) add("SUSTAINED_IMPROVEMENT_USED")
                if (sustainedWorsening.isNotEmpty()) add("SUSTAINED_WORSENING_USED")
                if (isEmpty()) add("NO_DOMINANT_SUSTAINED_TREND")
            }
        )
    }
}
