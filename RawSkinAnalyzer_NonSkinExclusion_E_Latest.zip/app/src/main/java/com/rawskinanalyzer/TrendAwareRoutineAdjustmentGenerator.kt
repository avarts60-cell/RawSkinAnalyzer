package com.rawskinanalyzer

data class RoutineAdjustmentCandidate(
    val concern: String,
    val targetIngredient: String,
    val proposedFrequency: String,
    val reason: String
)

data class TrendAwareRoutineAdjustment(
    val status: String,
    val candidates: List<RoutineAdjustmentCandidate>,
    val retainedRoutine: List<String>,
    val reviewFlags: List<String>
)

object TrendAwareRoutineAdjustmentGenerator {
    fun generate(
        adaptation: RoutineAdaptationResult,
        trend: MultiSessionTrendResult,
        ingredientPlans: List<IngredientUsePlan>,
        currentRoutine: FinalRoutineResult
    ): TrendAwareRoutineAdjustment {
        if (adaptation.action != RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT) {
            return TrendAwareRoutineAdjustment(
                status = "NO_ADJUSTMENT_REQUIRED",
                candidates = emptyList(),
                retainedRoutine = currentRoutine.morningRoutine + currentRoutine.eveningRoutine,
                reviewFlags = listOf("CURRENT_ADAPTATION_ACTION_DOES_NOT_REQUIRE_ADJUSTMENT")
            )
        }

        val worseningFeatures = trend.features
            .filter { it.direction == TrendDirection.SUSTAINED_WORSENING }
            .map { it.feature }

        val eligiblePlans = ingredientPlans.filter { plan ->
            val concernMatch = worseningFeatures.any {
                it.contains(plan.concern.name, ignoreCase = true) ||
                    plan.concern.name.contains(it, ignoreCase = true)
            }
            concernMatch && plan.caution == null
        }

        val candidates = eligiblePlans.map {
            RoutineAdjustmentCandidate(
                concern = it.concern.name,
                targetIngredient = it.ingredientName,
                proposedFrequency = "REVIEW_EXISTING_FREQUENCY_BEFORE_ESCALATION",
                reason = "SUSTAINED_WORSENING_MATCHED_TO_EXISTING_COMPATIBLE_PLAN"
            )
        }

        val flags = mutableListOf<String>()
        flags += "MANUAL_OR_POLICY_REVIEW_REQUIRED"
        flags += "NO_AUTOMATIC_FREQUENCY_ESCALATION"
        flags += "RECHECK_COMPATIBILITY_BEFORE_ACTIVATION"
        if (candidates.isEmpty()) flags += "NO_ELIGIBLE_EXISTING_INGREDIENT_PLAN"

        return TrendAwareRoutineAdjustment(
            status = if (candidates.isEmpty()) "REVIEW_REQUIRED_NO_CANDIDATE"
                     else "CANDIDATE_ADJUSTMENTS_GENERATED",
            candidates = candidates,
            retainedRoutine = currentRoutine.morningRoutine + currentRoutine.eveningRoutine,
            reviewFlags = flags.distinct()
        )
    }
}
