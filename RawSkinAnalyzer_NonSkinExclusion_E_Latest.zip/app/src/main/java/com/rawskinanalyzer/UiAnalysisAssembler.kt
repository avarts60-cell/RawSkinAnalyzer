package com.rawskinanalyzer

/**
 * UI-1B — UI-facing structured result bundle.
 *
 * Why this file exists: `FinalSkinAnalysisProfileAnalyzer.json()` already computes every
 * routine/progress/trend/adaptation object the UI needs, but it only returns a giant
 * pre-serialized JSON string — there was no structured Kotlin object a Compose screen could
 * bind to without re-parsing JSON inside a composable (which would violate the required
 * Compose -> ViewModel -> domain/repository flow). Rather than have the UI parse `json()`'s
 * output, or duplicate `json()` itself (which has real, one-time-only side effects —
 * `SkinSessionRepository.save(...)` persists this session, and `toleranceRepository.save(...)`
 * advances tolerance state), this file mirrors the exact same read side of that computation —
 * calling the exact same policy objects, in the exact same order, with the exact same
 * arguments — but stops short of any write. `MainActivity` calls this once per session,
 * strictly *before* the existing `json()` call, so both see identical "previous session" state;
 * `json()` remains completely unmodified and is still the single place persistence happens.
 *
 * Nothing here invents a score, confidence, recommendation, or historical session. Every field
 * below is a value some existing analyzer/policy already computed.
 */
data class FinalAnalysisBundle(
    val concerns: List<SkinConcern>,
    val objectives: List<SkinObjective>,
    val contextAdjustedSchedule: RoutineSchedule,
    val userRoutineContext: UserRoutineContext,
    val specificIngredients: List<SpecificIngredientOption>,
    val candidateSelections: List<CandidateSelectionDecision>,
    val selectedIngredients: List<SpecificIngredientOption>,
    val candidateCompatibility: List<CandidateCompatibilityDecision>,
    val toleranceRecords: List<IngredientToleranceRecord>,
    val routineIntensityDecisions: List<RoutineIntensityDecision>,
    val ingredientUsePlans: List<IngredientUsePlan>,
    val productRecommendations: List<ProductRecommendation>,
    val finalRoutineResult: FinalRoutineResult,
    val currentProgressSnapshot: SkinProgressSnapshot,
    val previousProgressSnapshot: SkinProgressSnapshot?,
    val progressResult: SkinProgressResult,
    val multiSessionTrend: MultiSessionTrendResult,
    val trendAwareAdaptation: TrendAwareAdaptationResult,
    val captureQualityReliability: CaptureQualityReliability,
    val generatedRoutineAdjustment: TrendAwareRoutineAdjustment,
    val controlledRoutineRevision: ControlledRoutineRevision,
    val routineExecution: RoutineAdaptationExecution,
    val analysisVersion: String,
    // BATCH 4A — additive longitudinal-comparability fields. All null/NOT_APPLICABLE-shaped
    // defaults when there is no previous session, exactly like `previousProgressSnapshot`
    // above — nothing here is shown as a comparison until a real previous session exists.
    val currentCaptureContext: SessionCaptureContext,
    val sessionComparability: SessionComparabilityResult?,
    val comparisonConfidence: ComparisonConfidenceResult?,
    val changeClassification: LongitudinalChangeResult?,
    val baselineSelection: SessionBaselineSelection,
    val baselineComparison: SkinProgressResult?,
    // BATCH 4B — additive per-characteristic comparability gating. Empty/unsuppressed-shaped
    // (mirrors the raw `progressResult.features`) when there is no previous session yet, exactly
    // like every other Batch 4A/4B comparison field's null-until-real-data convention.
    val characteristicComparability: List<CharacteristicComparabilityResult>,
    val gatedProgressFeatures: List<GatedFeatureProgress>,
    // BATCH 4C — additive per-characteristic longitudinal trend intelligence (repeated-session
    // evidence strength, trend confidence, direction stability). Populated for all eight
    // characteristics unconditionally (each individually reports INSUFFICIENT_HISTORY when there
    // is not yet enough data), mirroring every other Batch 4A/4B field's "always present, honest
    // about insufficiency" convention rather than being null until some threshold is met.
    val characteristicTrendIntelligence: List<CharacteristicTrendIntelligence>,
    // BATCH 4D-H — STEP 6: additive feature-level longitudinal result, complementary to (never
    // replacing) `characteristicTrendIntelligence` above — see FeatureLongitudinalTrend.kt.
    // Always present and honest about insufficiency (NOT_COMPARABLE/INSUFFICIENT_DATA are real,
    // shown states), mirroring every other Batch 4A/4B/4C field's convention.
    val featureLongitudinalResult: FeatureLongitudinalResult
)

object UiAnalysisAssembler {
    /**
     * Read-only mirror of `FinalSkinAnalysisProfileAnalyzer.json()`'s computation chain.
     * `toleranceRepository` is only ever `.get()` here, never `.save()`d — this function must
     * not advance tolerance state, since `json()` (called separately by MainActivity) already
     * does that exactly once per session.
     */
    fun assemble(
        x: FinalSkinAnalysisProfile,
        toleranceRepository: ToleranceStateRepository,
        captureConditionConsistency: String?,
        // BATCH 4A — additive, default null preserves the exact existing behavior for any
        // caller that hasn't been updated (comparability/baseline logic below simply treats
        // an unknown view count as "unknown" rather than penalizing or fabricating it).
        usableViewCount: Int? = null,
        // BATCH 4D-H — STEP 6: additive, default-empty preserves existing behavior exactly.
        // This is `MainActivity.lastFeatureIdentityRecords` for the CURRENT session — the same
        // value the real save path (`FinalSkinAnalysisProfileAnalyzer.json()`) receives, passed
        // here too so this read-only mirror can show the identical feature-trend section
        // without recomputing correspondence/fusion itself. This function still never saves
        // anything, per this file's own top-level doc comment.
        currentFeatureIdentityRecords: List<FeatureIdentityRecord> = emptyList()
    ): FinalAnalysisBundle {
        val concerns = SkinConcernInterpreter.fromFinalProfile(x)
        val objectives = SkinObjectivePlanner.plan(concerns, x.analysisConfidence)
        val strategy = RoutineStrategyPlanner.plan(objectives)
        val ingredientStrategy = IngredientStrategyPlanner.plan(strategy)
        val routineAssembly = RoutineCompatibilityPlanner.plan(ingredientStrategy)
        val routineSchedule = RoutineSchedulePlanner.plan(strategy, routineAssembly)
        val userRoutineContext = RoutineContextPlanner.defaultContext()
        val contextAdjustedSchedule = RoutineContextPlanner.apply(routineSchedule, userRoutineContext)
        val specificIngredients = SpecificIngredientMapper.map(ingredientStrategy, userRoutineContext)

        val candidateSelections = EvidenceAwareCandidateSelectionPolicy.select(specificIngredients, concerns)
        val candidateSelectionByKey = candidateSelections.associateBy {
            "${it.concern}:${it.ingredientName}:${it.role}"
        }
        val selectedIngredients = specificIngredients.filter { option ->
            candidateSelectionByKey["${option.concern}:${option.ingredientName}:${option.role}"]
                ?.selectionStatus == CandidateSelectionStatus.SELECTED
        }

        val candidateCompatibility = CandidateCompatibilityPolicy.plan(selectedIngredients)
        val compatibilityByName = candidateCompatibility.associateBy { it.ingredientName }

        // Read-only: reflects each ingredient's tolerance record as it stands going into this
        // session, without transitioning/saving it. json() performs the real transition+save.
        val toleranceSnapshot = selectedIngredients
            .map { it.ingredientName }
            .distinct()
            .associateWith { toleranceRepository.get(it) }

        val toleranceFilterDecisions = ToleranceAwareCandidateFilter.apply(selectedIngredients, toleranceSnapshot)
        val toleranceFilterByName = toleranceFilterDecisions.associateBy { it.ingredientName }
        val toleranceApprovedIngredients = selectedIngredients.filter {
            toleranceFilterByName[it.ingredientName]?.outcome != ToleranceFilterOutcome.EXCLUDED
        }

        val routineIntensityDecisions = toleranceApprovedIngredients.map { candidate ->
            val concernConfidence = concerns.firstOrNull { it.category == candidate.concern }?.confidence ?: "LOW"
            RoutineIntensityPolicy.calibrate(
                ingredientName = candidate.ingredientName,
                objectiveType = candidate.objectiveType,
                confidence = concernConfidence,
                compatibility = compatibilityByName[candidate.ingredientName]?.action ?: RoutineCompatibilityAction.REVIEW_REQUIRED,
                tolerance = toleranceSnapshot[candidate.ingredientName]?.state ?: ToleranceState.UNKNOWN
            )
        }

        // Batch 4D-A: mirrors the same real connection made in
        // FinalSkinAnalysisProfileAnalyzer.json() — routineIntensityDecisions/tolerance state
        // were already computed above in this file too, but were not previously passed into
        // use-planning here either.
        val intensityByName = routineIntensityDecisions.associateBy { it.ingredientName }
        val toleranceStateByName = toleranceSnapshot.mapValues { (_, record) -> record.state }
        val ingredientUsePlans = IngredientUsePlanner.plan(
            toleranceApprovedIngredients,
            userRoutineContext,
            intensityByName,
            toleranceStateByName
        )
        val productRequirements = ProductSelectionPlanner.requirements(ingredientUsePlans)
        val productCatalogCandidates = ProductCatalogRepository.candidates()
        val productMatches = ProductSelectionPlanner.rank(productRequirements, productCatalogCandidates)
        val acceptedProductMatches = productMatches.filter { it.accepted }
        val productRecommendations = ProductRecommendationAssembler.assemble(
            productRequirements,
            acceptedProductMatches,
            ingredientUsePlans
        )
        val finalRoutineResult = FinalRoutineResultAssembler.assemble(
            x.primaryFinding,
            x.secondaryFinding,
            contextAdjustedSchedule,
            ingredientUsePlans,
            productRecommendations
        )

        val currentProgressSnapshot = SkinProgressSnapshot(
            pigmentationScore = x.pigmentationScore,
            darkMarkScore = x.darkMarkScore,
            blemishLikeScore = x.blemishLikeScore,
            rednessScore = x.rednessScore,
            poreLikeScore = x.poreLikeScore,
            shineScore = x.surfaceShineScore,
            textureScore = x.textureIrregularityScore,
            drynessScore = x.drynessRelatedScore,
            confidence = x.analysisConfidence
        )
        val analysisVersion = "final_skin_analysis_profile_v29"
        val previousSession = SkinSessionRepository.previousSession(analysisVersion)
        val previousProgressSnapshot = previousSession?.snapshot
        val progressResult = SkinProgressTracker.compare(previousProgressSnapshot, currentProgressSnapshot)
        val trendHistory = SkinSessionRepository.compatibleHistory(analysisVersion) + currentProgressSnapshot
        val multiSessionTrend = MultiSessionTrendAnalyzer.analyze(trendHistory)
        val rawTrendAwareAdaptation = TrendAwareRoutineAdaptationPolicy.evaluate(progressResult, multiSessionTrend)
        val captureQualityReliability = CaptureQualityReliabilityGate.classify(captureConditionConsistency)
        val captureGatedAdaptation = CaptureQualityReliabilityGate.apply(rawTrendAwareAdaptation, captureQualityReliability)

        // BATCH 4A — steps 2/3/5/7/8: the current session's capture context, its comparability
        // against the previous session (if any), the resulting comparison confidence and
        // conservative change classification, and a separate fixed-baseline comparison. Each
        // wraps already-computed values above (`captureConditionConsistency`, `x`'s existing
        // per-characteristic scores/confidence, `progressResult`, `multiSessionTrend`) — no
        // score, confidence, or history is recomputed or duplicated.
        val currentCaptureContext = SessionCaptureContext.from(captureConditionConsistency, usableViewCount)
        val sessionComparability = previousSession?.let {
            SessionComparabilityEvaluator.evaluate(it, currentCaptureContext, analysisVersion)
        }

        // BATCH 4D-H — STEP 6: same read-only computation as the save path
        // (`FinalSkinAnalysisProfileAnalyzer.json()`), reusing `sessionComparability` computed
        // immediately above and the previous session's STORED feature records — never a second,
        // differently-derived comparability judgment for the same two sessions.
        val previousFeatureIdentityRecords = SkinSessionRepository.previousFeatureIdentityRecords(analysisVersion)
        val featureLongitudinalResult = FeatureLongitudinalTrendAnalyzer.analyze(
            previousRecords = previousFeatureIdentityRecords,
            currentRecords = currentFeatureIdentityRecords,
            comparability = sessionComparability
        )

        val comparisonConfidence = sessionComparability?.let {
            ComparisonConfidencePolicy.evaluate(it, previousProgressSnapshot!!.confidence, x.analysisConfidence)
        }
        val changeClassification = sessionComparability?.let { comparability ->
            LongitudinalChangeClassifier.classify(progressResult, multiSessionTrend, comparability, comparisonConfidence!!)
        }
        val baselineSelection = SkinSessionRepository.selectBaseline(analysisVersion)
        val baselineComparison = baselineSelection.baseline?.let { baseline ->
            if (baseline.sessionId == previousSession?.sessionId) null // avoid a redundant duplicate of progressResult
            else SkinProgressTracker.compare(baseline.snapshot, currentProgressSnapshot)
        }

        // BATCH 4B — steps 1-3: per-characteristic comparability gating, built on top of the
        // session-level `sessionComparability` computed above. `x.findings` already covers
        // exactly the eight characteristics this batch names, each carrying its own
        // already-computed `confidence` from Batch 1's calibration/confidence stage.
        val characteristicComparability =
            CharacteristicComparabilityEvaluator.evaluateAll(x.findings, sessionComparability)
        val characteristicComparabilityByName = characteristicComparability.associateBy { it.characteristic }
        val gatedProgressFeatures =
            CharacteristicGatedProgress.gate(progressResult, characteristicComparabilityByName)

        // BATCH 4B — step 4 (SECONDARY): the existing capture-quality-only cap
        // (`CaptureQualityReliabilityGate`, Batch 3B) is extended with a second, separately
        // reasoned cap for session-pair comparability, following the same cap-only pattern.
        val comparabilityGatedAdaptation = ComparabilityAdaptationGate.apply(captureGatedAdaptation, sessionComparability)

        // BATCH 4C — repeated-session trend evidence, trend confidence, and direction stability,
        // per characteristic. Reuses `multiSessionTrend` (already computed above),
        // `characteristicComparability` (Batch 4B, already computed above), and
        // `baselineSelection` (Batch 4A, already computed above) rather than recomputing any of
        // them. `SkinSessionRepository.history()` naturally excludes the current session (it is
        // saved separately, once, only inside `json()`), so this is genuinely historical-only.
        val orderedSessionHistory = SkinSessionRepository.history()
            .filter { it.analysisVersion == analysisVersion }
            .sortedBy { it.createdAtEpochMillis }
        val characteristicTrendIntelligence = CharacteristicTrendIntelligenceAnalyzer.analyzeAll(
            orderedHistory = orderedSessionHistory,
            currentSnapshot = currentProgressSnapshot,
            multiSessionTrend = multiSessionTrend,
            characteristicComparability = characteristicComparability,
            baseline = baselineSelection.baseline
        )
        val trendIntelligenceByCharacteristic = characteristicTrendIntelligence.associateBy { it.characteristic }
        val trendAwareAdaptation = FeatureLongitudinalAdaptationGate.apply(
            TrendIntelligenceAdaptationGate.apply(
                comparabilityGatedAdaptation,
                trendIntelligenceByCharacteristic
            ),
            featureLongitudinalResult
        )

        val generatedRoutineAdjustment = TrendAwareRoutineAdjustmentGenerator.generate(
            trendAwareAdaptation.decision,
            multiSessionTrend,
            ingredientUsePlans,
            finalRoutineResult
        )
        val controlledRoutineRevision = RoutineAdjustmentCandidateActivator.activate(
            generatedRoutineAdjustment,
            ingredientUsePlans,
            finalRoutineResult,
            toleranceByIngredient = toleranceSnapshot
        )
        val routineExecution = RoutineAdaptationExecutor.execute(trendAwareAdaptation.decision, finalRoutineResult)

        return FinalAnalysisBundle(
            concerns = concerns,
            objectives = objectives,
            contextAdjustedSchedule = contextAdjustedSchedule,
            userRoutineContext = userRoutineContext,
            specificIngredients = specificIngredients,
            candidateSelections = candidateSelections,
            selectedIngredients = selectedIngredients,
            candidateCompatibility = candidateCompatibility,
            toleranceRecords = toleranceSnapshot.values.toList(),
            routineIntensityDecisions = routineIntensityDecisions,
            ingredientUsePlans = ingredientUsePlans,
            productRecommendations = productRecommendations,
            finalRoutineResult = finalRoutineResult,
            currentProgressSnapshot = currentProgressSnapshot,
            previousProgressSnapshot = previousProgressSnapshot,
            progressResult = progressResult,
            multiSessionTrend = multiSessionTrend,
            trendAwareAdaptation = trendAwareAdaptation,
            captureQualityReliability = captureQualityReliability,
            generatedRoutineAdjustment = generatedRoutineAdjustment,
            controlledRoutineRevision = controlledRoutineRevision,
            routineExecution = routineExecution,
            analysisVersion = analysisVersion,
            currentCaptureContext = currentCaptureContext,
            sessionComparability = sessionComparability,
            comparisonConfidence = comparisonConfidence,
            changeClassification = changeClassification,
            baselineSelection = baselineSelection,
            baselineComparison = baselineComparison,
            characteristicComparability = characteristicComparability,
            gatedProgressFeatures = gatedProgressFeatures,
            characteristicTrendIntelligence = characteristicTrendIntelligence,
            featureLongitudinalResult = featureLongitudinalResult
        )
    }
}

/**
 * UI-1B — Skin Map structured result. Mirrors exactly what MainActivity's existing
 * runLocalizedPatternMapping()/runPatternHotspotDetection()/runCrossViewHotspotComparison()
 * stages already compute per view, bundled for the UI instead of only being written to
 * per-stage JSON files.
 */
data class SkinMapViewData(
    val cells: List<PatternMapCell>,
    val hotspots: List<PatternHotspot>
)

data class SkinMapBundle(
    val front: SkinMapViewData,
    val leftCheek: SkinMapViewData,
    val rightCheek: SkinMapViewData,
    val crossViewComparison: HotspotComparison
)

object SkinMapAssembler {
    fun assemble(
        frontCells: List<PatternMapCell>,
        leftCells: List<PatternMapCell>,
        rightCells: List<PatternMapCell>
    ): SkinMapBundle {
        val frontHotspots = PatternHotspotAnalyzer.analyze(frontCells)
        val leftHotspots = PatternHotspotAnalyzer.analyze(leftCells)
        val rightHotspots = PatternHotspotAnalyzer.analyze(rightCells)
        val comparison = CrossViewHotspotComparator.compare(frontHotspots, leftHotspots, rightHotspots)
        return SkinMapBundle(
            front = SkinMapViewData(frontCells, frontHotspots),
            leftCheek = SkinMapViewData(leftCells, leftHotspots),
            rightCheek = SkinMapViewData(rightCells, rightHotspots),
            crossViewComparison = comparison
        )
    }
}
