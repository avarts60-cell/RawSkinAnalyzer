package com.rawskinanalyzer

/**
 * UnifiedFeatureDiagnostics
 *
 * Batch 4D-G, step_9 (P0). One diagnostic object per session covering every stage from raw
 * specialized-feature evidence through fused cross-view evidence — every count below is read
 * directly off already-produced data structures (no re-estimation, per this step's own "use
 * actual computed data" / "do not fabricate visual maps" rules); this file only aggregates.
 *
 * Longitudinal metadata availability is reported as a plain boolean/count pair rather than as
 * real longitudinal figures, since (per `LongitudinalFeatureContract`'s own doc comment) this
 * batch does not yet persist feature identity records across sessions — reporting anything more
 * specific here would imply a longitudinal capability that does not exist yet.
 */
data class UnifiedFeatureDiagnosticsResult(
    val view: String,
    val specializedFeatureCountByType: Map<SpecializedFeatureType, Int>,
    val bumpCandidateCount: Int,
    val hairStubbleCount: Int,
    val poreFollicleCount: Int,
    val blemishCount: Int,
    val darkMarkCount: Int,
    val rednessCount: Int,
    val shineCount: Int,
    val confidenceDistribution: IntArray
)

data class UnifiedSessionDiagnosticsResult(
    val perView: List<UnifiedFeatureDiagnosticsResult>,
    val correspondenceCount: Int,
    val correspondenceCountByState: Map<CorrespondenceState, Int>,
    val supportingViewCountDistribution: Map<Int, Int>, // 1, 2, or 3 supporting views -> count of correspondences
    val fusedFeatureCount: Int,
    val postAcneAssociationCount: Int,
    val regionalMetrics: List<RegionalFusedMetrics>,
    val longitudinalMetadataAvailable: Boolean,
    val longitudinalIdentityRecordCount: Int,
    // BATCH 4D-H — STEP 8: additive cross-session diagnostics. Reuses the exact
    // `FeatureLongitudinalResult` already computed once by `FeatureLongitudinalTrendAnalyzer`
    // (passed in by the caller) — this object does not run any comparison itself, only reports
    // on one that already ran, per this file's own "use actual computed evidence" rule.
    val crossSessionComparabilityStatus: SessionComparabilityStatus?,
    val crossSessionChangeCount: Int,
    val crossSessionChangeCountByType: Map<FeatureChangeType, Int>,
    val crossSessionOverallDataStatus: String
)

object UnifiedFeatureDiagnostics {
    const val VERSION = "unified_feature_diagnostics_v1"

    private val hairFamily = setOf(SpecializedFeatureType.HAIR_LIKE, SpecializedFeatureType.STUBBLE_LIKE)
    private val poreFamily = setOf(SpecializedFeatureType.PORE_LIKE, SpecializedFeatureType.FOLLICULAR_OPENING_LIKE)
    private val blemishFamily = setOf(
        SpecializedFeatureType.BLEMISH_LIKE, SpecializedFeatureType.BLACKHEAD_LIKE, SpecializedFeatureType.WHITEHEAD_LIKE,
        SpecializedFeatureType.PAPULE_LIKE_VISUAL, SpecializedFeatureType.PUSTULE_LIKE_VISUAL, SpecializedFeatureType.UNCERTAIN_BLEMISH_LIKE
    )
    private val darkFamily = setOf(
        SpecializedFeatureType.DARK_MARK_LIKE, SpecializedFeatureType.PIGMENTATION_LIKE,
        SpecializedFeatureType.RED_MARK_LIKE, SpecializedFeatureType.POST_ACNE_MARK_LIKE, SpecializedFeatureType.UNCERTAIN_DARK_FEATURE
    )
    private val rednessFamily = setOf(SpecializedFeatureType.LOCALIZED_REDNESS_LIKE)

    fun perView(view: String, evidence: List<SpecializedFeatureEvidence>, bumpCandidates: List<BumpCandidate>, shineCount: Int): UnifiedFeatureDiagnosticsResult {
        val distribution = IntArray(5)
        for (e in evidence) distribution[(e.primaryConfidence * 5).toInt().coerceIn(0, 4)]++
        return UnifiedFeatureDiagnosticsResult(
            view = view,
            specializedFeatureCountByType = evidence.groupingBy { it.featureType }.eachCount(),
            bumpCandidateCount = bumpCandidates.size,
            hairStubbleCount = evidence.count { it.featureType in hairFamily },
            poreFollicleCount = evidence.count { it.featureType in poreFamily },
            blemishCount = evidence.count { it.featureType in blemishFamily },
            darkMarkCount = evidence.count { it.featureType in darkFamily },
            rednessCount = evidence.count { it.featureType in rednessFamily },
            shineCount = shineCount,
            confidenceDistribution = distribution
        )
    }

    fun session(
        perView: List<UnifiedFeatureDiagnosticsResult>,
        correspondences: List<FeatureCorrespondence>,
        fused: List<FusedFeatureEvidence>,
        postAcneAssociationCount: Int,
        regionalMetrics: List<RegionalFusedMetrics>,
        longitudinalIdentityRecordCount: Int,
        // BATCH 4D-H — STEP 8: additive, default-null preserves the exact existing behavior for
        // any caller that hasn't been updated (cross-session fields simply report as
        // unavailable/zero, same as before this parameter existed — mirroring every other
        // additive-optional-parameter convention already established in this codebase).
        crossSessionResult: FeatureLongitudinalResult? = null
    ): UnifiedSessionDiagnosticsResult = UnifiedSessionDiagnosticsResult(
        perView = perView,
        correspondenceCount = correspondences.size,
        correspondenceCountByState = correspondences.groupingBy { it.state }.eachCount(),
        supportingViewCountDistribution = correspondences.groupingBy { it.supportingViews.size }.eachCount(),
        fusedFeatureCount = fused.size,
        postAcneAssociationCount = postAcneAssociationCount,
        regionalMetrics = regionalMetrics,
        longitudinalMetadataAvailable = longitudinalIdentityRecordCount > 0,
        longitudinalIdentityRecordCount = longitudinalIdentityRecordCount,
        crossSessionComparabilityStatus = crossSessionResult?.comparability?.status,
        crossSessionChangeCount = crossSessionResult?.changes?.size ?: 0,
        crossSessionChangeCountByType = crossSessionResult?.changes?.groupingBy { it.changeType }?.eachCount() ?: emptyMap(),
        crossSessionOverallDataStatus = crossSessionResult?.overallDataStatus ?: "NOT_COMPUTED_THIS_SESSION"
    )

    fun perViewJson(d: UnifiedFeatureDiagnosticsResult): String {
        val byType = d.specializedFeatureCountByType.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        return """{"view":"${d.view}","specialized_feature_count_by_type":{$byType},"bump_candidate_count":${d.bumpCandidateCount},"hair_stubble_count":${d.hairStubbleCount},"pore_follicle_count":${d.poreFollicleCount},"blemish_count":${d.blemishCount},"dark_mark_count":${d.darkMarkCount},"redness_count":${d.rednessCount},"shine_count":${d.shineCount},"confidence_distribution":[${d.confidenceDistribution.joinToString(",")}]}"""
    }

    fun sessionJson(d: UnifiedSessionDiagnosticsResult): String {
        val perViewJson = d.perView.joinToString(",") { perViewJson(it) }
        val byState = d.correspondenceCountByState.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        val byViewCount = d.supportingViewCountDistribution.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        val metricsJson = d.regionalMetrics.joinToString(",") { CrossViewFeatureFusionEngine.regionalMetricsJson(it) }
        val byChangeType = d.crossSessionChangeCountByType.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        val crossSessionStatus = d.crossSessionComparabilityStatus?.let { "\"$it\"" } ?: "null"
        return """{"method":"$VERSION","per_view":[$perViewJson],"correspondence_count":${d.correspondenceCount},"correspondence_count_by_state":{$byState},"supporting_view_count_distribution":{$byViewCount},"fused_feature_count":${d.fusedFeatureCount},"post_acne_association_count":${d.postAcneAssociationCount},"regional_metrics":[$metricsJson],"longitudinal_metadata_available":${d.longitudinalMetadataAvailable},"longitudinal_identity_record_count":${d.longitudinalIdentityRecordCount},"cross_session_comparability_status":$crossSessionStatus,"cross_session_change_count":${d.crossSessionChangeCount},"cross_session_change_count_by_type":{$byChangeType},"cross_session_overall_data_status":"${d.crossSessionOverallDataStatus}"}"""
    }
}
