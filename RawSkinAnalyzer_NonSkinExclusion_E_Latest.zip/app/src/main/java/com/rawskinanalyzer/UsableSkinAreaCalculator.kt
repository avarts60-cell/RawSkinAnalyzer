package com.rawskinanalyzer

import kotlin.math.max

/**
 * UsableSkinAreaCalculator
 *
 * Batch 4E-A, step_1/step_2. Replaces the "sampledCellsProxy" fake denominator that
 * [SpecializedFeatureEvidenceAssembler.regionalMetrics], [ShineDetectionEngine.regionalSummary],
 * and [BumpSurfaceStructureEngine.regionalSummary] each independently invented
 * ("candidate count plus a per-tile constant" — see each of those functions' own prior doc
 * comments) with a real usable-skin-area figure, in actual pixels, derived from data the
 * pipeline already computed.
 *
 * Why this is genuinely real rather than another proxy: [MultiScaleTileExtractor] already builds
 * one MACRO tile per region whose `width`/`height` are the region's real bounding-box dimensions
 * — in original-capture pixels when `FaceGeometryResult.originalScaleAvailable` is true (see that
 * tile's own `originalCoordinatesAvailable` flag), otherwise honestly reported in normalized-image
 * pixels rather than fabricating a scale (same rule `MultiScaleTileExtractor.buildTile` already
 * follows). That MACRO tile's `skinCoverage`/`highConfidenceSkinCoverage`/`excludedCoverage` are
 * themselves the SAME cell-derived percentages `FaceConstrainedSkinAnalyzer` computed from
 * `SkinSegmentationEngine`'s per-pixel HIGH/MEDIUM/LOW/EXCLUDED classification (see
 * `MultiScaleTileSet.regionSkinCoverage` and friends). Multiplying real region area by real
 * skin-coverage percentages yields a real pixel-area figure — not a re-derivation of skin
 * classification, and not an invented physical/physiological measurement (still pixels, not mm).
 *
 * Medium-confidence pixels are weighted at 0.6 in [RegionUsableSkinArea.confidenceWeightedSkinAreaPixels]
 * to match [SkinSegmentationEngine.classify]'s own MEDIUM contribution weight — this file does not
 * invent a second confidence-weighting scheme, it reuses the one already established.
 */

data class RegionUsableSkinArea(
    val view: String,
    val region: AnatomicalRegion,
    /** Real bounding-box pixel area of the region's MACRO tile. 0 when no tile geometry is available. */
    val totalRegionAreaPixels: Long,
    /** "ORIGINAL_IMAGE_PIXELS" when the tile's width/height are real capture-image pixels,
     * "NORMALIZED_IMAGE_PIXELS_FALLBACK" when only normalized-image pixels were available (see
     * class doc), "UNAVAILABLE" when no MACRO tile exists at all for this region this session. */
    val areaBasis: String,
    val highConfidenceSkinAreaPixels: Double,
    val mediumConfidenceSkinAreaPixels: Double,
    /** high + medium. The actual usable-skin-area denominator for density figures. */
    val usableSkinAreaPixels: Double,
    val excludedAreaPixels: Double,
    /** high*1.0 + medium*0.6 — see class doc for why 0.6. */
    val confidenceWeightedSkinAreaPixels: Double,
    val usableSkinCoveragePercent: Double
)

object UsableSkinAreaCalculator {
    const val VERSION = "usable_skin_area_v1"

    /** Matches SkinSegmentationEngine.classify's MEDIUM tier weight — not re-derived, reused. */
    private const val MEDIUM_CONFIDENCE_WEIGHT = 0.6

    fun forRegion(view: String, tileSet: MultiScaleTileSet): RegionUsableSkinArea {
        val macro = tileSet.macroTiles.firstOrNull()
        val totalAreaPixels: Long
        val basis: String
        if (macro != null && macro.width > 0 && macro.height > 0) {
            totalAreaPixels = macro.width.toLong() * macro.height.toLong()
            basis = if (macro.originalCoordinatesAvailable) "ORIGINAL_IMAGE_PIXELS" else "NORMALIZED_IMAGE_PIXELS_FALLBACK"
        } else {
            totalAreaPixels = 0L
            basis = "UNAVAILABLE"
        }

        val skinPct = tileSet.regionSkinCoverage
        val highPct = tileSet.regionHighConfidenceSkinCoverage
        val mediumPct = max(0.0, skinPct - highPct)
        val exclPct = tileSet.regionExcludedCoverage

        val highArea = totalAreaPixels * (highPct / 100.0)
        val mediumArea = totalAreaPixels * (mediumPct / 100.0)
        val usableArea = highArea + mediumArea
        val exclArea = totalAreaPixels * (exclPct / 100.0)
        val weightedArea = highArea * 1.0 + mediumArea * MEDIUM_CONFIDENCE_WEIGHT

        return RegionUsableSkinArea(
            view = view,
            region = tileSet.region,
            totalRegionAreaPixels = totalAreaPixels,
            areaBasis = basis,
            highConfidenceSkinAreaPixels = highArea,
            mediumConfidenceSkinAreaPixels = mediumArea,
            usableSkinAreaPixels = usableArea,
            excludedAreaPixels = exclArea,
            confidenceWeightedSkinAreaPixels = weightedArea,
            usableSkinCoveragePercent = skinPct
        )
    }

    fun forView(view: String, tileSets: List<MultiScaleTileSet>): List<RegionUsableSkinArea> =
        tileSets.map { forRegion(view, it) }

    /** Per-view total usable-skin area, summed across regions. Not itself tied to one [AnatomicalRegion], so it is its own type rather than a misuse of [RegionUsableSkinArea]'s per-region field. */
    data class ViewUsableSkinArea(
        val view: String,
        val totalAreaPixels: Long,
        val areaBasis: String,
        val highConfidenceSkinAreaPixels: Double,
        val mediumConfidenceSkinAreaPixels: Double,
        val usableSkinAreaPixels: Double,
        val excludedAreaPixels: Double,
        val confidenceWeightedSkinAreaPixels: Double,
        val usableSkinCoveragePercent: Double,
        val regionsIncluded: Int
    )

    /**
     * Real density per 1,000,000 usable-skin pixels (~1 megapixel of usable skin), replacing the
     * old candidate-count-based sampledCellsProxy. Returns null (never a fabricated 0.0 or a
     * divide-by-a-fake-constant) when usable area is zero/unavailable, so callers can distinguish
     * "no usable skin to normalize against" from "measured zero density" instead of silently
     * conflating the two, per this batch's "preserve uncertainty" principle.
     */
    fun densityPerMillionUsableSkinPixels(candidateCount: Int, usableSkinAreaPixels: Double): Double? {
        if (usableSkinAreaPixels <= 0.0) return null
        return (candidateCount.toDouble() / usableSkinAreaPixels) * 1_000_000.0
    }

    /**
     * Batch 4E-C, step_1 addition: same formula as the [Int] overload above, but for a
     * fractional candidate count — specifically [CandidateQualityGate]'s `qualityWeightedTotal`
     * (an ACCEPT contributes 1.0, a WEIGHT contributes its 0.0-1.0 multiplier, a REJECT
     * contributes 0.0). Kept as a genuine overload rather than changing the [Int] signature above,
     * so every existing caller of the [Int] version (raw, ungated density) keeps compiling and
     * keeps its exact prior meaning unchanged.
     */
    fun densityPerMillionUsableSkinPixels(candidateCount: Double, usableSkinAreaPixels: Double): Double? {
        if (usableSkinAreaPixels <= 0.0) return null
        return (candidateCount / usableSkinAreaPixels) * 1_000_000.0
    }

    /** Sums per-region areas already computed for one view into a single per-view total. Regions with UNAVAILABLE basis contribute 0 area but do not block the sum. */
    fun totalForView(regions: List<RegionUsableSkinArea>): ViewUsableSkinArea {
        if (regions.isEmpty()) {
            return ViewUsableSkinArea(
                view = "UNKNOWN", totalAreaPixels = 0L, areaBasis = "UNAVAILABLE",
                highConfidenceSkinAreaPixels = 0.0, mediumConfidenceSkinAreaPixels = 0.0,
                usableSkinAreaPixels = 0.0, excludedAreaPixels = 0.0,
                confidenceWeightedSkinAreaPixels = 0.0, usableSkinCoveragePercent = 0.0, regionsIncluded = 0
            )
        }
        val totalArea = regions.sumOf { it.totalRegionAreaPixels }
        val usable = regions.sumOf { it.usableSkinAreaPixels }
        return ViewUsableSkinArea(
            view = regions.first().view,
            totalAreaPixels = totalArea,
            areaBasis = if (regions.any { it.areaBasis == "ORIGINAL_IMAGE_PIXELS" }) "ORIGINAL_IMAGE_PIXELS"
                        else if (regions.any { it.areaBasis == "NORMALIZED_IMAGE_PIXELS_FALLBACK" }) "NORMALIZED_IMAGE_PIXELS_FALLBACK"
                        else "UNAVAILABLE",
            highConfidenceSkinAreaPixels = regions.sumOf { it.highConfidenceSkinAreaPixels },
            mediumConfidenceSkinAreaPixels = regions.sumOf { it.mediumConfidenceSkinAreaPixels },
            usableSkinAreaPixels = usable,
            excludedAreaPixels = regions.sumOf { it.excludedAreaPixels },
            confidenceWeightedSkinAreaPixels = regions.sumOf { it.confidenceWeightedSkinAreaPixels },
            usableSkinCoveragePercent = if (totalArea > 0) usable / totalArea * 100.0 else 0.0,
            regionsIncluded = regions.size
        )
    }

    fun json(a: RegionUsableSkinArea): String =
        """{"view":"${a.view}","region":"${a.region}","total_region_area_pixels":${a.totalRegionAreaPixels},"area_basis":"${a.areaBasis}","high_confidence_skin_area_pixels":${a.highConfidenceSkinAreaPixels},"medium_confidence_skin_area_pixels":${a.mediumConfidenceSkinAreaPixels},"usable_skin_area_pixels":${a.usableSkinAreaPixels},"excluded_area_pixels":${a.excludedAreaPixels},"confidence_weighted_skin_area_pixels":${a.confidenceWeightedSkinAreaPixels},"usable_skin_coverage_percent":${a.usableSkinCoveragePercent}}"""

    fun json(list: List<RegionUsableSkinArea>): String =
        """{"method":"$VERSION","regions":[${list.joinToString(",") { json(it) }}]}"""

    fun json(v: ViewUsableSkinArea): String =
        """{"view":"${v.view}","total_area_pixels":${v.totalAreaPixels},"area_basis":"${v.areaBasis}","high_confidence_skin_area_pixels":${v.highConfidenceSkinAreaPixels},"medium_confidence_skin_area_pixels":${v.mediumConfidenceSkinAreaPixels},"usable_skin_area_pixels":${v.usableSkinAreaPixels},"excluded_area_pixels":${v.excludedAreaPixels},"confidence_weighted_skin_area_pixels":${v.confidenceWeightedSkinAreaPixels},"usable_skin_coverage_percent":${v.usableSkinCoveragePercent},"regions_included":${v.regionsIncluded}}"""
}
