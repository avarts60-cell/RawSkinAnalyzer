package com.rawskinanalyzer

enum class RoutineComplexity { MINIMAL, STANDARD, FLEXIBLE }
enum class TolerancePreference { CAUTIOUS, BALANCED, FLEXIBLE }
enum class ActiveIntensityPreference { LOW, MODERATE, UNSPECIFIED }

data class UserRoutineContext(
    val complexity: RoutineComplexity = RoutineComplexity.STANDARD,
    val tolerancePreference: TolerancePreference = TolerancePreference.BALANCED,
    val activeIntensityPreference: ActiveIntensityPreference = ActiveIntensityPreference.UNSPECIFIED,
    val morningTimeLimitMinutes: Int? = null,
    val eveningTimeLimitMinutes: Int? = null,
    val excludedCategories: Set<String> = emptySet()
)

object RoutineContextPlanner {
    fun defaultContext() = UserRoutineContext()

    fun apply(
        schedule: RoutineSchedule,
        context: UserRoutineContext
    ): RoutineSchedule {
        fun allowed(step: ScheduledRoutineStep) =
            step.category !in context.excludedCategories

        val morning = schedule.morningSteps.filter(::allowed).let { steps ->
            if (context.complexity == RoutineComplexity.MINIMAL) steps.take(1) else steps
        }
        val evening = schedule.eveningBaseSteps.filter(::allowed).let { steps ->
            if (context.complexity == RoutineComplexity.MINIMAL) steps.take(1) else steps
        }
        val alternating = schedule.alternatingNightSteps.filter(::allowed).let { steps ->
            when {
                context.tolerancePreference == TolerancePreference.CAUTIOUS -> steps.take(1)
                context.activeIntensityPreference == ActiveIntensityPreference.LOW -> steps.take(1)
                else -> steps
            }
        }

        val weekly = mutableListOf<String>()
        weekly += "CONTEXT: COMPLEXITY=${context.complexity}"
        weekly += "CONTEXT: TOLERANCE=${context.tolerancePreference}"
        weekly += "CONTEXT: ACTIVE_INTENSITY=${context.activeIntensityPreference}"
        weekly += schedule.weeklyPattern

        return RoutineSchedule(morning, evening, alternating, weekly)
    }
}
