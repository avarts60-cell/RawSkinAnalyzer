package com.rawskinanalyzer

import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * VisualFeatureCandidateEngine
 *
 * Batch 4D-D. The step_1 "reusable engine that identifies local visual structures inside
 * usable-skin areas", wired to the existing MACRO/MESO/MICRO tile pyramid (`MultiScaleTileExtractor`)
 * and skin-confidence data (`FaceConstrainedSkinAnalyzer`) rather than re-deriving either.
 *
 * Performance strategy (step_19): MICRO tiles carry the finest structural detail, so candidate
 * detection runs there. Decoding every MICRO tile in a region at full resolution is unnecessary —
 * MICRO tiles overlap by design (`MultiScaleTileExtractor.MICRO_OVERLAP_FRACTION`), so this engine
 * takes the top [MAX_MICRO_TILES_PER_REGION] MICRO tiles per region ranked by
 * `highConfidenceSkinCoverage` (the tiles most likely to contain real usable-skin structure,
 * reusing metadata `MultiScaleTileExtractor` already computed — no new coverage estimate). A
 * region already flagged `fineTilingSkippedReason` (low usable-skin coverage) produces zero
 * candidates, consistent with that stage's own gate rather than second-guessing it.
 */
object VisualFeatureCandidateEngine {
    const val VERSION = "visual_feature_candidate_engine_v1"

    private const val MAX_MICRO_TILES_PER_REGION = 5

    /** step_3: skin-confidence weighting applied to every candidate found within a tile. Uses the tile's own already-computed coverage fields — no per-pixel re-classification.
     * Batch 4D-F: widened from `private` to `internal` (no behavior change) so [ShineDetectionEngine]
     * can apply the exact same skin-weighting to shine candidates instead of duplicating this logic. */
    internal fun skinSupportFor(tile: AnalysisTile): CandidateSkinSupport {
        val highFraction = if (tile.skinCoverage > 0) min(1.0, tile.highConfidenceSkinCoverage / tile.skinCoverage) else 0.0
        val mediumCoverage = max(0.0, tile.skinCoverage - tile.highConfidenceSkinCoverage)
        var weight = (tile.highConfidenceSkinCoverage / 100.0) * 1.0 + (mediumCoverage / 100.0) * 0.5
        weight *= (1.0 - (tile.excludedCoverage / 100.0)).coerceIn(0.0, 1.0)
        weight = weight.coerceIn(0.0, 1.0)
        return CandidateSkinSupport(
            skinConfidenceAtLocation = tile.skinCoverage,
            highConfidenceSkinFraction = highFraction,
            exclusionOverlap = tile.excludedCoverage,
            skinWeight = weight
        )
    }

    /** Batch 4D-F: widened from `private` to `internal` (no behavior change) so [ShineDetectionEngine]
     * draws shine candidates from the SAME selected MICRO tiles the P0 structural pass uses,
     * rather than a second independent tile selection over the same tile pyramid. */
    internal fun selectTiles(tileSet: MultiScaleTileSet): List<AnalysisTile> {
        if (tileSet.fineTilingSkippedReason != null) return emptyList()
        return tileSet.microTiles
            .sortedByDescending { it.highConfidenceSkinCoverage }
            .take(MAX_MICRO_TILES_PER_REGION)
    }

    /** Runs candidate detection over one region's selected MICRO tiles. Never throws — a tile whose pixels can't be decoded (missing/corrupt capture.jpg, zero-area crop) is skipped, not fatal.
     * [boundaryContext], added Batch 4E-C step_2, is optional (defaults to null, meaning "no
     * boundary refinement available — behave exactly as before this batch") so every existing
     * caller/test keeps compiling and keeps its exact prior output. When supplied, each
     * candidate's tile-wide [CandidateSkinSupport] is additively refined with its OWN
     * bounding-box overlap against the same [PatternMapCell] grid — see
     * [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport]. */
    fun analyzeRegion(originalFile: File, tileSet: MultiScaleTileSet, boundaryContext: CandidateBoundaryContext? = null): List<VisualFeatureCandidate> {
        val candidates = mutableListOf<VisualFeatureCandidate>()
        var seq = 0
        for (tile in selectTiles(tileSet)) {
            val grid = try { VisualSignalGridExtractor.build(originalFile, tile) } catch (e: Exception) { null } ?: continue
            val skinSupport = skinSupportFor(tile)
            if (skinSupport.skinWeight <= 0.02) continue // effectively-excluded tile contributes nothing, per step_3

            val components = FeatureCandidateDetectors.components(grid)
            for (comp in components) {
                val signals = FeatureCandidateDetectors.signalsOf(grid, comp)
                val (evidence, classification) = FeatureSeparationEngine.classify(comp, signals, grid)
                val box = boundingBoxOriginal(grid, comp)
                // Batch 4D-F2, step_2: orientation is only computed for hair/stubble-leaning
                // candidates (the one evidence dimension it actually improves) rather than for
                // every candidate — a compact/round candidate's gradient axis is not a meaningful
                // "elongation direction" and computing it there would just be noise carried
                // downstream for no purpose.
                val orientation = if (evidence.hairStubbleLikelihood > 0.15)
                    FeatureOrientationEngine.estimate(grid, comp.cells)
                else FeatureOrientationEngine.OrientationEstimate(-1.0, 0.0)
                val morphology = CandidateMorphology(
                    boundingBoxX = box[0], boundingBoxY = box[1], boundingBoxWidth = box[2], boundingBoxHeight = box[3],
                    centroidX = box[0] + box[2] / 2, centroidY = box[1] + box[3] / 2,
                    areaPixels = comp.area * grid.cellSourcePixels * grid.cellSourcePixels,
                    perimeterCells = comp.perimeter,
                    aspectRatio = comp.aspectRatio, circularity = comp.circularity, elongation = comp.elongation,
                    localContrast = signals.meanGradient, brightness = signals.meanLuma,
                    meanCb = signals.meanCb, meanCr = signals.meanCr,
                    edgeStrength = signals.meanGradient, textureVariance = signals.meanVariance,
                    orientationDegrees = orientation.axisDegrees, orientationCoherence = orientation.coherence
                )
                // Batch 4E-C, step_2: candidate-own-footprint refinement, additive on top of the
                // tile-wide skinSupport computed above. refineCandidateSkinSupport itself returns
                // null (never a fabricated value) whenever boundaryContext is absent, the
                // footprint has zero cell overlap, or no original/normalized scale relationship
                // is available for this view — in every such case refinedSupport below is
                // identical to the pre-4E-C skinSupport, so nothing downstream changes.
                val refinement = boundaryContext?.let {
                    FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
                        originalBoundingBox = box, cells = it.cells, grid = it.patternGrid,
                        normalizedImageWidth = it.geom.normalizedImageWidth,
                        normalizedImageHeight = it.geom.normalizedImageHeight,
                        geom = it.geom,
                        // Batch 4E-E, step_3: candidate's OWN footprint checked against the SAME
                        // landmark-exclusion polygons (eyes/eyebrows/lips/approximate nostril
                        // band/outside-face) AnatomicalRegionMapper already built for this view,
                        // instead of only the pixel-color classifier's exclusion signal.
                        landmarkExclusionPolygons = it.regionSet?.exclusions?.map { ex -> ex.points } ?: emptyList()
                    )
                }
                val refinedSupport = if (refinement == null) skinSupport else skinSupport.copy(
                    boundarySkinConfidenceAtLocation = refinement.skinCoverage,
                    boundaryHighConfidenceSkinFraction = if (refinement.skinCoverage > 0) (refinement.highConfidenceSkinCoverage / refinement.skinCoverage).coerceIn(0.0, 1.0) else 0.0,
                    boundaryExclusionOverlap = refinement.excludedCoverage,
                    boundaryCellsOverlapped = refinement.cellsOverlapped,
                    boundaryLandmarkExclusionOverlap = refinement.landmarkExclusionOverlap
                )
                val candidateConfidence = (classification.classificationConfidence * skinSupport.skinWeight).coerceIn(0.0, 1.0)
                candidates.add(
                    VisualFeatureCandidate(
                        candidateId = "${tile.view}_${tile.region}_${tile.tileId}_c${seq++}",
                        view = tile.view, region = tile.region, tileId = tile.tileId, scale = tile.scale,
                        morphology = morphology, skinSupport = refinedSupport, evidence = evidence,
                        classification = classification, candidateConfidence = candidateConfidence
                    )
                )
            }
        }
        return candidates
    }

    private fun boundingBoxOriginal(grid: SignalGrid, comp: GridComponent): IntArray {
        val topLeft = grid.cellToOriginalBox(comp.minRow, comp.minCol)
        val bottomRight = grid.cellToOriginalBox(comp.maxRow, comp.maxCol)
        val x = topLeft[0]; val y = topLeft[1]
        val width = max(1, bottomRight[2] - topLeft[0])
        val height = max(1, bottomRight[3] - topLeft[1])
        return intArrayOf(x, y, width, height)
    }

    /** Batch 4E-C, step_2. Optional context bundle threaded through [analyzeRegion]/[analyzeView]
     * so candidate-level boundary refinement can reuse the SAME [PatternMapCell] grid and
     * [FaceGeometryResult] the rest of this view's pipeline already produced — never a second,
     * independently-decoded skin classification. [patternGrid] must be the same grid size passed
     * to `LocalizedPatternMapper.map()`/`FaceConstrainedSkinAnalyzer.analyze()` for this view (the
     * project convention is 6 — see MainActivity's own comment on that constant). */
    data class CandidateBoundaryContext(
        val cells: List<PatternMapCell>,
        val patternGrid: Int,
        val geom: FaceGeometryResult,
        /** Batch 4E-E, step_3 addition. The SAME [RegionSet] (with its already-built landmark
         * [ExclusionPolygon]s: eyes, eyebrows, lips, approximate nostril band, outside-face)
         * [AnatomicalRegionMapper.map] already produced for this view — never a second,
         * independently-derived exclusion geometry. Defaulted to null so every pre-4E-E caller
         * keeps compiling and keeps its exact prior output (no landmark-exclusion refinement
         * attempted when absent, exactly the same as before this batch). */
        val regionSet: RegionSet? = null
    )

    /** Runs [analyzeRegion] over every region tile-set for a view. */
    fun analyzeView(originalFile: File, tileSets: List<MultiScaleTileSet>, boundaryContext: CandidateBoundaryContext? = null): List<VisualFeatureCandidate> =
        tileSets.flatMap { analyzeRegion(originalFile, it, boundaryContext) }

    // --- step_15: regional aggregation ---
    fun aggregate(view: String, tileSet: MultiScaleTileSet, candidates: List<VisualFeatureCandidate>): RegionalFeatureSummary {
        val byType = candidates.groupBy { it.classification.primaryFeatureType }
        val measurements = FeatureCandidateType.values().mapNotNull { type ->
            val list = byType[type] ?: return@mapNotNull null
            if (list.isEmpty()) return@mapNotNull null
            FeatureMeasurement(
                type = type,
                count = list.size,
                totalAreaPixels = list.sumOf { it.morphology.areaPixels.toLong() },
                meanApparentSizePixels = list.map { it.morphology.areaPixels }.average(),
                meanConfidence = list.map { it.candidateConfidence }.average(),
                meanLocalContrast = list.map { it.morphology.localContrast }.average()
            )
        }
        // Density normalized against usable (skin-weighted) grid cells actually sampled this
        // region, not raw tile pixel count — so density is comparable across regions even when
        // MICRO-tile selection (step_19) decoded different pixel counts per region.
        val sampledCellsProxy = max(1, candidates.size + (tileSet.microTiles.size * 25))
        val density = FeatureCandidateType.values().associateWith { type ->
            ((byType[type]?.size ?: 0).toDouble() / sampledCellsProxy) * 1000.0
        }
        return RegionalFeatureSummary(
            view = view, region = tileSet.region,
            regionSkinCoverage = tileSet.regionSkinCoverage, regionHighConfidenceSkinCoverage = tileSet.regionHighConfidenceSkinCoverage,
            candidatesConsidered = candidates.size,
            measurementsByType = measurements, densityByType = density
        )
    }

    fun json(candidates: List<VisualFeatureCandidate>, summaries: List<RegionalFeatureSummary>): String {
        val candJson = candidates.joinToString(",") { VisualFeatureJson.candidateJson(it) }
        val sumJson = summaries.joinToString(",") { VisualFeatureJson.regionalSummaryJson(it) }
        return """{"method":"$VERSION","candidate_count":${candidates.size},"candidates":[$candJson],"regional_summaries":[$sumJson]}"""
    }
}
