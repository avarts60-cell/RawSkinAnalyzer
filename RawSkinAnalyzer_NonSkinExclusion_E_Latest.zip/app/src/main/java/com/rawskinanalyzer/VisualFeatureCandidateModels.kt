package com.rawskinanalyzer

/**
 * VisualFeatureCandidateModels
 *
 * Batch 4D-D, step_20. Extends the architecture hooks [FeatureCandidateType] / [FeatureCandidateRegion]
 * / [TileAnalysisInput] / [FeatureCandidateOutput] already defined in `MultiScaleTileExtractor.kt`
 * rather than duplicating them — [VisualFeatureCandidate] below carries the same identifying
 * fields those hooks already specified (type, source coords, scale, confidence, supporting
 * tile/region) plus the morphology/evidence/classification fields step_1 and step_11 add on top.
 */

/** step_1's per-candidate structural properties, computed once by the candidate engine and shared by every downstream detector/classifier. */
data class CandidateMorphology(
    val boundingBoxX: Int, val boundingBoxY: Int, val boundingBoxWidth: Int, val boundingBoxHeight: Int,
    val centroidX: Int, val centroidY: Int,
    val areaPixels: Int,
    val perimeterCells: Int,
    val aspectRatio: Double,
    val circularity: Double,
    val elongation: Double,
    val localContrast: Double,
    val brightness: Double,
    val meanCb: Double,
    val meanCr: Double,
    val edgeStrength: Double,
    val textureVariance: Double,
    /** Batch 4D-F2, step_2. Real gradient-derived elongation axis in degrees [0,180), from
     * [FeatureOrientationEngine]. -1.0 (default) means orientation was not computed for this
     * candidate (only hair/stubble-leaning candidates have it computed — see
     * VisualFeatureCandidateEngine.analyzeRegion) or the component had too little gradient
     * energy to estimate reliably. Additive field: every existing constructor call that does
     * not pass it keeps its previous behavior. */
    val orientationDegrees: Double = -1.0,
    /** Batch 4D-F2, step_2. 0-1 structure-tensor coherence paired with [orientationDegrees]; 0.0 when orientation was not computed. */
    val orientationCoherence: Double = 0.0
)

/** step_3's skin-quality weighting applied to a candidate, plus the exclusion overlap that can zero it out. */
data class CandidateSkinSupport(
    val skinConfidenceAtLocation: Double, // 0-100, sampled from the underlying tile's skinCoverage/highConfidenceSkinCoverage blend
    val highConfidenceSkinFraction: Double,
    val exclusionOverlap: Double, // 0-100, portion of the candidate's own area falling in excluded (non-skin/hair/shadow/highlight) cells
    val skinWeight: Double, // 0-1 multiplier actually applied to candidateConfidence
    // --- Batch 4E-C, step_2 additions (additive; every field above is unchanged in meaning and
    // is still computed exactly as before — these are a MORE PRECISE, candidate-own-footprint
    // alternative, not a replacement). Null means "not computed for this candidate" (currently:
    // whenever the caller didn't supply cells/grid/geom, or the candidate's footprint didn't
    // overlap any cell / had no scale relationship available) — never fabricated as a copy of the
    // tile-wide value above or as a placeholder 0.0/100.0. See
    // FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport for how these are computed. ---
    /** Candidate's OWN bounding-box overlap against the skin-classification grid — as opposed to
     * [skinConfidenceAtLocation]'s whole-tile aggregate. */
    val boundarySkinConfidenceAtLocation: Double? = null,
    val boundaryHighConfidenceSkinFraction: Double? = null,
    /** Candidate's OWN bounding-box overlap with excluded cells — as opposed to [exclusionOverlap]'s whole-tile aggregate. */
    val boundaryExclusionOverlap: Double? = null,
    /** How many grid cells the candidate's own footprint actually overlapped — present exactly when the three boundary fields above are non-null. */
    val boundaryCellsOverlapped: Int? = null,
    // --- Batch 4E-E, step_3 addition (additive; every field above is unchanged in meaning). ---
    /** The portion of [boundaryExclusionOverlap] specifically attributable to this candidate's own
     * footprint overlapping a landmark-derived exclusion polygon (eyes/eyebrows/lips/approximate
     * nostril band/outside-face) rather than the pixel-color classifier's shadow/highlight/
     * non-skin-color signal — see [CandidateBoundarySkinRefinement.landmarkExclusionOverlap]. Null
     * under the exact same "not computed for this candidate" contract as the other boundary
     * fields (never a fabricated 0.0 standing in for "unavailable"); a genuine zero (no landmark
     * overlap, but boundary refinement WAS computed) is reported as 0.0, not null. */
    val boundaryLandmarkExclusionOverlap: Double? = null
)

/** step_11 per-dimension likelihoods a candidate was scored against, before a primary type is chosen. */
data class FeatureEvidence(
    val hairStubbleLikelihood: Double,
    val follicularLikelihood: Double,
    val poreLikelihood: Double,
    val darkMarkLikelihood: Double,
    val rednessLikelihood: Double,
    val blemishLikeLikelihood: Double,
    val textureLikelihood: Double,
    val shineLikelihood: Double
)

/** step_11 output: the resolved (possibly still uncertain) classification for one candidate. */
data class FeatureClassification(
    val primaryFeatureType: FeatureCandidateType,
    val secondaryFeatureTypes: List<FeatureCandidateType>,
    val classificationConfidence: Double,
    val evidenceReasons: List<String>
)

/** A fully-formed candidate: identity + morphology + skin support + evidence + resolved classification. This is the primary unit the rest of Batch 4D-D operates on. */
data class VisualFeatureCandidate(
    val candidateId: String,
    val view: String,
    val region: AnatomicalRegion,
    val tileId: String,
    val scale: AnalysisScale,
    val morphology: CandidateMorphology,
    val skinSupport: CandidateSkinSupport,
    val evidence: FeatureEvidence,
    val classification: FeatureClassification,
    /** Final candidate confidence: classification confidence already weighted by skinSupport.skinWeight. Never re-derived downstream — this is the one authoritative value regional aggregation consumes. */
    val candidateConfidence: Double
)

/** step_14: per-candidate-type measurements, image-space only (no physical-unit calibration claimed). */
data class FeatureMeasurement(
    val type: FeatureCandidateType,
    val count: Int,
    val totalAreaPixels: Long,
    val meanApparentSizePixels: Double,
    val meanConfidence: Double,
    val meanLocalContrast: Double
)

/** step_15: per-(view, region) rollup. Candidate-level evidence (the full VisualFeatureCandidate list) is preserved alongside this, never discarded in favor of only the summary. */
data class RegionalFeatureSummary(
    val view: String,
    val region: AnatomicalRegion,
    val regionSkinCoverage: Double,
    val regionHighConfidenceSkinCoverage: Double,
    val candidatesConsidered: Int,
    val measurementsByType: List<FeatureMeasurement>,
    /** Candidates per 1000 usable-skin grid cells actually sampled — a density figure independent of how many tiles happened to be decoded for this region. */
    val densityByType: Map<FeatureCandidateType, Double>
)

object VisualFeatureJson {
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

    fun morphologyJson(m: CandidateMorphology): String =
        """{"bounding_box":{"x":${m.boundingBoxX},"y":${m.boundingBoxY},"width":${m.boundingBoxWidth},"height":${m.boundingBoxHeight}},"centroid":{"x":${m.centroidX},"y":${m.centroidY}},"area_pixels":${m.areaPixels},"perimeter_cells":${m.perimeterCells},"aspect_ratio":${m.aspectRatio},"circularity":${m.circularity},"elongation":${m.elongation},"local_contrast":${m.localContrast},"brightness":${m.brightness},"mean_cb":${m.meanCb},"mean_cr":${m.meanCr},"edge_strength":${m.edgeStrength},"texture_variance":${m.textureVariance},"orientation_degrees":${m.orientationDegrees},"orientation_coherence":${m.orientationCoherence}}"""

    fun skinSupportJson(s: CandidateSkinSupport): String =
        """{"skin_confidence_at_location":${s.skinConfidenceAtLocation},"high_confidence_skin_fraction":${s.highConfidenceSkinFraction},"exclusion_overlap":${s.exclusionOverlap},"skin_weight":${s.skinWeight},"boundary_refinement":${
            if (s.boundarySkinConfidenceAtLocation == null) "null"
            else """{"skin_confidence_at_location":${s.boundarySkinConfidenceAtLocation},"high_confidence_skin_fraction":${s.boundaryHighConfidenceSkinFraction},"exclusion_overlap":${s.boundaryExclusionOverlap},"landmark_exclusion_overlap":${s.boundaryLandmarkExclusionOverlap ?: "null"},"cells_overlapped":${s.boundaryCellsOverlapped}}"""
        }}"""

    fun evidenceJson(e: FeatureEvidence): String =
        """{"hair_stubble":${e.hairStubbleLikelihood},"follicular":${e.follicularLikelihood},"pore":${e.poreLikelihood},"dark_mark":${e.darkMarkLikelihood},"redness":${e.rednessLikelihood},"blemish_like":${e.blemishLikeLikelihood},"texture":${e.textureLikelihood},"shine":${e.shineLikelihood}}"""

    fun classificationJson(c: FeatureClassification): String =
        """{"primary_feature_type":"${c.primaryFeatureType}","secondary_feature_types":[${c.secondaryFeatureTypes.joinToString(",") { "\"$it\"" }}],"classification_confidence":${c.classificationConfidence},"evidence_reasons":[${c.evidenceReasons.joinToString(",") { "\"${esc(it)}\"" }}]}"""

    fun candidateJson(c: VisualFeatureCandidate): String =
        """{"candidate_id":"${c.candidateId}","view":"${esc(c.view)}","region":"${c.region}","tile_id":"${c.tileId}","scale":"${c.scale}","morphology":${morphologyJson(c.morphology)},"skin_support":${skinSupportJson(c.skinSupport)},"evidence":${evidenceJson(c.evidence)},"classification":${classificationJson(c.classification)},"candidate_confidence":${c.candidateConfidence}}"""

    fun measurementJson(m: FeatureMeasurement): String =
        """{"type":"${m.type}","count":${m.count},"total_area_pixels":${m.totalAreaPixels},"mean_apparent_size_pixels":${m.meanApparentSizePixels},"mean_confidence":${m.meanConfidence},"mean_local_contrast":${m.meanLocalContrast}}"""

    fun regionalSummaryJson(s: RegionalFeatureSummary): String {
        val density = s.densityByType.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        return """{"view":"${esc(s.view)}","region":"${s.region}","region_skin_coverage":${s.regionSkinCoverage},"region_high_confidence_skin_coverage":${s.regionHighConfidenceSkinCoverage},"candidates_considered":${s.candidatesConsidered},"measurements_by_type":[${s.measurementsByType.joinToString(",") { measurementJson(it) }}],"density_by_type":{$density}}"""
    }
}
