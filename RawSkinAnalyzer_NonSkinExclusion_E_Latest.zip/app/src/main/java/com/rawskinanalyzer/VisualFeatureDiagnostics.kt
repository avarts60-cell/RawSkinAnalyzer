package com.rawskinanalyzer

/**
 * VisualFeatureDiagnostics
 *
 * Batch 4D-D, step_18. Every field here is read directly off already-built
 * [VisualFeatureCandidate]s — nothing is estimated or re-derived, matching the truthfulness rule
 * `TileDiagnostics` (Batch 4D-C) already established for this project.
 */
object VisualFeatureDiagnostics {

    data class CandidateLocationEntry(
        val candidateId: String, val region: AnatomicalRegion, val sourceX: Int, val sourceY: Int,
        val scale: AnalysisScale, val skinConfidence: Double, val confidence: Double
    )

    data class SessionCandidateDiagnostics(
        val view: String,
        val countByType: Map<FeatureCandidateType, Int>,
        val countByRegion: Map<AnatomicalRegion, Int>,
        // Confidence distribution buckets: [0.0-0.2), [0.2-0.4), [0.4-0.6), [0.6-0.8), [0.8-1.0]
        val confidenceDistribution: IntArray,
        val hairStubbleMap: List<CandidateLocationEntry>,
        val poreFollicleMap: List<CandidateLocationEntry>,
        val darkFeatureMap: List<CandidateLocationEntry>,
        val rednessMap: List<CandidateLocationEntry>,
        val textureMap: List<CandidateLocationEntry>,
        val blemishLikeMap: List<CandidateLocationEntry>,
        val unclassifiedCount: Int
    )

    private fun toEntry(c: VisualFeatureCandidate) = CandidateLocationEntry(
        candidateId = c.candidateId, region = c.region, sourceX = c.morphology.boundingBoxX, sourceY = c.morphology.boundingBoxY,
        scale = c.scale, skinConfidence = c.skinSupport.skinConfidenceAtLocation, confidence = c.candidateConfidence
    )

    fun summarize(view: String, candidates: List<VisualFeatureCandidate>): SessionCandidateDiagnostics {
        fun byPrimary(type: FeatureCandidateType) = candidates.filter { it.classification.primaryFeatureType == type }.map(::toEntry)

        val distribution = IntArray(5)
        for (c in candidates) {
            val bucket = (c.candidateConfidence * 5).toInt().coerceIn(0, 4)
            distribution[bucket]++
        }

        return SessionCandidateDiagnostics(
            view = view,
            countByType = candidates.groupingBy { it.classification.primaryFeatureType }.eachCount(),
            countByRegion = candidates.groupingBy { it.region }.eachCount(),
            confidenceDistribution = distribution,
            hairStubbleMap = byPrimary(FeatureCandidateType.HAIR_OR_STUBBLE_CANDIDATE),
            poreFollicleMap = byPrimary(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE),
            darkFeatureMap = byPrimary(FeatureCandidateType.DARK_MARK_CANDIDATE),
            rednessMap = byPrimary(FeatureCandidateType.REDNESS_REGION),
            textureMap = byPrimary(FeatureCandidateType.TEXTURE_IRREGULARITY_CANDIDATE),
            blemishLikeMap = byPrimary(FeatureCandidateType.BLEMISH_LIKE_CANDIDATE),
            unclassifiedCount = candidates.count { it.classification.primaryFeatureType == FeatureCandidateType.UNKNOWN_CANDIDATE }
        )
    }

    private fun entryJson(e: CandidateLocationEntry): String =
        """{"candidate_id":"${e.candidateId}","region":"${e.region}","source_x":${e.sourceX},"source_y":${e.sourceY},"scale":"${e.scale}","skin_confidence":${e.skinConfidence},"confidence":${e.confidence}}"""

    fun json(d: SessionCandidateDiagnostics): String {
        val byType = d.countByType.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        val byRegion = d.countByRegion.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        return """{"view":"${d.view}","count_by_type":{$byType},"count_by_region":{$byRegion},"confidence_distribution":[${d.confidenceDistribution.joinToString(",")}],"unclassified_count":${d.unclassifiedCount},"hair_stubble_map":[${d.hairStubbleMap.joinToString(",") { entryJson(it) }}],"pore_follicle_map":[${d.poreFollicleMap.joinToString(",") { entryJson(it) }}],"dark_feature_map":[${d.darkFeatureMap.joinToString(",") { entryJson(it) }}],"redness_map":[${d.rednessMap.joinToString(",") { entryJson(it) }}],"texture_map":[${d.textureMap.joinToString(",") { entryJson(it) }}],"blemish_like_map":[${d.blemishLikeMap.joinToString(",") { entryJson(it) }}]}"""
    }

    // -----------------------------------------------------------------------
    // Batch 4D-F2, step_7 (P1): bump/surface-structure and post-acne-association diagnostics.
    // Same truthfulness rule as above — every field read directly off already-built
    // [BumpCandidate]/[PostAcneSpatialAssociation] objects, nothing re-estimated.
    // -----------------------------------------------------------------------
    data class SessionBumpDiagnostics(
        val view: String,
        val countByPrimaryType: Map<SpecializedFeatureType, Int>,
        val countByRegion: Map<AnatomicalRegion, Int>,
        val confidenceDistribution: IntArray,
        val meanInternalReliefContrast: Double
    )

    fun summarizeBumps(view: String, candidates: List<BumpCandidate>): SessionBumpDiagnostics {
        val distribution = IntArray(5)
        for (c in candidates) distribution[(c.confidence * 5).toInt().coerceIn(0, 4)]++
        return SessionBumpDiagnostics(
            view = view,
            countByPrimaryType = candidates.groupingBy { it.primaryType }.eachCount(),
            countByRegion = candidates.groupingBy { it.region }.eachCount(),
            confidenceDistribution = distribution,
            meanInternalReliefContrast = if (candidates.isEmpty()) 0.0 else candidates.map { it.internalReliefContrast }.average()
        )
    }

    fun bumpDiagnosticsJson(d: SessionBumpDiagnostics): String {
        val byType = d.countByPrimaryType.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        val byRegion = d.countByRegion.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        return """{"view":"${d.view}","count_by_primary_type":{$byType},"count_by_region":{$byRegion},"confidence_distribution":[${d.confidenceDistribution.joinToString(",")}],"mean_internal_relief_contrast":${d.meanInternalReliefContrast}}"""
    }

    // -----------------------------------------------------------------------
    // Batch 4E-E, step_7 (P0): non-skin exclusion precision diagnostics. Every field here is
    // read directly off already-built [VisualFeatureCandidate.skinSupport] / already-run
    // [CandidateQualityGate] decisions — nothing is re-estimated, same truthfulness rule as the
    // rest of this file. Kept separate from user-facing scores, per this batch's own
    // "keep diagnostics separate from user-facing scores" requirement.
    // -----------------------------------------------------------------------
    data class ExclusionDiagnostics(
        val view: String,
        val candidateCount: Int,
        /** Candidates whose exclusion figures came from candidate-own-footprint boundary
         * refinement (Batch 4E-C/4E-E) rather than the coarser whole-tile aggregate. */
        val candidatesWithBoundaryGeometryBasis: Int,
        val candidatesWithTileWideBasisOnly: Int,
        /** Candidates whose own footprint overlaps a landmark-derived exclusion polygon
         * (eyes/eyebrows/lips/approximate-nostril-band/outside-face) by more than 0%. */
        val candidatesWithLandmarkExclusion: Int,
        /** Mean landmark-exclusion overlap (0-100) across candidates that HAVE boundary geometry
         * (0.0 when none do — a real average of zero, not "unavailable"). */
        val meanLandmarkExclusionOverlap: Double,
        /** Mean combined (pixel-classifier + landmark) exclusion overlap across the same set. */
        val meanCombinedExclusionOverlap: Double,
        /** Present only when a [CandidateQualityDecision] map is supplied to [summarizeExclusion] — see that function's own doc. */
        val candidatesRejected: Int,
        val candidatesWeighted: Int,
        val candidatesAccepted: Int
    )

    fun summarizeExclusion(
        view: String,
        candidates: List<VisualFeatureCandidate>,
        // Optional: keyed by candidateId, e.g. the output of CandidateQualityGate.evaluateAll
        // filtered/re-keyed by the caller. Defaulted to empty so a caller with only the candidate
        // list (no evidence/quality-gate run yet) still gets the boundary/landmark figures above;
        // the three quality-status counts are simply 0 in that case, never fabricated as if the
        // gate had run.
        qualityDecisionsByCandidateId: Map<String, CandidateQualityDecision> = emptyMap()
    ): ExclusionDiagnostics {
        val withBoundary = candidates.filter { it.skinSupport.boundarySkinConfidenceAtLocation != null }
        val withLandmark = withBoundary.filter { (it.skinSupport.boundaryLandmarkExclusionOverlap ?: 0.0) > 0.0 }
        return ExclusionDiagnostics(
            view = view,
            candidateCount = candidates.size,
            candidatesWithBoundaryGeometryBasis = withBoundary.size,
            candidatesWithTileWideBasisOnly = candidates.size - withBoundary.size,
            candidatesWithLandmarkExclusion = withLandmark.size,
            meanLandmarkExclusionOverlap = if (withBoundary.isEmpty()) 0.0 else withBoundary.map { it.skinSupport.boundaryLandmarkExclusionOverlap ?: 0.0 }.average(),
            meanCombinedExclusionOverlap = if (withBoundary.isEmpty()) 0.0 else withBoundary.map { it.skinSupport.boundaryExclusionOverlap ?: 0.0 }.average(),
            candidatesRejected = candidates.count { qualityDecisionsByCandidateId[it.candidateId]?.status == CandidateQualityStatus.REJECT },
            candidatesWeighted = candidates.count { qualityDecisionsByCandidateId[it.candidateId]?.status == CandidateQualityStatus.WEIGHT },
            candidatesAccepted = candidates.count { qualityDecisionsByCandidateId[it.candidateId]?.status == CandidateQualityStatus.ACCEPT }
        )
    }

    fun exclusionDiagnosticsJson(d: ExclusionDiagnostics): String =
        """{"view":"${d.view}","candidate_count":${d.candidateCount},"candidates_with_boundary_geometry_basis":${d.candidatesWithBoundaryGeometryBasis},"candidates_with_tile_wide_basis_only":${d.candidatesWithTileWideBasisOnly},"candidates_with_landmark_exclusion":${d.candidatesWithLandmarkExclusion},"mean_landmark_exclusion_overlap":${d.meanLandmarkExclusionOverlap},"mean_combined_exclusion_overlap":${d.meanCombinedExclusionOverlap},"candidates_rejected":${d.candidatesRejected},"candidates_weighted":${d.candidatesWeighted},"candidates_accepted":${d.candidatesAccepted}}"""

    data class PostAcneAssociationDiagnostics(
        val countByRegion: Map<AnatomicalRegion, Int>,
        val meanAssociationConfidence: Double,
        val distinctDarkFeatureCandidatesAssociated: Int,
        val distinctBlemishCandidatesAssociated: Int
    )

    fun summarizeAssociations(associations: List<PostAcneSpatialAssociation>): PostAcneAssociationDiagnostics =
        PostAcneAssociationDiagnostics(
            countByRegion = associations.groupingBy { it.region }.eachCount(),
            meanAssociationConfidence = if (associations.isEmpty()) 0.0 else associations.map { it.associationConfidence }.average(),
            distinctDarkFeatureCandidatesAssociated = associations.map { it.darkFeatureCandidateId }.distinct().size,
            distinctBlemishCandidatesAssociated = associations.map { it.blemishCandidateId }.distinct().size
        )

    fun associationDiagnosticsJson(d: PostAcneAssociationDiagnostics): String {
        val byRegion = d.countByRegion.entries.joinToString(",") { (k, v) -> "\"$k\":$v" }
        return """{"count_by_region":{$byRegion},"mean_association_confidence":${d.meanAssociationConfidence},"distinct_dark_feature_candidates_associated":${d.distinctDarkFeatureCandidatesAssociated},"distinct_blemish_candidates_associated":${d.distinctBlemishCandidatesAssociated}}"""
    }
}
