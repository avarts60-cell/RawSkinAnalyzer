package com.rawskinanalyzer

import android.graphics.Bitmap
import android.graphics.Color
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * VisualSignalGridExtractor
 *
 * Batch 4D-D, step_1/step_2. This is the ONE place a MICRO/MESO analysis tile is actually
 * decoded to pixels for the feature-candidate engine (via [RegionOfInterestExtractor.decodeCrop],
 * reusing that existing lazy on-demand decode path rather than adding a second one — see that
 * file's doc comment). Every detector in this batch (hair/stubble, pore/follicle, dark-feature,
 * redness, texture) consumes the SAME [SignalGrid] this file builds, so a tile is decoded once
 * per candidate pass, never once per detector.
 *
 * The grid is a coarse downsample of the decoded bitmap (default cell = 3x3 source pixels,
 * averaged) rather than per-pixel analysis. This keeps a MICRO tile's candidate pass bounded
 * (a 512x512 decode becomes a ~170x170 signal grid) while still resolving pore- and hair-scale
 * structures, which are already only a few source pixels wide at MICRO scale. Per-cell signals:
 *  - luma: mean perceptual brightness (0-255)
 *  - cb/cr: YCbCr chroma (reuses the same conversion `SkinSegmentationEngine` already applies
 *    elsewhere in this project, so redness/tone reasoning here is consistent with the rest of
 *    the pipeline rather than a third independent color model)
 *  - gradientMagnitude: a simple central-difference gradient over the downsampled luma grid
 *    (a lightweight Sobel-equivalent — see [computeGradients]). This is edge strength, not a
 *    full Canny pipeline, which is appropriate for candidate *evidence* rather than a final
 *    segmentation.
 *  - localVariance: luma variance in a 3x3 neighborhood of grid cells — the texture/micro-contrast
 *    signal step_8 asks for.
 */
data class SignalCell(val row: Int, val col: Int, val luma: Double, val cb: Double, val cr: Double)

class SignalGrid(
    val cols: Int,
    val rows: Int,
    val cellSourcePixels: Int,
    /** Origin of this grid in ORIGINAL-image pixel coordinates (source_x/source_y of the decoded crop, pre-downsample). */
    val originX: Int,
    val originY: Int,
    /** Original-image pixels per grid cell (accounts for BitmapRegionDecoder inSampleSize + the cellSourcePixels averaging). */
    val originalPixelsPerCellX: Double,
    val originalPixelsPerCellY: Double,
    val luma: Array<DoubleArray>,
    val cb: Array<DoubleArray>,
    val cr: Array<DoubleArray>,
    val gradientMagnitude: Array<DoubleArray>,
    val localVariance: Array<DoubleArray>,
    val regionMeanLuma: Double,
    val regionMeanCb: Double,
    val regionMeanCr: Double,
    val regionLumaStdDev: Double
) {
    fun inBounds(r: Int, c: Int) = r in 0 until rows && c in 0 until cols

    /** Maps a grid cell to a bounding box in ORIGINAL-image pixel coordinates. */
    fun cellToOriginalBox(r: Int, c: Int): IntArray {
        val x0 = originX + (c * originalPixelsPerCellX).toInt()
        val y0 = originY + (r * originalPixelsPerCellY).toInt()
        val x1 = originX + (((c + 1) * originalPixelsPerCellX)).toInt()
        val y1 = originY + (((r + 1) * originalPixelsPerCellY)).toInt()
        return intArrayOf(x0, y0, max(x0 + 1, x1), max(y0 + 1, y1))
    }
}

object VisualSignalGridExtractor {
    const val VERSION = "visual_signal_grid_extractor_v1"

    /** Bitmap decode is capped here — a MICRO tile does not need more than this to resolve pore/hair-scale structure; this is the memory-bounding step_19 requires. */
    private const val MAX_DECODE_DIMENSION = 512

    /** Source pixels averaged per grid cell. 3 keeps single-pixel sensor noise from being read as a candidate while still resolving sub-millimeter structures at MICRO scale. */
    private const val CELL_SOURCE_PIXELS = 3

    /**
     * Decodes [tile]'s pixels from [originalFile] (the same `capture.jpg` every other
     * original-coordinate consumer in this project reads) and builds a [SignalGrid]. Returns
     * null (never throws) exactly when [RegionOfInterestExtractor.decodeCrop] would — a tile
     * whose pixels can't be decoded is not usable candidate evidence, and callers already treat
     * per-tile failure as non-fatal to the whole session, consistent with this project's
     * established try/catch-and-record convention.
     */
    fun build(originalFile: File, tile: AnalysisTile): SignalGrid? {
        if (!tile.originalCoordinatesAvailable || tile.width <= 0 || tile.height <= 0) return null
        val crop = RegionCrop(
            region = tile.region, view = tile.view,
            sourceX = tile.sourceX, sourceY = tile.sourceY, width = tile.width, height = tile.height,
            scale = null, originalImageWidth = tile.originalImageWidth, originalImageHeight = tile.originalImageHeight,
            clampedAtEdge = false
        )
        val bmp = RegionOfInterestExtractor.decodeCrop(originalFile, crop, MAX_DECODE_DIMENSION) ?: return null
        return try {
            buildFromBitmap(bmp, tile)
        } finally {
            bmp.recycle()
        }
    }

    private fun buildFromBitmap(bmp: Bitmap, tile: AnalysisTile): SignalGrid? {
        val w = bmp.width; val h = bmp.height
        if (w < CELL_SOURCE_PIXELS || h < CELL_SOURCE_PIXELS) return null
        val cols = w / CELL_SOURCE_PIXELS
        val rows = h / CELL_SOURCE_PIXELS
        if (cols < 3 || rows < 3) return null

        val pixels = IntArray(w * h)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)

        val luma = Array(rows) { DoubleArray(cols) }
        val cb = Array(rows) { DoubleArray(cols) }
        val cr = Array(rows) { DoubleArray(cols) }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                var sumY = 0.0; var sumCb = 0.0; var sumCr = 0.0; var n = 0
                val py0 = r * CELL_SOURCE_PIXELS; val px0 = c * CELL_SOURCE_PIXELS
                for (dy in 0 until CELL_SOURCE_PIXELS) {
                    for (dx in 0 until CELL_SOURCE_PIXELS) {
                        val px = px0 + dx; val py = py0 + dy
                        if (px >= w || py >= h) continue
                        val pixel = pixels[py * w + px]
                        val rC = Color.red(pixel).toDouble(); val gC = Color.green(pixel).toDouble(); val bC = Color.blue(pixel).toDouble()
                        val y = 0.299 * rC + 0.587 * gC + 0.114 * bC
                        val cbV = 128.0 - 0.168736 * rC - 0.331264 * gC + 0.5 * bC
                        val crV = 128.0 + 0.5 * rC - 0.418688 * gC - 0.081312 * bC
                        sumY += y; sumCb += cbV; sumCr += crV; n++
                    }
                }
                if (n > 0) { luma[r][c] = sumY / n; cb[r][c] = sumCb / n; cr[r][c] = sumCr / n }
            }
        }

        val gradient = computeGradients(luma, rows, cols)
        val variance = computeLocalVariance(luma, rows, cols)

        var sumLuma = 0.0; var sumCb = 0.0; var sumCr = 0.0
        val flat = DoubleArray(rows * cols)
        var idx = 0
        for (r in 0 until rows) for (c in 0 until cols) { sumLuma += luma[r][c]; sumCb += cb[r][c]; sumCr += cr[r][c]; flat[idx++] = luma[r][c] }
        val count = (rows * cols).toDouble()
        val meanLuma = sumLuma / count; val meanCb = sumCb / count; val meanCr = sumCr / count
        var varSum = 0.0
        for (v in flat) varSum += (v - meanLuma) * (v - meanLuma)
        val stdDev = sqrt(varSum / count)

        // The original-image span this decode covers, per axis (accounts for any inSampleSize
        // BitmapRegionDecoder applied, since decoded width/height may be smaller than tile.width/height).
        val origPerCellX = tile.width.toDouble() / cols.coerceAtLeast(1)
        val origPerCellY = tile.height.toDouble() / rows.coerceAtLeast(1)

        return SignalGrid(
            cols = cols, rows = rows, cellSourcePixels = CELL_SOURCE_PIXELS,
            originX = tile.sourceX, originY = tile.sourceY,
            originalPixelsPerCellX = origPerCellX, originalPixelsPerCellY = origPerCellY,
            luma = luma, cb = cb, cr = cr,
            gradientMagnitude = gradient, localVariance = variance,
            regionMeanLuma = meanLuma, regionMeanCb = meanCb, regionMeanCr = meanCr, regionLumaStdDev = stdDev
        )
    }

    /** Central-difference gradient magnitude over the downsampled luma grid — a lightweight, technically-justified edge-strength signal (not a claimed full Sobel/Canny implementation). */
    private fun computeGradients(luma: Array<DoubleArray>, rows: Int, cols: Int): Array<DoubleArray> {
        val g = Array(rows) { DoubleArray(cols) }
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val left = luma[r][max(0, c - 1)]; val right = luma[r][min(cols - 1, c + 1)]
                val up = luma[max(0, r - 1)][c]; val down = luma[min(rows - 1, r + 1)][c]
                val gx = right - left; val gy = down - up
                g[r][c] = sqrt(gx * gx + gy * gy)
            }
        }
        return g
    }

    /** 3x3-neighborhood luma variance per cell — the local micro-texture signal used by texture/roughness/pore detectors. */
    private fun computeLocalVariance(luma: Array<DoubleArray>, rows: Int, cols: Int): Array<DoubleArray> {
        val v = Array(rows) { DoubleArray(cols) }
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                var sum = 0.0; var sumSq = 0.0; var n = 0
                for (dr in -1..1) for (dc in -1..1) {
                    val rr = r + dr; val cc = c + dc
                    if (rr in 0 until rows && cc in 0 until cols) { val lv = luma[rr][cc]; sum += lv; sumSq += lv * lv; n++ }
                }
                if (n > 0) { val mean = sum / n; v[r][c] = max(0.0, sumSq / n - mean * mean) }
            }
        }
        return v
    }
}
