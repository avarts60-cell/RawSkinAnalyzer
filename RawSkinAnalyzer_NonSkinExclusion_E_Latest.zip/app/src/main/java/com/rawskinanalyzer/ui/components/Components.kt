package com.rawskinanalyzer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.theme.AccentOnPrimary
import com.rawskinanalyzer.ui.theme.AccentPrimary
import com.rawskinanalyzer.ui.theme.ClinicalOutlineSubtle
import com.rawskinanalyzer.ui.theme.ClinicalSurfaceElevated
import com.rawskinanalyzer.ui.theme.ClinicalSurfaceElevated2
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.ClinicalTextTertiary
import com.rawskinanalyzer.ui.theme.SignalAttention
import com.rawskinanalyzer.ui.theme.SignalGood
import com.rawskinanalyzer.ui.theme.SignalModerate
import com.rawskinanalyzer.ui.theme.SignalNeutral

/** Section header used to introduce a group of cards on any screen. */
@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    trailing: String? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.titleSmall,
            color = ClinicalTextTertiary
        )
        if (trailing != null) {
            Text(text = trailing, style = MaterialTheme.typography.labelMedium, color = AccentPrimary)
        }
    }
}

/** Primary call-to-action button. Elevated, accent-filled, rounded. */
@Composable
fun PremiumButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true
) {
    val bg = if (filled) AccentPrimary else Color.Transparent
    val fg = if (filled) AccentOnPrimary else AccentPrimary
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .then(if (!filled) Modifier.border(1.dp, AccentPrimary, RoundedCornerShape(16.dp)) else Modifier)
            .background(if (enabled) bg else ClinicalSurfaceElevated2)
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 16.dp, horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            color = if (enabled) fg else ClinicalTextTertiary
        )
    }
}

/** Generic elevated card surface all other components build on. */
@Composable
fun ClinicalCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(ClinicalSurfaceElevated)
            .border(1.dp, ClinicalOutlineSubtle, RoundedCornerShape(20.dp))
            .padding(20.dp)
    ) { content() }
}

private fun levelColor(score: Double): Color = when {
    score >= 60.0 -> SignalAttention
    score >= 30.0 -> SignalModerate
    score >= 12.0 -> SignalGood
    else -> SignalNeutral
}

/**
 * Displays a single skin characteristic score. Score and confidence are always shown as
 * two visually distinct values — this card never merges them into one number.
 */
@Composable
fun SkinScoreCard(
    characteristic: String,
    score: Double,
    level: String,
    confidence: String,
    modifier: Modifier = Modifier
) {
    ClinicalCard(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = characteristic.replace('_', ' ').lowercase()
                        .replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.titleMedium,
                    color = ClinicalTextPrimary
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = level.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
            Text(
                text = "${score.toInt()}",
                style = MaterialTheme.typography.displayMedium,
                color = levelColor(score)
            )
        }
        Spacer(Modifier.height(14.dp))
        ConfidenceIndicator(confidence = confidence)
    }
}

/** Small pill + dot showing HIGH / MODERATE / LOW confidence, always separate from score. */
@Composable
fun ConfidenceIndicator(confidence: String, modifier: Modifier = Modifier) {
    val color = when (confidence.uppercase()) {
        "HIGH" -> SignalGood
        "MODERATE" -> SignalModerate
        "LOW" -> SignalAttention
        else -> SignalNeutral
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "Confidence: ${confidence.lowercase().replaceFirstChar { it.uppercase() }}",
            style = MaterialTheme.typography.labelMedium,
            color = ClinicalTextSecondary
        )
    }
}

/** Highlights the single primary or secondary finding on Dashboard / Results. */
@Composable
fun PrimaryFindingCard(
    label: String,
    finding: String,
    modifier: Modifier = Modifier,
    accent: Boolean = true
) {
    ClinicalCard(modifier = modifier) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.titleSmall,
            color = if (accent) AccentPrimary else ClinicalTextTertiary
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = finding,
            style = MaterialTheme.typography.headlineMedium,
            color = ClinicalTextPrimary
        )
    }
}

/** Session / pipeline status line — used for "SESSION READY", stage failures, etc. */
@Composable
fun AnalysisStatusCard(
    title: String,
    detail: String,
    modifier: Modifier = Modifier,
    isError: Boolean = false
) {
    ClinicalCard(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isError) SignalAttention else SignalGood)
            )
            Spacer(Modifier.width(10.dp))
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(6.dp))
        Text(text = detail, style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary)
    }
}

@Composable
fun LoadingState(message: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = AccentPrimary, strokeWidth = 2.dp)
        Spacer(Modifier.height(16.dp))
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary, textAlign = TextAlign.Center)
    }
}

@Composable
fun EmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(ClinicalSurfaceElevated2),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Search, contentDescription = null, tint = ClinicalTextTertiary)
        }
        Spacer(Modifier.height(16.dp))
        Text(text = title, style = MaterialTheme.typography.titleLarge, color = ClinicalTextPrimary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            PremiumButton(text = actionText, onClick = onAction)
        }
    }
}

@Composable
fun ErrorState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = SignalAttention, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(16.dp))
        Text(text = title, style = MaterialTheme.typography.titleLarge, color = ClinicalTextPrimary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(text = message, style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary, textAlign = TextAlign.Center)
        if (actionText != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            PremiumButton(text = actionText, onClick = onAction, filled = false)
        }
    }
}

/** Thin animated progress bar used for the 3-photo capture workflow. */
@Composable
fun StepProgressBar(completed: Int, total: Int, modifier: Modifier = Modifier) {
    val target = if (total <= 0) 0f else completed.toFloat() / total.toFloat()
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(target) { progress = target }
    val animated by animateFloatAsState(targetValue = progress, animationSpec = tween(400), label = "step-progress")
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(ClinicalSurfaceElevated2)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(animated.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(RoundedCornerShape(3.dp))
                .background(AccentPrimary)
        )
    }
}

/** UI-1B — small labeled tag used for objective types, tolerance states, routine phases, etc. */
@Composable
fun PillTag(text: String, modifier: Modifier = Modifier, tint: Color = ClinicalTextSecondary) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(ClinicalSurfaceElevated2)
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}

/** UI-1B — a short italic-weight disclosure line used wherever a screen must surface a
 * backend-supplied limitation (insufficient data, incomparable sessions, reduced reliability)
 * instead of silently proceeding as if the comparison were fully trustworthy. */
@Composable
fun LimitationNote(text: String, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .padding(top = 6.dp)
                .size(6.dp)
                .clip(CircleShape)
                .background(SignalModerate)
        )
        Spacer(Modifier.width(10.dp))
        Text(text = text, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
    }
}

/** UI-1B — one feature's previous -> current score comparison for the Progress screen. */
@Composable
fun FeatureProgressRow(
    feature: String,
    previousScore: Double,
    currentScore: Double,
    // BATCH 4B: nullable so a NOT_COMPARABLE/INSUFFICIENT_DATA characteristic (see
    // `CharacteristicGatedProgress`) can render without asserting a direction or numerical
    // change it does not have — the raw scores above are still always shown (preserved, not
    // suppressed). Non-null (the pre-Batch-4B behavior) still renders exactly as before.
    delta: Double?,
    direction: String?,
    modifier: Modifier = Modifier,
    // BATCH 4B: optional short comparability label ("Comparable with limitations", "Not
    // comparable", etc.) shown under the header when the comparison is not a normal
    // full-strength one. Null (default) preserves the exact prior layout.
    comparabilityLabel: String? = null
) {
    val directionColor = when (direction) {
        "IMPROVED" -> SignalGood
        "WORSENED" -> SignalAttention
        "STABLE" -> SignalNeutral
        else -> ClinicalTextTertiary
    }
    ClinicalCard(modifier = modifier) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                text = feature.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                style = MaterialTheme.typography.titleMedium,
                color = ClinicalTextPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = direction?.replace('_', ' ')?.lowercase()?.replaceFirstChar { it.uppercase() }
                    ?: "Comparison limited",
                style = MaterialTheme.typography.labelMedium,
                color = directionColor
            )
        }
        if (comparabilityLabel != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = comparabilityLabel,
                style = MaterialTheme.typography.labelSmall,
                color = ClinicalTextTertiary
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            ScoreBar(value = previousScore, color = ClinicalTextTertiary, modifier = Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Text(
                text = "${previousScore.toInt()} → ${currentScore.toInt()}",
                style = MaterialTheme.typography.labelMedium,
                color = ClinicalTextSecondary
            )
            Spacer(Modifier.width(8.dp))
            ScoreBar(value = currentScore, color = directionColor, modifier = Modifier.weight(1f))
        }
        if (delta != null && kotlin.math.abs(delta) > 0.05) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Change: ${if (delta > 0) "+" else ""}${String.format(java.util.Locale.US, "%.1f", delta)}",
                style = MaterialTheme.typography.labelSmall,
                color = ClinicalTextTertiary
            )
        } else if (delta == null) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Numerical change not shown — comparability for this characteristic is limited this session.",
                style = MaterialTheme.typography.labelSmall,
                color = ClinicalTextTertiary
            )
        }
    }
}

@Composable
private fun ScoreBar(value: Double, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(ClinicalSurfaceElevated2)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth((value / 100.0).coerceIn(0.0, 1.0).toFloat())
                .fillMaxHeight()
                .clip(RoundedCornerShape(3.dp))
                .background(color)
        )
    }
}

/** UI-1B — a row of dots representing a real multi-session value series (never interpolated
 * or extended beyond the sessions actually supplied). */
@Composable
fun TrendSparkline(values: List<Double>, modifier: Modifier = Modifier) {
    if (values.isEmpty()) return
    val max = (values.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
    Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        values.forEachIndexed { index, v ->
            val heightFraction = (v / max).coerceIn(0.05, 1.0)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 2.dp)
                    .height((heightFraction * 40).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (index == values.lastIndex) AccentPrimary else ClinicalSurfaceElevated2)
            )
        }
    }
}

/**
 * BATCH 4C — one characteristic's longitudinal trend-intelligence summary for the Progress
 * screen. Deliberately takes plain strings/doubles (not the domain enums directly) to match
 * this file's existing convention (see `FeatureProgressRow`'s `direction: String?`) and to keep
 * this file free of a dependency on the `com.rawskinanalyzer` domain package.
 *
 * Callers must not invoke this for a NOT_COMPARABLE/INSUFFICIENT_DATA directionStability — show
 * a `LimitationNote` instead in that case (see `ProgressScreen`). Score, trend-evidence
 * strength, and direction stability are kept as visually separate lines, never merged into one
 * figure, and no clinical-certainty language is used anywhere in this card.
 */
@Composable
fun TrendIntelligenceCard(
    directionStability: String,
    trendConfidence: String,
    evidenceState: String,
    baselineChange: Double?,
    explanation: String?,
    modifier: Modifier = Modifier
) {
    fun label(raw: String) = raw.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }

    val stabilityColor = when (directionStability) {
        "IMPROVING" -> SignalGood
        "WORSENING" -> SignalAttention
        "OSCILLATING" -> SignalModerate
        "STABLE" -> SignalNeutral
        else -> ClinicalTextTertiary
    }
    val evidenceColor = when (trendConfidence) {
        "HIGH" -> SignalGood
        "MODERATE" -> SignalModerate
        "LOW" -> SignalAttention
        else -> SignalNeutral
    }

    ClinicalCard(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "Trend stability", style = MaterialTheme.typography.labelMedium, color = ClinicalTextTertiary)
            Text(text = label(directionStability), style = MaterialTheme.typography.titleSmall, color = stabilityColor)
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(evidenceColor))
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Trend evidence: ${label(trendConfidence)} (${label(evidenceState)})",
                style = MaterialTheme.typography.labelMedium,
                color = ClinicalTextSecondary
            )
        }
        if (baselineChange != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Since baseline: ${if (baselineChange > 0) "+" else ""}${String.format(java.util.Locale.US, "%.1f", baselineChange)}",
                style = MaterialTheme.typography.labelSmall,
                color = ClinicalTextTertiary
            )
        }
        if (!explanation.isNullOrBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(text = explanation, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
        }
    }
}

/** UI-1B — one past session summary row for the History screen. */
@Composable
fun SessionHistoryRow(
    dateLabel: String,
    leadingSignal: String,
    confidence: String,
    compatible: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    ClinicalCard(modifier = modifier.clickable { onClick() }) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(text = dateLabel, style = MaterialTheme.typography.titleMedium, color = ClinicalTextPrimary)
                Spacer(Modifier.height(4.dp))
                Text(
                    text = leadingSignal.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                ConfidenceIndicator(confidence = confidence)
                if (!compatible) {
                    Spacer(Modifier.height(4.dp))
                    PillTag(text = "Different analysis version", tint = SignalModerate)
                }
            }
        }
    }
}

/** UI-1B — one line of a routine (a single AM/PM/alternating step or ingredient entry). */
@Composable
fun RoutineStepRow(primary: String, secondary: String? = null, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier
                .padding(top = 6.dp)
                .size(6.dp)
                .clip(CircleShape)
                .background(AccentPrimary)
        )
        Spacer(Modifier.width(12.dp))
        Column {
            Text(text = primary, style = MaterialTheme.typography.bodyLarge, color = ClinicalTextPrimary)
            if (secondary != null) {
                Spacer(Modifier.height(2.dp))
                Text(text = secondary, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
            }
        }
    }
}

@Composable
fun StatusChip(text: String, active: Boolean, modifier: Modifier = Modifier) {
    val bg = if (active) AccentPrimary else ClinicalSurfaceElevated2
    val fg = if (active) AccentOnPrimary else ClinicalTextSecondary
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelMedium, color = fg, fontWeight = FontWeight.Medium)
    }
}
