package com.rawskinanalyzer.ui.nav

import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarViewWeek
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rawskinanalyzer.ui.screens.AnalyzeScreen
import com.rawskinanalyzer.ui.screens.DashboardScreen
import com.rawskinanalyzer.ui.screens.DetailedResultsScreen
import com.rawskinanalyzer.ui.screens.HistoryScreen
import com.rawskinanalyzer.ui.screens.ProgressScreen
import com.rawskinanalyzer.ui.screens.ResultsScreen
import com.rawskinanalyzer.ui.screens.RoutineScreen
import com.rawskinanalyzer.ui.screens.SessionDetailScreen
import com.rawskinanalyzer.ui.screens.SettingsScreen
import com.rawskinanalyzer.ui.screens.SkinMapScreen
import com.rawskinanalyzer.ui.state.AnalysisViewModel
import com.rawskinanalyzer.ui.state.UiSessionStep
import com.rawskinanalyzer.ui.theme.AccentPrimary
import com.rawskinanalyzer.ui.theme.ClinicalBackground
import com.rawskinanalyzer.ui.theme.ClinicalSurfaceElevated
import com.rawskinanalyzer.ui.theme.ClinicalTextTertiary

/**
 * Navigation: UI-1A's three original routes (home/analyze/results), UI-1B's five additions
 * (detailed_results/skin_map/progress/routine/history + session_detail), and UI-2's Settings
 * route, plus a persistent bottom navigation bar for the required destinations (Home,
 * Progress, Analyze, Routine, History — Analyze stays the visually prominent, center item).
 * Settings and the other secondary routes (Detailed Results, Skin Map, Session Details) are
 * reached by drilling in from a primary screen (a gear icon on Dashboard, for Settings), not
 * from the bottom bar, so the five required destinations stay uncluttered.
 */
object Routes {
    const val HOME = "home"
    const val ANALYZE = "analyze"
    const val RESULTS = "results"
    const val DETAILED_RESULTS = "detailed_results"
    const val SKIN_MAP = "skin_map"
    const val PROGRESS = "progress"
    const val ROUTINE = "routine"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val SESSION_DETAIL = "session_detail/{index}"
    fun sessionDetail(index: Int) = "session_detail/$index"
}

private data class BottomDestination(val route: String, val label: String, val icon: ImageVector)

private val bottomDestinations = listOf(
    BottomDestination(Routes.HOME, "Home", Icons.Filled.Home),
    BottomDestination(Routes.PROGRESS, "Progress", Icons.Filled.CalendarViewWeek),
    BottomDestination(Routes.ANALYZE, "Analyze", Icons.Filled.CameraAlt),
    BottomDestination(Routes.ROUTINE, "Routine", Icons.Filled.Spa),
    BottomDestination(Routes.HISTORY, "History", Icons.Filled.History)
)

@Composable
fun AppRoot(
    viewModel: AnalysisViewModel,
    onPreviewCreated: (TextureView) -> Unit,
    onSelectStep: (UiSessionStep) -> Unit,
    onCapture: () -> Unit,
    onSwitchCamera: (String) -> Unit,
    navController: NavHostController = rememberNavController()
) {
    val state by viewModel.state.collectAsState()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Surface(modifier = Modifier.background(ClinicalBackground)) {
        Scaffold(
            containerColor = ClinicalBackground,
            bottomBar = {
                // Bottom navigation is available from every primary/secondary screen except
                // Analyze itself, which already owns the full screen for the camera preview.
                if (currentRoute != Routes.ANALYZE) {
                    NavigationBar(containerColor = ClinicalSurfaceElevated) {
                        bottomDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            NavigationBarItem(
                                selected = selected,
                                onClick = {
                                    if (!selected) {
                                        navController.navigate(dest.route) {
                                            popUpTo(Routes.HOME) { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                                icon = { Icon(dest.icon, contentDescription = dest.label) },
                                label = { Text(dest.label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AccentPrimary,
                                    selectedTextColor = AccentPrimary,
                                    unselectedIconColor = ClinicalTextTertiary,
                                    unselectedTextColor = ClinicalTextTertiary,
                                    indicatorColor = ClinicalSurfaceElevated
                                )
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = Routes.HOME,
                modifier = Modifier
                    .background(ClinicalBackground)
                    .padding(bottom = padding.calculateBottomPadding())
            ) {
                composable(Routes.HOME) {
                    DashboardScreen(
                        state = state,
                        onStartAnalysis = { navController.navigate(Routes.ANALYZE) },
                        onViewResults = { navController.navigate(Routes.RESULTS) },
                        onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                        onOpenProgress = { navController.navigate(Routes.PROGRESS) },
                        onOpenRoutine = { navController.navigate(Routes.ROUTINE) },
                        onOpenHistory = { navController.navigate(Routes.HISTORY) }
                    )
                }
                composable(Routes.ANALYZE) {
                    AnalyzeScreen(
                        state = state,
                        onPreviewCreated = onPreviewCreated,
                        onSelectStep = onSelectStep,
                        onCapture = onCapture,
                        onSwitchCamera = onSwitchCamera,
                        onViewResults = { navController.navigate(Routes.RESULTS) },
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(Routes.RESULTS) {
                    ResultsScreen(
                        state = state,
                        onBack = { navController.popBackStack() },
                        onOpenDetailedResults = { navController.navigate(Routes.DETAILED_RESULTS) }
                    )
                }
                composable(Routes.DETAILED_RESULTS) {
                    DetailedResultsScreen(
                        state = state,
                        onBack = { navController.popBackStack() },
                        onOpenSkinMap = { navController.navigate(Routes.SKIN_MAP) }
                    )
                }
                composable(Routes.SKIN_MAP) {
                    SkinMapScreen(
                        state = state,
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(Routes.PROGRESS) {
                    ProgressScreen(
                        state = state,
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(Routes.ROUTINE) {
                    RoutineScreen(
                        state = state,
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(Routes.HISTORY) {
                    HistoryScreen(
                        state = state,
                        onBack = { navController.popBackStack() },
                        onOpenSession = { index -> navController.navigate(Routes.sessionDetail(index)) }
                    )
                }
                composable(Routes.SETTINGS) {
                    SettingsScreen(
                        state = state,
                        onBack = { navController.popBackStack() },
                        onClearHistory = { viewModel.clearHistory() }
                    )
                }
                composable(
                    route = Routes.SESSION_DETAIL,
                    arguments = listOf(navArgument("index") { type = NavType.IntType })
                ) { backStack ->
                    val index = backStack.arguments?.getInt("index") ?: -1
                    SessionDetailScreen(
                        session = state.sessionHistory.getOrNull(index),
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
