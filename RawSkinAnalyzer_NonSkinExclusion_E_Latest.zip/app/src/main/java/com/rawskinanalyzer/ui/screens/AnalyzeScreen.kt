package com.rawskinanalyzer.ui.screens

import android.view.TextureView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.LoadingState
import com.rawskinanalyzer.ui.components.PremiumButton
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.components.StatusChip
import com.rawskinanalyzer.ui.components.StepProgressBar
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.state.UiSessionStep
import com.rawskinanalyzer.ui.theme.ClinicalSurface
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary

/**
 * Connects to the existing Camera2/RAW capture pipeline: the TextureView created here is
 * the same preview surface MainActivity's openCamera()/createSession()/captureEvidence()
 * already drive. Nothing about capture, DNG writing, or evidence hashing is reimplemented.
 */
@Composable
fun AnalyzeScreen(
    state: RawSkinUiState,
    onPreviewCreated: (TextureView) -> Unit,
    onSelectStep: (UiSessionStep) -> Unit,
    onCapture: () -> Unit,
    onSwitchCamera: (String) -> Unit,
    onViewResults: () -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Analyze", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        SectionHeader(title = "Three-Photo Session")
        Spacer(Modifier.height(10.dp))
        StepProgressBar(completed = state.completedSteps.size, total = 3)
        Spacer(Modifier.height(14.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            listOf(UiSessionStep.FRONT, UiSessionStep.LEFT_CHEEK, UiSessionStep.RIGHT_CHEEK).forEach { step ->
                StatusChip(
                    text = step.label,
                    active = step == state.currentStep,
                    modifier = Modifier.weight(1f).clickable { onSelectStep(step) }
                )
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            text = "Capture instructions: face the camera directly, use even lighting, and hold steady. Capture Front Face, then Left Cheek, then Right Cheek in order.",
            style = MaterialTheme.typography.bodyMedium,
            color = ClinicalTextSecondary
        )
        Spacer(Modifier.height(16.dp))

        // Existing Camera2 preview surface — capture logic lives entirely in MainActivity.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(20.dp))
                .background(ClinicalSurface)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    TextureView(context).also { onPreviewCreated(it) }
                }
            )
        }

        Spacer(Modifier.height(14.dp))
        if (state.cameraStatus.isNotEmpty()) {
            Text(text = state.cameraStatus, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
            Spacer(Modifier.height(6.dp))
        }
        if (state.captureQuality != null) {
            Text(text = "Quality: ${state.captureQuality}", style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
            Spacer(Modifier.height(6.dp))
        }
        if (state.lastError != null) {
            AnalysisStatusCard(title = "Something needs attention", detail = state.lastError, isError = true)
            Spacer(Modifier.height(6.dp))
        }

        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Icon(
                Icons.Filled.Cameraswitch,
                contentDescription = "Switch camera",
                tint = ClinicalTextSecondary,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(ClinicalSurface)
                    .clickable {
                        onSwitchCamera(if (state.cameraStatus.contains("Camera 1")) "0" else "1")
                    }
                    .padding(14.dp)
            )
            PremiumButton(text = "Capture", onClick = onCapture, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(14.dp))
        if (state.analysisRunning) {
            LoadingState(message = "Running analysis pipeline…")
        } else if (state.analysisReady) {
            PremiumButton(text = "View Results", onClick = onViewResults, modifier = Modifier.fillMaxWidth(), filled = false)
        }
        Spacer(Modifier.height(24.dp))
    }
}
