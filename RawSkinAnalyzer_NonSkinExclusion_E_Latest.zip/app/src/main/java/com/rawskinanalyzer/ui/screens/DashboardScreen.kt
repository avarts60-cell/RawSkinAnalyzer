package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.ConfidenceIndicator
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.PremiumButton
import com.rawskinanalyzer.ui.components.PrimaryFindingCard
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.ClinicalTextTertiary

@Composable
fun DashboardScreen(
    state: RawSkinUiState,
    onStartAnalysis: () -> Unit,
    onViewResults: () -> Unit,
    // UI-2: additive, defaulted so any existing call site (none outside AppRoot) still
    // compiles without change.
    onOpenSettings: (() -> Unit)? = null,
    onOpenProgress: (() -> Unit)? = null,
    onOpenRoutine: (() -> Unit)? = null,
    onOpenHistory: (() -> Unit)? = null
) {
    val profile = state.finalProfile

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp),
        contentPadding = PaddingValues(top = 32.dp, bottom = 32.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column {
                    Text(text = "RawSkinAnalyzer", style = MaterialTheme.typography.headlineLarge, color = ClinicalTextPrimary)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Evidence-based skin capture and heuristic analysis",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ClinicalTextSecondary
                    )
                }
                if (onOpenSettings != null) {
                    Icon(
                        Icons.Filled.Settings,
                        contentDescription = "Settings",
                        tint = ClinicalTextSecondary,
                        modifier = Modifier.clickable { onOpenSettings() }
                    )
                }
            }
            Spacer(Modifier.height(28.dp))
        }

        if (profile == null) {
            item {
                EmptyState(
                    title = "No analysis yet",
                    message = "Complete a three-photo session (front, left cheek, right cheek) to see your first skin summary here.",
                    actionText = "Start Analysis",
                    onAction = onStartAnalysis
                )
            }
        } else {
            item {
                SectionHeader(title = "Latest Analysis")
                Spacer(Modifier.height(12.dp))
                PrimaryFindingCard(label = "Primary Finding", finding = profile.primaryFinding)
                Spacer(Modifier.height(12.dp))
                PrimaryFindingCard(label = "Secondary Finding", finding = profile.secondaryFinding, accent = false)
                Spacer(Modifier.height(12.dp))
                AnalysisStatusCard(
                    title = "Overall profile: ${profile.overallProfile.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                    detail = "Heuristic, rule-based analysis. Not a clinical diagnosis."
                )
                Spacer(Modifier.height(12.dp))
                ConfidenceIndicator(confidence = profile.analysisConfidence)
                Spacer(Modifier.height(20.dp))
                PremiumButton(text = "View Full Results", onClick = onViewResults, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                PremiumButton(text = "Start New Analysis", onClick = onStartAnalysis, modifier = Modifier.fillMaxWidth(), filled = false)
                Spacer(Modifier.height(28.dp))
            }
        }

        // UI-2: real tie-in into the UI-1B screens — a one-line, non-fabricated status per
        // destination, using exactly what's already in RawSkinUiState (no new computation).
        if (onOpenProgress != null || onOpenRoutine != null || onOpenHistory != null) {
            item {
                SectionHeader(title = "Your Skin Journey")
                Spacer(Modifier.height(12.dp))
                if (onOpenHistory != null) {
                    DashboardLinkCard(
                        title = "History",
                        detail = if (state.sessionHistory.isEmpty())
                            "No sessions recorded yet."
                        else
                            "${state.sessionHistory.size} session(s) recorded on this device.",
                        onClick = onOpenHistory
                    )
                    Spacer(Modifier.height(10.dp))
                }
                if (onOpenProgress != null) {
                    val bundle = state.analysisBundle
                    DashboardLinkCard(
                        title = "Progress",
                        detail = when {
                            bundle == null -> "Complete a session to start tracking progress."
                            bundle.previousProgressSnapshot == null -> "Baseline session recorded — comparisons begin next session."
                            else -> "Overall direction: ${bundle.progressResult.overallDirection.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}."
                        },
                        onClick = onOpenProgress
                    )
                    Spacer(Modifier.height(10.dp))
                }
                if (onOpenRoutine != null) {
                    val bundle = state.analysisBundle
                    DashboardLinkCard(
                        title = "Routine",
                        detail = if (bundle == null)
                            "Complete a session to generate a routine."
                        else
                            "${bundle.ingredientUsePlans.size} ingredient(s) in your current routine · adaptation: ${bundle.routineExecution.action.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}.",
                        onClick = onOpenRoutine
                    )
                }
                Spacer(Modifier.height(20.dp))
            }
        }

        item {
            SectionHeader(title = "Recent Session")
            Spacer(Modifier.height(12.dp))
            AnalysisStatusCard(
                title = if (state.sessionId.isNotEmpty()) state.sessionId else "No active session",
                detail = if (state.completedSteps.isEmpty())
                    "No captures recorded for this session yet."
                else
                    "${state.completedSteps.size}/3 required views captured."
            )
        }
    }
}

@Composable
private fun DashboardLinkCard(title: String, detail: String, onClick: () -> Unit) {
    ClinicalCard(modifier = Modifier.clickable { onClick() }) {
        Text(text = title, style = MaterialTheme.typography.titleMedium, color = ClinicalTextPrimary)
        Spacer(Modifier.height(4.dp))
        Text(text = detail, style = MaterialTheme.typography.bodySmall, color = ClinicalTextTertiary)
    }
}
