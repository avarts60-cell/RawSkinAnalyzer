package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.ConfidenceIndicator
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.LoadingState
import com.rawskinanalyzer.ui.components.PremiumButton
import com.rawskinanalyzer.ui.components.PrimaryFindingCard
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.components.SkinScoreCard
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary

/**
 * UI-1B — Detailed Analysis. Everything shown is read from the real
 * `FinalSkinAnalysisProfile` (unchanged from UI-1A's ResultsScreen) plus the real
 * `SkinMapBundle` cross-view comparison for the "Analysis limitations" / "three-view support"
 * section. No score, confidence, or pattern is computed in this composable — both are pushed
 * in from MainActivity's existing pipeline via the ViewModel.
 */
@Composable
fun DetailedResultsScreen(
    state: RawSkinUiState,
    onBack: () -> Unit,
    onOpenSkinMap: () -> Unit
) {
    val profile = state.finalProfile
    val skinMap = state.skinMap

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Detailed Analysis", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (profile == null) {
            if (state.analysisRunning) {
                LoadingState(message = "Running analysis pipeline for this session…")
            } else {
                EmptyState(
                    title = "No results available",
                    message = "Complete a three-photo session to generate a detailed analysis."
                )
            }
            return@Column
        }

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                PrimaryFindingCard(label = "Primary Finding", finding = profile.primaryFinding)
                Spacer(Modifier.height(12.dp))
                PrimaryFindingCard(label = "Secondary Finding", finding = profile.secondaryFinding, accent = false)
                Spacer(Modifier.height(12.dp))
                AnalysisStatusCard(
                    title = "Session: ${state.sessionId.ifEmpty { "Unknown session" }}",
                    detail = "Overall profile: ${profile.overallProfile.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}"
                )
                Spacer(Modifier.height(12.dp))
                ConfidenceIndicator(confidence = profile.analysisConfidence)
                Spacer(Modifier.height(24.dp))

                SectionHeader(title = "Three-View Support")
                Spacer(Modifier.height(12.dp))
                if (skinMap != null) {
                    val comparison = skinMap.crossViewComparison
                    ClinicalCard {
                        Text(
                            text = comparison.result.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.titleMedium,
                            color = ClinicalTextPrimary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Front: ${comparison.frontCount} · Left cheek: ${comparison.leftCount} · Right cheek: ${comparison.rightCount} pattern signals detected",
                            style = MaterialTheme.typography.bodySmall,
                            color = ClinicalTextSecondary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Cross-view evidence score: ${comparison.evidenceScore.toInt()}/100",
                            style = MaterialTheme.typography.bodySmall,
                            color = ClinicalTextSecondary
                        )
                    }
                } else {
                    ClinicalCard {
                        Text(
                            text = "Three-view pattern comparison not available for this session.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ClinicalTextSecondary
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                PremiumButton(text = "Open Skin Map", onClick = onOpenSkinMap, filled = false)
                Spacer(Modifier.height(24.dp))

                SectionHeader(title = "Characteristic Scores & Confidence")
                Spacer(Modifier.height(12.dp))
            }
            items(profile.findings.sortedBy { it.priority }) { finding ->
                SkinScoreCard(
                    characteristic = finding.characteristic,
                    score = finding.score,
                    level = finding.level,
                    confidence = finding.confidence
                )
                Spacer(Modifier.height(8.dp))
                ClinicalCard {
                    Text(
                        text = "Evidence: ${finding.evidence}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ClinicalTextSecondary
                    )
                }
                Spacer(Modifier.height(12.dp))
            }
            item {
                Spacer(Modifier.height(8.dp))
                SectionHeader(title = "Analysis Limitations")
                Spacer(Modifier.height(12.dp))
                ClinicalCard {
                    Text(
                        text = "These are heuristic, rule-based scores derived from pixel analysis of your photos. " +
                            "They are not a clinical diagnosis and have not been validated against ground truth. " +
                            "Confidence reflects how consistent the underlying signal was across views — it is a " +
                            "separate measurement from the score itself, never a certainty percentage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ClinicalTextSecondary
                    )
                }
            }
        }
    }
}
