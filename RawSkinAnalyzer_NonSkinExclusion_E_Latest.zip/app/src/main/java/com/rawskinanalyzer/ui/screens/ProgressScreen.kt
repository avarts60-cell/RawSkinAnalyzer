package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.LoadingState
import com.rawskinanalyzer.ui.components.FeatureProgressRow
import com.rawskinanalyzer.ui.components.LimitationNote
import com.rawskinanalyzer.ui.components.PillTag
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.components.TrendIntelligenceCard
import com.rawskinanalyzer.ui.components.TrendSparkline
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.ClinicalTextTertiary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * BATCH 4C — translates this batch's deterministic explanation tags
 * (`CharacteristicTrendIntelligence.explanationTags`, produced by
 * `CharacteristicTrendIntelligenceAnalyzer`) into a single concise, non-diagnostic sentence.
 * Only tags the backend actually attached are ever shown — nothing here is invented, and
 * priority order picks the single most informative tag rather than concatenating all of them
 * into a wall of text. Returns null when no tag in the list has a mapped explanation (in which
 * case the caller shows nothing extra beyond the structured stability/evidence lines).
 */
private fun trendExplanationFor(tags: List<String>): String? {
    val priority = listOf(
        "NOT_COMPARABLE" to "The sessions are not sufficiently comparable.",
        "INSUFFICIENT_HISTORY" to "There is not enough historical data yet.",
        "CONTRADICTORY_SESSIONS" to "Recent sessions are inconsistent.",
        "REPEATED_WORSENING" to "Repeated measurements support this trend.",
        "REPEATED_IMPROVEMENT" to "Repeated measurements support this trend.",
        "LOW_TREND_RELIABILITY" to "This is an early signal and needs more sessions.",
        "SINGLE_SESSION_CHANGE" to "This is based on a single session's change so far.",
        "STABLE_OVER_TIME" to "This characteristic has stayed stable across your recent sessions.",
        "CAPTURE_CONDITION_CONFLICT" to "Some earlier sessions had reduced capture reliability and weren't counted as full evidence.",
        "MIXED_TREND_EVIDENCE_STRENGTH" to "Evidence strength varies across the sessions behind this trend."
    )
    return priority.firstOrNull { tags.contains(it.first) }?.second
}

/**
 * BATCH 4C — a second, independent explanation derived by comparing `recentTrendDirection`
 * (the existing `MultiSessionTrendAnalyzer` direction, unmodified) against `baselineChange`
 * (this batch's fixed-baseline delta). This is deliberately not one of `explanationTags` — it is
 * a relationship between two already-computed fields, not a new backend-computed tag — but it is
 * only ever derived from real values already present on [intel], never fabricated.
 */
private fun baselineDivergenceNote(intel: com.rawskinanalyzer.CharacteristicTrendIntelligence): String? {
    val change = intel.baselineChange ?: return null
    val recentlyImproving = intel.recentTrendDirection == com.rawskinanalyzer.TrendDirection.SUSTAINED_IMPROVEMENT
    val recentlyWorsening = intel.recentTrendDirection == com.rawskinanalyzer.TrendDirection.SUSTAINED_WORSENING
    return when {
        recentlyImproving && change > 3.0 -> "The recent trend differs from the baseline."
        recentlyWorsening && change < -3.0 -> "The recent trend differs from the baseline."
        else -> null
    }
}

private fun combinedTrendExplanation(intel: com.rawskinanalyzer.CharacteristicTrendIntelligence): String? {
    val parts = listOfNotNull(trendExplanationFor(intel.explanationTags), baselineDivergenceNote(intel))
    return parts.distinct().takeIf { it.isNotEmpty() }?.joinToString(" ")
}

/**
 * UI-1B — Progress. Every value shown comes from `SkinProgressTracker`/`MultiSessionTrendAnalyzer`
 * output (via `UiAnalysisAssembler`) or `SkinSessionRepository.history()` — no session, score,
 * or trend direction is invented, and a `INSUFFICIENT_COMPARISON_DATA`/`INSUFFICIENT_TREND_DATA`
 * result is shown as a limitation, never silently upgraded into a comparison.
 */
@Composable
fun ProgressScreen(
    state: RawSkinUiState,
    onBack: () -> Unit
) {
    val bundle = state.analysisBundle
    var selectedFeature by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Progress", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (bundle == null) {
            if (state.analysisRunning) {
                LoadingState(message = "Running analysis pipeline for this session…")
            } else {
                EmptyState(
                    title = "No progress data yet",
                    message = "Complete a session to see progress. A second compatible session is needed for a comparison."
                )
            }
            return@Column
        }

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                SectionHeader(title = "Session Timeline")
                Spacer(Modifier.height(10.dp))
                if (state.sessionHistory.isEmpty()) {
                    ClinicalCard {
                        Text(
                            text = "No prior sessions recorded yet on this device.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ClinicalTextSecondary
                        )
                    }
                } else {
                    ClinicalCard {
                        val fmt = remember { SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US) }
                        state.sessionHistory.take(6).forEach { session ->
                            Text(
                                text = fmt.format(Date(session.createdAtEpochMillis)),
                                style = MaterialTheme.typography.bodySmall,
                                color = ClinicalTextSecondary
                            )
                            Spacer(Modifier.height(4.dp))
                        }
                        if (state.sessionHistory.size > 6) {
                            Text(
                                text = "+${state.sessionHistory.size - 6} earlier session(s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = ClinicalTextTertiary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Baseline Comparison")
                Spacer(Modifier.height(10.dp))
                if (bundle.previousProgressSnapshot == null) {
                    ClinicalCard {
                        Text(
                            text = "No previous compatible session available yet — this is the baseline session.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ClinicalTextSecondary
                        )
                    }
                } else {
                    AnalysisStatusCard(
                        title = "Overall direction: ${bundle.progressResult.overallDirection.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                        detail = "Comparison confidence: ${bundle.progressResult.comparisonConfidence.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}"
                    )
                }
                if (bundle.progressResult.overallDirection.name == "INSUFFICIENT_COMPARISON_DATA") {
                    Spacer(Modifier.height(10.dp))
                    LimitationNote("Not enough compatible session history yet for a reliable baseline comparison.")
                }
                if (bundle.captureQualityReliability.name != "RELIABLE") {
                    Spacer(Modifier.height(10.dp))
                    LimitationNote("This session's capture-condition reliability was ${bundle.captureQualityReliability.name.lowercase()} — comparisons and routine-adjustment confidence have been capped accordingly, not treated as a full-strength result.")
                }
                Spacer(Modifier.height(20.dp))

                // BATCH 4A — step 9: real comparability/comparison-confidence/change-
                // classification output from this batch, shown only when a previous session
                // exists to compare against (same "no previous session yet" convention as the
                // existing Baseline Comparison section above). Nothing here replaces the
                // existing overallDirection/comparisonConfidence line above; it adds the
                // finer-grained signals that line could not represent (see ComparisonConfidence.kt).
                if (bundle.sessionComparability != null && bundle.comparisonConfidence != null && bundle.changeClassification != null) {
                    SectionHeader(title = "Comparison Reliability")
                    Spacer(Modifier.height(10.dp))
                    AnalysisStatusCard(
                        title = "Sessions are ${bundle.sessionComparability.status.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                        detail = "Change assessment: ${bundle.changeClassification.classification.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }} · Comparison confidence: ${bundle.comparisonConfidence.level.name.lowercase().replaceFirstChar { it.uppercase() }}"
                    )
                    if (bundle.sessionComparability.status == com.rawskinanalyzer.SessionComparabilityStatus.LIMITED_COMPARABILITY ||
                        bundle.sessionComparability.status == com.rawskinanalyzer.SessionComparabilityStatus.NOT_COMPARABLE
                    ) {
                        Spacer(Modifier.height(10.dp))
                        LimitationNote("These two sessions have reduced comparability (${bundle.sessionComparability.reasons.joinToString(", ") { it.replace('_', ' ').lowercase() }}) — the change assessment above reflects that, rather than treating every score difference as a genuine skin change.")
                    }
                    if (bundle.changeClassification.classification == com.rawskinanalyzer.LongitudinalChangeClassification.UNCERTAIN) {
                        Spacer(Modifier.height(10.dp))
                        LimitationNote("This session's change vs. the last one is not reliable enough on its own to call improving or worsening — more consistent sessions over time will clarify this.")
                    }
                    Spacer(Modifier.height(20.dp))
                }

                // BATCH 4A — step 5: fixed baseline (earliest sufficiently reliable session),
                // separate from the rolling previous-session comparison above. Only shown when
                // it would add information beyond that comparison (see UiAnalysisAssembler:
                // baselineComparison is null when the baseline *is* the previous session).
                if (bundle.baselineComparison != null && bundle.baselineSelection.baseline != null) {
                    SectionHeader(title = "Since Your Baseline")
                    Spacer(Modifier.height(10.dp))
                    val fmt = remember { SimpleDateFormat("MMM d, yyyy", Locale.US) }
                    AnalysisStatusCard(
                        title = "Baseline: ${fmt.format(Date(bundle.baselineSelection.baseline.createdAtEpochMillis))}",
                        detail = "Overall direction since baseline: ${bundle.baselineComparison.overallDirection.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }} (baseline quality: ${bundle.baselineSelection.quality.name.replace('_', ' ').lowercase()})"
                    )
                    Spacer(Modifier.height(20.dp))
                }

                // BATCH 4C — Longitudinal Trend Intelligence section header. The actual
                // per-characteristic cards render further down, one per item in the
                // `gatedFeatures`/`items(...)` loop below (next to that characteristic's own
                // progress row and multi-session sparkline) rather than as a separate list here,
                // so the new evidence/stability information sits directly beside the existing
                // score comparison it qualifies instead of duplicating a second characteristic
                // list on the same screen.
                SectionHeader(title = "Longitudinal Trend Intelligence")
                Spacer(Modifier.height(10.dp))
                ClinicalCard {
                    Text(
                        text = "For each characteristic below, this shows how much repeated, " +
                            "reliable evidence supports its trend — not just the latest change.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ClinicalTextSecondary
                    )
                }
                Spacer(Modifier.height(20.dp))

                // BATCH 4D-H — STEP 6: compact feature-level trend summary, complementary to
                // (not replacing) the characteristic-level "Longitudinal Trend Intelligence"
                // section above. Reuses `bundle.featureLongitudinalResult`
                // (`UiAnalysisAssembler`/`FeatureLongitudinalTrendAnalyzer`) exactly as computed
                // — nothing here re-derives a trend or a comparability status. NOT_COMPARABLE
                // and INSUFFICIENT_DATA are shown as real, honest states, never silently hidden
                // or upgraded into a trend.
                SectionHeader(title = "Feature-Level Trends")
                Spacer(Modifier.height(10.dp))
                val featureResult = bundle.featureLongitudinalResult
                when {
                    featureResult.overallDataStatus == "NOT_COMPARABLE" -> {
                        LimitationNote(
                            "Feature-level tracking (pores, blemishes, dark marks, and similar) isn't " +
                                "comparable between these two sessions yet: " +
                                featureResult.comparability.reasons.joinToString(", ") { it.replace('_', ' ').lowercase() } + "."
                        )
                    }
                    featureResult.overallDataStatus == "INSUFFICIENT_DATA" || featureResult.summaries.isEmpty() -> {
                        ClinicalCard {
                            Text(
                                text = "Not enough comparable session history yet for feature-level trends " +
                                    "(individual pores, blemishes, dark marks, etc). This needs at least one " +
                                    "earlier comparable session with recorded feature evidence.",
                                style = MaterialTheme.typography.bodySmall,
                                color = ClinicalTextSecondary
                            )
                        }
                    }
                    else -> {
                        featureResult.summaries.take(6).forEach { s ->
                            val label = "${s.featureCategory.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }} · " +
                                s.region.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
                            AnalysisStatusCard(
                                title = "$label: ${s.trendState.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                                detail = s.evidenceReason
                            )
                            Spacer(Modifier.height(8.dp))
                        }
                        if (featureResult.summaries.size > 6) {
                            Text(
                                text = "+${featureResult.summaries.size - 6} more feature/region trend(s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = ClinicalTextTertiary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Characteristic Selection")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bundle.progressResult.features.take(4).forEach { f ->
                        PillTag(
                            text = f.feature.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                            tint = if (selectedFeature == f.feature) ClinicalTextPrimary else ClinicalTextTertiary,
                            modifier = Modifier.clickable { selectedFeature = f.feature }
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            // BATCH 4B — steps 1-3: per-characteristic comparability-gated rows, built from
            // `CharacteristicGatedProgress` (via `UiAnalysisAssembler`) instead of the raw
            // `bundle.progressResult.features` list directly. A NOT_COMPARABLE/INSUFFICIENT_DATA
            // characteristic still shows both raw historical scores (preserved, never hidden)
            // but no longer renders a numerical delta/direction as if it were a normal,
            // full-strength comparison — see `GatedFeatureProgress`.
            val gatedFeatures = if (selectedFeature != null)
                bundle.gatedProgressFeatures.filter { it.feature == selectedFeature }
            else bundle.gatedProgressFeatures

            items(gatedFeatures) { f ->
                val limited = f.comparability == com.rawskinanalyzer.CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS ||
                    f.comparability == com.rawskinanalyzer.CharacteristicComparabilityStatus.NOT_COMPARABLE ||
                    f.comparability == com.rawskinanalyzer.CharacteristicComparabilityStatus.INSUFFICIENT_DATA
                FeatureProgressRow(
                    feature = f.feature,
                    previousScore = f.previousScore,
                    currentScore = f.currentScore,
                    delta = f.delta,
                    direction = f.direction?.name,
                    comparabilityLabel = if (limited)
                        f.comparability.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
                    else null
                )
                if (limited && f.reasons.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    LimitationNote(
                        "Limited comparability for this characteristic: " +
                            f.reasons.joinToString(", ") { it.replace('_', ' ').lowercase() } + "."
                    )
                }
                val trend = bundle.multiSessionTrend.features.firstOrNull { it.feature == f.feature }
                if (trend != null) {
                    Spacer(Modifier.height(6.dp))
                    ClinicalCard {
                        Text(
                            text = "Multi-session trend (${bundle.multiSessionTrend.sessionsUsed} sessions): ${trend.direction.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ClinicalTextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        TrendSparkline(values = trend.values)
                    }
                }

                // BATCH 4C — per-characteristic longitudinal trend intelligence. Reuses
                // `bundle.characteristicTrendIntelligence` (already computed by
                // `UiAnalysisAssembler`/`CharacteristicTrendIntelligenceAnalyzer`) — nothing here
                // recomputes a trend. A NOT_COMPARABLE or INSUFFICIENT_DATA direction-stability
                // result never renders as a trend card; it renders as an honest limitation note
                // instead, per the batch requirement not to imply a trend that doesn't exist.
                val trendIntel = bundle.characteristicTrendIntelligence.firstOrNull { it.characteristic == f.feature }
                if (trendIntel != null) {
                    Spacer(Modifier.height(6.dp))
                    val notComparable = trendIntel.directionStability == com.rawskinanalyzer.TrendDirectionStability.NOT_COMPARABLE
                    val insufficientData = trendIntel.directionStability == com.rawskinanalyzer.TrendDirectionStability.INSUFFICIENT_DATA
                    if (notComparable || insufficientData) {
                        LimitationNote(
                            trendExplanationFor(trendIntel.explanationTags)
                                ?: "Not enough reliable historical evidence yet for a longitudinal trend on this characteristic."
                        )
                    } else {
                        TrendIntelligenceCard(
                            directionStability = trendIntel.directionStability.name,
                            trendConfidence = trendIntel.trendConfidence.name,
                            evidenceState = trendIntel.evidenceState.name,
                            baselineChange = trendIntel.baselineChange,
                            explanation = combinedTrendExplanation(trendIntel)
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            item {
                if (bundle.multiSessionTrend.overallDirection.name == "INSUFFICIENT_TREND_DATA") {
                    LimitationNote("At least three compatible sessions are needed for a multi-session trend — only ${bundle.multiSessionTrend.sessionsUsed} available so far.")
                }
            }
        }
    }
}
