package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.ConfidenceIndicator
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.PremiumButton
import com.rawskinanalyzer.ui.components.PrimaryFindingCard
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.components.SkinScoreCard
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary

@Composable
fun ResultsScreen(
    state: RawSkinUiState,
    onBack: () -> Unit,
    // UI-1B: optional so this screen's UI-1A call sites (none changed) keep compiling; the
    // new AppRoot call site below supplies it to link into the new Detailed Analysis screen.
    onOpenDetailedResults: (() -> Unit)? = null
) {
    val profile = state.finalProfile

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Analysis Results", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (profile == null) {
            EmptyState(
                title = "No results available",
                message = if (state.analysisRunning)
                    "Analysis is still running for the current session."
                else
                    "Complete a three-photo session to generate results."
            )
            return@Column
        }

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                PrimaryFindingCard(label = "Primary Finding", finding = profile.primaryFinding)
                Spacer(Modifier.height(12.dp))
                PrimaryFindingCard(label = "Secondary Finding", finding = profile.secondaryFinding, accent = false)
                Spacer(Modifier.height(12.dp))
                AnalysisStatusCard(
                    title = "Analysis status: ${state.sessionId.ifEmpty { "Unknown session" }}",
                    detail = "Three-view session (front, left cheek, right cheek) used for this result."
                )
                Spacer(Modifier.height(12.dp))
                ConfidenceIndicator(confidence = profile.analysisConfidence)
                if (onOpenDetailedResults != null) {
                    Spacer(Modifier.height(16.dp))
                    PremiumButton(text = "View Detailed Analysis", onClick = onOpenDetailedResults, filled = false)
                }
                Spacer(Modifier.height(24.dp))
                SectionHeader(title = "Characteristic Scores")
                Spacer(Modifier.height(12.dp))
            }
            items(profile.findings.sortedBy { it.priority }) { finding ->
                SkinScoreCard(
                    characteristic = finding.characteristic,
                    score = finding.score,
                    level = finding.level,
                    confidence = finding.confidence
                )
                Spacer(Modifier.height(12.dp))
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "These are heuristic, rule-based scores derived from pixel analysis of your photos. They are not a clinical diagnosis and have not been validated against ground truth.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
        }
    }
}
