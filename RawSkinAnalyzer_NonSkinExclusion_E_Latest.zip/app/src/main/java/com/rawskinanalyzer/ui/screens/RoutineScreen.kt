package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.LimitationNote
import com.rawskinanalyzer.ui.components.LoadingState
import com.rawskinanalyzer.ui.components.PillTag
import com.rawskinanalyzer.ui.components.RoutineStepRow
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.SignalAttention
import com.rawskinanalyzer.ui.theme.SignalGood

/**
 * UI-1B — Routine. Every objective, ingredient, schedule step, and caution below is read
 * directly from the already-computed Brain 2 chain (`SkinObjectivePlanner` ->
 * `RoutineStrategyPlanner` -> ... -> `FinalRoutineResultAssembler` /
 * `RoutineAdjustmentCandidateActivator` /`RoutineAdaptationExecutor`, all bundled by
 * `UiAnalysisAssembler`). No product, ingredient, or medical claim is added by this screen.
 */
@Composable
fun RoutineScreen(
    state: RawSkinUiState,
    onBack: () -> Unit
) {
    val bundle = state.analysisBundle

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Routine", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (bundle == null) {
            if (state.analysisRunning) {
                LoadingState(message = "Running analysis pipeline for this session…")
            } else {
                EmptyState(
                    title = "No routine available",
                    message = "Complete a three-photo session to generate a routine."
                )
            }
            return@Column
        }

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                SectionHeader(title = "Current Objectives")
                Spacer(Modifier.height(10.dp))
            }
            items(bundle.objectives.sortedBy { it.priority }) { objective ->
                ClinicalCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = objective.title, style = MaterialTheme.typography.titleMedium, color = ClinicalTextPrimary, modifier = Modifier.weight(1f))
                        PillTag(text = objective.objectiveType.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() })
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(text = objective.rationale, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Objective strength: ${objective.strengthReason}",
                        style = MaterialTheme.typography.labelSmall,
                        color = ClinicalTextSecondary
                    )
                }
                Spacer(Modifier.height(10.dp))
            }

            item {
                Spacer(Modifier.height(8.dp))
                SectionHeader(title = "Morning Routine")
                Spacer(Modifier.height(6.dp))
                ClinicalCard {
                    if (bundle.finalRoutineResult.morningRoutine.isEmpty()) {
                        Text("No morning steps generated for this session.", style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary)
                    } else {
                        bundle.finalRoutineResult.morningRoutine.forEach { RoutineStepRow(primary = it) }
                    }
                }
                Spacer(Modifier.height(16.dp))

                SectionHeader(title = "Evening Routine")
                Spacer(Modifier.height(6.dp))
                ClinicalCard {
                    if (bundle.finalRoutineResult.eveningRoutine.isEmpty()) {
                        Text("No evening steps generated for this session.", style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary)
                    } else {
                        bundle.finalRoutineResult.eveningRoutine.forEach { RoutineStepRow(primary = it) }
                    }
                }
                if (bundle.finalRoutineResult.alternatingPlan.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    SectionHeader(title = "Alternating / Weekly Plan")
                    Spacer(Modifier.height(6.dp))
                    ClinicalCard {
                        bundle.finalRoutineResult.alternatingPlan.forEach { RoutineStepRow(primary = it) }
                    }
                }
                Spacer(Modifier.height(16.dp))

                SectionHeader(title = "Selected Ingredients")
                Spacer(Modifier.height(6.dp))
            }

            items(bundle.ingredientUsePlans) { plan ->
                val compatibility = bundle.candidateCompatibility.firstOrNull { it.ingredientName == plan.ingredientName }
                val tolerance = bundle.toleranceRecords.firstOrNull { it.ingredientName == plan.ingredientName }
                val intensity = bundle.routineIntensityDecisions.firstOrNull { it.ingredientName == plan.ingredientName }
                ClinicalCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = plan.ingredientName, style = MaterialTheme.typography.titleMedium, color = ClinicalTextPrimary, modifier = Modifier.weight(1f))
                        PillTag(text = plan.routinePhase)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(text = "${plan.concentrationGuidance} · ${plan.frequencyGuidance}", style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
                    Spacer(Modifier.height(4.dp))
                    Text(text = "Why selected: ${plan.introductionRule}", style = MaterialTheme.typography.labelSmall, color = ClinicalTextSecondary)
                    if (plan.caution != null) {
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            PillTag(text = "Caution", tint = SignalAttention)
                            Spacer(Modifier.width(8.dp))
                            Text(text = plan.caution, style = MaterialTheme.typography.labelSmall, color = ClinicalTextSecondary)
                        }
                    }
                    if (compatibility != null) {
                        Spacer(Modifier.height(6.dp))
                        Text(text = "Compatibility: ${compatibility.action.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }} — ${compatibility.reason}", style = MaterialTheme.typography.labelSmall, color = ClinicalTextSecondary)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        if (tolerance != null) {
                            Spacer(Modifier.height(6.dp))
                            PillTag(text = "Tolerance: ${tolerance.state.name.lowercase().replaceFirstChar { it.uppercase() }}")
                        }
                        if (intensity != null) {
                            PillTag(text = intensity.level.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() })
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            item {
                if (bundle.finalRoutineResult.cautions.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    SectionHeader(title = "Compatibility Limitations")
                    Spacer(Modifier.height(6.dp))
                    ClinicalCard {
                        bundle.finalRoutineResult.cautions.forEach {
                            Text(text = "• $it", style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
                            Spacer(Modifier.height(4.dp))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))

                SectionHeader(title = "Changes From Previous Routine")
                Spacer(Modifier.height(6.dp))
                if (bundle.controlledRoutineRevision.changeLog.isEmpty() && bundle.routineExecution.appliedChanges.all { it == "CURRENT_ROUTINE_PRESERVED" }) {
                    ClinicalCard {
                        Text(text = "Routine maintained — no adjustment was triggered this session.", style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary)
                    }
                } else {
                    ClinicalCard {
                        (bundle.routineExecution.appliedChanges + bundle.controlledRoutineRevision.changeLog).distinct().forEach { change ->
                            Text(text = "• ${change.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}", style = MaterialTheme.typography.bodySmall, color = SignalGood)
                            Spacer(Modifier.height(4.dp))
                        }
                    }
                }
                if (bundle.routineExecution.reviewFlags.isNotEmpty() || bundle.controlledRoutineRevision.reviewFlags.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    (bundle.routineExecution.reviewFlags + bundle.controlledRoutineRevision.reviewFlags).distinct().forEach {
                        LimitationNote(it.replace('_', ' ').lowercase().replaceFirstChar { c -> c.uppercase() })
                        Spacer(Modifier.height(6.dp))
                    }
                }
                Spacer(Modifier.height(10.dp))
                AnalysisStatusCard(
                    title = "Routine adaptation: ${bundle.routineExecution.action.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                    detail = "Confidence: ${bundle.trendAwareAdaptation.decision.adaptationConfidence.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}"
                )
                Spacer(Modifier.height(24.dp))
                Text(
                    text = "This routine is a rule-based suggestion derived from your own heuristic scores. It is not a medical prescription — introduce new active ingredients one at a time and stop if irritation occurs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
        }
    }
}
