package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.AnalysisScorePolicy
import com.rawskinanalyzer.CandidateCompatibilityPolicy
import com.rawskinanalyzer.EvidenceAwareCandidateSelectionPolicy
import com.rawskinanalyzer.ObjectiveStrengthPolicy
import com.rawskinanalyzer.RoutineIntensityPolicy
import com.rawskinanalyzer.SkinSessionRetentionPolicy
import com.rawskinanalyzer.ToleranceTransitionPolicy
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.PillTag
import com.rawskinanalyzer.ui.components.PremiumButton
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.SignalAttention

/**
 * UI-2 — Settings. Every fact shown is real:
 * - "Local-only" reflects `AndroidManifest.xml` genuinely requesting no network permission
 *   and this codebase making no network calls anywhere (`strict_scope` across every session
 *   has explicitly kept it that way).
 * - Session count comes from the live `RawSkinUiState.sessionHistory`.
 * - The retention policy shown is `SkinSessionRetentionPolicy`'s actual default, the same one
 *   `SkinSessionRepository.applyLifecyclePolicy()` already enforces after every save.
 * - Version strings are the real `const val VERSION` from each calibration/policy object —
 *   nothing here is a marketing label.
 * "Clear stored history" is a real, immediate action (`AnalysisViewModel.clearHistory()`),
 * gated behind a confirmation dialog since it is destructive and irreversible.
 */
@Composable
fun SettingsScreen(
    state: RawSkinUiState,
    onBack: () -> Unit,
    onClearHistory: () -> Unit
) {
    var showConfirmClear by remember { mutableStateOf(false) }
    val retention = remember { SkinSessionRetentionPolicy() }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Settings", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                SectionHeader(title = "Privacy")
                Spacer(Modifier.height(10.dp))
                ClinicalCard {
                    Text(
                        text = "All capture, analysis, and routine data stays on this device. RawSkinAnalyzer does not request network access and makes no network calls — nothing you capture is uploaded anywhere.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ClinicalTextSecondary
                    )
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Stored Data")
                Spacer(Modifier.height(10.dp))
                ClinicalCard {
                    Text(
                        text = "${state.sessionHistory.size} session(s) stored on this device",
                        style = MaterialTheme.typography.titleMedium,
                        color = ClinicalTextPrimary
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Retention policy: up to ${retention.maxSessions} sessions, spanning the ${retention.retainAnalysisVersions} most recent analysis versions. Older sessions are trimmed automatically after each new analysis.",
                        style = MaterialTheme.typography.bodySmall,
                        color = ClinicalTextSecondary
                    )
                    Spacer(Modifier.height(16.dp))
                    PremiumButton(
                        text = "Clear Stored History",
                        onClick = { showConfirmClear = true },
                        filled = false,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Capture")
                Spacer(Modifier.height(10.dp))
                ClinicalCard {
                    Text(
                        text = "Front and rear cameras can be switched during a capture session from the Analyze screen. There are no additional saved capture preferences in this build — every session uses the same RAW-first capture and normalization pipeline.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ClinicalTextSecondary
                    )
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Analysis — Technical Information")
                Spacer(Modifier.height(10.dp))
                ClinicalCard {
                    VersionRow("Score policy", AnalysisScorePolicy.VERSION)
                    VersionRow("Candidate selection", EvidenceAwareCandidateSelectionPolicy.VERSION)
                    VersionRow("Compatibility policy", CandidateCompatibilityPolicy.VERSION)
                    VersionRow("Routine intensity policy", RoutineIntensityPolicy.VERSION)
                    VersionRow("Tolerance policy", ToleranceTransitionPolicy.VERSION)
                    VersionRow("Objective strength policy", ObjectiveStrengthPolicy.VERSION, last = true)
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "About")
                Spacer(Modifier.height(10.dp))
                ClinicalCard {
                    Text(
                        text = "RawSkinAnalyzer produces heuristic, rule-based skin-pattern scores and routine suggestions from your own photos. It is not a medical device and does not provide a clinical diagnosis. Scores and confidence are always shown separately, and comparisons the backend marks as unreliable or incomparable are labeled as such rather than hidden.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ClinicalTextSecondary
                    )
                }
            }
        }
    }

    if (showConfirmClear) {
        AlertDialog(
            onDismissRequest = { showConfirmClear = false },
            title = { Text("Clear stored history?") },
            text = {
                Text("This permanently deletes all ${state.sessionHistory.size} stored session(s) on this device, including progress and trend history. This cannot be undone.")
            },
            confirmButton = {
                TextButton(onClick = {
                    onClearHistory()
                    showConfirmClear = false
                }) {
                    Text("Clear", color = SignalAttention)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClear = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun VersionRow(label: String, version: String, last: Boolean = false) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
        PillTag(text = version)
    }
    if (!last) Spacer(Modifier.height(10.dp))
}
