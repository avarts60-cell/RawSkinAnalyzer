package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.PatternHotspot
import com.rawskinanalyzer.PatternMapCell
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.LoadingState
import com.rawskinanalyzer.ui.components.PillTag
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.AccentPrimary
import com.rawskinanalyzer.ui.theme.ClinicalOutlineSubtle
import com.rawskinanalyzer.ui.theme.ClinicalSurfaceElevated2
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.ClinicalTextTertiary
import com.rawskinanalyzer.ui.theme.SignalAttention
import com.rawskinanalyzer.ui.theme.SignalModerate

private enum class MapView(val label: String) { FRONT("Front Face"), LEFT("Left Cheek"), RIGHT("Right Cheek") }

/**
 * UI-1B — Skin Map. Every cell color and every hotspot marker below comes directly from the
 * real `LocalizedPatternMapper`/`PatternHotspotAnalyzer` output already computed by
 * MainActivity's existing pipeline (see SkinMapAssembler) — no anatomical measurement or
 * heatmap value is invented here. The grid itself is a plain data-driven visualization (a
 * colored cell per already-computed `PatternMapCell`), not an image overlay, since no overlay
 * generator exists in the analysis engine to reuse.
 *
 * UI-3 — grid cells are now directly tappable. Tapping a cell selects the existing
 * `PatternMapCell` at that row/column (and its matching `PatternHotspot`, if any) and shows it
 * in an inline detail card below the grid. No new data is computed or fabricated for this —
 * the detail card only re-displays fields already present on the same `PatternMapCell` /
 * `PatternHotspot` objects the grid and the hotspot list below already consume.
 */
@Composable
fun SkinMapScreen(
    state: RawSkinUiState,
    onBack: () -> Unit
) {
    var selected by remember { mutableStateOf(MapView.FRONT) }
    var selectedCell by remember { mutableStateOf<PatternMapCell?>(null) }
    LaunchedEffect(selected) { selectedCell = null }
    val skinMap = state.skinMap

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Skin Map", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (skinMap == null) {
            if (state.analysisRunning) {
                LoadingState(message = "Running analysis pipeline for this session…")
            } else {
                EmptyState(
                    title = "No skin map available",
                    message = "Complete a three-photo session to generate a skin map."
                )
            }
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MapView.values().forEach { view ->
                PillTag(
                    text = view.label,
                    tint = if (view == selected) ClinicalTextPrimary else ClinicalTextTertiary,
                    modifier = Modifier.clickable { selected = view }
                )
            }
        }
        Spacer(Modifier.height(16.dp))

        val viewData = when (selected) {
            MapView.FRONT -> skinMap.front
            MapView.LEFT -> skinMap.leftCheek
            MapView.RIGHT -> skinMap.rightCheek
        }

        ClinicalCard {
            SkinMapGrid(
                cells = viewData.cells,
                hotspots = viewData.hotspots,
                selectedCell = selectedCell,
                onCellTap = { cell -> selectedCell = cell }
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Tap any cell for its readings.",
                style = MaterialTheme.typography.labelSmall,
                color = ClinicalTextTertiary
            )
        }

        if (selectedCell != null) {
            Spacer(Modifier.height(16.dp))
            CellDetailCard(
                cell = selectedCell!!,
                hotspots = viewData.hotspots.filter { it.row == selectedCell!!.row && it.col == selectedCell!!.col },
                onDismiss = { selectedCell = null }
            )
        }
        Spacer(Modifier.height(16.dp))

        SectionHeader(title = "Legend")
        Spacer(Modifier.height(10.dp))
        ClinicalCard {
            LegendRow(color = SignalAttention, label = "Elevated redness")
            Spacer(Modifier.height(8.dp))
            LegendRow(color = ClinicalTextTertiary, label = "Darker area (relative to session average)")
            Spacer(Modifier.height(8.dp))
            LegendRow(color = SignalModerate, label = "Elevated texture variation")
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Cell shade reflects sampled pixel data only (redness, luma, texture) for the 6×6 grid over this view — it is not a medical measurement of pore size, hydration, or any anatomical quantity.",
                style = MaterialTheme.typography.bodySmall,
                color = ClinicalTextSecondary
            )
        }
        Spacer(Modifier.height(16.dp))

        SectionHeader(title = "Localized Feature Information — ${selected.label}")
        Spacer(Modifier.height(10.dp))
        if (viewData.hotspots.isEmpty()) {
            ClinicalCard {
                Text(
                    text = "No localized hotspots detected above this session's own average for this view.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = ClinicalTextSecondary
                )
            }
        } else {
            // Kept as a fallback list alongside tap-to-inspect on the grid above, so hotspots
            // are still reachable without tapping (e.g. accessibility, or scanning all at once).
            viewData.hotspots.take(8).forEach { hotspot ->
                HotspotRow(
                    hotspot = hotspot,
                    onClick = {
                        selectedCell = viewData.cells.firstOrNull { it.row == hotspot.row && it.col == hotspot.col }
                    }
                )
                Spacer(Modifier.height(8.dp))
            }
        }
        Spacer(Modifier.height(16.dp))

        SectionHeader(title = "Cross-View Support")
        Spacer(Modifier.height(10.dp))
        ClinicalCard {
            val c = skinMap.crossViewComparison
            Text(
                text = c.result.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                style = MaterialTheme.typography.titleMedium,
                color = ClinicalTextPrimary
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Evidence score: ${c.evidenceScore.toInt()}/100 — how consistently the same pattern types appeared across front, left cheek, and right cheek captures.",
                style = MaterialTheme.typography.bodySmall,
                color = ClinicalTextSecondary
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun LegendRow(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(14.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(color)
        )
        Spacer(Modifier.width(10.dp))
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
    }
}

@Composable
private fun HotspotRow(hotspot: PatternHotspot, onClick: () -> Unit = {}) {
    ClinicalCard(modifier = Modifier.clickable { onClick() }) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(
                    text = hotspot.type.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.titleMedium,
                    color = ClinicalTextPrimary
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "Grid position: row ${hotspot.row + 1}, column ${hotspot.col + 1}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
            Text(
                text = "+${hotspot.strength.toInt()}",
                style = MaterialTheme.typography.titleMedium,
                color = SignalModerate
            )
        }
    }
}

/**
 * UI-3 — inline detail card for a tapped grid cell. All values shown come straight from the
 * `PatternMapCell` already computed for this cell (and its `PatternHotspot`s, if any) — nothing
 * here is measured or invented specifically for this card.
 */
@Composable
private fun CellDetailCard(cell: PatternMapCell, hotspots: List<PatternHotspot>, onDismiss: () -> Unit) {
    ClinicalCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Region: row ${cell.row + 1}, column ${cell.col + 1}",
                style = MaterialTheme.typography.titleMedium,
                color = ClinicalTextPrimary
            )
            Icon(
                Icons.Filled.Close,
                contentDescription = "Dismiss",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onDismiss() }
            )
        }
        Spacer(Modifier.height(10.dp))
        if (cell.skinPercent < 10.0) {
            Text(
                text = "Not enough sampled skin in this region for this session (${cell.skinPercent.toInt()}% skin coverage).",
                style = MaterialTheme.typography.bodyMedium,
                color = ClinicalTextSecondary
            )
        } else {
            CellMetricRow("Skin coverage", "${cell.skinPercent.toInt()}%")
            CellMetricRow("Redness (sampled)", String.format(java.util.Locale.US, "%.1f", cell.redness))
            CellMetricRow("Brightness (mean luma)", String.format(java.util.Locale.US, "%.1f", cell.meanLuma))
            CellMetricRow("Texture variation", String.format(java.util.Locale.US, "%.1f", cell.texture))
            CellMetricRow("Dark pixels", "${cell.darkPercent.toInt()}%")
            if (hotspots.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Flagged in this session",
                    style = MaterialTheme.typography.labelMedium,
                    color = ClinicalTextTertiary
                )
                Spacer(Modifier.height(6.dp))
                hotspots.forEach { hotspot ->
                    Text(
                        text = "• ${hotspot.type.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }} (+${hotspot.strength.toInt()} vs. this view's average)",
                        style = MaterialTheme.typography.bodySmall,
                        color = SignalModerate
                    )
                }
            } else {
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "Not flagged as a hotspot in this session — within this view's own average range.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
        }
    }
}

@Composable
private fun CellMetricRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = ClinicalTextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodyMedium, color = ClinicalTextPrimary)
    }
}

/** Pure data-driven 6x6 grid: cell background encodes which signal (if any) is dominant for
 * that cell relative to this view's own average, plus a marker on any cell that is a detected
 * hotspot. No anatomical face outline is drawn — this is explicitly a grid, not a face overlay,
 * since no overlay-generation exists in the analysis engine to reuse. */
private const val SKIN_MAP_GRID_SIZE = 6

@Composable
private fun SkinMapGrid(
    cells: List<PatternMapCell>,
    hotspots: List<PatternHotspot>,
    selectedCell: PatternMapCell? = null,
    onCellTap: (PatternMapCell) -> Unit = {}
) {
    val grid = SKIN_MAP_GRID_SIZE
    val hotspotAt = hotspots.associateBy { it.row to it.col }
    val usable = cells.filter { it.skinPercent >= 10.0 }
    val meanRed = usable.map { it.redness }.average().let { if (it.isNaN()) 0.0 else it }
    val meanLuma = usable.map { it.meanLuma }.average().let { if (it.isNaN()) 128.0 else it }
    val meanTex = usable.map { it.texture }.average().let { if (it.isNaN()) 0.0 else it }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .pointerInput(cells) {
                detectTapGestures { tapOffset ->
                    val cellW = size.width.toFloat() / grid
                    val cellH = size.height.toFloat() / grid
                    if (cellW <= 0f || cellH <= 0f) return@detectTapGestures
                    val col = (tapOffset.x / cellW).toInt().coerceIn(0, grid - 1)
                    val row = (tapOffset.y / cellH).toInt().coerceIn(0, grid - 1)
                    cells.firstOrNull { it.row == row && it.col == col }?.let(onCellTap)
                }
            }
    ) {
        val cellSize = Size(size.width / grid, size.height / grid)
        cells.forEach { cell ->
            val base = when {
                cell.skinPercent < 10.0 -> ClinicalOutlineSubtle
                cell.redness > meanRed + 8 -> SignalAttention.copy(alpha = 0.55f)
                cell.meanLuma < meanLuma - 18 -> ClinicalTextTertiary.copy(alpha = 0.55f)
                cell.texture > meanTex + 12 -> SignalModerate.copy(alpha = 0.45f)
                else -> ClinicalSurfaceElevated2
            }
            val topLeft = Offset(cell.col * cellSize.width, cell.row * cellSize.height)
            drawRect(color = base, topLeft = topLeft, size = cellSize)
            val isSelected = selectedCell != null && selectedCell.row == cell.row && selectedCell.col == cell.col
            drawRect(
                color = if (isSelected) AccentPrimary else ClinicalOutlineSubtle,
                topLeft = topLeft,
                size = cellSize,
                style = Stroke(width = if (isSelected) 3f else 1.5f)
            )
            if (hotspotAt.containsKey(cell.row to cell.col)) {
                drawCircle(
                    color = AccentPrimary,
                    radius = cellSize.width * 0.12f,
                    center = Offset(topLeft.x + cellSize.width / 2f, topLeft.y + cellSize.height / 2f)
                )
            }
        }
    }
}
