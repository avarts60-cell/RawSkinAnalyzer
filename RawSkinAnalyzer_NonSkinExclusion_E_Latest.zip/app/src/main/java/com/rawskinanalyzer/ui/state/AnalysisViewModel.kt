package com.rawskinanalyzer.ui.state

import androidx.lifecycle.ViewModel
import com.rawskinanalyzer.FinalAnalysisBundle
import com.rawskinanalyzer.FinalSkinAnalysisProfile
import com.rawskinanalyzer.SkinMapBundle
import com.rawskinanalyzer.SkinSessionRepository
import com.rawskinanalyzer.StoredSkinSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** The three required capture steps, mirrored from MainActivity.SessionStep for UI purposes. */
enum class UiSessionStep(val label: String) {
    FRONT("Front Face"),
    LEFT_CHEEK("Left Cheek"),
    RIGHT_CHEEK("Right Cheek")
}

/**
 * UI-1A: single source of truth for the Compose layer, populated exclusively from real
 * backend state as MainActivity's existing pipeline runs. Nothing here is fabricated —
 * screens render whatever this holds, including "nothing yet" via null/empty defaults.
 */
data class RawSkinUiState(
    val sessionId: String = "",
    val currentStep: UiSessionStep = UiSessionStep.FRONT,
    val completedSteps: Set<UiSessionStep> = emptySet(),
    val cameraStatus: String = "",
    val captureQuality: String? = null,
    val analysisRunning: Boolean = false,
    val analysisReady: Boolean = false,
    val lastError: String? = null,
    val finalProfile: FinalSkinAnalysisProfile? = null,
    val logLines: List<String> = emptyList(),
    // UI-1B: real structured objects from the already-computed routine/progress/trend chain
    // (see UiAnalysisAssembler) and the localized pattern-mapping chain (SkinMapAssembler).
    // Null until the current session's final analysis has completed, same convention as
    // finalProfile above — screens show an empty state, never a fabricated one, until then.
    val analysisBundle: FinalAnalysisBundle? = null,
    val skinMap: SkinMapBundle? = null,
    // Real persisted/in-memory session history (SkinSessionRepository.history()), refreshed
    // every time a session's final analysis completes.
    val sessionHistory: List<StoredSkinSession> = emptyList()
)

class AnalysisViewModel : ViewModel() {
    private val _state = MutableStateFlow(RawSkinUiState())
    val state: StateFlow<RawSkinUiState> = _state

    fun setSessionId(id: String) = _state.update { it.copy(sessionId = id) }

    fun setCurrentStep(step: UiSessionStep) = _state.update { it.copy(currentStep = step) }

    fun setCompletedSteps(steps: Set<UiSessionStep>) = _state.update { it.copy(completedSteps = steps) }

    fun setCameraStatus(text: String) = _state.update { it.copy(cameraStatus = text) }

    fun setCaptureQuality(text: String?) = _state.update { it.copy(captureQuality = text) }

    fun setAnalysisRunning(running: Boolean) = _state.update { it.copy(analysisRunning = running) }

    fun setAnalysisReady(ready: Boolean) = _state.update { it.copy(analysisReady = ready) }

    fun setError(message: String?) = _state.update { it.copy(lastError = message) }

    fun setFinalProfile(profile: FinalSkinAnalysisProfile?) = _state.update { it.copy(finalProfile = profile) }

    fun setAnalysisBundle(bundle: FinalAnalysisBundle?) = _state.update { it.copy(analysisBundle = bundle) }

    fun setSkinMap(map: SkinMapBundle?) = _state.update { it.copy(skinMap = map) }

    fun setSessionHistory(history: List<StoredSkinSession>) = _state.update { it.copy(sessionHistory = history) }

    // UI-2: Settings' "clear stored history" action. Delegates entirely to the repository
    // (already-existing storage layer); the ViewModel only re-syncs UI state afterward, per
    // the required Compose -> ViewModel -> repository flow.
    fun clearHistory() {
        SkinSessionRepository.clearAll()
        _state.update { it.copy(sessionHistory = emptyList()) }
    }

    fun appendLog(message: String) = _state.update {
        it.copy(logLines = (it.logLines + message).takeLast(200))
    }

    fun resetForNewSession(sessionId: String) = _state.update {
        RawSkinUiState(sessionId = sessionId)
    }
}
