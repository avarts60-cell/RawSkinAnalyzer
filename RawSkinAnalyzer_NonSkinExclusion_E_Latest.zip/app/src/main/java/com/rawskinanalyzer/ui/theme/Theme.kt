package com.rawskinanalyzer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * UI-1A design system: premium dark clinical-luxury.
 * One restrained accent color, deep neutral background, elevated surfaces.
 * No neon, no beauty-filter gradients, no fake-AI glow effects.
 */

// Background / surface neutrals
val ClinicalBackground = Color(0xFF0B0D10)
val ClinicalSurface = Color(0xFF15181C)
val ClinicalSurfaceElevated = Color(0xFF1C2025)
val ClinicalSurfaceElevated2 = Color(0xFF23282E)
val ClinicalOutline = Color(0xFF2C3238)
val ClinicalOutlineSubtle = Color(0xFF1F2429)

// Text
val ClinicalTextPrimary = Color(0xFFF2F3F5)
val ClinicalTextSecondary = Color(0xFFA6AEB8)
val ClinicalTextTertiary = Color(0xFF6B7480)

// Restrained single accent: a desaturated warm gold, evokes "premium clinical" without neon.
val AccentPrimary = Color(0xFFC9A063)
val AccentPrimaryMuted = Color(0xFF8A7247)
val AccentOnPrimary = Color(0xFF16130B)

// Signal colors used sparingly for status/confidence only, kept low-saturation.
val SignalGood = Color(0xFF6FA786)
val SignalModerate = Color(0xFFC9A063)
val SignalAttention = Color(0xFFC4715C)
val SignalNeutral = Color(0xFF7A828C)

private val ClinicalColorScheme = darkColorScheme(
    primary = AccentPrimary,
    onPrimary = AccentOnPrimary,
    secondary = AccentPrimaryMuted,
    onSecondary = ClinicalTextPrimary,
    background = ClinicalBackground,
    onBackground = ClinicalTextPrimary,
    surface = ClinicalSurface,
    onSurface = ClinicalTextPrimary,
    surfaceVariant = ClinicalSurfaceElevated,
    onSurfaceVariant = ClinicalTextSecondary,
    outline = ClinicalOutline,
    outlineVariant = ClinicalOutlineSubtle,
    error = SignalAttention,
    onError = ClinicalTextPrimary
)

val ClinicalTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Light, fontSize = 56.sp, letterSpacing = (-0.5).sp),
    displayMedium = TextStyle(fontWeight = FontWeight.Light, fontSize = 44.sp, letterSpacing = (-0.25).sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 28.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 18.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 13.sp, letterSpacing = 0.6.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 0.4.sp)
)

@Composable
fun RawSkinAnalyzerTheme(content: @Composable () -> Unit) {
    // Deliberately always dark: this is the app's identity, not a system-following theme.
    MaterialTheme(
        colorScheme = ClinicalColorScheme,
        typography = ClinicalTypography,
        content = content
    )
}
