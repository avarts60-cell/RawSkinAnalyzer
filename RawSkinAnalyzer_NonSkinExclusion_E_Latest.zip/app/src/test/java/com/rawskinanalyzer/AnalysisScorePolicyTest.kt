package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Test

class AnalysisScorePolicyTest {
    @Test fun lowBoundary() {
        assertEquals("LOW_VISIBLE_SIGNAL", AnalysisScorePolicy.level(29.999))
    }
    @Test fun moderateBoundary() {
        assertEquals("MODERATE_VISIBLE_SIGNAL", AnalysisScorePolicy.level(30.0))
    }
    @Test fun highBoundary() {
        assertEquals("HIGH_VISIBLE_SIGNAL", AnalysisScorePolicy.level(60.0))
    }
    @Test fun invalidConfidenceWhenFailuresExist() {
        assertEquals(
            "INVALID",
            AnalysisScorePolicy.evidenceConfidence("HIGH_CROSS_VIEW_CONSISTENCY", true, 1)
        )
    }
}
