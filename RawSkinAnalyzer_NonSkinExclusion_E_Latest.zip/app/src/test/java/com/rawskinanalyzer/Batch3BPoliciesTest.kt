package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Batch3BPoliciesTest {

    private fun option(
        name: String,
        role: IngredientSelectionRole,
        phase: String = "AM_OR_PM",
        concern: SkinConcernCategory = SkinConcernCategory.TONE_PIGMENTATION,
        caution: String? = null
    ) = SpecificIngredientOption(
        concern = concern,
        ingredientName = name,
        role = role,
        routinePhase = phase,
        sourceCategory = "TEST_CATEGORY",
        caution = caution,
        objectiveType = SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE,
        objectiveStrengthReason = "test"
    )

    // ---- CandidateCompatibilityPolicy ----

    @Test fun conflictingActivesInSamePhaseAreSeparated() {
        val selected = listOf(
            option("Salicylic acid", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.BLEMISH_LIKE_APPEARANCE, caution = "x"),
            option("Azelaic acid", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.DARK_MARKS, caution = "x")
        )
        val result = CandidateCompatibilityPolicy.plan(selected)
        assertTrue(result.all { it.action == RoutineCompatibilityAction.SEPARATE_SESSION })
        assertTrue(result.all { it.reason == "CONFLICT_WITH_CANDIDATE" })
    }

    @Test fun unrelatedCompatibleIngredientsAreIncluded() {
        val selected = listOf(
            option("Niacinamide", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.REDNESS_APPEARANCE),
            option("Ceramides", IngredientSelectionRole.SUPPORTIVE, concern = SkinConcernCategory.REDNESS_APPEARANCE)
        )
        val result = CandidateCompatibilityPolicy.plan(selected)
        assertTrue(result.all { it.action == RoutineCompatibilityAction.INCLUDE })
        assertTrue(result.all { it.reason == "ALLOWED_COMPATIBLE_COMBINATION" })
    }

    @Test fun sameIngredientAcrossTwoConcernsIsDuplicateRole() {
        val selected = listOf(
            option("Niacinamide", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.TONE_PIGMENTATION),
            option("Niacinamide", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.REDNESS_APPEARANCE)
        )
        val result = CandidateCompatibilityPolicy.plan(selected)
        assertTrue(result.any { it.reason == "DUPLICATE_ROLE" })
    }

    // ---- ToleranceTransitionPolicy ----

    @Test fun unknownBecomesIntroducingOnFirstInclusion() {
        val start = IngredientToleranceRecord("Niacinamide", ToleranceState.UNKNOWN, 0, "none")
        val after = ToleranceTransitionPolicy.transition(start, ToleranceFeedback.FIRST_TIME_INCLUDED)
        assertEquals(ToleranceState.INTRODUCING, after.state)
    }

    @Test fun introducingRequiresThreeStableSessionsToReachTolerated() {
        var record = IngredientToleranceRecord("Niacinamide", ToleranceState.INTRODUCING, 0, "start")
        record = ToleranceTransitionPolicy.transition(record, ToleranceFeedback.STABLE_CONTINUED_USE)
        assertEquals(ToleranceState.INTRODUCING, record.state)
        record = ToleranceTransitionPolicy.transition(record, ToleranceFeedback.STABLE_CONTINUED_USE)
        assertEquals(ToleranceState.INTRODUCING, record.state)
        record = ToleranceTransitionPolicy.transition(record, ToleranceFeedback.STABLE_CONTINUED_USE)
        assertEquals(ToleranceState.TOLERATED, record.state)
    }

    @Test fun mildReactionDuringIntroductionMovesToCaution() {
        val start = IngredientToleranceRecord("Salicylic acid", ToleranceState.INTRODUCING, 1, "start")
        val after = ToleranceTransitionPolicy.transition(start, ToleranceFeedback.MILD_REACTION_REPORTED)
        assertEquals(ToleranceState.CAUTION, after.state)
    }

    @Test fun strongReactionAlwaysPauses() {
        val fromTolerated = ToleranceTransitionPolicy.transition(
            IngredientToleranceRecord("X", ToleranceState.TOLERATED, 5, "s"),
            ToleranceFeedback.STRONG_REACTION_REPORTED
        )
        assertEquals(ToleranceState.PAUSED, fromTolerated.state)
    }

    @Test fun pausedNeverAutoResumesWithoutExplicitRequest() {
        val paused = IngredientToleranceRecord("X", ToleranceState.PAUSED, 2, "s")
        val stillPaused = ToleranceTransitionPolicy.transition(paused, ToleranceFeedback.STABLE_CONTINUED_USE)
        assertEquals(ToleranceState.PAUSED, stillPaused.state)
        val resumed = ToleranceTransitionPolicy.transition(paused, ToleranceFeedback.RESUME_REQUESTED)
        assertEquals(ToleranceState.INTRODUCING, resumed.state)
    }

    @Test fun toleratedWithMildReactionMovesToCaution() {
        val tolerated = IngredientToleranceRecord("X", ToleranceState.TOLERATED, 10, "s")
        val after = ToleranceTransitionPolicy.transition(tolerated, ToleranceFeedback.MILD_REACTION_REPORTED)
        assertEquals(ToleranceState.CAUTION, after.state)
    }

    // ---- ToleranceAwareCandidateFilter ----

    @Test fun pausedIngredientIsExcluded() {
        val candidates = listOf(option("Salicylic acid", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.BLEMISH_LIKE_APPEARANCE))
        val tolerance = mapOf("Salicylic acid" to IngredientToleranceRecord("Salicylic acid", ToleranceState.PAUSED, 1, "s"))
        val result = ToleranceAwareCandidateFilter.apply(candidates, tolerance)
        assertEquals(ToleranceFilterOutcome.EXCLUDED, result.single().outcome)
        assertEquals("PAUSED_DUE_TO_CAUTION", result.single().reason)
    }

    @Test fun cautionExcludesNonPrimaryButLimitsPrimary() {
        val candidates = listOf(
            option("Niacinamide", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.TONE_PIGMENTATION),
            option("Vitamin C", IngredientSelectionRole.SUPPORTIVE, concern = SkinConcernCategory.TONE_PIGMENTATION)
        )
        val tolerance = mapOf(
            "Niacinamide" to IngredientToleranceRecord("Niacinamide", ToleranceState.CAUTION, 1, "s"),
            "Vitamin C" to IngredientToleranceRecord("Vitamin C", ToleranceState.CAUTION, 1, "s")
        )
        val result = ToleranceAwareCandidateFilter.apply(candidates, tolerance)
        assertEquals(ToleranceFilterOutcome.LIMITED, result[0].outcome)
        assertEquals(ToleranceFilterOutcome.EXCLUDED, result[1].outcome)
    }

    @Test fun onlyOneUnknownIngredientIntroducedSimultaneously() {
        val candidates = listOf(
            option("Niacinamide", IngredientSelectionRole.PRIMARY, concern = SkinConcernCategory.TONE_PIGMENTATION),
            option("Vitamin C", IngredientSelectionRole.SUPPORTIVE, concern = SkinConcernCategory.TONE_PIGMENTATION)
        )
        val tolerance = mapOf(
            "Niacinamide" to IngredientToleranceRecord("Niacinamide", ToleranceState.UNKNOWN, 0, "s"),
            "Vitamin C" to IngredientToleranceRecord("Vitamin C", ToleranceState.UNKNOWN, 0, "s")
        )
        val result = ToleranceAwareCandidateFilter.apply(candidates, tolerance)
        assertEquals(ToleranceFilterOutcome.INCLUDED, result[0].outcome)
        assertEquals(ToleranceFilterOutcome.LIMITED, result[1].outcome)
    }

    @Test fun toleratedIsIncluded() {
        val candidates = listOf(option("Niacinamide", IngredientSelectionRole.PRIMARY))
        val tolerance = mapOf("Niacinamide" to IngredientToleranceRecord("Niacinamide", ToleranceState.TOLERATED, 10, "s"))
        val result = ToleranceAwareCandidateFilter.apply(candidates, tolerance)
        assertEquals(ToleranceFilterOutcome.INCLUDED, result.single().outcome)
    }

    // ---- RoutineIntensityPolicy ----

    @Test fun cautionToleranceForcesMinimalRegardlessOfObjective() {
        val decision = RoutineIntensityPolicy.calibrate(
            "X", SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, "HIGH",
            RoutineCompatibilityAction.INCLUDE, ToleranceState.CAUTION
        )
        assertEquals(RoutineIntensityLevel.MINIMAL, decision.level)
    }

    @Test fun escalationRequiresFullStackAgreement() {
        val decision = RoutineIntensityPolicy.calibrate(
            "X", SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, "HIGH",
            RoutineCompatibilityAction.INCLUDE, ToleranceState.TOLERATED
        )
        assertEquals(RoutineIntensityLevel.CAUTIOUS_ESCALATION, decision.level)
    }

    @Test fun highConfidenceAloneDoesNotEscalateWithoutToleratedState() {
        val decision = RoutineIntensityPolicy.calibrate(
            "X", SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, "HIGH",
            RoutineCompatibilityAction.INCLUDE, ToleranceState.INTRODUCING
        )
        assertEquals(RoutineIntensityLevel.CONSERVATIVE, decision.level)
    }

    @Test fun blockedCompatibilityForcesMinimal() {
        val decision = RoutineIntensityPolicy.calibrate(
            "X", SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, "HIGH",
            RoutineCompatibilityAction.SEPARATE_SESSION, ToleranceState.TOLERATED
        )
        assertEquals(RoutineIntensityLevel.MINIMAL, decision.level)
        assertEquals("BLOCKED_BY_COMPATIBILITY", decision.reason)
    }

    // ---- CaptureQualityReliabilityGate ----

    @Test fun reliableCaptureDoesNotAlterAdaptation() {
        val base = TrendAwareAdaptationResult(
            RoutineAdaptationResult(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, listOf("x"), listOf("y"), "HIGH"),
            true, listOf("z")
        )
        val result = CaptureQualityReliabilityGate.apply(base, CaptureQualityReliability.RELIABLE)
        assertEquals(base, result)
    }

    @Test fun lowReliabilityCapsConsiderAdjustmentDownToReviewAndMonitor() {
        val base = TrendAwareAdaptationResult(
            RoutineAdaptationResult(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, listOf("x"), listOf("y"), "HIGH"),
            true, listOf("z")
        )
        val result = CaptureQualityReliabilityGate.apply(base, CaptureQualityReliability.LOW)
        assertEquals(RoutineAdaptationAction.REVIEW_AND_MONITOR, result.decision.action)
        assertEquals("LOW", result.decision.adaptationConfidence)
        assertTrue(result.decision.reasons.contains("CAPTURE_QUALITY_LOW_RELIABILITY_TREND_CAPPED"))
    }

    @Test fun reducedReliabilityCapsHighConfidenceToModerate() {
        val base = TrendAwareAdaptationResult(
            RoutineAdaptationResult(RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE, emptyList(), emptyList(), "HIGH"),
            true, emptyList()
        )
        val result = CaptureQualityReliabilityGate.apply(base, CaptureQualityReliability.REDUCED)
        assertEquals("MODERATE", result.decision.adaptationConfidence)
        // Reduced reliability never touches action, only confidence.
        assertEquals(RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE, result.decision.action)
    }

    @Test fun classifyMapsConsistencyStringsCorrectly() {
        assertEquals(CaptureQualityReliability.RELIABLE, CaptureQualityReliabilityGate.classify("HIGH_CAPTURE_CONDITION_CONSISTENCY"))
        assertEquals(CaptureQualityReliability.REDUCED, CaptureQualityReliabilityGate.classify("MODERATE_CAPTURE_CONDITION_VARIATION"))
        assertEquals(CaptureQualityReliability.LOW, CaptureQualityReliabilityGate.classify("MAJOR_CAPTURE_CONDITION_INCONSISTENCY"))
        assertEquals(CaptureQualityReliability.RELIABLE, CaptureQualityReliabilityGate.classify(null))
    }

    // ---- RoutineAdjustmentCandidateActivator tolerance extension ----

    @Test fun pausedToleranceRejectsAdjustmentCandidateEvenWithoutCaution() {
        val adjustment = TrendAwareRoutineAdjustment(
            status = "CANDIDATES_GENERATED",
            candidates = listOf(
                RoutineAdjustmentCandidate(
                    concern = "TONE_PIGMENTATION",
                    targetIngredient = "Niacinamide",
                    proposedFrequency = "REVIEW_EXISTING_FREQUENCY_BEFORE_ESCALATION",
                    reason = "test"
                )
            ),
            retainedRoutine = emptyList(),
            reviewFlags = emptyList()
        )
        val plan = IngredientUsePlan(
            concern = SkinConcernCategory.TONE_PIGMENTATION,
            ingredientName = "Niacinamide",
            concentrationGuidance = "x",
            frequencyGuidance = "y",
            routinePhase = "AM_OR_PM",
            introductionRule = "z",
            caution = null
        )
        val routine = FinalRoutineResult("p", "s", emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
        val tolerance = mapOf("Niacinamide" to IngredientToleranceRecord("Niacinamide", ToleranceState.PAUSED, 2, "s"))

        val result = RoutineAdjustmentCandidateActivator.activate(adjustment, listOf(plan), routine, tolerance)
        assertEquals(1, result.rejectedCandidates.size)
        assertEquals("PAUSED_DUE_TO_CAUTION", result.rejectedCandidates.single().reason)
    }

    @Test fun toleratedToleranceStillAllowsExistingApprovalPath() {
        val adjustment = TrendAwareRoutineAdjustment(
            status = "CANDIDATES_GENERATED",
            candidates = listOf(
                RoutineAdjustmentCandidate(
                    concern = "TONE_PIGMENTATION",
                    targetIngredient = "Niacinamide",
                    proposedFrequency = "REVIEW_EXISTING_FREQUENCY_BEFORE_ESCALATION",
                    reason = "test"
                )
            ),
            retainedRoutine = emptyList(),
            reviewFlags = emptyList()
        )
        val plan = IngredientUsePlan(
            concern = SkinConcernCategory.TONE_PIGMENTATION,
            ingredientName = "Niacinamide",
            concentrationGuidance = "x",
            frequencyGuidance = "y",
            routinePhase = "AM_OR_PM",
            introductionRule = "z",
            caution = null
        )
        val routine = FinalRoutineResult("p", "s", emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList())
        val tolerance = mapOf("Niacinamide" to IngredientToleranceRecord("Niacinamide", ToleranceState.TOLERATED, 5, "s"))

        val result = RoutineAdjustmentCandidateActivator.activate(adjustment, listOf(plan), routine, tolerance)
        assertEquals(1, result.approvedCandidates.size)
    }

    @Test fun noToleranceMapPreservesPreviousBehavior() {
        val adjustment = TrendAwareRoutineAdjustment(
            status = "CANDIDATES_GENERATED",
            candidates = listOf(
                RoutineAdjustmentCandidate(
                    concern = "TONE_PIGMENTATION",
                    targetIngredient = "Niacinamide",
                    proposedFrequency = "REVIEW_EXISTING_FREQUENCY_BEFORE_ESCALATION",
                    reason = "test"
                )
            ),
            retainedRoutine = emptyList(),
            reviewFlags = emptyList()
        )
        val plan = IngredientUsePlan(
            concern = SkinConcernCategory.TONE_PIGMENTATION,
            ingredientName = "Niacinamide",
            concentrationGuidance = "x",
            frequencyGuidance = "y",
            routinePhase = "AM_OR_PM",
            introductionRule = "z",
            caution = null
        )
        val routine = FinalRoutineResult("p", "s", emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList(), emptyList())

        // No toleranceByIngredient supplied at all — must behave exactly as before this session.
        val result = RoutineAdjustmentCandidateActivator.activate(adjustment, listOf(plan), routine)
        assertEquals(1, result.approvedCandidates.size)
    }
}
