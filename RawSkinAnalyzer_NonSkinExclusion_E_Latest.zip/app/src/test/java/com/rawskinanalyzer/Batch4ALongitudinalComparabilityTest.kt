package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun snapshot(v: Double = 20.0, confidence: String = "HIGH") = SkinProgressSnapshot(
    pigmentationScore = v, darkMarkScore = v, blemishLikeScore = v, rednessScore = v,
    poreLikeScore = v, shineScore = v, textureScore = v, drynessScore = v, confidence = confidence
)

private fun session(
    id: String,
    version: String = "v1",
    ts: Long = 0L,
    snap: SkinProgressSnapshot = snapshot(),
    ctx: SessionCaptureContext? = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3)
) = StoredSkinSession(id, ts, version, snap, ctx)

class SessionComparabilityEvaluatorTest {
    @Test fun versionMismatchIsNotComparable() {
        val prev = session("a", version = "v_old")
        val result = SessionComparabilityEvaluator.evaluate(
            prev, SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3), "v_new"
        )
        assertEquals(SessionComparabilityStatus.NOT_COMPARABLE, result.status)
        assertTrue(result.reasons.contains("ANALYSIS_PIPELINE_VERSION_MISMATCH"))
    }

    @Test fun bothFullyReliableIsHighlyComparable() {
        val prev = session("a")
        val current = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3)
        val result = SessionComparabilityEvaluator.evaluate(prev, current, "v1")
        assertEquals(SessionComparabilityStatus.HIGHLY_COMPARABLE, result.status)
    }

    @Test fun unknownPreviousContextIsLimited() {
        val prev = session("a", ctx = null)
        val current = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3)
        val result = SessionComparabilityEvaluator.evaluate(prev, current, "v1")
        assertEquals(SessionComparabilityStatus.LIMITED_COMPARABILITY, result.status)
    }

    @Test fun lowReliabilityEitherSideIsLimited() {
        val prev = session("a", ctx = SessionCaptureContext.from("MAJOR_CAPTURE_CONDITION_INCONSISTENCY", 3))
        val current = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3)
        val result = SessionComparabilityEvaluator.evaluate(prev, current, "v1")
        assertEquals(SessionComparabilityStatus.LIMITED_COMPARABILITY, result.status)
    }

    @Test fun insufficientUsableViewsIsNotComparable() {
        val prev = session("a", ctx = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 1))
        val current = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3)
        val result = SessionComparabilityEvaluator.evaluate(prev, current, "v1")
        assertEquals(SessionComparabilityStatus.NOT_COMPARABLE, result.status)
    }

    @Test fun twoOfThreeViewsIsComparableNotHighlyComparable() {
        val prev = session("a", ctx = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 2))
        val current = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3)
        val result = SessionComparabilityEvaluator.evaluate(prev, current, "v1")
        assertEquals(SessionComparabilityStatus.COMPARABLE, result.status)
    }
}

class ComparisonConfidencePolicyTest {
    @Test fun notComparableIsInsufficient() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.NOT_COMPARABLE, listOf("X"))
        val result = ComparisonConfidencePolicy.evaluate(comparability, "HIGH", "HIGH")
        assertEquals(ComparisonConfidenceLevel.INSUFFICIENT, result.level)
    }

    @Test fun highlyComparableHighBothIsHigh() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val result = ComparisonConfidencePolicy.evaluate(comparability, "HIGH", "HIGH")
        assertEquals(ComparisonConfidenceLevel.HIGH, result.level)
    }

    @Test fun limitedComparabilityCapsAtLowEvenIfBothSessionsHigh() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.LIMITED_COMPARABILITY, emptyList())
        val result = ComparisonConfidencePolicy.evaluate(comparability, "HIGH", "HIGH")
        assertEquals(ComparisonConfidenceLevel.LOW, result.level)
    }

    @Test fun weakerSessionConfidenceCannotBeRescuedByComparability() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val result = ComparisonConfidencePolicy.evaluate(comparability, "LOW", "HIGH")
        assertEquals(ComparisonConfidenceLevel.LOW, result.level)
    }
}

class LongitudinalChangeClassifierTest {
    private fun progress(direction: ProgressDirection) = SkinProgressResult(emptyList(), direction, "HIGH_COMPARISON_CONFIDENCE")
    private fun trend(direction: TrendDirection, used: Int = 3) = MultiSessionTrendResult(emptyList(), direction, "HIGH_TREND_CONFIDENCE", used)

    @Test fun notComparablePropagates() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.NOT_COMPARABLE, listOf("X"))
        val confidence = ComparisonConfidenceResult(ComparisonConfidenceLevel.INSUFFICIENT, emptyList())
        val result = LongitudinalChangeClassifier.classify(
            progress(ProgressDirection.WORSENED), trend(TrendDirection.INSUFFICIENT_TREND_DATA, 0), comparability, confidence
        )
        assertEquals(LongitudinalChangeClassification.NOT_COMPARABLE, result.classification)
    }

    @Test fun insufficientDataWhenNoPreviousSession() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val confidence = ComparisonConfidenceResult(ComparisonConfidenceLevel.HIGH, emptyList())
        val result = LongitudinalChangeClassifier.classify(
            progress(ProgressDirection.INSUFFICIENT_COMPARISON_DATA), trend(TrendDirection.INSUFFICIENT_TREND_DATA, 0), comparability, confidence
        )
        assertEquals(LongitudinalChangeClassification.INSUFFICIENT_DATA, result.classification)
    }

    @Test fun highConfidenceAgreementIsWorsening() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val confidence = ComparisonConfidenceResult(ComparisonConfidenceLevel.HIGH, emptyList())
        val result = LongitudinalChangeClassifier.classify(
            progress(ProgressDirection.WORSENED), trend(TrendDirection.SUSTAINED_WORSENING), comparability, confidence
        )
        assertEquals(LongitudinalChangeClassification.WORSENING, result.classification)
    }

    @Test fun lowConfidenceWithoutTrendConfirmationIsUncertain() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.LIMITED_COMPARABILITY, emptyList())
        val confidence = ComparisonConfidenceResult(ComparisonConfidenceLevel.LOW, emptyList())
        val result = LongitudinalChangeClassifier.classify(
            progress(ProgressDirection.WORSENED), trend(TrendDirection.INSUFFICIENT_TREND_DATA, 1), comparability, confidence
        )
        assertEquals(LongitudinalChangeClassification.UNCERTAIN, result.classification)
    }

    @Test fun lowConfidenceConfirmedByRepeatedTrendIsAllowed() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.LIMITED_COMPARABILITY, emptyList())
        val confidence = ComparisonConfidenceResult(ComparisonConfidenceLevel.LOW, emptyList())
        val result = LongitudinalChangeClassifier.classify(
            progress(ProgressDirection.WORSENED), trend(TrendDirection.SUSTAINED_WORSENING, 5), comparability, confidence
        )
        assertEquals(LongitudinalChangeClassification.WORSENING, result.classification)
    }

    @Test fun singleSessionAnomalyContradictingStableTrendIsUncertain() {
        val comparability = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val confidence = ComparisonConfidenceResult(ComparisonConfidenceLevel.MODERATE, emptyList())
        val result = LongitudinalChangeClassifier.classify(
            progress(ProgressDirection.WORSENED), trend(TrendDirection.STABLE_TREND, 5), comparability, confidence
        )
        assertEquals(LongitudinalChangeClassification.UNCERTAIN, result.classification)
    }
}

class SessionBaselineSelectorTest {
    @Test fun emptyHistoryHasNoBaseline() {
        val result = SessionBaselineSelector.select(emptyList())
        assertNull(result.baseline)
        assertEquals(SessionComparabilityStatus.NOT_COMPARABLE, result.quality)
    }

    @Test fun prefersEarliestFullyReliableSession() {
        val poor = session("early_poor", ts = 1L, ctx = SessionCaptureContext.from("MAJOR_CAPTURE_CONDITION_INCONSISTENCY", 3))
        val good = session("later_good", ts = 2L, ctx = SessionCaptureContext.from("HIGH_CAPTURE_CONDITION_CONSISTENCY", 3))
        val result = SessionBaselineSelector.select(listOf(poor, good))
        assertEquals("later_good", result.baseline?.sessionId)
        assertEquals(SessionComparabilityStatus.HIGHLY_COMPARABLE, result.quality)
    }

    @Test fun fallsBackToEarliestWhenNothingFullyReliable() {
        val a = session("a", ts = 1L, ctx = SessionCaptureContext.from("MODERATE_CAPTURE_CONDITION_VARIATION", 3))
        val b = session("b", ts = 2L, ctx = SessionCaptureContext.from("MODERATE_CAPTURE_CONDITION_VARIATION", 3))
        val result = SessionBaselineSelector.select(listOf(b, a))
        assertEquals("a", result.baseline?.sessionId)
        assertEquals(SessionComparabilityStatus.COMPARABLE, result.quality)
    }

    @Test fun onlyLowReliabilitySessionsStillYieldsEarliestWithReducedConfidence() {
        val a = session("a", ts = 1L, ctx = SessionCaptureContext.from("MAJOR_CAPTURE_CONDITION_INCONSISTENCY", 3))
        val result = SessionBaselineSelector.select(listOf(a))
        assertEquals("a", result.baseline?.sessionId)
        assertEquals(SessionComparabilityStatus.LIMITED_COMPARABILITY, result.quality)
    }
}
