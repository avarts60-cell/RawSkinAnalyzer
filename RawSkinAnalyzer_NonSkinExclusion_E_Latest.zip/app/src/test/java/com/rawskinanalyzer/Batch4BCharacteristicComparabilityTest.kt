package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun finding(characteristic: String, confidence: String) = FinalSkinFinding(
    characteristic = characteristic,
    score = 40.0,
    level = "MODERATE_SIGNAL",
    priority = 0,
    evidence = "test",
    confidence = confidence
)

private val EIGHT_CHARACTERISTICS = listOf(
    "REDNESS", "PIGMENTATION_OR_TONE_VARIATION", "DARK_MARK_SIGNAL", "BLEMISH_LIKE_FEATURES",
    "TEXTURE_IRREGULARITY", "PORE_LIKE_FEATURES", "SURFACE_SHINE_SIGNAL", "DRYNESS_RELATED_SURFACE_SIGNAL"
)

class CharacteristicComparabilityEvaluatorTest {

    @Test fun noPreviousSessionIsInsufficientData() {
        val result = CharacteristicComparabilityEvaluator.evaluate("REDNESS", "HIGH", null)
        assertEquals(CharacteristicComparabilityStatus.INSUFFICIENT_DATA, result.status)
        assertTrue(result.reasons.contains("INSUFFICIENT_LONGITUDINAL_SUPPORT"))
    }

    @Test fun sessionNotComparablePropagatesToEveryCharacteristic() {
        val sessionResult = SessionComparabilityResult(
            SessionComparabilityStatus.NOT_COMPARABLE,
            listOf("ANALYSIS_PIPELINE_VERSION_MISMATCH")
        )
        val result = CharacteristicComparabilityEvaluator.evaluate("REDNESS", "HIGH", sessionResult)
        assertEquals(CharacteristicComparabilityStatus.NOT_COMPARABLE, result.status)
        assertTrue(result.reasons.contains("ANALYSIS_VERSION_DIFFERENCE"))
    }

    @Test fun highlyComparableSessionWithHighConfidenceIsDirectlyComparable() {
        val sessionResult = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val result = CharacteristicComparabilityEvaluator.evaluate("REDNESS", "HIGH", sessionResult)
        assertEquals(CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE, result.status)
        assertTrue(result.reasons.isEmpty())
    }

    @Test fun lowCharacteristicConfidenceLimitsOnlyThatCharacteristicEvenWhenSessionIsHighlyComparable() {
        val sessionResult = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val limited = CharacteristicComparabilityEvaluator.evaluate("BLEMISH_LIKE_FEATURES", "LOW", sessionResult)
        val normal = CharacteristicComparabilityEvaluator.evaluate("REDNESS", "HIGH", sessionResult)
        assertEquals(CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS, limited.status)
        assertTrue(limited.reasons.contains("LOW_CHARACTERISTIC_CONFIDENCE"))
        assertEquals(CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE, normal.status)
    }

    @Test fun limitedComparabilitySessionCapsEveryCharacteristicEvenWithHighConfidence() {
        val sessionResult = SessionComparabilityResult(
            SessionComparabilityStatus.LIMITED_COMPARABILITY,
            listOf("CAPTURE_QUALITY_LOW_RELIABILITY_SESSION_INVOLVED")
        )
        val result = CharacteristicComparabilityEvaluator.evaluate("REDNESS", "HIGH", sessionResult)
        assertEquals(CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS, result.status)
        assertTrue(result.reasons.contains("CAPTURE_CONDITION_MISMATCH"))
    }

    @Test fun evaluateAllCoversExactlyTheEightCharacteristicsFromTheirOwnFindings() {
        val findings = EIGHT_CHARACTERISTICS.mapIndexed { i, c ->
            finding(c, if (i == 2) "LOW" else "HIGH") // DARK_MARK_SIGNAL is LOW-confidence here
        }
        val sessionResult = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val results = CharacteristicComparabilityEvaluator.evaluateAll(findings, sessionResult)

        assertEquals(8, results.size)
        assertEquals(EIGHT_CHARACTERISTICS.toSet(), results.map { it.characteristic }.toSet())

        val darkMark = results.first { it.characteristic == "DARK_MARK_SIGNAL" }
        val redness = results.first { it.characteristic == "REDNESS" }
        // A session can be comparable for one characteristic and limited for another: same
        // session-level input, two different per-characteristic outputs.
        assertEquals(CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS, darkMark.status)
        assertEquals(CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE, redness.status)
    }
}

class CharacteristicGatedProgressTest {

    private fun progress(feature: String, direction: ProgressDirection = ProgressDirection.WORSENED) =
        SkinProgressResult(
            features = listOf(FeatureProgress(feature, 20.0, 40.0, 20.0, direction)),
            overallDirection = direction,
            comparisonConfidence = "HIGH_COMPARISON_CONFIDENCE"
        )

    @Test fun notComparableSuppressesDeltaAndDirectionButPreservesRawScores() {
        val comparability = mapOf(
            "REDNESS" to CharacteristicComparabilityResult(
                "REDNESS", CharacteristicComparabilityStatus.NOT_COMPARABLE, listOf("ANALYSIS_VERSION_DIFFERENCE")
            )
        )
        val gated = CharacteristicGatedProgress.gate(progress("REDNESS"), comparability)
        val row = gated.single()
        assertNull(row.delta)
        assertNull(row.direction)
        assertEquals(20.0, row.previousScore, 0.0001)
        assertEquals(40.0, row.currentScore, 0.0001)
    }

    @Test fun insufficientDataAlsoSuppressesNumericalChange() {
        val comparability = mapOf(
            "REDNESS" to CharacteristicComparabilityResult(
                "REDNESS", CharacteristicComparabilityStatus.INSUFFICIENT_DATA, listOf("INSUFFICIENT_LONGITUDINAL_SUPPORT")
            )
        )
        val gated = CharacteristicGatedProgress.gate(progress("REDNESS"), comparability)
        assertNull(gated.single().delta)
    }

    @Test fun directlyComparableShowsNormalDeltaAndDirection() {
        val comparability = mapOf(
            "REDNESS" to CharacteristicComparabilityResult(
                "REDNESS", CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE, emptyList()
            )
        )
        val gated = CharacteristicGatedProgress.gate(progress("REDNESS"), comparability)
        val row = gated.single()
        assertNotNull(row.delta)
        assertNotNull(row.direction)
        assertEquals(20.0, row.delta)
        assertEquals(ProgressDirection.WORSENED, row.direction)
    }

    @Test fun comparableWithLimitationsStillShowsDeltaButIsFlagged() {
        val comparability = mapOf(
            "REDNESS" to CharacteristicComparabilityResult(
                "REDNESS", CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS, listOf("LOW_CHARACTERISTIC_CONFIDENCE")
            )
        )
        val gated = CharacteristicGatedProgress.gate(progress("REDNESS"), comparability)
        val row = gated.single()
        assertNotNull(row.delta)
        assertEquals(CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS, row.comparability)
    }

    @Test fun missingComparabilityEntryDefaultsToInsufficientDataConservatively() {
        val gated = CharacteristicGatedProgress.gate(progress("REDNESS"), emptyMap())
        val row = gated.single()
        assertEquals(CharacteristicComparabilityStatus.INSUFFICIENT_DATA, row.comparability)
        assertNull(row.delta)
    }
}

class ComparabilityAdaptationGateTest {

    private fun adaptation(
        action: RoutineAdaptationAction = RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT,
        confidence: String = "HIGH"
    ) = TrendAwareAdaptationResult(
        decision = RoutineAdaptationResult(action, listOf("base_reason"), listOf("REDNESS"), confidence),
        trendInfluenceApplied = true,
        trendReasons = listOf("base_trend_reason")
    )

    @Test fun nullComparabilityDoesNotChangeAdaptation() {
        val result = ComparabilityAdaptationGate.apply(adaptation(), null)
        assertEquals(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, result.decision.action)
        assertEquals("HIGH", result.decision.adaptationConfidence)
    }

    @Test fun highlyComparableOrComparableDoesNotChangeAdaptation() {
        val highly = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
        val comparable = SessionComparabilityResult(SessionComparabilityStatus.COMPARABLE, emptyList())
        assertEquals(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, ComparabilityAdaptationGate.apply(adaptation(), highly).decision.action)
        assertEquals(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, ComparabilityAdaptationGate.apply(adaptation(), comparable).decision.action)
    }

    @Test fun notComparableCapsConsiderAdjustmentToReviewAndMonitorWithLowConfidence() {
        val notComparable = SessionComparabilityResult(SessionComparabilityStatus.NOT_COMPARABLE, listOf("x"))
        val result = ComparabilityAdaptationGate.apply(adaptation(), notComparable)
        assertEquals(RoutineAdaptationAction.REVIEW_AND_MONITOR, result.decision.action)
        assertEquals("LOW", result.decision.adaptationConfidence)
        assertTrue(result.decision.reasons.contains("SESSION_COMPARABILITY_NOT_COMPARABLE_TREND_CAPPED"))
        assertTrue(result.trendReasons.contains("SESSION_COMPARABILITY_NOT_COMPARABLE_TREND_CAPPED"))
    }

    @Test fun limitedComparabilityCapsConsiderAdjustmentToReviewAndMonitorWithModerateConfidence() {
        val limited = SessionComparabilityResult(SessionComparabilityStatus.LIMITED_COMPARABILITY, listOf("x"))
        val result = ComparabilityAdaptationGate.apply(adaptation(), limited)
        assertEquals(RoutineAdaptationAction.REVIEW_AND_MONITOR, result.decision.action)
        assertEquals("MODERATE", result.decision.adaptationConfidence)
        assertTrue(result.decision.reasons.contains("SESSION_COMPARABILITY_LIMITED_TREND_CONSERVATIVE"))
    }

    @Test fun weakerActionsAreNotEscalatedByEitherCap() {
        val maintainDecision = adaptation(action = RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE, confidence = "LOW")
        val notComparable = SessionComparabilityResult(SessionComparabilityStatus.NOT_COMPARABLE, listOf("x"))
        val result = ComparabilityAdaptationGate.apply(maintainDecision, notComparable)
        // Action never escalates; confidence is only ever capped down (already LOW here).
        assertEquals(RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE, result.decision.action)
        assertEquals("LOW", result.decision.adaptationConfidence)
    }

    @Test fun neverEscalatesConfidence() {
        val lowConfidenceReview = adaptation(action = RoutineAdaptationAction.REVIEW_AND_MONITOR, confidence = "LOW")
        val comparable = SessionComparabilityResult(SessionComparabilityStatus.COMPARABLE, emptyList())
        val result = ComparabilityAdaptationGate.apply(lowConfidenceReview, comparable)
        assertEquals("LOW", result.decision.adaptationConfidence)
    }
}
