package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun snap(redness: Double, confidence: String = "HIGH") = SkinProgressSnapshot(
    pigmentationScore = 20.0, darkMarkScore = 20.0, blemishLikeScore = 20.0, rednessScore = redness,
    poreLikeScore = 20.0, shineScore = 20.0, textureScore = 20.0, drynessScore = 20.0, confidence = confidence
)

private fun sess(
    id: String,
    ts: Long,
    redness: Double,
    reliability: String = "HIGH_CAPTURE_CONDITION_CONSISTENCY",
    version: String = "v1"
) = StoredSkinSession(id, ts, version, snap(redness), SessionCaptureContext.from(reliability, 3))

private val COMPARABLE = CharacteristicComparabilityResult(
    "REDNESS", CharacteristicComparabilityStatus.DIRECTLY_COMPARABLE, emptyList()
)
private val LIMITED = CharacteristicComparabilityResult(
    "REDNESS", CharacteristicComparabilityStatus.COMPARABLE_WITH_LIMITATIONS, listOf("LOW_CHARACTERISTIC_CONFIDENCE")
)
private val NOT_COMPARABLE = CharacteristicComparabilityResult(
    "REDNESS", CharacteristicComparabilityStatus.NOT_COMPARABLE, listOf("ANALYSIS_VERSION_DIFFERENCE")
)

class CharacteristicTrendIntelligenceAnalyzerTest {

    @Test
    fun noHistoryIsInsufficient() {
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, emptyList(), 20.0, null, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY, r.evidenceState)
        assertEquals(TrendConfidenceLevel.INSUFFICIENT, r.trendConfidence)
        assertEquals(TrendDirectionStability.INSUFFICIENT_DATA, r.directionStability)
    }

    @Test
    fun notComparableCurrentSessionIsConservative() {
        val history = listOf(sess("a", 0L, 30.0))
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 10.0, NOT_COMPARABLE, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.INSUFFICIENT_HISTORY, r.evidenceState)
        assertEquals(TrendDirectionStability.NOT_COMPARABLE, r.directionStability)
        assertTrue(r.explanationTags.contains("NOT_COMPARABLE"))
    }

    @Test
    fun singleReliableImprovementIsSingleObservation() {
        // one past session, one transition into current -> only 1 directional data point
        val history = listOf(sess("a", 0L, 30.0))
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 15.0, COMPARABLE, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.SINGLE_OBSERVATION, r.evidenceState)
        assertEquals(TrendConfidenceLevel.INSUFFICIENT, r.trendConfidence)
        assertTrue(r.explanationTags.contains("SINGLE_SESSION_CHANGE"))
    }

    @Test
    fun repeatedReliableImprovementIsStrongSignal() {
        // 4 past sessions all worsening-to-improving descending scores + 1 current => 4 reliable
        // improving transitions => STRONG_REPEATED_SIGNAL (directionalCount >= 4).
        val history = listOf(
            sess("a", 0L, 50.0), sess("b", 1L, 40.0), sess("c", 2L, 30.0),
            sess("d", 3L, 20.0), sess("e", 4L, 15.0)
        )
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 5.0, COMPARABLE, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL, r.evidenceState)
        assertEquals(TrendConfidenceLevel.HIGH, r.trendConfidence)
        assertEquals(TrendDirectionStability.IMPROVING, r.directionStability)
        assertTrue(r.explanationTags.contains("REPEATED_IMPROVEMENT"))
    }

    @Test
    fun contradictoryDirectionsAreFlagged() {
        val history = listOf(sess("a", 0L, 10.0), sess("b", 1L, 30.0))
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 10.0, COMPARABLE, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.CONTRADICTORY_SIGNAL, r.evidenceState)
        assertEquals(TrendDirectionStability.OSCILLATING, r.directionStability)
        assertTrue(r.explanationTags.contains("CONTRADICTORY_SESSIONS"))
    }

    @Test
    fun lowReliabilityPastSessionIsExcludedFromEvidence() {
        // The b->c transition is worsening but session c has LOW reliability, so that
        // transition must not strengthen or count toward the trend.
        val history = listOf(
            sess("a", 0L, 30.0, reliability = "HIGH_CAPTURE_CONDITION_CONSISTENCY"),
            sess("b", 1L, 25.0, reliability = "HIGH_CAPTURE_CONDITION_CONSISTENCY"),
            sess("c", 2L, 40.0, reliability = "MAJOR_CAPTURE_CONDITION_INCONSISTENCY")
        )
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 15.0, COMPARABLE, null, null
        )
        // Reliable transitions: a->b (improving), c->current (comparable, allowed) — wait c is
        // the endpoint of an unreliable transition (b->c uses c's reliability = LOW, excluded);
        // c->current uses current comparability (COMPARABLE, allowed). Two reliable improving
        // transitions -> EARLY_SIGNAL, not contradicted by the excluded worsening transition.
        assertEquals(RepeatedSessionEvidenceState.EARLY_SIGNAL, r.evidenceState)
        assertTrue(r.explanationTags.contains("CAPTURE_CONDITION_CONFLICT"))
        assertEquals(2, r.reliableTransitionsUsed)
        assertEquals(3, r.totalTransitionsConsidered)
    }

    @Test
    fun stableRepeatedMeasurementsAreRepeatedSignal() {
        val history = listOf(sess("a", 0L, 20.0), sess("b", 1L, 21.0))
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 20.5, COMPARABLE, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.REPEATED_SIGNAL, r.evidenceState)
        assertEquals(TrendDirectionStability.STABLE, r.directionStability)
        assertTrue(r.explanationTags.contains("STABLE_OVER_TIME"))
    }

    @Test
    fun limitedComparabilityCapsHighConfidenceToModerate() {
        val history = listOf(
            sess("a", 0L, 50.0), sess("b", 1L, 40.0), sess("c", 2L, 30.0),
            sess("d", 3L, 20.0), sess("e", 4L, 15.0)
        )
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 5.0, LIMITED, null, null
        )
        assertEquals(RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL, r.evidenceState)
        assertEquals(TrendConfidenceLevel.MODERATE, r.trendConfidence)
    }

    @Test
    fun baselineChangeIsComputedIndependentlyOfRecentTrend() {
        val baseline = sess("baseline", 0L, 40.0)
        val history = listOf(baseline, sess("b", 1L, 30.0))
        val trend = FeatureTrend("REDNESS", listOf(40.0, 30.0, 20.0), -10.0, TrendDirection.SUSTAINED_IMPROVEMENT)
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 20.0, COMPARABLE, trend, baseline
        )
        assertEquals(-20.0, r.baselineChange)
        assertEquals(TrendDirection.SUSTAINED_IMPROVEMENT, r.recentTrendDirection)
    }

    @Test
    fun noBaselineYieldsNullBaselineChange() {
        val history = listOf(sess("a", 0L, 30.0))
        val r = CharacteristicTrendIntelligenceAnalyzer.analyze(
            "REDNESS", { it.rednessScore }, history, 20.0, COMPARABLE, null, null
        )
        assertNull(r.baselineChange)
    }
}

class TrendIntelligenceAdaptationGateTest {

    private fun adaptation(
        action: RoutineAdaptationAction,
        confidence: String,
        affected: List<String>
    ) = TrendAwareAdaptationResult(
        decision = RoutineAdaptationResult(action, listOf("BASE"), affected, confidence),
        trendInfluenceApplied = true,
        trendReasons = listOf("BASE_TREND")
    )

    private fun intel(characteristic: String, state: RepeatedSessionEvidenceState) =
        CharacteristicTrendIntelligence(
            characteristic, state, TrendConfidenceLevel.MODERATE, TrendDirectionStability.WORSENING,
            null, TrendDirection.MIXED_TREND, emptyList(), 1, 1
        )

    @Test
    fun noAffectedFeaturesIsNoOp() {
        val a = adaptation(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, "HIGH", emptyList())
        val result = TrendIntelligenceAdaptationGate.apply(a, emptyMap())
        assertEquals(a, result)
    }

    @Test
    fun weakEvidenceOnlyCapsConsiderAdjustmentDownToReviewAndMonitor() {
        val a = adaptation(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, "HIGH", listOf("REDNESS"))
        val map = mapOf("REDNESS" to intel("REDNESS", RepeatedSessionEvidenceState.SINGLE_OBSERVATION))
        val result = TrendIntelligenceAdaptationGate.apply(a, map)
        assertEquals(RoutineAdaptationAction.REVIEW_AND_MONITOR, result.decision.action)
        assertEquals("LOW", result.decision.adaptationConfidence)
        assertTrue(result.decision.reasons.contains("TREND_EVIDENCE_INSUFFICIENT_FOR_ADJUSTMENT"))
    }

    @Test
    fun repeatedReliableEvidenceDoesNotCapAction() {
        val a = adaptation(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, "HIGH", listOf("REDNESS"))
        val map = mapOf("REDNESS" to intel("REDNESS", RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL))
        val result = TrendIntelligenceAdaptationGate.apply(a, map)
        assertEquals(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, result.decision.action)
        assertEquals("HIGH", result.decision.adaptationConfidence)
    }

    @Test
    fun mixedEvidenceCapsHighConfidenceToModerateWithoutChangingAction() {
        val a = adaptation(
            RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, "HIGH", listOf("REDNESS", "BLEMISH_LIKE_FEATURES")
        )
        val map = mapOf(
            "REDNESS" to intel("REDNESS", RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL),
            "BLEMISH_LIKE_FEATURES" to intel("BLEMISH_LIKE_FEATURES", RepeatedSessionEvidenceState.EARLY_SIGNAL)
        )
        val result = TrendIntelligenceAdaptationGate.apply(a, map)
        assertEquals(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, result.decision.action)
        assertEquals("MODERATE", result.decision.adaptationConfidence)
        assertTrue(result.decision.reasons.contains("MIXED_TREND_EVIDENCE_STRENGTH"))
    }

    @Test
    fun neverEscalatesAWeakerExistingAction() {
        val a = adaptation(RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE, "MODERATE", listOf("REDNESS"))
        val map = mapOf("REDNESS" to intel("REDNESS", RepeatedSessionEvidenceState.STRONG_REPEATED_SIGNAL))
        val result = TrendIntelligenceAdaptationGate.apply(a, map)
        assertEquals(RoutineAdaptationAction.MAINTAIN_CURRENT_ROUTINE, result.decision.action)
        assertEquals("MODERATE", result.decision.adaptationConfidence)
    }
}
