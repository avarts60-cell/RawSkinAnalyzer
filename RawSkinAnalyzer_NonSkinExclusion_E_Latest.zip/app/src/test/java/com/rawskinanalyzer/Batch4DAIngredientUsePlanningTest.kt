package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * BATCH 4D-A — deterministic tests for the new IngredientUsePlanner <-> RoutineIntensityPolicy /
 * ToleranceState connection. Per PROJECT_STATUS.md's "session_budget"/testing rule, these were
 * written and hand-traced this session; whether they were actually executed is recorded
 * truthfully in PROJECT_STATUS.md rather than claimed here.
 */
class Batch4DAIngredientUsePlanningTest {

    private fun defaultContext() = RoutineContextPlanner.defaultContext()

    private fun option(
        ingredientName: String = "Niacinamide",
        objectiveType: SkinObjectiveType = SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE
    ) = SpecificIngredientOption(
        concern = SkinConcernCategory.TONE_PIGMENTATION,
        ingredientName = ingredientName,
        role = IngredientSelectionRole.PRIMARY,
        routinePhase = "AM",
        sourceCategory = "OBJECTIVE_TARGETED_SUPPORT",
        caution = null,
        objectiveType = objectiveType,
        objectiveStrengthReason = "test"
    )

    @Test fun minimalIntensityForcesReviewRequiredRatherThanGuessing() {
        val opt = option()
        val intensity = mapOf(
            "Niacinamide" to RoutineIntensityDecision("Niacinamide", RoutineIntensityLevel.MINIMAL, "LIMITED_BY_TOLERANCE")
        )
        val plans = IngredientUsePlanner.plan(listOf(opt), defaultContext(), intensity)
        val plan = plans.single()
        assertEquals("REVIEW_REQUIRED", plan.concentrationGuidance)
        assertEquals("REVIEW_REQUIRED", plan.frequencyGuidance)
        assertEquals("REVIEW_REQUIRED_BEFORE_USE", plan.introductionRule)
        assertEquals("MINIMAL", plan.intensityLevel)
    }

    @Test fun conservativeIntensityMakesGuidanceMoreConservativeThanDefaultUserPreference() {
        val opt = option()
        val intensity = mapOf(
            "Niacinamide" to RoutineIntensityDecision("Niacinamide", RoutineIntensityLevel.CONSERVATIVE, "CONSERVATIVE_INTRODUCTION")
        )
        // Default context is not itself cautious/low-intensity, so without intensity wiring this
        // would previously have produced the non-conservative branch. With intensity wired in,
        // CONSERVATIVE must still force the conservative branch — the ceiling behavior this
        // batch adds.
        val plans = IngredientUsePlanner.plan(listOf(opt), defaultContext(), intensity)
        val plan = plans.single()
        assertEquals("LOWER_STRENGTH_OPTION", plan.concentrationGuidance)
        assertEquals("START_FEW_SESSIONS_PER_WEEK", plan.frequencyGuidance)
    }

    @Test fun standardIntensityDoesNotForceConservativeWhenUserPreferenceIsNotCautious() {
        val opt = option()
        val intensity = mapOf(
            "Niacinamide" to RoutineIntensityDecision("Niacinamide", RoutineIntensityLevel.STANDARD, "ALLOWED_COMPATIBLE_COMBINATION")
        )
        val plans = IngredientUsePlanner.plan(listOf(opt), defaultContext(), intensity)
        val plan = plans.single()
        assertEquals("STANDARD_COSMETIC_STRENGTH_OPTION", plan.concentrationGuidance)
    }

    @Test fun cautiousEscalationDoesNotUnlockAHigherFrequencyTierThanStandard() {
        val opt = option()
        val standard = IngredientUsePlanner.plan(
            listOf(opt), defaultContext(),
            mapOf("Niacinamide" to RoutineIntensityDecision("Niacinamide", RoutineIntensityLevel.STANDARD, "x"))
        ).single()
        val escalated = IngredientUsePlanner.plan(
            listOf(opt), defaultContext(),
            mapOf("Niacinamide" to RoutineIntensityDecision("Niacinamide", RoutineIntensityLevel.CAUTIOUS_ESCALATION, "x"))
        ).single()
        // No aggressive schedule from a single analysis — CAUTIOUS_ESCALATION must not produce a
        // stronger guidance tier than STANDARD already does.
        assertEquals(standard.concentrationGuidance, escalated.concentrationGuidance)
        assertEquals(standard.frequencyGuidance, escalated.frequencyGuidance)
    }

    @Test fun absentIntensityDataPreservesPreBatch4DABehavior() {
        val opt = option()
        val withoutIntensity = IngredientUsePlanner.plan(listOf(opt), defaultContext())
        val plan = withoutIntensity.single()
        // Default (non-cautious) UserRoutineContext, no intensity supplied at all -> same
        // non-conservative branch as before this batch existed.
        assertEquals("STANDARD_COSMETIC_STRENGTH_OPTION", plan.concentrationGuidance)
        assertEquals("NOT_SPECIFIED", plan.intensityLevel)
        assertEquals("UNKNOWN", plan.toleranceState)
    }

    @Test fun toleranceStateIsCarriedThroughForExplainabilityWithoutBeingReDecided() {
        val opt = option()
        val tolerance = mapOf("Niacinamide" to ToleranceState.TOLERATED)
        val plans = IngredientUsePlanner.plan(listOf(opt), defaultContext(), emptyMap(), tolerance)
        assertEquals("TOLERATED", plans.single().toleranceState)
    }

    @Test fun everyReturnedPlanCarriesTheIntensityReasonUnaltered() {
        val opt = option()
        val intensity = mapOf(
            "Niacinamide" to RoutineIntensityDecision("Niacinamide", RoutineIntensityLevel.CONSERVATIVE, "CONSERVATIVE_INTRODUCTION")
        )
        val plan = IngredientUsePlanner.plan(listOf(opt), defaultContext(), intensity).single()
        assertEquals("CONSERVATIVE_INTRODUCTION", plan.intensityReason)
    }

    @Test fun cautiousUserPreferenceAloneStillProducesConservativeGuidanceAsBefore() {
        val opt = option()
        val cautiousContext = UserRoutineContext(
            complexity = defaultContext().complexity,
            tolerancePreference = TolerancePreference.CAUTIOUS,
            activeIntensityPreference = defaultContext().activeIntensityPreference,
            morningTimeLimitMinutes = defaultContext().morningTimeLimitMinutes,
            eveningTimeLimitMinutes = defaultContext().eveningTimeLimitMinutes
        )
        val plan = IngredientUsePlanner.plan(listOf(opt), cautiousContext).single()
        assertEquals("LOWER_STRENGTH_OPTION", plan.concentrationGuidance)
        assertTrue(plan.introductionRule == "START_CONSERVATIVELY_AND_REVIEW_TOLERANCE")
    }
}
