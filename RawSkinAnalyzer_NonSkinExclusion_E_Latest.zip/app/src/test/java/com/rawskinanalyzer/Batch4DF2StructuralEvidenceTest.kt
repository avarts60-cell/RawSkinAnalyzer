package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4D-F2. Plain JUnit — no android.* dependency for the pure-math/pure-logic pieces
 * ([FeatureOrientationEngine]'s angle math, [PostAcneSpatialAssociationEngine]'s association
 * logic), same pattern [FeatureCalibrationValidatorTest]/[AnalysisScorePolicyTest] already use.
 * Source-level only per this project's verification_policy — UNIT_TESTED is UNVERIFIED until
 * these actually execute against the exact compiled baseline (see PROJECT_STATUS.md).
 */
class Batch4DF2StructuralEvidenceTest {

    // -----------------------------------------------------------------------
    // FeatureOrientationEngine
    // -----------------------------------------------------------------------

    @Test fun axisDistanceWrapsCorrectlyNear180() {
        // 179 and 1 degrees are axis-adjacent (2 degrees apart), not 178 apart, since an axis has
        // period 180 (no distinguishable head/tail) — this is the whole reason axisDistanceDegrees
        // exists instead of a plain abs(a-b).
        assertEquals(2.0, FeatureOrientationEngine.axisDistanceDegrees(179.0, 1.0), 0.001)
        assertEquals(0.0, FeatureOrientationEngine.axisDistanceDegrees(90.0, 90.0), 0.001)
        assertEquals(90.0, FeatureOrientationEngine.axisDistanceDegrees(0.0, 90.0), 0.001)
    }

    @Test fun circularMeanOfIdenticalAxesReturnsThatAxis() {
        val estimates = listOf(
            FeatureOrientationEngine.OrientationEstimate(45.0, 0.9),
            FeatureOrientationEngine.OrientationEstimate(45.0, 0.8),
            FeatureOrientationEngine.OrientationEstimate(45.0, 0.7)
        )
        val mean = FeatureOrientationEngine.circularMeanAxisDegrees(estimates)
        assertTrue(mean != null)
        assertEquals(45.0, mean!!, 0.5)
    }

    @Test fun circularMeanIgnoresLowCoherenceOrUnestimatedEntries() {
        val estimates = listOf(
            FeatureOrientationEngine.OrientationEstimate(-1.0, 0.0), // unestimated
            FeatureOrientationEngine.OrientationEstimate(30.0, 0.01), // below usability threshold
            FeatureOrientationEngine.OrientationEstimate(60.0, 0.9)
        )
        val mean = FeatureOrientationEngine.circularMeanAxisDegrees(estimates)
        assertTrue(mean != null)
        assertEquals(60.0, mean!!, 0.5) // only the third entry is usable
    }

    @Test fun circularMeanOfEmptyOrAllUnusableReturnsNull() {
        assertEquals(null, FeatureOrientationEngine.circularMeanAxisDegrees(emptyList()))
        assertEquals(
            null,
            FeatureOrientationEngine.circularMeanAxisDegrees(listOf(FeatureOrientationEngine.OrientationEstimate(-1.0, 0.0)))
        )
    }

    // -----------------------------------------------------------------------
    // PostAcneSpatialAssociationEngine
    // -----------------------------------------------------------------------

    private fun evidence(
        id: String, type: SpecializedFeatureType, x: Int, y: Int, area: Int, shape: String, confidence: Double
    ) = SpecializedFeatureEvidence(
        featureType = type, candidateId = id, primaryConfidence = confidence, secondaryConfidence = 0.0,
        sourceView = "FRONT FACE", anatomicalRegion = AnatomicalRegion.FOREHEAD,
        sourceCoordinates = x to y, boundingBox = intArrayOf(x - 5, y - 5, 10, 10), scale = AnalysisScale.MICRO,
        area = area, shape = shape, skinConfidence = 80.0, supportingSignals = emptyList(), evidenceReasons = emptyList(),
        classificationState = FeatureClassificationState.SUPPORTED
    )

    @Test fun associatesNearbyCompatibleDarkAndBlemishCandidates() {
        // Close together (10px apart), similar area, compatible types (post-acne-mark near a
        // pustule-like blemish is the physically-expected pairing per typeCompatibility).
        val dark = evidence("dark1", SpecializedFeatureType.POST_ACNE_MARK_LIKE, 100, 100, 200, "COMPACT_ROUND", 0.6)
        val blemish = evidence("blem1", SpecializedFeatureType.PUSTULE_LIKE_VISUAL, 108, 104, 210, "COMPACT_ROUND", 0.6)
        // A few extra same-region candidates purely so regionSpan() has more than one point to
        // measure spread from, matching how this engine is actually invoked (session-wide lists).
        val filler = evidence("filler1", SpecializedFeatureType.PORE_LIKE, 300, 300, 20, "COMPACT_ROUND", 0.5)

        val associations = PostAcneSpatialAssociationEngine.associate(listOf(dark, blemish, filler))
        assertTrue(associations.isNotEmpty())
        val a = associations.first()
        assertEquals("dark1", a.darkFeatureCandidateId)
        assertEquals("blem1", a.blemishCandidateId)
        assertTrue(a.associationConfidence > 0.2)
    }

    @Test fun doesNotAssociateDistantCandidates() {
        val dark = evidence("dark2", SpecializedFeatureType.PIGMENTATION_LIKE, 0, 0, 200, "IRREGULAR", 0.6)
        val blemish = evidence("blem2", SpecializedFeatureType.BLACKHEAD_LIKE, 900, 900, 210, "COMPACT_ROUND", 0.6)
        val associations = PostAcneSpatialAssociationEngine.associate(listOf(dark, blemish))
        assertTrue(associations.none { it.darkFeatureCandidateId == "dark2" && it.blemishCandidateId == "blem2" })
    }

    @Test fun producesNoAssociationsWhenOneFamilyIsAbsent() {
        val dark = evidence("dark3", SpecializedFeatureType.DARK_MARK_LIKE, 50, 50, 100, "COMPACT_ROUND", 0.6)
        val associations = PostAcneSpatialAssociationEngine.associate(listOf(dark))
        assertTrue(associations.isEmpty())
    }
}
