package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Batch 4D-G. Plain JUnit, no android.* dependency — same pattern as Batch4DF2StructuralEvidenceTest. */
class Batch4DGCorrespondenceFusionTest {

    private fun regionSetWithPolygon(region: AnatomicalRegion, minX: Float, minY: Float, maxX: Float, maxY: Float): RegionSet {
        val points = listOf(
            GeometryPoint(0f, 0f, minX, minY),
            GeometryPoint(0f, 0f, maxX, minY),
            GeometryPoint(0f, 0f, maxX, maxY),
            GeometryPoint(0f, 0f, minX, maxY)
        )
        return RegionSet(listOf(RegionPolygon(region, points, 0.7)), emptyList(), emptyList())
    }

    // -----------------------------------------------------------------------
    // RegionalNormalizationEngine
    // -----------------------------------------------------------------------

    @Test fun normalizesWithinRegionBoundingBox() {
        val rs = regionSetWithPolygon(AnatomicalRegion.FOREHEAD, 100f, 100f, 300f, 200f)
        val pos = RegionalNormalizationEngine.normalize(rs, AnatomicalRegion.FOREHEAD, 200, 150)
        assertEquals(RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE, pos.method)
        assertEquals(0.5, pos.nx, 0.01)
        assertEquals(0.5, pos.ny, 0.01)
        assertTrue(!pos.outOfBounds)
    }

    @Test fun clampsAndFlagsOutOfBoundsPoints() {
        val rs = regionSetWithPolygon(AnatomicalRegion.NOSE, 0f, 0f, 100f, 100f)
        val pos = RegionalNormalizationEngine.normalize(rs, AnatomicalRegion.NOSE, 150, 50)
        assertTrue(pos.outOfBounds)
        assertEquals(1.0, pos.nx, 0.001) // clamped
    }

    @Test fun fallsBackWhenRegionGeometryMissing() {
        val pos = RegionalNormalizationEngine.normalize(null, AnatomicalRegion.CHIN, 50, 50)
        assertEquals(RegionalNormalizationEngine.METHOD_UNAVAILABLE_FALLBACK, pos.method)
    }

    // -----------------------------------------------------------------------
    // FeatureCorrespondenceEngine
    // -----------------------------------------------------------------------

    private fun evidence(
        id: String, type: SpecializedFeatureType, view: String, x: Int, y: Int, area: Int,
        confidence: Double = 0.6, region: AnatomicalRegion = AnatomicalRegion.LEFT_CHEEK
    ) = SpecializedFeatureEvidence(
        featureType = type, candidateId = id, primaryConfidence = confidence, secondaryConfidence = 0.0,
        sourceView = view, anatomicalRegion = region,
        sourceCoordinates = x to y, boundingBox = intArrayOf(x - 5, y - 5, 10, 10), scale = AnalysisScale.MICRO,
        area = area, shape = "COMPACT_ROUND", skinConfidence = 80.0, supportingSignals = emptyList(), evidenceReasons = emptyList(),
        classificationState = FeatureClassificationState.SUPPORTED
    )

    @Test fun matchesCompatibleFeaturesAcrossViewsIntoOneCorrespondence() {
        // Same region, same family, close normalized positions in two different views' own region geometry.
        val rsFront = regionSetWithPolygon(AnatomicalRegion.LEFT_CHEEK, 0f, 0f, 100f, 100f)
        val rsLeft = regionSetWithPolygon(AnatomicalRegion.LEFT_CHEEK, 0f, 0f, 200f, 200f)
        val e1 = evidence("front1", SpecializedFeatureType.BLACKHEAD_LIKE, "FRONT FACE", 50, 50, 100)
        val e2 = evidence("left1", SpecializedFeatureType.BLACKHEAD_LIKE, "LEFT CHEEK", 100, 100, 110)

        val corr = FeatureCorrespondenceEngine.buildCorrespondences(
            listOf(e1, e2), mapOf("FRONT FACE" to rsFront, "LEFT CHEEK" to rsLeft), "session1", "HIGH_CAPTURE_CONDITION_CONSISTENCY"
        )
        assertEquals(1, corr.size)
        val c = corr.first()
        assertEquals(2, c.sourceFeatures.size)
        assertEquals(2, c.supportingViews.size)
        assertTrue(c.state == CorrespondenceState.SUPPORTED || c.state == CorrespondenceState.PARTIAL)
    }

    @Test fun singleViewFeatureProducesUncertainSingleRecord() {
        val rs = regionSetWithPolygon(AnatomicalRegion.NOSE, 0f, 0f, 100f, 100f)
        val e1 = evidence("only1", SpecializedFeatureType.PORE_LIKE, "FRONT FACE", 50, 50, 30, region = AnatomicalRegion.NOSE)
        val corr = FeatureCorrespondenceEngine.buildCorrespondences(listOf(e1), mapOf("FRONT FACE" to rs), "session1", null)
        assertEquals(1, corr.size)
        assertEquals(CorrespondenceState.UNCERTAIN, corr.first().state)
        assertEquals(listOf("only1"), corr.first().sourceFeatures)
    }

    @Test fun doesNotMatchIncompatibleFamiliesOrDistantPositions() {
        val rsFront = regionSetWithPolygon(AnatomicalRegion.CHIN, 0f, 0f, 100f, 100f)
        val rsLeft = regionSetWithPolygon(AnatomicalRegion.CHIN, 0f, 0f, 100f, 100f)
        val e1 = evidence("f1", SpecializedFeatureType.HAIR_LIKE, "FRONT FACE", 5, 5, 20, region = AnatomicalRegion.CHIN)
        val e2 = evidence("l1", SpecializedFeatureType.DARK_MARK_LIKE, "LEFT CHEEK", 95, 95, 20, region = AnatomicalRegion.CHIN)
        val corr = FeatureCorrespondenceEngine.buildCorrespondences(listOf(e1, e2), mapOf("FRONT FACE" to rsFront, "LEFT CHEEK" to rsLeft), "s", null)
        assertEquals(2, corr.size) // two independent single-view records, not one merged
        assertTrue(corr.all { it.sourceFeatures.size == 1 })
    }

    // -----------------------------------------------------------------------
    // CrossViewFeatureFusionEngine
    // -----------------------------------------------------------------------

    @Test fun fusionWeightsByConfidenceAndSkinConfidenceWithoutLettingWeakViewErodeStrong() {
        val strong = PerViewFeatureEvidenceRef("a", "FRONT FACE", confidence = 0.9, area = 100, skinConfidence = 95.0)
        val weak = PerViewFeatureEvidenceRef("b", "LEFT CHEEK", confidence = 0.2, area = 50, skinConfidence = 20.0)
        val evidenceById = mapOf(
            "a" to dummyEvidence("a", strong), "b" to dummyEvidence("b", weak)
        )
        val correspondence = FeatureCorrespondence(
            correspondenceId = "c1", featureType = SpecializedFeatureType.BLACKHEAD_LIKE, anatomicalRegion = AnatomicalRegion.NOSE,
            normalizedLocation = NormalizedPosition(0.5, 0.5, RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE, false),
            sourceFeatures = listOf("a", "b"), supportingViews = listOf("FRONT FACE", "LEFT CHEEK"),
            correspondenceConfidence = 0.7, evidenceReasons = emptyList(), normalizedSizeApproximate = 0.5,
            shapeDescriptor = "COMPACT_ROUND", regionalContext = "NOSE", skinConfidence = 20.0, captureQuality = "HIGH_CAPTURE_CONDITION_CONSISTENCY",
            sourceSessionIds = listOf("s1"), state = CorrespondenceState.SUPPORTED
        )
        val fused = CrossViewFeatureFusionEngine.fuse(listOf(correspondence), evidenceById)
        assertEquals(1, fused.size)
        // Fused confidence should be much closer to the strong view (heavily weighted) than a plain average (0.55) would be.
        assertTrue(fused.first().fusedConfidence > 0.7)
    }

    private fun dummyEvidence(id: String, ref: PerViewFeatureEvidenceRef) = SpecializedFeatureEvidence(
        featureType = SpecializedFeatureType.BLACKHEAD_LIKE, candidateId = id, primaryConfidence = ref.confidence, secondaryConfidence = 0.0,
        sourceView = ref.view, anatomicalRegion = AnatomicalRegion.NOSE, sourceCoordinates = 0 to 0, boundingBox = intArrayOf(0, 0, 1, 1),
        scale = AnalysisScale.MICRO, area = ref.area, shape = "COMPACT_ROUND", skinConfidence = ref.skinConfidence,
        supportingSignals = emptyList(), evidenceReasons = emptyList(), classificationState = FeatureClassificationState.SUPPORTED
    )

    // -----------------------------------------------------------------------
    // LongitudinalFeatureContract
    // -----------------------------------------------------------------------

    private fun identity(type: SpecializedFeatureType, region: AnatomicalRegion, nx: Double, ny: Double, size: Double, conf: Double, session: String) =
        FeatureIdentityRecord(
            featureType = type, anatomicalRegion = region,
            normalizedLocation = NormalizedPosition(nx, ny, RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE, false),
            apparentSize = size, featureConfidence = conf, sourceView = "FRONT FACE", sessionId = session,
            captureQuality = null, comparabilityState = "CURRENT_SESSION_ONLY_NO_PRIOR_COMPARISON"
        )

    @Test fun notComparableSessionsProduceOnlyUncertainChanges() {
        val prev = listOf(identity(SpecializedFeatureType.BLACKHEAD_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, 100.0, 0.6, "s0"))
        val cur = listOf(identity(SpecializedFeatureType.BLACKHEAD_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, 100.0, 0.6, "s1"))
        val result = LongitudinalFeatureContract.compareIdentities(prev, cur, SessionComparabilityResult(SessionComparabilityStatus.NOT_COMPARABLE, listOf("test")))
        assertTrue(result.all { it.changeType == FeatureChangeType.UNCERTAIN_CHANGE })
    }

    @Test fun matchesPersistingFeatureWhenComparable() {
        val prev = listOf(identity(SpecializedFeatureType.BLACKHEAD_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, 100.0, 0.6, "s0"))
        val cur = listOf(identity(SpecializedFeatureType.BLACKHEAD_LIKE, AnatomicalRegion.NOSE, 0.52, 0.5, 105.0, 0.62, "s1"))
        val result = LongitudinalFeatureContract.compareIdentities(prev, cur, SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList()))
        assertEquals(1, result.size)
        assertEquals(FeatureChangeType.PERSISTING_FEATURE, result.first().changeType)
    }

    @Test fun flagsNewAndResolvedFeatures() {
        val prev = listOf(identity(SpecializedFeatureType.BLACKHEAD_LIKE, AnatomicalRegion.NOSE, 0.2, 0.2, 100.0, 0.6, "s0"))
        val cur = listOf(identity(SpecializedFeatureType.BLACKHEAD_LIKE, AnatomicalRegion.NOSE, 0.8, 0.8, 100.0, 0.6, "s1"))
        val result = LongitudinalFeatureContract.compareIdentities(prev, cur, SessionComparabilityResult(SessionComparabilityStatus.COMPARABLE, emptyList()))
        assertEquals(2, result.size)
        assertTrue(result.any { it.changeType == FeatureChangeType.NEW_FEATURE_CANDIDATE })
        assertTrue(result.any { it.changeType == FeatureChangeType.RESOLVED_FEATURE_CANDIDATE })
    }
}
