package com.rawskinanalyzer

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4D-H. Plain JUnit, no android.* dependency — same pattern as
 * Batch4DGCorrespondenceFusionTest. Covers: FeatureLongitudinalTrendAnalyzer's
 * comparability-gating and conservative classification, the region-wide change metrics it adds
 * on top of LongitudinalFeatureContract.compareIdentities (already tested by
 * Batch4DGCorrespondenceFusionTest and left untouched here), and FeatureLongitudinalAdaptationGate's
 * cap-only behavior. Persistence round-trip JSON shape is tested directly against
 * PersistentSkinSessionStore's private serialize/parse pair via its public save/history contract
 * on SkinSessionRepository + an InMemorySkinSessionStore substitute is not representative of the
 * real JSON path, so this file instead exercises the JSON shape logic that
 * LongitudinalFeatureContract/FeatureLongitudinalTrendAnalyzer expose directly, and separately
 * exercises SkinSessionRepository's previousFeatureIdentityRecords absence/availability
 * distinction using InMemorySkinSessionStore (which round-trips StoredSkinSession by reference,
 * not by JSON, but exercises the exact same repository-level contract callers depend on).
 */
class Batch4DHLongitudinalFeatureEvidenceTest {

    private fun record(
        type: SpecializedFeatureType,
        region: AnatomicalRegion,
        nx: Double, ny: Double,
        size: Double = 10.0,
        confidence: Double = 0.8,
        sessionId: String = "s1"
    ) = FeatureIdentityRecord(
        featureType = type,
        anatomicalRegion = region,
        normalizedLocation = NormalizedPosition(nx, ny, RegionalNormalizationEngine.METHOD_REGION_POLYGON_RELATIVE, false),
        apparentSize = size,
        featureConfidence = confidence,
        sourceView = "FRONT FACE",
        sessionId = sessionId,
        captureQuality = null,
        comparabilityState = "CURRENT_SESSION_ONLY_NO_PRIOR_COMPARISON"
    )

    private val highlyComparable = SessionComparabilityResult(SessionComparabilityStatus.HIGHLY_COMPARABLE, emptyList())
    private val notComparable = SessionComparabilityResult(SessionComparabilityStatus.NOT_COMPARABLE, listOf("ANALYSIS_PIPELINE_VERSION_MISMATCH"))

    // -----------------------------------------------------------------------
    // FeatureLongitudinalTrendAnalyzer — top-level gating
    // -----------------------------------------------------------------------

    @Test fun noPreviousRecordsYieldsInsufficientDataNeverStable() {
        val current = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(null, current, highlyComparable)
        assertEquals("INSUFFICIENT_DATA", result.overallDataStatus)
        assertTrue(result.summaries.isEmpty())
        assertTrue(result.changes.isEmpty())
    }

    @Test fun nullComparabilityYieldsInsufficientDataAndSyntheticNotComparableReason() {
        val current = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(emptyList(), current, null)
        assertEquals("INSUFFICIENT_DATA", result.overallDataStatus)
        assertEquals(SessionComparabilityStatus.NOT_COMPARABLE, result.comparability.status)
    }

    @Test fun notComparableSessionsNeverProduceDirectionalClassification() {
        val previous = listOf(record(SpecializedFeatureType.BLEMISH_LIKE, AnatomicalRegion.CHIN, 0.3, 0.3, sessionId = "s0"))
        val current = listOf(record(SpecializedFeatureType.BLEMISH_LIKE, AnatomicalRegion.CHIN, 0.31, 0.31))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(previous, current, notComparable)
        assertEquals("NOT_COMPARABLE", result.overallDataStatus)
        assertTrue(result.summaries.isNotEmpty())
        result.summaries.forEach { assertEquals(FeatureTrendState.NOT_COMPARABLE, it.trendState) }
    }

    // -----------------------------------------------------------------------
    // Conservative classification — step_11 accuracy/uncertainty rules
    // -----------------------------------------------------------------------

    @Test fun persistingFeatureAcrossSessionsClassifiesStable() {
        val previous = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, confidence = 0.8, sessionId = "s0"))
        val current = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, confidence = 0.8))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(previous, current, highlyComparable)
        assertEquals(1, result.summaries.size)
        assertEquals(FeatureTrendState.STABLE, result.summaries.first().trendState)
    }

    @Test fun singleNewCandidateAloneNeverClassifiesWorsening() {
        // Only ONE change record for this type+region — below MIN_EVIDENCE_FOR_CLASSIFICATION
        // would not apply here since the constant is 1, but the point of this test is that a
        // lone NEW_FEATURE_CANDIDATE with nothing else in the group must not itself read as a
        // confirmed WORSENING claim about a "new lesion" — it should present as the visible-
        // appearance-only state, never framed as onset.
        val current = listOf(record(SpecializedFeatureType.DARK_MARK_LIKE, AnatomicalRegion.LEFT_CHEEK, 0.6, 0.6, confidence = 0.9))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(emptyList(), current, highlyComparable)
        // previous is empty (not null) -> genuinely comparable, zero-previous-feature session
        assertEquals("EVIDENCE_AVAILABLE", result.overallDataStatus)
        val summary = result.summaries.first()
        // A lone NEW_FEATURE_CANDIDATE with no PERSISTING_FEATURE counterpart in the same group
        // does not satisfy the "resolution/new-dominated relative to persisting" rule, so it
        // falls through to UNCERTAIN/MIXED rather than a bare WORSENING claim from one record.
        assertTrue(summary.trendState != FeatureTrendState.WORSENING || summary.evidenceReason.contains("appearance only"))
    }

    @Test fun lowConfidenceEvidenceClassifiesUncertainNotStable() {
        val previous = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, confidence = 0.1, sessionId = "s0"))
        val current = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, confidence = 0.1))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(previous, current, highlyComparable)
        assertEquals(FeatureTrendState.UNCERTAIN, result.summaries.first().trendState)
    }

    @Test fun resolvedFeatureNeverLabeledAsResolvedInReasonText() {
        val previous = listOf(record(SpecializedFeatureType.BLEMISH_LIKE, AnatomicalRegion.CHIN, 0.4, 0.4, confidence = 0.8, sessionId = "s0"))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(previous, emptyList(), highlyComparable)
        val summary = result.summaries.first()
        assertTrue(summary.trendState == FeatureTrendState.IMPROVING || summary.trendState == FeatureTrendState.UNCERTAIN)
        assertTrue(!summary.evidenceReason.contains("resolved", ignoreCase = true))
        assertTrue(!summary.evidenceReason.contains("healed", ignoreCase = true))
    }

    // -----------------------------------------------------------------------
    // Regional change metrics
    // -----------------------------------------------------------------------

    @Test fun regionalMetricsCountRawFeaturesNotFusedCorrespondences() {
        val previous = listOf(
            record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.2, 0.2, sessionId = "s0"),
            record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.8, 0.8, sessionId = "s0")
        )
        val current = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.2, 0.2))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(previous, current, highlyComparable)
        val metrics = result.regionalMetrics.first { it.region == AnatomicalRegion.NOSE }
        assertEquals(2, metrics.previousCount)
        assertEquals(1, metrics.currentCount)
        assertEquals(-1, metrics.countDelta)
    }

    @Test fun emptySessionsProduceNullDensityNotZero() {
        val result = FeatureLongitudinalTrendAnalyzer.analyze(emptyList(), emptyList(), highlyComparable)
        assertTrue(result.regionalMetrics.isEmpty())
    }

    // -----------------------------------------------------------------------
    // SkinSessionRepository.previousFeatureIdentityRecords — absence vs empty
    // -----------------------------------------------------------------------

    @Test fun legacySessionWithoutFeatureQualityReturnsNullNotEmpty() {
        val store = InMemorySkinSessionStore()
        SkinSessionRepository.configure(store)
        store.save(
            StoredSkinSession(
                sessionId = "legacy1",
                createdAtEpochMillis = 1000L,
                analysisVersion = "test_version_h1",
                snapshot = SkinProgressSnapshot(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "MODERATE")
                // featureEvidenceCaptureQuality defaults to null: pre-batch session
            )
        )
        val result = SkinSessionRepository.previousFeatureIdentityRecords("test_version_h1")
        assertNull(result)
    }

    @Test fun sessionWithRecordedZeroFeaturesReturnsEmptyNotNull() {
        val store = InMemorySkinSessionStore()
        SkinSessionRepository.configure(store)
        store.save(
            StoredSkinSession(
                sessionId = "s_zero",
                createdAtEpochMillis = 1000L,
                analysisVersion = "test_version_h2",
                snapshot = SkinProgressSnapshot(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "MODERATE"),
                featureIdentityRecords = emptyList(),
                featureEvidenceCaptureQuality = FeatureEvidenceCaptureQuality(
                    featureEvidenceAvailable = true,
                    captureConditionConsistency = "CONSISTENT",
                    usableViewCount = 3
                )
            )
        )
        val result = SkinSessionRepository.previousFeatureIdentityRecords("test_version_h2")
        assertTrue(result != null && result.isEmpty())
    }

    @Test fun sessionWithRealFeatureRecordsReturnsThem() {
        val store = InMemorySkinSessionStore()
        SkinSessionRepository.configure(store)
        val records = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, sessionId = "s_real"))
        store.save(
            StoredSkinSession(
                sessionId = "s_real",
                createdAtEpochMillis = 1000L,
                analysisVersion = "test_version_h3",
                snapshot = SkinProgressSnapshot(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, "MODERATE"),
                featureIdentityRecords = records,
                featureEvidenceCaptureQuality = FeatureEvidenceCaptureQuality(true, "CONSISTENT", 3)
            )
        )
        val result = SkinSessionRepository.previousFeatureIdentityRecords("test_version_h3")
        assertEquals(1, result?.size)
        assertEquals(SpecializedFeatureType.PORE_LIKE, result?.first()?.featureType)
    }

    // -----------------------------------------------------------------------
    // FeatureLongitudinalAdaptationGate — cap-only Brain 2 boundary
    // -----------------------------------------------------------------------

    private fun considerAdjustment(confidence: String = "HIGH") = TrendAwareAdaptationResult(
        decision = RoutineAdaptationResult(
            action = RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT,
            reasons = listOf("BASE_REASON"),
            affectedFeatures = listOf("BLEMISH_LIKE_FEATURES"),
            adaptationConfidence = confidence
        ),
        trendInfluenceApplied = true,
        trendReasons = listOf("BASE_TREND_REASON")
    )

    @Test fun gateNeverEscalatesAnAlreadyConservativeDecision() {
        val reviewOnly = TrendAwareAdaptationResult(
            decision = RoutineAdaptationResult(RoutineAdaptationAction.REVIEW_AND_MONITOR, listOf("X"), emptyList(), "LOW"),
            trendInfluenceApplied = false,
            trendReasons = emptyList()
        )
        val weakFeatureResult = FeatureLongitudinalResult(
            changes = emptyList(), regionalMetrics = emptyList(), summaries = emptyList(),
            comparability = notComparable, overallDataStatus = "NOT_COMPARABLE"
        )
        val gated = FeatureLongitudinalAdaptationGate.apply(reviewOnly, weakFeatureResult)
        assertEquals(RoutineAdaptationAction.REVIEW_AND_MONITOR, gated.decision.action)
        assertEquals("LOW", gated.decision.adaptationConfidence)
    }

    @Test fun gateCapsConsiderAdjustmentWhenFeatureEvidenceNotComparable() {
        val featureResult = FeatureLongitudinalResult(
            changes = emptyList(), regionalMetrics = emptyList(), summaries = emptyList(),
            comparability = notComparable, overallDataStatus = "NOT_COMPARABLE"
        )
        val gated = FeatureLongitudinalAdaptationGate.apply(considerAdjustment(), featureResult)
        assertEquals(RoutineAdaptationAction.REVIEW_AND_MONITOR, gated.decision.action)
        assertEquals("LOW", gated.decision.adaptationConfidence)
        assertTrue(gated.decision.reasons.contains("FEATURE_LEVEL_EVIDENCE_NOT_COMPARABLE"))
    }

    @Test fun gateCapsConfidenceWhenFeatureEvidenceMostlyUncertain() {
        val uncertainSummary = FeatureTrendSummary(
            featureCategory = SpecializedFeatureType.PORE_LIKE, region = AnatomicalRegion.NOSE,
            trendState = FeatureTrendState.UNCERTAIN, changeConfidence = 0.1, supportingSessions = 2,
            evidenceReason = "low confidence"
        )
        val featureResult = FeatureLongitudinalResult(
            changes = emptyList(), regionalMetrics = emptyList(), summaries = listOf(uncertainSummary),
            comparability = highlyComparable, overallDataStatus = "EVIDENCE_AVAILABLE"
        )
        val gated = FeatureLongitudinalAdaptationGate.apply(considerAdjustment("HIGH"), featureResult)
        assertEquals(RoutineAdaptationAction.CONSIDER_ROUTINE_ADJUSTMENT, gated.decision.action) // never escalated away, only confidence capped
        assertEquals("MODERATE", gated.decision.adaptationConfidence)
    }

    @Test fun gateLeavesStrongFeatureEvidenceUntouched() {
        val stableSummary = FeatureTrendSummary(
            featureCategory = SpecializedFeatureType.PORE_LIKE, region = AnatomicalRegion.NOSE,
            trendState = FeatureTrendState.STABLE, changeConfidence = 0.9, supportingSessions = 2,
            evidenceReason = "stable"
        )
        val featureResult = FeatureLongitudinalResult(
            changes = emptyList(), regionalMetrics = emptyList(), summaries = listOf(stableSummary),
            comparability = highlyComparable, overallDataStatus = "EVIDENCE_AVAILABLE"
        )
        val original = considerAdjustment("HIGH")
        val gated = FeatureLongitudinalAdaptationGate.apply(original, featureResult)
        assertEquals(original, gated)
    }

    // -----------------------------------------------------------------------
    // JSON shape sanity (parseable, no exceptions, expected top-level keys)
    // -----------------------------------------------------------------------

    @Test fun jsonOutputIsWellFormedAndParseable() {
        val previous = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5, sessionId = "s0"))
        val current = listOf(record(SpecializedFeatureType.PORE_LIKE, AnatomicalRegion.NOSE, 0.5, 0.5))
        val result = FeatureLongitudinalTrendAnalyzer.analyze(previous, current, highlyComparable)
        val json = JSONObject(FeatureLongitudinalTrendAnalyzer.json(result))
        assertEquals(false, json.getBoolean("medical_diagnosis"))
        assertTrue(json.has("summaries"))
        assertTrue(json.has("regional_metrics"))
        assertTrue(json.has("changes"))
        assertTrue(json.getJSONArray("summaries").length() >= 1)
    }
}
