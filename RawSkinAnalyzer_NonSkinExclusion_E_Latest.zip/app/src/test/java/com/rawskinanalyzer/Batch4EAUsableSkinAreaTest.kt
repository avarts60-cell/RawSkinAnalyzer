package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4E-A. Plain JUnit, no android.* dependency — same pattern as prior batch test files.
 * Covers [UsableSkinAreaCalculator]: real-pixel-area computation from a region's MACRO tile,
 * the original-vs-normalized-pixel area-basis distinction, the MEDIUM-confidence 0.6 weighting
 * (matching [SkinSegmentationEngine]'s own weight), the UNAVAILABLE case when no MACRO tile
 * exists, the null-not-zero contract for [UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels]
 * when usable area is zero, and [UsableSkinAreaCalculator.totalForView] aggregation.
 */
class Batch4EAUsableSkinAreaTest {

    private fun macroTile(
        width: Int, height: Int, originalAvailable: Boolean,
        skinCoverage: Double, highSkinCoverage: Double, excludedCoverage: Double
    ) = AnalysisTile(
        tileId = "t0", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, scale = AnalysisScale.MACRO,
        sourceX = 0, sourceY = 0, width = width, height = height,
        originalImageWidth = if (originalAvailable) 4080 else null,
        originalImageHeight = if (originalAvailable) 3060 else null,
        originalCoordinatesAvailable = originalAvailable,
        skinCoverage = skinCoverage, highConfidenceSkinCoverage = highSkinCoverage, excludedCoverage = excludedCoverage,
        geometryConfidence = 0.9
    )

    private fun tileSet(macro: AnalysisTile?, skin: Double, high: Double, excl: Double) = MultiScaleTileSet(
        view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD,
        macroTiles = if (macro == null) emptyList() else listOf(macro),
        mesoTiles = emptyList(), microTiles = emptyList(),
        regionSkinCoverage = skin, regionHighConfidenceSkinCoverage = high, regionExcludedCoverage = excl,
        fineTilingSkippedReason = null
    )

    @Test
    fun realPixelArea_whenOriginalCoordinatesAvailable() {
        // 1000x500 region, 80% usable skin (60% high, 20% medium), 10% excluded.
        val macro = macroTile(width = 1000, height = 500, originalAvailable = true, skinCoverage = 80.0, highSkinCoverage = 60.0, excludedCoverage = 10.0)
        val ts = tileSet(macro, 80.0, 60.0, 10.0)
        val result = UsableSkinAreaCalculator.forRegion("FRONT FACE", ts)

        assertEquals("ORIGINAL_IMAGE_PIXELS", result.areaBasis)
        assertEquals(500_000L, result.totalRegionAreaPixels) // 1000*500
        assertEquals(300_000.0, result.highConfidenceSkinAreaPixels, 0.01) // 500000*0.60
        assertEquals(100_000.0, result.mediumConfidenceSkinAreaPixels, 0.01) // 500000*0.20
        assertEquals(400_000.0, result.usableSkinAreaPixels, 0.01) // high+medium
        assertEquals(50_000.0, result.excludedAreaPixels, 0.01) // 500000*0.10
        // confidence-weighted: 300000*1.0 + 100000*0.6 = 360000
        assertEquals(360_000.0, result.confidenceWeightedSkinAreaPixels, 0.01)
    }

    @Test
    fun fallsBackToNormalizedPixels_whenOriginalScaleUnavailable() {
        val macro = macroTile(width = 200, height = 100, originalAvailable = false, skinCoverage = 50.0, highSkinCoverage = 25.0, excludedCoverage = 5.0)
        val ts = tileSet(macro, 50.0, 25.0, 5.0)
        val result = UsableSkinAreaCalculator.forRegion("FRONT FACE", ts)

        assertEquals("NORMALIZED_IMAGE_PIXELS_FALLBACK", result.areaBasis)
        assertEquals(20_000L, result.totalRegionAreaPixels)
    }

    @Test
    fun unavailable_whenNoMacroTileExists() {
        val ts = tileSet(null, 0.0, 0.0, 0.0)
        val result = UsableSkinAreaCalculator.forRegion("FRONT FACE", ts)

        assertEquals("UNAVAILABLE", result.areaBasis)
        assertEquals(0L, result.totalRegionAreaPixels)
        assertEquals(0.0, result.usableSkinAreaPixels, 0.0001)
    }

    @Test
    fun density_isNull_notZero_whenUsableAreaIsZero() {
        val d = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 3, usableSkinAreaPixels = 0.0)
        assertNull(d)
    }

    @Test
    fun density_isRealPerMillionPixelFigure() {
        // 2 candidates over 500,000 usable pixels => 2 / 500000 * 1,000,000 = 4.0
        val d = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 2, usableSkinAreaPixels = 500_000.0)
        assertEquals(4.0, d!!, 0.0001)
    }

    @Test
    fun totalForView_sumsAcrossRegions() {
        val macroA = macroTile(width = 1000, height = 500, originalAvailable = true, skinCoverage = 80.0, highSkinCoverage = 60.0, excludedCoverage = 10.0)
        val macroB = macroTile(width = 400, height = 400, originalAvailable = true, skinCoverage = 50.0, highSkinCoverage = 50.0, excludedCoverage = 0.0)
        val regions = listOf(
            UsableSkinAreaCalculator.forRegion("FRONT FACE", tileSet(macroA, 80.0, 60.0, 10.0)),
            UsableSkinAreaCalculator.forRegion("FRONT FACE", tileSet(macroB, 50.0, 50.0, 0.0))
        )
        val total = UsableSkinAreaCalculator.totalForView(regions)

        assertEquals(2, total.regionsIncluded)
        assertEquals(500_000L + 160_000L, total.totalAreaPixels) // 1000*500 + 400*400
        assertTrue(total.usableSkinAreaPixels > 0.0)
        assertEquals("ORIGINAL_IMAGE_PIXELS", total.areaBasis)
    }

    @Test
    fun totalForView_handlesEmptyList() {
        val total = UsableSkinAreaCalculator.totalForView(emptyList())
        assertEquals(0, total.regionsIncluded)
        assertEquals("UNAVAILABLE", total.areaBasis)
    }

    // ------------------------------------------------------------------
    // Batch 4E-C, step_1: the fractional (Double candidateCount) overload used for
    // CandidateQualityGate-weighted density -- same formula/null contract as the Int overload
    // above, exercised separately since it's a genuine second overload, not a reuse of the first.
    // ------------------------------------------------------------------

    @Test
    fun fractionalDensity_isNull_notZero_whenUsableAreaIsZero() {
        val d = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 3.0, usableSkinAreaPixels = 0.0)
        assertNull(d)
    }

    @Test
    fun fractionalDensity_matchesIntOverload_whenCountIsWhole() {
        val intVersion = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 2, usableSkinAreaPixels = 500_000.0)
        val doubleVersion = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 2.0, usableSkinAreaPixels = 500_000.0)
        assertEquals(intVersion!!, doubleVersion!!, 0.0001)
    }

    @Test
    fun fractionalDensity_reflectsPartialWeight_belowFullCountDensity() {
        // 5 raw candidates, but only 2.0 quality-weighted (e.g. some REJECTed, one WEIGHTed at
        // 0.5, one at 0.4, three ACCEPTed at 1.0 each minus rejects -- exact mix doesn't matter,
        // only that a fractional weighted total produces a proportionally lower density than the
        // full raw count would).
        val rawDensity = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 5, usableSkinAreaPixels = 100_000.0)
        val gatedDensity = UsableSkinAreaCalculator.densityPerMillionUsableSkinPixels(candidateCount = 2.0, usableSkinAreaPixels = 100_000.0)
        assertTrue(gatedDensity!! < rawDensity!!)
        assertEquals(20.0, gatedDensity, 0.0001) // 2.0 / 100000 * 1,000,000
    }
}
