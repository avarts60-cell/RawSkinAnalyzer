package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4E-B, step_5. Plain JUnit, no android.* dependency. Covers [CandidateQualityGate]: clean
 * ACCEPT, high exclusion-overlap REJECT, low skin-confidence REJECT, PARTIALLY_SUPPORTED/UNCERTAIN
 * WEIGHT, MICRO-only never rejects (only weights down), missing-candidate INSUFFICIENT_DATA,
 * per-feature-class threshold differences (structural vs localized-concern), reduced/low capture
 * quality only ever lowering weight, and that REJECT always carries weight 0.0 while WEIGHT never
 * exceeds 1.0.
 */
class Batch4EBCandidateQualityGateTest {

    private fun morphology() = CandidateMorphology(
        boundingBoxX = 10, boundingBoxY = 10, boundingBoxWidth = 8, boundingBoxHeight = 8,
        centroidX = 14, centroidY = 14, areaPixels = 64, perimeterCells = 20,
        aspectRatio = 1.0, circularity = 0.7, elongation = 1.1, localContrast = 0.5,
        brightness = 0.5, meanCb = 128.0, meanCr = 128.0, edgeStrength = 0.4, textureVariance = 0.2
    )

    private fun skinSupport(skinConfidence: Double, exclusionOverlap: Double) = CandidateSkinSupport(
        skinConfidenceAtLocation = skinConfidence, highConfidenceSkinFraction = skinConfidence / 100.0,
        exclusionOverlap = exclusionOverlap, skinWeight = (skinConfidence / 100.0).coerceIn(0.0, 1.0)
    )

    private fun evidenceRec(featureType: SpecializedFeatureType, skinConfidence: Double, scale: AnalysisScale, state: FeatureClassificationState, primaryConfidence: Double = 0.7) =
        SpecializedFeatureEvidence(
            featureType = featureType, candidateId = "c1", primaryConfidence = primaryConfidence, secondaryConfidence = 0.1,
            sourceView = "FRONT FACE", anatomicalRegion = AnatomicalRegion.FOREHEAD,
            sourceCoordinates = 14 to 14, boundingBox = intArrayOf(10, 10, 8, 8), scale = scale,
            area = 64, shape = "COMPACT_ROUND", skinConfidence = skinConfidence,
            supportingSignals = listOf("compactness"), evidenceReasons = listOf("test"), classificationState = state
        )

    private fun candidate(featureType: SpecializedFeatureType, skinConfidence: Double, exclusionOverlap: Double, scale: AnalysisScale, confidence: Double = 0.7) = VisualFeatureCandidate(
        candidateId = "c1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = scale,
        morphology = morphology(), skinSupport = skinSupport(skinConfidence, exclusionOverlap),
        evidence = FeatureEvidence(0.1, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
        classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), confidence, listOf("test")),
        candidateConfidence = confidence
    )

    @Test
    fun cleanAccept_supportedStructural_highSkinConfidence_lowExclusion() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val cand = candidate(SpecializedFeatureType.PORE_LIKE, 70.0, 5.0, AnalysisScale.MESO)
        val d = CandidateQualityGate.evaluate(ev, cand, CaptureQualityReliability.RELIABLE)
        assertEquals(CandidateQualityStatus.ACCEPT, d.status)
        assertEquals(1.0, d.weight, 0.0001)
    }

    @Test
    fun highExclusionOverlap_rejectsRegardlessOfConfidence() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val cand = candidate(SpecializedFeatureType.PORE_LIKE, 70.0, 90.0, AnalysisScale.MESO)
        val d = CandidateQualityGate.evaluate(ev, cand)
        assertEquals(CandidateQualityStatus.REJECT, d.status)
        assertEquals(0.0, d.weight, 0.0001)
    }

    @Test
    fun lowSkinConfidence_rejects() {
        val ev = evidenceRec(SpecializedFeatureType.BLEMISH_LIKE, 10.0, AnalysisScale.MESO, FeatureClassificationState.PARTIALLY_SUPPORTED)
        val cand = candidate(SpecializedFeatureType.BLEMISH_LIKE, 10.0, 5.0, AnalysisScale.MESO)
        val d = CandidateQualityGate.evaluate(ev, cand)
        assertEquals(CandidateQualityStatus.REJECT, d.status)
    }

    @Test
    fun partiallySupported_weighsDownButDoesNotReject() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 55.0, AnalysisScale.MESO, FeatureClassificationState.PARTIALLY_SUPPORTED)
        val cand = candidate(SpecializedFeatureType.PORE_LIKE, 55.0, 10.0, AnalysisScale.MESO)
        val d = CandidateQualityGate.evaluate(ev, cand)
        assertEquals(CandidateQualityStatus.WEIGHT, d.status)
        assertTrue(d.weight in 0.0..1.0)
        assertTrue(d.weight < 1.0)
    }

    @Test
    fun microOnly_neverRejects_onlyWeighsDown() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MICRO, FeatureClassificationState.SUPPORTED)
        val cand = candidate(SpecializedFeatureType.PORE_LIKE, 70.0, 5.0, AnalysisScale.MICRO)
        val d = CandidateQualityGate.evaluate(ev, cand)
        assertTrue("MICRO-only must never REJECT on its own", d.status != CandidateQualityStatus.REJECT)
        assertEquals(CandidateQualityStatus.WEIGHT, d.status)
        assertTrue(d.weight < 1.0)
    }

    @Test
    fun missingCandidate_supportedEvidence_stillUsable() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val d = CandidateQualityGate.evaluate(ev, null)
        assertTrue(d.status == CandidateQualityStatus.ACCEPT || d.status == CandidateQualityStatus.WEIGHT)
    }

    @Test
    fun missingCandidate_unsupportedEvidence_isInsufficientData() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 40.0, AnalysisScale.MESO, FeatureClassificationState.PARTIALLY_SUPPORTED)
        val d = CandidateQualityGate.evaluate(ev, null)
        assertEquals(CandidateQualityStatus.INSUFFICIENT_DATA, d.status)
        assertTrue(d.weight <= 1.0)
    }

    @Test
    fun localizedConcern_needsHigherSkinConfidenceThanStructural_toAccept() {
        // 50.0 clears PORE_LIKE's (structural) accept bar of 45.0 but not BLEMISH_LIKE's
        // (localized concern) accept bar of 60.0.
        val structural = candidate(SpecializedFeatureType.PORE_LIKE, 50.0, 5.0, AnalysisScale.MESO)
        val structuralEv = evidenceRec(SpecializedFeatureType.PORE_LIKE, 50.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val structuralDecision = CandidateQualityGate.evaluate(structuralEv, structural)
        assertEquals(CandidateQualityStatus.ACCEPT, structuralDecision.status)

        val concern = candidate(SpecializedFeatureType.BLEMISH_LIKE, 50.0, 5.0, AnalysisScale.MESO)
        val concernEv = evidenceRec(SpecializedFeatureType.BLEMISH_LIKE, 50.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val concernDecision = CandidateQualityGate.evaluate(concernEv, concern)
        assertTrue("BLEMISH_LIKE needs a higher skin-confidence bar than PORE_LIKE to ACCEPT", concernDecision.status != CandidateQualityStatus.ACCEPT)
    }

    @Test
    fun lowCaptureQuality_onlyLowersWeight_neverRejectsOnItsOwn() {
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val cand = candidate(SpecializedFeatureType.PORE_LIKE, 70.0, 5.0, AnalysisScale.MESO)
        val reliable = CandidateQualityGate.evaluate(ev, cand, CaptureQualityReliability.RELIABLE)
        val low = CandidateQualityGate.evaluate(ev, cand, CaptureQualityReliability.LOW)
        assertTrue(low.status != CandidateQualityStatus.REJECT)
        assertTrue("low capture quality must not increase weight above the reliable case", low.weight <= reliable.weight)
    }

    @Test
    fun evaluateAll_returnsExactlyOneDecisionPerEvidenceItem_nothingDropped() {
        val items = listOf(
            evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED).copy(candidateId = "a"),
            evidenceRec(SpecializedFeatureType.PORE_LIKE, 5.0, AnalysisScale.MESO, FeatureClassificationState.UNCERTAIN).copy(candidateId = "b")
        )
        val decisions = CandidateQualityGate.evaluateAll(items, emptyMap())
        assertEquals(2, decisions.size)
        assertTrue(decisions.containsKey("a") && decisions.containsKey("b"))
    }
}
