package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4E-B, step_1. Plain JUnit, no android.* dependency — same pattern as every prior batch
 * test file in this project. Covers [DensityIntegratedScoring]: no-evidence no-op, a nudge
 * toward high real density, a nudge toward low real density, characteristics with no matching
 * evidence left untouched, null-density regions excluded (not treated as zero), the shine path
 * (RegionalShineSummary, not SpecializedRegionalMetric), and that a nudge never exceeds the
 * documented cap.
 */
class Batch4EBDensityIntegrationTest {

    private fun finding(characteristic: String, score: Double) =
        FinalSkinFinding(characteristic, score, "MODERATE_SIGNAL", 1, "evidence", "MODERATE")

    private fun baseProfile(scores: Map<String, Double>): FinalSkinAnalysisProfile {
        val findings = scores.entries.mapIndexed { i, (c, s) -> finding(c, s).copy(priority = i + 1) }
        return FinalSkinAnalysisProfile(
            findings = findings,
            primaryFinding = findings.first().characteristic,
            secondaryFinding = findings.getOrElse(1) { findings.first() }.characteristic,
            overallProfile = "MULTI_FACTOR_VISIBLE_SKIN_PROFILE",
            analysisConfidence = "MODERATE",
            rednessScore = scores["REDNESS"] ?: 0.0,
            pigmentationScore = scores["PIGMENTATION_OR_TONE_VARIATION"] ?: 0.0,
            darkMarkScore = scores["DARK_MARK_SIGNAL"] ?: 0.0,
            blemishLikeScore = scores["BLEMISH_LIKE_FEATURES"] ?: 0.0,
            textureIrregularityScore = scores["TEXTURE_IRREGULARITY"] ?: 0.0,
            poreLikeScore = scores["PORE_LIKE_FEATURES"] ?: 0.0,
            surfaceShineScore = scores["SURFACE_SHINE_SIGNAL"] ?: 0.0,
            drynessRelatedScore = scores["DRYNESS_RELATED_SURFACE_SIGNAL"] ?: 0.0
        )
    }

    // Batch 4E-C: qualityGatedDensity defaults to the same value as the raw density (as if every
    // candidate ACCEPTed), so every pre-existing test below -- written before quality-gated
    // density existed -- keeps exercising the same "gated density drives the nudge" code path
    // with an unchanged expected outcome, per this batch's own "do not silently change unrelated
    // legacy metrics."
    private fun poreMetric(density: Double?, qualityGatedDensity: Double? = density) = SpecializedRegionalMetric(
        view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, featureType = SpecializedFeatureType.PORE_LIKE,
        rawCount = 5, skinWeightedCount = 4.0, densityPer1000Cells = 12.0, coveragePixels = 500L,
        averageApparentSizePixels = 20.0, meanVisibility = 0.5, meanConfidence = 0.7, regionSkinCoverage = 60.0,
        usableSkinAreaPixels = 100000.0, areaBasis = "ORIGINAL_IMAGE_PIXELS",
        densityPerMillionUsableSkinPixels = density,
        qualityGatedDensityPerMillionUsableSkinPixels = qualityGatedDensity
    )

    private fun shineSummary(density: Double?) = RegionalShineSummary(
        view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, regionSkinCoverage = 60.0,
        candidateCount = 3, totalShineAreaPixels = 200L, meanRelativeIntensity = 0.4, meanConfidence = 0.6,
        shineDensityPer1000Cells = 8.0, usableSkinAreaPixels = 100000.0, areaBasis = "ORIGINAL_IMAGE_PIXELS",
        densityPerMillionUsableSkinPixels = density
    )

    @Test
    fun noEvidence_returnsBaseUnchanged() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 20.0))
        val result = DensityIntegratedScoring.apply(base, emptyList(), emptyList())
        assertEquals(base, result)
    }

    @Test
    fun highRealDensity_nudgesScoreUpward_andMarksEvidence() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 10.0))
        // 80.0 density / 40.0 reference * 100 = 200 -> clamped to 100 densitySignal, well above base score.
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(80.0)), emptyList())
        val f = result.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }
        assertTrue("score should increase toward the density signal", f.score > 10.0)
        assertTrue(f.hasHighResolutionDensityEvidence)
        assertEquals(1, f.highResolutionDensitySupportingRegionCount)
        assertEquals(f.score, result.poreLikeScore, 0.0001)
    }

    @Test
    fun lowRealDensity_nudgesScoreDownward() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 50.0))
        // 0.0 density -> densitySignal 0.0, below the base score of 50.0.
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(0.0)), emptyList())
        val f = result.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }
        assertTrue("score should decrease toward the low density signal", f.score < 50.0)
    }

    @Test
    fun nudgeNeverExceedsDocumentedCap() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 0.0))
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(1000.0)), emptyList())
        val f = result.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }
        assertTrue("nudge must be capped at 8.0 points", f.score <= 8.0001)
    }

    @Test
    fun characteristicWithNoMatchingEvidence_isUntouched() {
        val base = baseProfile(mapOf("TEXTURE_IRREGULARITY" to 33.0, "PORE_LIKE_FEATURES" to 10.0))
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(80.0)), emptyList())
        val texture = result.findings.first { it.characteristic == "TEXTURE_IRREGULARITY" }
        assertEquals(33.0, texture.score, 0.0001)
        assertFalse(texture.hasHighResolutionDensityEvidence)
    }

    @Test
    fun nullDensityRegions_areExcludedNotTreatedAsZero() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 40.0))
        // Every metric has null density (usable area unavailable) -> no evidence at all, not a
        // zero-density nudge.
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(null), poreMetric(null)), emptyList())
        val f = result.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }
        assertEquals(40.0, f.score, 0.0001)
        assertFalse(f.hasHighResolutionDensityEvidence)
    }

    @Test
    fun mixedNullAndRealDensity_onlyCountsRealRegions() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 10.0))
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(null), poreMetric(80.0)), emptyList())
        val f = result.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }
        assertTrue(f.hasHighResolutionDensityEvidence)
        assertEquals(1, f.highResolutionDensitySupportingRegionCount)
    }

    @Test
    fun shineDensity_nudgesSurfaceShineSignal_viaRegionalShineSummaryNotSpecializedFeatureType() {
        val base = baseProfile(mapOf("SURFACE_SHINE_SIGNAL" to 5.0))
        val result = DensityIntegratedScoring.apply(base, emptyList(), listOf(shineSummary(60.0)))
        val f = result.findings.first { it.characteristic == "SURFACE_SHINE_SIGNAL" }
        assertTrue(f.score > 5.0)
        assertEquals(f.score, result.surfaceShineScore, 0.0001)
    }

    @Test
    fun priorityIsRecomputedAfterNudging() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 5.0, "REDNESS" to 50.0))
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(200.0)), emptyList())
        // Pore-like was nudged up but capped at +8 (=13.0), still below REDNESS's untouched 50.0,
        // so REDNESS should remain priority 1.
        val redness = result.findings.first { it.characteristic == "REDNESS" }
        assertEquals(1, redness.priority)
    }

    // ------------------------------------------------------------------
    // Batch 4E-C, step_1: candidate-quality-gated density actually drives the nudge.
    // ------------------------------------------------------------------

    @Test
    fun rejectedCandidates_useGatedZeroDensity_notRawHighDensity() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 50.0))
        // Raw density says "very high" (80.0), but every candidate was REJECTed by the quality
        // gate, so the gated density is 0.0 -- the nudge must follow the gated figure, not the
        // raw one, per "a rejected candidate must not contribute to quality-gated density."
        val result = DensityIntegratedScoring.apply(base, listOf(poreMetric(density = 80.0, qualityGatedDensity = 0.0)), emptyList())
        val f = result.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }
        assertTrue("score should move toward the gated (low) density, not the raw (high) one", f.score < 50.0)
    }

    @Test
    fun weightedCandidates_useFractionalGatedDensity_belowRawDensity() {
        val base = baseProfile(mapOf("PORE_LIKE_FEATURES" to 10.0))
        // Raw density 80.0 (as if every candidate counted fully); gated density only 20.0 (as if
        // most candidates were WEIGHTed down or REJECTed) -- the resulting nudge must be smaller
        // than what the raw density alone would have produced.
        val gatedResult = DensityIntegratedScoring.apply(base, listOf(poreMetric(density = 80.0, qualityGatedDensity = 20.0)), emptyList())
        val rawOnlyResult = DensityIntegratedScoring.apply(base, listOf(poreMetric(density = 80.0, qualityGatedDensity = 80.0)), emptyList())
        val gatedScore = gatedResult.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }.score
        val rawOnlyScore = rawOnlyResult.findings.first { it.characteristic == "PORE_LIKE_FEATURES" }.score
        assertTrue("gated (partially-weighted) density must nudge less than full raw density", gatedScore < rawOnlyScore)
    }

    @Test
    fun shineHasNoQualityGateIntegration_fallsBackToRawDensity() {
        val base = baseProfile(mapOf("SURFACE_SHINE_SIGNAL" to 5.0))
        // RegionalShineSummary carries no quality-gate fields at all -- confirms the documented
        // fallback-to-raw path for shine specifically still nudges using the raw density.
        val result = DensityIntegratedScoring.apply(base, emptyList(), listOf(shineSummary(60.0)))
        val f = result.findings.first { it.characteristic == "SURFACE_SHINE_SIGNAL" }
        assertTrue("shine must still nudge from its raw density (no gate integration exists for it)", f.score > 5.0)
    }
}
