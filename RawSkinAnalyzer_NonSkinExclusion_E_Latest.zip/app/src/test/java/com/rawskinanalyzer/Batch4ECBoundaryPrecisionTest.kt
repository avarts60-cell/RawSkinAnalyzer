package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4E-C, step_2 — candidate boundary precision.
 *
 * Covers: [MultiScaleTileExtractor.toNormalized] as the exact inverse of [MultiScaleTileExtractor.toOriginal];
 * [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport]'s null-vs-real-value contract (never a
 * fabricated 0.0/100.0); and [CandidateQualityGate] actually preferring a candidate's boundary-refined
 * skin support over its whole-tile-aggregate one when both are present.
 */
class Batch4ECBoundaryPrecisionTest {

    private fun geom(normW: Int = 120, normH: Int = 120, origW: Int? = 240, origH: Int? = 240, scaleAvailable: Boolean = true) = FaceGeometryResult(
        faceDetected = true, faceDetectionConfidence = 0.9, bounds = null,
        landmarks = emptyList(), contours = emptyList(),
        normalizedImageWidth = normW, normalizedImageHeight = normH,
        originalImageWidth = origW, originalImageHeight = origH,
        originalScaleAvailable = scaleAvailable,
        landmarkCompleteness = 0.5, contourCompleteness = 0.5,
        geometryConfidence = 0.5, notes = emptyList()
    )

    // grid=6 over a 120x120 normalized image -> each cell is 20x20 normalized pixels.
    // Cell (row=0, col=0) is fully "skin" (100%); cell (row=0, col=1) is fully "excluded" (100% non-skin).
    private fun cells(): List<PatternMapCell> = listOf(
        PatternMapCell(row = 0, col = 0, samples = 100, skinPercent = 100.0, meanLuma = 150.0, redness = 5.0, texture = 1.0, darkPercent = 0.0,
            highConfidenceSkinPercent = 90.0, excludedShadowPercent = 0.0, excludedHighlightPercent = 0.0, excludedNonSkinPercent = 0.0, uncertainPercent = 0.0, meanConfidenceWeight = 1.0),
        PatternMapCell(row = 0, col = 1, samples = 100, skinPercent = 0.0, meanLuma = 50.0, redness = 0.0, texture = 0.0, darkPercent = 80.0,
            highConfidenceSkinPercent = 0.0, excludedShadowPercent = 0.0, excludedHighlightPercent = 0.0, excludedNonSkinPercent = 100.0, uncertainPercent = 0.0, meanConfidenceWeight = 1.0)
    )

    // ------------------------------------------------------------------
    // toNormalized / toOriginal — exact algebraic inverse
    // ------------------------------------------------------------------

    @Test
    fun toNormalized_isExactInverseOf_toOriginal() {
        val g = geom(normW = 120, normH = 120, origW = 240, origH = 240)
        val original = MultiScaleTileExtractor.toOriginal(30f, 40f, g)!!
        val backToNormalized = MultiScaleTileExtractor.toNormalized(original.first, original.second, g)!!
        assertEquals(30.0, backToNormalized.first.toDouble(), 0.01)
        assertEquals(40.0, backToNormalized.second.toDouble(), 0.01)
    }

    @Test
    fun toNormalized_returnsNull_whenNoScaleAvailable() {
        val g = geom(scaleAvailable = false)
        assertNull(MultiScaleTileExtractor.toNormalized(10f, 10f, g))
    }

    // ------------------------------------------------------------------
    // refineCandidateSkinSupport — null contract
    // ------------------------------------------------------------------

    @Test
    fun refine_returnsNull_whenCellsEmpty() {
        val g = geom()
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(0, 0, 10, 10), emptyList(), 6, 120, 120, g
        )
        assertNull(result)
    }

    @Test
    fun refine_returnsNull_whenBoundingBoxHasZeroArea() {
        val g = geom()
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(0, 0, 0, 10), cells(), 6, 120, 120, g
        )
        assertNull(result)
    }

    @Test
    fun refine_returnsNull_whenNoScaleAvailable() {
        val g = geom(scaleAvailable = false)
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(0, 0, 10, 10), cells(), 6, 120, 120, g
        )
        assertNull(result)
    }

    @Test
    fun refine_returnsNull_whenFootprintOverlapsNoCell() {
        val g = geom()
        // Original-image box far outside the 240x240 original image / cell grid entirely.
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(10_000, 10_000, 10, 10), cells(), 6, 120, 120, g
        )
        assertNull(result)
    }

    @Test
    fun refine_candidateEntirelyInSkinCell_reportsHighSkinLowExclusion() {
        val g = geom(normW = 120, normH = 120, origW = 240, origH = 240)
        // Cell (0,0) spans normalized [0,20]x[0,20] -> original [0,40]x[0,40] (2x scale).
        // A candidate box entirely inside that -> original [5,5,10,10].
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(5, 5, 10, 10), cells(), 6, 120, 120, g
        )
        assertNotNull(result)
        assertEquals(100.0, result!!.skinCoverage, 0.01)
        assertEquals(0.0, result.excludedCoverage, 0.01)
        assertTrue(result.cellsOverlapped >= 1)
    }

    @Test
    fun refine_candidateEntirelyInExcludedCell_reportsLowSkinHighExclusion() {
        val g = geom(normW = 120, normH = 120, origW = 240, origH = 240)
        // Cell (0,1) spans normalized [20,40]x[0,20] -> original [40,80]x[0,40].
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(50, 5, 10, 10), cells(), 6, 120, 120, g
        )
        assertNotNull(result)
        assertEquals(0.0, result!!.skinCoverage, 0.01)
        assertEquals(100.0, result.excludedCoverage, 0.01)
    }

    // ------------------------------------------------------------------
    // CandidateQualityGate actually preferring boundary-refined values
    // ------------------------------------------------------------------

    private fun morphology() = CandidateMorphology(
        boundingBoxX = 10, boundingBoxY = 10, boundingBoxWidth = 8, boundingBoxHeight = 8,
        centroidX = 14, centroidY = 14, areaPixels = 64, perimeterCells = 20,
        aspectRatio = 1.0, circularity = 0.7, elongation = 1.1, localContrast = 0.5,
        brightness = 0.5, meanCb = 128.0, meanCr = 128.0, edgeStrength = 0.4, textureVariance = 0.2
    )

    private fun evidenceRec(featureType: SpecializedFeatureType, skinConfidence: Double, scale: AnalysisScale, state: FeatureClassificationState) =
        SpecializedFeatureEvidence(
            featureType = featureType, candidateId = "c1", primaryConfidence = 0.7, secondaryConfidence = 0.1,
            sourceView = "FRONT FACE", anatomicalRegion = AnatomicalRegion.FOREHEAD,
            sourceCoordinates = 14 to 14, boundingBox = intArrayOf(10, 10, 8, 8), scale = scale,
            area = 64, shape = "COMPACT_ROUND", skinConfidence = skinConfidence,
            supportingSignals = listOf("compactness"), evidenceReasons = listOf("test"), classificationState = state
        )

    @Test
    fun gate_prefersBoundaryRefinedSkinConfidence_overTileWideAggregate_forReject() {
        // Tile-wide aggregate looks fine (70), but the candidate's OWN footprint boundary
        // refinement says it's actually mostly non-skin (skin confidence 5, exclusion 95) --
        // the gate must REJECT based on the more precise boundary figures, not ACCEPT based on
        // the coarser tile-wide ones.
        val skinSupport = CandidateSkinSupport(
            skinConfidenceAtLocation = 70.0, highConfidenceSkinFraction = 0.6, exclusionOverlap = 5.0, skinWeight = 0.7,
            boundarySkinConfidenceAtLocation = 5.0, boundaryHighConfidenceSkinFraction = 0.0,
            boundaryExclusionOverlap = 95.0, boundaryCellsOverlapped = 3
        )
        val candidate = VisualFeatureCandidate(
            candidateId = "c1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
            morphology = morphology(), skinSupport = skinSupport,
            evidence = FeatureEvidence(0.1, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
            classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), 0.7, listOf("test")),
            candidateConfidence = 0.7
        )
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val decision = CandidateQualityGate.evaluate(ev, candidate)
        assertEquals(CandidateQualityStatus.REJECT, decision.status)
        assertTrue(decision.reasons.any { it.contains("boundary_geometry_confidence_available") })
    }

    @Test
    fun gate_fallsBackToTileWideAggregate_whenNoBoundaryRefinementPresent() {
        // Same tile-wide values as the previous test's candidate, but with no boundary
        // refinement at all -- must fall back to the pre-4E-C tile-wide skinConfidenceAtLocation
        // (70, well above ACCEPT bar) rather than rejecting.
        val skinSupport = CandidateSkinSupport(
            skinConfidenceAtLocation = 70.0, highConfidenceSkinFraction = 0.6, exclusionOverlap = 5.0, skinWeight = 0.7
        )
        val candidate = VisualFeatureCandidate(
            candidateId = "c1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
            morphology = morphology(), skinSupport = skinSupport,
            evidence = FeatureEvidence(0.1, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
            classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), 0.7, listOf("test")),
            candidateConfidence = 0.7
        )
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 70.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val decision = CandidateQualityGate.evaluate(ev, candidate)
        assertEquals(CandidateQualityStatus.ACCEPT, decision.status)
        assertTrue(decision.reasons.any { it.contains("no_boundary_geometry_confidence_available") })
    }
}
