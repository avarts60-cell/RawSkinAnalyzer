package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

/**
 * Batch 4E-D, step_3 — extending candidate-level boundary skin support to shine and bump
 * candidates.
 *
 * PROJECT_STATUS.md recorded this exact gap after Batch 4E-C step_2 ("Shine and bumps remain
 * un-refined at the boundary level ... both reuse VisualFeatureCandidateEngine.skinSupportFor
 * directly on a tile, not through analyzeRegion, so they are unaffected by this change and still
 * use tile-wide skin support only. A real, documented gap, not a silent one."). This test covers
 * the model/serialization side of closing that gap: [ShineCandidate] and [BumpCandidate] can now
 * carry the same four boundary-refinement fields [CandidateSkinSupport] already carries for
 * structural candidates, default to null (never fabricated), and serialize identically to the
 * existing `boundary_refinement` JSON convention ([VisualFeatureJson.skinSupportJson]).
 *
 * Full analyzeRegion()/analyzeView() end-to-end coverage (real pixel decode -> real refinement
 * value) is intentionally NOT duplicated here: [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport]
 * itself is already fully covered by [Batch4ECBoundaryPrecisionTest], and ShineDetectionEngine/
 * BumpSurfaceStructureEngine call that exact same function with the exact same boundingBox/cells/
 * grid/geom shape VisualFeatureCandidateEngine.analyzeRegion already does (verified by inspection,
 * not re-tested here to avoid a third redundant copy of the same null-contract test matrix).
 */
class Batch4EDShineBumpBoundarySupportTest {

    private fun shineCandidate(
        boundarySkin: Double? = null,
        boundaryHigh: Double? = null,
        boundaryExcl: Double? = null,
        boundaryCells: Int? = null
    ) = ShineCandidate(
        candidateId = "s1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD,
        tileId = "t1", scale = AnalysisScale.MICRO, boundingBox = intArrayOf(10, 10, 8, 8),
        centroidX = 14, centroidY = 14, areaPixels = 64,
        relativeIntensity = 0.6, chromaDesaturation = 0.5, compactness = 0.7,
        skinConfidence = 80.0, confidence = 0.55, evidenceReasons = listOf("test"),
        boundarySkinConfidenceAtLocation = boundarySkin,
        boundaryHighConfidenceSkinFraction = boundaryHigh,
        boundaryExclusionOverlap = boundaryExcl,
        boundaryCellsOverlapped = boundaryCells
    )

    private fun bumpCandidate(
        boundarySkin: Double? = null,
        boundaryHigh: Double? = null,
        boundaryExcl: Double? = null,
        boundaryCells: Int? = null
    ) = BumpCandidate(
        candidateId = "b1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD,
        tileId = "t1", scale = AnalysisScale.MICRO, boundingBox = intArrayOf(10, 10, 8, 8),
        centroidX = 14, centroidY = 14, areaPixels = 64,
        primaryType = SpecializedFeatureType.BUMP_LIKE,
        internalReliefContrast = 0.5, reliefAxisCoherence = 0.6, compactness = 0.7, elongation = 1.1,
        shineOverlapFraction = 0.1, skinConfidence = 80.0, confidence = 0.55,
        evidenceReasons = listOf("test"),
        boundarySkinConfidenceAtLocation = boundarySkin,
        boundaryHighConfidenceSkinFraction = boundaryHigh,
        boundaryExclusionOverlap = boundaryExcl,
        boundaryCellsOverlapped = boundaryCells
    )

    // ------------------------------------------------------------------
    // Default null contract — no fabricated values when boundary refinement wasn't computed
    // ------------------------------------------------------------------

    @Test
    fun shineCandidate_boundaryFields_defaultToNull() {
        val c = shineCandidate()
        assertNull(c.boundarySkinConfidenceAtLocation)
        assertNull(c.boundaryHighConfidenceSkinFraction)
        assertNull(c.boundaryExclusionOverlap)
        assertNull(c.boundaryCellsOverlapped)
    }

    @Test
    fun bumpCandidate_boundaryFields_defaultToNull() {
        val c = bumpCandidate()
        assertNull(c.boundarySkinConfidenceAtLocation)
        assertNull(c.boundaryHighConfidenceSkinFraction)
        assertNull(c.boundaryExclusionOverlap)
        assertNull(c.boundaryCellsOverlapped)
    }

    // ------------------------------------------------------------------
    // JSON serialization — boundary_refinement sub-object present/null, matching the existing
    // VisualFeatureJson.skinSupportJson convention
    // ------------------------------------------------------------------

    @Test
    fun shineCandidateJson_boundaryRefinement_isNull_whenNotComputed() {
        val json = SpecializedFeatureJson.shineCandidateJson(shineCandidate())
        assertTrue(json.contains("\"boundary_refinement\":null"))
    }

    @Test
    fun shineCandidateJson_boundaryRefinement_carriesRealValues_whenComputed() {
        val json = SpecializedFeatureJson.shineCandidateJson(
            shineCandidate(boundarySkin = 12.5, boundaryHigh = 0.0, boundaryExcl = 87.5, boundaryCells = 2)
        )
        assertFalse(json.contains("\"boundary_refinement\":null"))
        assertTrue(json.contains("\"skin_confidence_at_location\":12.5"))
        assertTrue(json.contains("\"exclusion_overlap\":87.5"))
        assertTrue(json.contains("\"cells_overlapped\":2"))
    }

    @Test
    fun bumpCandidateJson_boundaryRefinement_isNull_whenNotComputed() {
        val json = SpecializedFeatureJson.bumpCandidateJson(bumpCandidate())
        assertTrue(json.contains("\"boundary_refinement\":null"))
    }

    @Test
    fun bumpCandidateJson_boundaryRefinement_carriesRealValues_whenComputed() {
        val json = SpecializedFeatureJson.bumpCandidateJson(
            bumpCandidate(boundarySkin = 95.0, boundaryHigh = 0.8, boundaryExcl = 5.0, boundaryCells = 4)
        )
        assertFalse(json.contains("\"boundary_refinement\":null"))
        assertTrue(json.contains("\"skin_confidence_at_location\":95.0"))
        assertTrue(json.contains("\"high_confidence_skin_fraction\":0.8"))
        assertTrue(json.contains("\"cells_overlapped\":4"))
    }

    // ------------------------------------------------------------------
    // Engine signature contract — boundaryContext parameter is optional and additive
    // ------------------------------------------------------------------

    @Test
    fun shineDetectionEngine_analyzeView_acceptsNullBoundaryContext_sameAsOmittingIt() {
        // Both calls must compile and behave identically with an empty tile set (no image
        // decode needed) -- confirms the new parameter is truly additive/defaulted, not a
        // breaking signature change for the many existing callers/tests that don't pass it.
        val originalFile = java.io.File("/nonexistent/capture.jpg")
        val withoutContext = ShineDetectionEngine.analyzeView(originalFile, emptyList())
        val withNullContext = ShineDetectionEngine.analyzeView(originalFile, emptyList(), null)
        assertEquals(withoutContext, withNullContext)
        assertTrue(withoutContext.isEmpty())
    }

    @Test
    fun bumpSurfaceStructureEngine_analyzeView_acceptsNullBoundaryContext_sameAsOmittingIt() {
        val originalFile = java.io.File("/nonexistent/capture.jpg")
        val withoutContext = BumpSurfaceStructureEngine.analyzeView(originalFile, emptyList())
        val withNullContext = BumpSurfaceStructureEngine.analyzeView(originalFile, emptyList(), null)
        assertEquals(withoutContext, withNullContext)
        assertTrue(withoutContext.isEmpty())
    }
}
