package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Batch 4E-E, step_3/step_5/step_7 — non-skin exclusion precision.
 *
 * Covers: [FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport]'s new
 * `landmarkExclusionPolygons` parameter (candidate-own-footprint overlap against
 * landmark-derived exclusion polygons — eyes/eyebrows/lips/approximate-nostril-band/
 * outside-face — as opposed to only the pixel-color classifier's exclusion grid);
 * [CandidateQualityGate] actually using the combined (pixel + landmark) exclusion figure
 * once boundary refinement is supplied; [AnatomicalRegionMapper]'s nostril-band and
 * outside-face exclusion geometry directly; and [VisualFeatureDiagnostics.summarizeExclusion]'s
 * candidate-level exclusion diagnostics. Does NOT re-test the pre-existing pixel-classifier-only
 * contract (empty cells / zero-area box / unavailable scale / zero cell overlap) --
 * fully covered already by Batch4ECBoundaryPrecisionTest, and unchanged by this batch since
 * `landmarkExclusionPolygons` defaults to empty.
 */
class Batch4EENonSkinExclusionPrecisionTest {

    private fun geom(normW: Int = 120, normH: Int = 120, origW: Int? = 240, origH: Int? = 240, scaleAvailable: Boolean = true) = FaceGeometryResult(
        faceDetected = true, faceDetectionConfidence = 0.9, bounds = null,
        landmarks = emptyList(), contours = emptyList(),
        normalizedImageWidth = normW, normalizedImageHeight = normH,
        originalImageWidth = origW, originalImageHeight = origH,
        originalScaleAvailable = scaleAvailable,
        landmarkCompleteness = 0.5, contourCompleteness = 0.5,
        geometryConfidence = 0.5, notes = emptyList()
    )

    // grid=6 over a 120x120 normalized image -> each cell is 20x20 normalized pixels.
    // Cell (row=0, col=0) is fully "skin" (100%, 0% pixel-classifier exclusion), and has NO
    // pixel-level exclusion at all -- any exclusion measured on it must come purely from the
    // landmark-polygon overlap this batch adds.
    private fun cells(): List<PatternMapCell> = listOf(
        PatternMapCell(row = 0, col = 0, samples = 100, skinPercent = 100.0, meanLuma = 150.0, redness = 5.0, texture = 1.0, darkPercent = 0.0,
            highConfidenceSkinPercent = 90.0, excludedShadowPercent = 0.0, excludedHighlightPercent = 0.0, excludedNonSkinPercent = 0.0, uncertainPercent = 0.0, meanConfidenceWeight = 1.0)
    )

    private fun gp(x: Float, y: Float) = GeometryPoint(x, y, null, null)

    /** A square landmark-exclusion polygon spanning normalized [5,5]-[15,15] -- entirely inside cell (0,0)'s [0,20]x[0,20] span. */
    private fun eyePolygon(): List<GeometryPoint> = listOf(gp(5f, 5f), gp(15f, 5f), gp(15f, 15f), gp(5f, 15f))

    // ------------------------------------------------------------------
    // refineCandidateSkinSupport -- landmark exclusion overlap
    // ------------------------------------------------------------------

    @Test
    fun refine_withNoLandmarkPolygons_behavesExactlyAsBeforeBatch4EE() {
        val g = geom()
        // Candidate box entirely inside cell (0,0): original [10,10]-[20,20] (2x scale) -> normalized [5,5]-[10,10].
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(10, 10, 10, 10), cells(), 6, 120, 120, g
        )
        assertNotNull(result)
        assertEquals(0.0, result!!.landmarkExclusionOverlap, 0.01)
        assertEquals(0.0, result.excludedCoverage, 0.01) // no pixel exclusion, no landmark exclusion supplied
    }

    @Test
    fun refine_candidateEntirelyInsideLandmarkExclusionPolygon_reportsHighLandmarkOverlap() {
        val g = geom()
        // Candidate footprint entirely inside the eye polygon [5,5]-[15,15] normalized:
        // original [12,12]-[24,24] (2x scale) -> normalized [6,6]-[12,12], inside [5,5]-[15,15].
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(12, 12, 12, 12), cells(), 6, 120, 120, g,
            landmarkExclusionPolygons = listOf(eyePolygon())
        )
        assertNotNull(result)
        // Pixel-classifier exclusion is 0 (cell (0,0) is 100% skin), so any excludedCoverage here
        // is purely the landmark contribution -- this is the precise scenario a whole-tile/whole-cell
        // aggregate could never distinguish (the cell as a whole is mostly non-eye skin).
        assertTrue("expected substantial landmark overlap, got ${result!!.landmarkExclusionOverlap}", result!!.landmarkExclusionOverlap > 50.0)
        assertEquals(result.landmarkExclusionOverlap, result.excludedCoverage, 0.01)
    }

    @Test
    fun refine_candidateEntirelyOutsideLandmarkExclusionPolygon_reportsZeroLandmarkOverlap() {
        val g = geom()
        // Candidate footprint far from the eye polygon but still inside cell (0,0):
        // original [30,2]-[36,8] -> normalized [15,1]-[18,4], outside [5,5]-[15,15].
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(30, 2, 6, 6), cells(), 6, 120, 120, g,
            landmarkExclusionPolygons = listOf(eyePolygon())
        )
        assertNotNull(result)
        assertEquals(0.0, result!!.landmarkExclusionOverlap, 0.01)
        assertEquals(0.0, result.excludedCoverage, 0.01)
    }

    @Test
    fun refine_landmarkOverlapCombinesWithPixelExclusion_cappedAt100() {
        val g = geom()
        // Cell (0,1) [20,40]x[0,20] normalized is 100% pixel-excluded (non-skin color).
        // Put a landmark exclusion polygon over the same span so both signals fire at once.
        val cellsWithExcluded = cells() + PatternMapCell(
            row = 0, col = 1, samples = 100, skinPercent = 0.0, meanLuma = 50.0, redness = 0.0, texture = 0.0, darkPercent = 80.0,
            highConfidenceSkinPercent = 0.0, excludedShadowPercent = 0.0, excludedHighlightPercent = 0.0, excludedNonSkinPercent = 100.0, uncertainPercent = 0.0, meanConfidenceWeight = 1.0
        )
        val overlappingPolygon = listOf(gp(20f, 0f), gp(40f, 0f), gp(40f, 20f), gp(20f, 20f))
        // original [50,5]-[60,15] -> normalized [25,2.5]-[30,7.5], inside cell (0,1) and the polygon.
        val result = FaceConstrainedSkinAnalyzer.refineCandidateSkinSupport(
            intArrayOf(50, 5, 10, 10), cellsWithExcluded, 6, 120, 120, g,
            landmarkExclusionPolygons = listOf(overlappingPolygon)
        )
        assertNotNull(result)
        assertTrue(result!!.landmarkExclusionOverlap > 0.0)
        assertEquals(100.0, result.excludedCoverage, 0.01) // combined, capped at 100
    }

    // ------------------------------------------------------------------
    // AnatomicalRegionMapper -- nostril and outside-face exclusion geometry (audit, unchanged)
    // ------------------------------------------------------------------

    @Test
    fun regionMapper_producesApproximateNostrilExclusion_whenNoseContourPresent() {
        val nose = listOf(gp(40f, 60f), gp(60f, 60f), gp(60f, 80f), gp(40f, 80f))
        val g = FaceGeometryResult(
            faceDetected = true, faceDetectionConfidence = 0.8,
            bounds = FaceBounds(android.graphics.Rect(0, 0, 100, 100), null),
            landmarks = emptyList(),
            contours = listOf(FaceContourGroup(FaceLandmarkGroup.NOSE, nose)),
            normalizedImageWidth = 100, normalizedImageHeight = 100,
            originalImageWidth = null, originalImageHeight = null, originalScaleAvailable = false,
            landmarkCompleteness = 0.3, contourCompleteness = 0.3, geometryConfidence = 0.3, notes = emptyList()
        )
        val set = AnatomicalRegionMapper.map(g)
        val nostrilExclusion = set.exclusions.firstOrNull { it.category == NonSkinExclusionCategory.NOSTRILS_APPROXIMATE }
        assertNotNull("expected an approximate nostril exclusion polygon from a present NOSE contour", nostrilExclusion)
        assertEquals("APPROXIMATE_LOWER_NOSE_BAND_NO_PER_NOSTRIL_LANDMARK", nostrilExclusion!!.reason)
    }

    @Test
    fun regionMapper_producesOutsideFaceExclusion_fromFaceOutlineBoundingBox() {
        val outline = listOf(gp(10f, 10f), gp(90f, 10f), gp(90f, 90f), gp(10f, 90f))
        val g = FaceGeometryResult(
            faceDetected = true, faceDetectionConfidence = 0.8,
            bounds = FaceBounds(android.graphics.Rect(0, 0, 100, 100), null),
            landmarks = emptyList(),
            contours = listOf(FaceContourGroup(FaceLandmarkGroup.FACE_OUTLINE, outline)),
            normalizedImageWidth = 100, normalizedImageHeight = 100,
            originalImageWidth = null, originalImageHeight = null, originalScaleAvailable = false,
            landmarkCompleteness = 0.3, contourCompleteness = 0.3, geometryConfidence = 0.3, notes = emptyList()
        )
        val set = AnatomicalRegionMapper.map(g)
        val outsideFace = set.exclusions.firstOrNull { it.category == NonSkinExclusionCategory.OUTSIDE_FACE }
        assertNotNull(outsideFace)
        assertEquals(4, outsideFace!!.points.size)
    }

    // ------------------------------------------------------------------
    // CandidateQualityGate -- combined landmark+pixel exclusion actually drives the decision
    // ------------------------------------------------------------------

    private fun morphology() = CandidateMorphology(
        boundingBoxX = 10, boundingBoxY = 10, boundingBoxWidth = 8, boundingBoxHeight = 8,
        centroidX = 14, centroidY = 14, areaPixels = 64, perimeterCells = 20,
        aspectRatio = 1.0, circularity = 0.7, elongation = 1.1, localContrast = 0.5,
        brightness = 0.5, meanCb = 128.0, meanCr = 128.0, edgeStrength = 0.4, textureVariance = 0.2
    )

    private fun evidenceRec(featureType: SpecializedFeatureType, skinConfidence: Double, scale: AnalysisScale, state: FeatureClassificationState) =
        SpecializedFeatureEvidence(
            featureType = featureType, candidateId = "c1", primaryConfidence = 0.7, secondaryConfidence = 0.1,
            sourceView = "FRONT FACE", anatomicalRegion = AnatomicalRegion.FOREHEAD,
            sourceCoordinates = 14 to 14, boundingBox = intArrayOf(10, 10, 8, 8), scale = scale,
            area = 64, shape = "COMPACT_ROUND", skinConfidence = skinConfidence,
            supportingSignals = listOf("compactness"), evidenceReasons = listOf("test"), classificationState = state
        )

    @Test
    fun gate_rejectsOnLandmarkExclusionAlone_evenWhenPixelExclusionIsZero() {
        // Tile-wide aggregate and pixel-classifier boundary exclusion both look clean, but this
        // candidate's own footprint sits mostly on a landmark-excluded structure (e.g. an
        // eyebrow) -- boundaryExclusionOverlap (combined) must reflect that and REJECT, exactly
        // the scenario a pixel-color classifier alone could never catch.
        val skinSupport = CandidateSkinSupport(
            skinConfidenceAtLocation = 80.0, highConfidenceSkinFraction = 0.7, exclusionOverlap = 2.0, skinWeight = 0.8,
            boundarySkinConfidenceAtLocation = 80.0, boundaryHighConfidenceSkinFraction = 0.5,
            boundaryExclusionOverlap = 90.0, boundaryCellsOverlapped = 2,
            boundaryLandmarkExclusionOverlap = 90.0 // all of it is landmark, not pixel-classifier
        )
        val candidate = VisualFeatureCandidate(
            candidateId = "c1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
            morphology = morphology(), skinSupport = skinSupport,
            evidence = FeatureEvidence(0.1, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
            classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), 0.7, listOf("test")),
            candidateConfidence = 0.7
        )
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 80.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val decision = CandidateQualityGate.evaluate(ev, candidate)
        assertEquals(CandidateQualityStatus.REJECT, decision.status)
        assertTrue(decision.reasons.any { it.contains("landmark_exclusion_contribution") })
    }

    @Test
    fun gate_doesNotMentionLandmarkContribution_whenNoneIsPresent() {
        val skinSupport = CandidateSkinSupport(
            skinConfidenceAtLocation = 80.0, highConfidenceSkinFraction = 0.7, exclusionOverlap = 2.0, skinWeight = 0.8,
            boundarySkinConfidenceAtLocation = 80.0, boundaryHighConfidenceSkinFraction = 0.6,
            boundaryExclusionOverlap = 5.0, boundaryCellsOverlapped = 2,
            boundaryLandmarkExclusionOverlap = 0.0
        )
        val candidate = VisualFeatureCandidate(
            candidateId = "c1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
            morphology = morphology(), skinSupport = skinSupport,
            evidence = FeatureEvidence(0.1, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
            classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), 0.7, listOf("test")),
            candidateConfidence = 0.7
        )
        val ev = evidenceRec(SpecializedFeatureType.PORE_LIKE, 80.0, AnalysisScale.MESO, FeatureClassificationState.SUPPORTED)
        val decision = CandidateQualityGate.evaluate(ev, candidate)
        assertTrue(decision.reasons.none { it.contains("landmark_exclusion_contribution") })
    }

    // ------------------------------------------------------------------
    // VisualFeatureDiagnostics.summarizeExclusion
    // ------------------------------------------------------------------

    private fun candidateWith(skinSupport: CandidateSkinSupport, id: String) = VisualFeatureCandidate(
        candidateId = id, view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
        morphology = morphology(), skinSupport = skinSupport,
        evidence = FeatureEvidence(0.1, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
        classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), 0.7, listOf("test")),
        candidateConfidence = 0.7
    )

    @Test
    fun exclusionDiagnostics_countsBoundaryVsTileWideBasisAndLandmarkOverlap() {
        val withBoundaryAndLandmark = candidateWith(
            CandidateSkinSupport(
                skinConfidenceAtLocation = 80.0, highConfidenceSkinFraction = 0.7, exclusionOverlap = 2.0, skinWeight = 0.8,
                boundarySkinConfidenceAtLocation = 80.0, boundaryHighConfidenceSkinFraction = 0.5,
                boundaryExclusionOverlap = 40.0, boundaryCellsOverlapped = 2, boundaryLandmarkExclusionOverlap = 40.0
            ), "c1"
        )
        val withBoundaryNoLandmark = candidateWith(
            CandidateSkinSupport(
                skinConfidenceAtLocation = 80.0, highConfidenceSkinFraction = 0.7, exclusionOverlap = 2.0, skinWeight = 0.8,
                boundarySkinConfidenceAtLocation = 90.0, boundaryHighConfidenceSkinFraction = 0.8,
                boundaryExclusionOverlap = 0.0, boundaryCellsOverlapped = 3, boundaryLandmarkExclusionOverlap = 0.0
            ), "c2"
        )
        val tileWideOnly = candidateWith(
            CandidateSkinSupport(skinConfidenceAtLocation = 70.0, highConfidenceSkinFraction = 0.6, exclusionOverlap = 5.0, skinWeight = 0.7),
            "c3"
        )

        val diag = VisualFeatureDiagnostics.summarizeExclusion("FRONT FACE", listOf(withBoundaryAndLandmark, withBoundaryNoLandmark, tileWideOnly))

        assertEquals(3, diag.candidateCount)
        assertEquals(2, diag.candidatesWithBoundaryGeometryBasis)
        assertEquals(1, diag.candidatesWithTileWideBasisOnly)
        assertEquals(1, diag.candidatesWithLandmarkExclusion)
        assertEquals(20.0, diag.meanLandmarkExclusionOverlap, 0.01) // (40+0)/2
        assertEquals(20.0, diag.meanCombinedExclusionOverlap, 0.01) // (40+0)/2
        // No quality decisions supplied -> gate-status counts are honestly 0, not fabricated.
        assertEquals(0, diag.candidatesRejected)
        assertEquals(0, diag.candidatesWeighted)
        assertEquals(0, diag.candidatesAccepted)
    }

    @Test
    fun exclusionDiagnostics_reflectsSuppliedQualityDecisions() {
        val c = candidateWith(
            CandidateSkinSupport(skinConfidenceAtLocation = 80.0, highConfidenceSkinFraction = 0.7, exclusionOverlap = 2.0, skinWeight = 0.8),
            "c1"
        )
        val decisions = mapOf("c1" to CandidateQualityDecision(CandidateQualityStatus.REJECT, 0.0, listOf("test")))
        val diag = VisualFeatureDiagnostics.summarizeExclusion("FRONT FACE", listOf(c), decisions)
        assertEquals(1, diag.candidatesRejected)
        assertEquals(0, diag.candidatesAccepted)
    }

    // ------------------------------------------------------------------
    // SpecializedFeatureEvidenceAssembler.contaminationDiagnostics (EXACT REMAINING WORK item #2)
    // ------------------------------------------------------------------

    private fun candidateAt(id: String, boxX: Int, boxY: Int, boxW: Int, boxH: Int, hairStubbleLikelihood: Double = 0.0) = VisualFeatureCandidate(
        candidateId = id, view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
        morphology = CandidateMorphology(
            boundingBoxX = boxX, boundingBoxY = boxY, boundingBoxWidth = boxW, boundingBoxHeight = boxH,
            centroidX = boxX + boxW / 2, centroidY = boxY + boxH / 2, areaPixels = boxW * boxH, perimeterCells = 10,
            aspectRatio = 1.0, circularity = 0.7, elongation = 1.1, localContrast = 0.5,
            brightness = 0.5, meanCb = 128.0, meanCr = 128.0, edgeStrength = 0.4, textureVariance = 0.2
        ),
        skinSupport = CandidateSkinSupport(skinConfidenceAtLocation = 80.0, highConfidenceSkinFraction = 0.7, exclusionOverlap = 2.0, skinWeight = 0.8),
        evidence = FeatureEvidence(hairStubbleLikelihood, 0.1, 0.6, 0.1, 0.1, 0.1, 0.1, 0.1),
        classification = FeatureClassification(FeatureCandidateType.PORE_OR_FOLLICULAR_CANDIDATE, emptyList(), 0.7, listOf("test")),
        candidateConfidence = 0.7
    )

    private fun shineCandidateAt(boxX: Int, boxY: Int, boxW: Int, boxH: Int, confidence: Double) = ShineCandidate(
        candidateId = "shine1", view = "FRONT FACE", region = AnatomicalRegion.FOREHEAD, tileId = "t1", scale = AnalysisScale.MESO,
        boundingBox = intArrayOf(boxX, boxY, boxW, boxH), centroidX = boxX + boxW / 2, centroidY = boxY + boxH / 2,
        areaPixels = boxW * boxH, relativeIntensity = 0.8, chromaDesaturation = 0.8, compactness = 0.7,
        skinConfidence = 70.0, confidence = confidence, evidenceReasons = listOf("test")
    )

    @Test
    fun contaminationDiagnostics_noOverlapNoHairSignal_reportsAllZero() {
        val c = candidateAt("c1", 10, 10, 10, 10, hairStubbleLikelihood = 0.0)
        val diag = SpecializedFeatureEvidenceAssembler.contaminationDiagnostics("FRONT FACE", listOf(c), emptyList())
        assertEquals(1, diag.candidateCount)
        assertEquals(0, diag.candidatesWithShineOverlap)
        assertEquals(0.0, diag.meanShineOverlapFraction, 0.001)
        assertEquals(1.0, diag.meanShineSuppressionFactor, 0.001) // no suppression -> factor 1.0
        assertEquals(0, diag.candidatesWithHairStubbleSignal)
        assertEquals(0.0, diag.meanHairStubbleLikelihoodWherePresent, 0.001)
    }

    @Test
    fun contaminationDiagnostics_fullShineOverlap_reportsMaximumSuppressionFactor() {
        // Candidate box exactly equals the shine candidate box -> full overlap, fraction=1.0.
        val c = candidateAt("c1", 10, 10, 10, 10)
        val shine = shineCandidateAt(10, 10, 10, 10, confidence = 1.0)
        val diag = SpecializedFeatureEvidenceAssembler.contaminationDiagnostics("FRONT FACE", listOf(c), listOf(shine))
        assertEquals(1, diag.candidatesWithShineOverlap)
        assertEquals(1.0, diag.meanShineOverlapFraction, 0.001)
        assertEquals(1.0, diag.meanShineConfidenceWhereOverlapping, 0.001)
        // suppressionFactor = 1.0 - 0.5*overlap*shineConf = 1.0 - 0.5*1.0*1.0 = 0.5 (the documented floor)
        assertEquals(0.5, diag.meanShineSuppressionFactor, 0.001)
    }

    @Test
    fun contaminationDiagnostics_hairStubbleSignal_countedAndAveraged() {
        val c1 = candidateAt("c1", 10, 10, 10, 10, hairStubbleLikelihood = 0.4)
        val c2 = candidateAt("c2", 50, 50, 10, 10, hairStubbleLikelihood = 0.0)
        val c3 = candidateAt("c3", 80, 80, 10, 10, hairStubbleLikelihood = 0.8)
        val diag = SpecializedFeatureEvidenceAssembler.contaminationDiagnostics("FRONT FACE", listOf(c1, c2, c3), emptyList())
        assertEquals(3, diag.candidateCount)
        assertEquals(2, diag.candidatesWithHairStubbleSignal)
        assertEquals(0.6, diag.meanHairStubbleLikelihoodWherePresent, 0.001) // (0.4+0.8)/2
    }

    @Test
    fun contaminationDiagnostics_diagnosticsJsonRoundTrips() {
        val c = candidateAt("c1", 10, 10, 10, 10, hairStubbleLikelihood = 0.3)
        val diag = SpecializedFeatureEvidenceAssembler.contaminationDiagnostics("FRONT FACE", listOf(c), emptyList())
        val json = SpecializedFeatureEvidenceAssembler.contaminationDiagnosticsJson(diag)
        assertTrue(json.contains("\"view\":\"FRONT FACE\""))
        assertTrue(json.contains("\"candidates_with_hair_stubble_signal\":1"))
    }
}
