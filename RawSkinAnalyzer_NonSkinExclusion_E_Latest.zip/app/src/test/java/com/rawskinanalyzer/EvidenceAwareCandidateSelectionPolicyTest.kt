package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EvidenceAwareCandidateSelectionPolicyTest {

    private fun concern(
        category: SkinConcernCategory,
        priority: Int = 1,
        confidence: String = "HIGH"
    ) = SkinConcern(
        category = category,
        priority = priority,
        score = 70.0,
        level = "HIGH_SIGNAL",
        evidenceSource = "TEST_STAGE",
        interpretation = "test",
        confidence = confidence
    )

    private fun option(
        role: IngredientSelectionRole,
        objectiveType: SkinObjectiveType,
        concern: SkinConcernCategory = SkinConcernCategory.TONE_PIGMENTATION,
        name: String = "TestIngredient"
    ) = SpecificIngredientOption(
        concern = concern,
        ingredientName = name,
        role = role,
        routinePhase = "AM_OR_PM",
        sourceCategory = "TEST_CATEGORY",
        caution = null,
        objectiveType = objectiveType,
        objectiveStrengthReason = "test reason"
    )

    @Test fun primaryRoleIsSelectedUnderTopTierObjective() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION, priority = 1))
        val options = listOf(option(IngredientSelectionRole.PRIMARY, SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(CandidateSelectionStatus.SELECTED, result.single().selectionStatus)
        assertTrue(result.single().selectionReason.contains("TARGETS_PRIMARY_OBJECTIVE"))
        assertTrue(result.single().selectionReason.contains("SUPPORTED_BY_EVIDENCE"))
    }

    @Test fun optionalRoleIsLimitedUnderWeakObjective() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION, confidence = "HIGH"))
        val options = listOf(option(IngredientSelectionRole.OPTIONAL, SkinObjectiveType.MAINTAIN_CURRENT_STATE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(CandidateSelectionStatus.LIMITED, result.single().selectionStatus)
        assertEquals("LIMITED_BY_LOW_EVIDENCE", result.single().selectionReason)
    }

    @Test fun optionalRoleIsSelectedUnderTopTierObjective() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION))
        val options = listOf(option(IngredientSelectionRole.OPTIONAL, SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(CandidateSelectionStatus.SELECTED, result.single().selectionStatus)
    }

    @Test fun onlyPrimaryRoleQualifiesUnderMaintainObjective() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION))
        val options = listOf(
            option(IngredientSelectionRole.PRIMARY, SkinObjectiveType.MAINTAIN_CURRENT_STATE),
            option(IngredientSelectionRole.SUPPORTIVE, SkinObjectiveType.MAINTAIN_CURRENT_STATE),
            option(IngredientSelectionRole.OPTIONAL, SkinObjectiveType.MAINTAIN_CURRENT_STATE)
        )
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(CandidateSelectionStatus.SELECTED, result[0].selectionStatus)
        assertEquals(CandidateSelectionStatus.LIMITED, result[1].selectionStatus)
        assertEquals(CandidateSelectionStatus.LIMITED, result[2].selectionStatus)
    }

    @Test fun monitorObjectiveDefersEveryCandidateRegardlessOfRole() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION))
        val options = listOf(
            option(IngredientSelectionRole.PRIMARY, SkinObjectiveType.MONITOR),
            option(IngredientSelectionRole.SUPPORTIVE, SkinObjectiveType.MONITOR),
            option(IngredientSelectionRole.OPTIONAL, SkinObjectiveType.MONITOR)
        )
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        result.forEach {
            assertEquals(CandidateSelectionStatus.DEFERRED, it.selectionStatus)
            assertEquals("INSUFFICIENT_INFORMATION", it.selectionReason)
        }
    }

    @Test fun lowConfidenceLimitedReasonTakesPrecedenceOverRoleReason() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION, confidence = "LOW"))
        val options = listOf(option(IngredientSelectionRole.SUPPORTIVE, SkinObjectiveType.MAINTAIN_CURRENT_STATE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(CandidateSelectionStatus.LIMITED, result.single().selectionStatus)
        assertEquals("LIMITED_BY_CONFIDENCE", result.single().selectionReason)
    }

    @Test fun secondaryPriorityConcernIsTaggedTargetsSecondaryObjective() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION, priority = 2))
        val options = listOf(option(IngredientSelectionRole.PRIMARY, SkinObjectiveType.SUPPORT_BALANCE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(CandidateSelectionStatus.SELECTED, result.single().selectionStatus)
        assertTrue(result.single().selectionReason.contains("TARGETS_SECONDARY_OBJECTIVE"))
    }

    @Test fun missingConcernDataDefaultsToConservativeLowConfidence() {
        // No matching concern supplied — the lookup must not assume high confidence.
        val options = listOf(option(IngredientSelectionRole.SUPPORTIVE, SkinObjectiveType.MAINTAIN_CURRENT_STATE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, emptyList())
        assertEquals("LOW", result.single().confidence)
        assertEquals(CandidateSelectionStatus.LIMITED, result.single().selectionStatus)
        assertEquals("LIMITED_BY_CONFIDENCE", result.single().selectionReason)
    }

    @Test fun everyDecisionCarriesThePolicyVersion() {
        val concerns = listOf(concern(SkinConcernCategory.TONE_PIGMENTATION))
        val options = listOf(option(IngredientSelectionRole.PRIMARY, SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE))
        val result = EvidenceAwareCandidateSelectionPolicy.select(options, concerns)
        assertEquals(EvidenceAwareCandidateSelectionPolicy.VERSION, result.single().policyVersion)
    }
}
