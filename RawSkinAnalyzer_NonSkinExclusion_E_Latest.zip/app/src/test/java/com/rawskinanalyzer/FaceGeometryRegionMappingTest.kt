package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

// FaceBounds carries android.graphics.Rect fields (unmocked stub under plain JUnit — see
// SkinRoiValidityTest's note on Bitmap/Color for the same reason). Everything else exercised
// here (GeometryPoint, AnatomicalRegionMapper, FaceConstrainedSkinAnalyzer) is plain Kotlin
// with no Android dependency, but the whole file needs the Robolectric runner because
// syntheticFullFace() constructs a Rect.
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])

/**
 * Tests the pure-Kotlin geometric logic in AnatomicalRegionMapper and
 * FaceConstrainedSkinAnalyzer using a hand-built synthetic FaceGeometryResult, rather than a
 * real ML Kit detection. This deliberately does NOT exercise FaceGeometryAnalyzer itself
 * (that class talks to Play Services' ML Kit client and cannot run under plain JUnit/Robolectric
 * — it needs an instrumented/device test, which is out of scope per this batch's testing
 * policy: device verification is deferred). What IS tested here is everything downstream of a
 * detection result: region construction, exclusion construction, and the cell/region overlap
 * math — none of which touches Android APIs and all of which is worth checking without a
 * device.
 *
 * NOTE: written and reviewed statically in this session; not yet compiled or run (no
 * kotlinc/Gradle available in this sandbox — see PROJECT_STATUS.md verification status).
 * Treat this file as ready for the first real Gradle test run, not as evidence one has
 * already happened.
 */
class FaceGeometryRegionMappingTest {

    private fun gp(x: Float, y: Float) = GeometryPoint(x, y, x * 2f, y * 2f) // arbitrary 2x "original" scale for testing bounds passthrough

    /** A simple, roughly face-shaped synthetic geometry on a 100x100 normalized image, fully populated so every region should build. */
    private fun syntheticFullFace(): FaceGeometryResult {
        val faceOutline = listOf(
            gp(30f, 10f), gp(70f, 10f), gp(90f, 50f), gp(70f, 90f), gp(30f, 90f), gp(10f, 50f)
        )
        val leftEye = listOf(gp(35f, 35f), gp(42f, 33f), gp(42f, 38f), gp(35f, 38f))
        val rightEye = listOf(gp(58f, 35f), gp(65f, 33f), gp(65f, 38f), gp(58f, 38f))
        val leftBrow = listOf(gp(33f, 28f), gp(44f, 27f))
        val rightBrow = listOf(gp(56f, 27f), gp(67f, 28f))
        val nose = listOf(gp(46f, 40f), gp(54f, 40f), gp(54f, 58f), gp(46f, 58f))
        val mouth = listOf(gp(40f, 68f), gp(60f, 68f), gp(60f, 74f), gp(40f, 74f))
        val leftCheek = listOf(gp(28f, 50f), gp(32f, 55f))
        val rightCheek = listOf(gp(68f, 50f), gp(72f, 55f))

        val contours = listOf(
            FaceContourGroup(FaceLandmarkGroup.FACE_OUTLINE, faceOutline),
            FaceContourGroup(FaceLandmarkGroup.LEFT_EYE, leftEye),
            FaceContourGroup(FaceLandmarkGroup.RIGHT_EYE, rightEye),
            FaceContourGroup(FaceLandmarkGroup.LEFT_EYEBROW, leftBrow),
            FaceContourGroup(FaceLandmarkGroup.RIGHT_EYEBROW, rightBrow),
            FaceContourGroup(FaceLandmarkGroup.NOSE, nose),
            FaceContourGroup(FaceLandmarkGroup.MOUTH, mouth),
            FaceContourGroup(FaceLandmarkGroup.LEFT_CHEEK, leftCheek),
            FaceContourGroup(FaceLandmarkGroup.RIGHT_CHEEK, rightCheek)
        )

        return FaceGeometryResult(
            faceDetected = true,
            faceDetectionConfidence = 0.9,
            bounds = FaceBounds(android.graphics.Rect(10, 10, 90, 90), android.graphics.Rect(20, 20, 180, 180)),
            landmarks = emptyList(),
            contours = contours,
            normalizedImageWidth = 100,
            normalizedImageHeight = 100,
            originalImageWidth = 200,
            originalImageHeight = 200,
            originalScaleAvailable = true,
            landmarkCompleteness = 0.5,
            contourCompleteness = 9.0 / 15.0,
            geometryConfidence = FaceGeometryAnalyzer.geometryConfidenceOf(0.5, 9.0 / 15.0),
            notes = emptyList()
        )
    }

    @Test
    fun noFaceGeometry_producesNoRegionsAndAllSkipped() {
        val noFace = FaceGeometryResult(
            faceDetected = false, faceDetectionConfidence = 0.0, bounds = null,
            landmarks = emptyList(), contours = emptyList(),
            normalizedImageWidth = 100, normalizedImageHeight = 100,
            originalImageWidth = null, originalImageHeight = null, originalScaleAvailable = false,
            landmarkCompleteness = 0.0, contourCompleteness = 0.0, geometryConfidence = 0.0, notes = listOf("NO_FACE_DETECTED")
        )
        val result = AnatomicalRegionMapper.map(noFace)
        assertTrue(result.regions.isEmpty())
        assertEquals(AnatomicalRegion.values().size, result.skippedRegions.size)
    }

    @Test
    fun fullFaceGeometry_buildsAllEightRegions() {
        val regionSet = AnatomicalRegionMapper.map(syntheticFullFace())
        val builtRegions = regionSet.regions.map { it.region }.toSet()
        assertEquals(
            "Expected all 8 required regions to build from a fully-populated synthetic contour set; skipped=${regionSet.skippedRegions}",
            AnatomicalRegion.values().toSet(),
            builtRegions
        )
        // Every region's confidence must be derived (bounded, non-zero, non-fabricated-constant like exactly 1.0)
        regionSet.regions.forEach {
            assertTrue("${it.region} confidence should be in (0,1]", it.confidence > 0.0 && it.confidence <= 1.0)
        }
    }

    @Test
    fun eyesAndLipsAreExcludedNotRegions() {
        val regionSet = AnatomicalRegionMapper.map(syntheticFullFace())
        val exclusionCategories = regionSet.exclusions.map { it.category }.toSet()
        assertTrue(exclusionCategories.contains(NonSkinExclusionCategory.EYES))
        assertTrue(exclusionCategories.contains(NonSkinExclusionCategory.LIPS))
        assertTrue(exclusionCategories.contains(NonSkinExclusionCategory.EYEBROWS))
        assertTrue(exclusionCategories.contains(NonSkinExclusionCategory.NOSTRILS_APPROXIMATE))
        // Architecture hook only — never produced by this batch, see AnatomicalRegionMapper class doc.
        assertTrue(exclusionCategories.none { it == NonSkinExclusionCategory.HAIR_OR_STUBBLE })
    }

    private fun uniformCell(row: Int, col: Int, skinPercent: Double, highConfidencePercent: Double) = PatternMapCell(
        row = row, col = col, samples = 100, skinPercent = skinPercent, meanLuma = 128.0, redness = 0.0, texture = 0.0,
        darkPercent = 0.0, highConfidenceSkinPercent = highConfidencePercent,
        excludedShadowPercent = 0.0, excludedHighlightPercent = 0.0, excludedNonSkinPercent = 0.0,
        uncertainPercent = 100.0 - skinPercent, meanConfidenceWeight = 0.8
    )

    @Test
    fun faceConstrainedSkinAnalyzer_attributesUniformSkinCoverageToOverlappingRegions() {
        val geometry = syntheticFullFace()
        val regionSet = AnatomicalRegionMapper.map(geometry)
        // 6x6 grid over the 100x100 normalized image used by syntheticFullFace(), matching the
        // grid size MainActivity's runFaceConstrainedSkinAnalysis() actually passes.
        val grid = 6
        val cells = (0 until grid).flatMap { row -> (0 until grid).map { col -> uniformCell(row, col, skinPercent = 80.0, highConfidencePercent = 60.0) } }

        val reports = FaceConstrainedSkinAnalyzer.analyze(
            cells = cells, grid = grid,
            normalizedImageWidth = geometry.normalizedImageWidth, normalizedImageHeight = geometry.normalizedImageHeight,
            regionSet = regionSet
        )

        assertEquals(regionSet.regions.size, reports.size)
        reports.forEach { report ->
            // Every cell reports the same 80% skin / 60% high-confidence, so any region built
            // from at least one overlapping cell should recover exactly that (weighted average
            // of a uniform value is that value), regardless of the region's polygon shape.
            assertEquals("skinCoverage for ${report.region}", 80.0, report.skinCoverage, 0.01)
            assertEquals("highConfidenceSkinCoverage for ${report.region}", 60.0, report.highConfidenceSkinCoverage, 0.01)
            assertEquals("mediumConfidenceSkinCoverage for ${report.region}", 20.0, report.mediumConfidenceSkinCoverage, 0.01)
            assertTrue("cellsConsidered for ${report.region} should be > 0", report.cellsConsidered > 0)
            // geometryConfidence must be carried through from the region polygon, not recomputed here.
            assertEquals(regionSet.region(report.region)!!.confidence, report.geometryConfidence, 1e-9)
        }
    }

    @Test
    fun faceConstrainedSkinAnalyzer_returnsEmptyWhenNoRegions() {
        val geometry = syntheticFullFace().let { it.copy(contours = emptyList()) }
        val regionSet = AnatomicalRegionMapper.map(geometry) // will skip everything: no contours at all
        val cells = listOf(uniformCell(0, 0, 50.0, 10.0))
        val reports = FaceConstrainedSkinAnalyzer.analyze(cells, 6, 100, 100, regionSet)
        assertTrue(reports.isEmpty())
    }
}
