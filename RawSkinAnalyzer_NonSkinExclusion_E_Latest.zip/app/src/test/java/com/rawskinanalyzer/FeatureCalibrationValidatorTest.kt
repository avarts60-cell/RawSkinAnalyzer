package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Plain JUnit — no android.* dependency, so (like AnalysisScorePolicyTest) this does not
 * need the Robolectric setup SkinRoiValidityTest required.
 */
class FeatureCalibrationValidatorTest {

    private fun input(name: String, value: Double, weight: Double) =
        CalibrationInput(name, value, weight)

    @Test fun realRednessComponentPassesWithNoErrors() {
        // Same shape/weights as SkinScoreCalibration.redness for plausible real inputs.
        val component = SkinScoreCalibration.redness(
            localizedRedness = 40.0,
            withinViewVariation = 12.0,
            elevatedAreaPercent = 20.0
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertTrue(result.valid)
        assertTrue(result.findings.none { it.severity == CalibrationFindingSeverity.ERROR })
    }

    @Test fun hardBoundViolationIsErrorAndInvalid() {
        // localized_redness_normalized is HARD_GUARANTEED to [0,100] by its upstream clamp;
        // a value outside that range indicates the guarantee was broken somewhere upstream.
        val component = CalibratedComponent(
            characteristic = "REDNESS",
            calibratedScore = 100.0,
            inputs = listOf(
                input("localized_redness_normalized", 150.0, 0.55),
                input("within_view_redness_variation", 5.0, 2.0),
                input("elevated_redness_area_percent", 10.0, 0.25)
            ),
            calibrationVersion = SkinScoreCalibration.VERSION
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertFalse(result.valid)
        assertTrue(result.findings.any {
            it.code == "INPUT_OUT_OF_EXPECTED_RANGE" && it.severity == CalibrationFindingSeverity.ERROR
        })
    }

    @Test fun softBoundViolationIsWarningButStillValid() {
        // within_view_redness_variation has no upstream clamp (SOFT_PLAUSIBILITY); an
        // out-of-range value is worth flagging but is not, on its own, an error.
        val inputs = listOf(
            input("localized_redness_normalized", 20.0, 0.55),
            input("within_view_redness_variation", 90.0, 2.0),
            input("elevated_redness_area_percent", 5.0, 0.25)
        )
        val rawSum = inputs.sumOf { it.contribution }
        val component = CalibratedComponent(
            characteristic = "REDNESS",
            calibratedScore = rawSum.coerceIn(0.0, 100.0),
            inputs = inputs,
            calibrationVersion = SkinScoreCalibration.VERSION
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertTrue(result.valid)
        assertTrue(result.findings.any {
            it.code == "INPUT_OUT_OF_EXPECTED_RANGE" && it.severity == CalibrationFindingSeverity.WARNING
        })
    }

    @Test fun nonFiniteInputIsError() {
        val component = CalibratedComponent(
            characteristic = "REDNESS",
            calibratedScore = 50.0,
            inputs = listOf(
                input("localized_redness_normalized", Double.NaN, 0.55),
                input("within_view_redness_variation", 5.0, 2.0),
                input("elevated_redness_area_percent", 10.0, 0.25)
            ),
            calibrationVersion = SkinScoreCalibration.VERSION
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertFalse(result.valid)
        assertTrue(result.findings.any {
            it.code == "NON_FINITE_INPUT_VALUE" && it.severity == CalibrationFindingSeverity.ERROR
        })
    }

    @Test fun scoreNotMatchingItsOwnInputsIsError() {
        // calibratedScore deliberately does not equal the clamped sum of its own inputs'
        // contributions — simulates a corrupted/hand-edited record.
        val component = CalibratedComponent(
            characteristic = "REDNESS",
            calibratedScore = 5.0,
            inputs = listOf(
                input("localized_redness_normalized", 40.0, 0.55),
                input("within_view_redness_variation", 12.0, 2.0),
                input("elevated_redness_area_percent", 20.0, 0.25)
            ),
            calibrationVersion = SkinScoreCalibration.VERSION
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertFalse(result.valid)
        assertTrue(result.findings.any { it.code == "SCORE_INPUT_SUM_MISMATCH" })
    }

    @Test fun clampedRawSumProducesInfoFindingNotError() {
        val inputs = listOf(
            input("localized_redness_normalized", 100.0, 0.55),
            input("within_view_redness_variation", 40.0, 2.0),
            input("elevated_redness_area_percent", 100.0, 0.25)
        )
        val rawSum = inputs.sumOf { it.contribution } // well over 100
        val component = CalibratedComponent(
            characteristic = "REDNESS",
            calibratedScore = rawSum.coerceIn(0.0, 100.0),
            inputs = inputs,
            calibrationVersion = SkinScoreCalibration.VERSION
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertEquals(100.0, result.calibratedScore, 0.0001)
        assertTrue(result.findings.any {
            it.code == "RAW_WEIGHTED_SUM_CLAMPED" && it.severity == CalibrationFindingSeverity.INFO
        })
    }

    @Test fun unspecifiedInputNameProducesInfoNotError() {
        val component = CalibratedComponent(
            characteristic = "NEW_CHARACTERISTIC",
            calibratedScore = 10.0,
            inputs = listOf(input("brand_new_signal_not_yet_bounded", 10.0, 1.0)),
            calibrationVersion = SkinScoreCalibration.VERSION
        )
        val result = FeatureCalibrationValidator.validate(component)
        assertTrue(result.valid)
        assertTrue(result.findings.any {
            it.code == "NO_BOUND_SPECIFIED" && it.severity == CalibrationFindingSeverity.INFO
        })
    }

    @Test fun allSevenCalibrationFunctionsProduceOnlyKnownBoundInputs() {
        // Every input name actually emitted by SkinScoreCalibration today must have a bound
        // (even if SOFT) so this test starts failing the moment a new named input is added
        // without updating FeatureCalibrationBounds.
        val components = listOf(
            SkinScoreCalibration.redness(40.0, 12.0, 20.0),
            SkinScoreCalibration.pigmentationVariation(30.0, 15.0, 20.0, 10.0),
            SkinScoreCalibration.blemishLike(15.0, 20.0, 8.0, 30.0),
            SkinScoreCalibration.textureIrregularity(30.0, 10.0, 15.0),
            SkinScoreCalibration.poreLike(15.0, 15.0),
            SkinScoreCalibration.surfaceOiliness(20.0, 10.0),
            SkinScoreCalibration.surfaceDryness(20.0, 10.0)
        )
        components.forEach { c ->
            c.inputs.forEach { i ->
                assertTrue(
                    "input '${i.name}' from ${c.characteristic} has no FeatureCalibrationBounds entry",
                    FeatureCalibrationBounds.forInput(i.name) != null
                )
            }
        }
    }
}
