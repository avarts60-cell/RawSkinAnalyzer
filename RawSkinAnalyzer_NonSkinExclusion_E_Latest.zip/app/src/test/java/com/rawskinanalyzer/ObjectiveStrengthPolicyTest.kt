package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ObjectiveStrengthPolicyTest {

    @Test fun highScoreHighConfidencePrimaryReachesTopTier() {
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 70.0, findingConfidence = "HIGH", sessionAnalysisConfidence = "HIGH", priority = 1
        )
        assertEquals(SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, result.objectiveType)
        assertFalse(result.wasCapped)
    }

    @Test fun highScoreLowFindingConfidenceIsCappedConservatively() {
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 70.0, findingConfidence = "LOW", sessionAnalysisConfidence = "HIGH", priority = 1
        )
        assertEquals(SkinObjectiveType.MAINTAIN_CURRENT_STATE, result.objectiveType)
        assertTrue(result.wasCapped)
        assertTrue(result.reason.contains("finding_confidence=LOW"))
    }

    @Test fun highScoreModerateFindingConfidenceCapsAtSupportBalance() {
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 70.0, findingConfidence = "MODERATE", sessionAnalysisConfidence = "HIGH", priority = 1
        )
        assertEquals(SkinObjectiveType.SUPPORT_BALANCE, result.objectiveType)
        assertTrue(result.wasCapped)
    }

    @Test fun lowSessionConfidenceCapsEvenAHighConfidenceFinding() {
        // Session-level (whole-analysis) confidence is a session-wide limitation and caps
        // every objective this session produces, on top of that finding's own confidence.
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 80.0, findingConfidence = "HIGH", sessionAnalysisConfidence = "LOW", priority = 1
        )
        assertEquals(SkinObjectiveType.MAINTAIN_CURRENT_STATE, result.objectiveType)
        assertTrue(result.wasCapped)
        assertTrue(result.reason.contains("session_confidence=LOW"))
    }

    @Test fun tertiaryPriorityFindingCannotReachTopTierEvenWithHighConfidence() {
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 90.0, findingConfidence = "HIGH", sessionAnalysisConfidence = "HIGH", priority = 3
        )
        assertEquals(SkinObjectiveType.SUPPORT_BALANCE, result.objectiveType)
        assertTrue(result.wasCapped)
        assertTrue(result.reason.contains("priority=3"))
    }

    @Test fun primaryAndSecondaryPriorityAreNotPriorityCapped() {
        val p1 = ObjectiveStrengthPolicy.calibrate(90.0, "HIGH", "HIGH", 1)
        val p2 = ObjectiveStrengthPolicy.calibrate(90.0, "HIGH", "HIGH", 2)
        assertEquals(SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, p1.objectiveType)
        assertEquals(SkinObjectiveType.IMPROVE_VISIBLE_APPEARANCE, p2.objectiveType)
    }

    @Test fun lowScoreIsNeverEscalatedByHighConfidence() {
        // Confidence and priority only ever cap (reduce) strength; they never escalate a low
        // score above what the score itself justifies.
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 5.0, findingConfidence = "HIGH", sessionAnalysisConfidence = "HIGH", priority = 1
        )
        assertEquals(SkinObjectiveType.MONITOR, result.objectiveType)
        assertFalse(result.wasCapped)
    }

    @Test fun multipleBindingCapsAreAllReportedInReason() {
        val result = ObjectiveStrengthPolicy.calibrate(
            score = 90.0, findingConfidence = "LOW", sessionAnalysisConfidence = "LOW", priority = 1
        )
        assertEquals(SkinObjectiveType.MAINTAIN_CURRENT_STATE, result.objectiveType)
        assertTrue(result.reason.contains("finding_confidence=LOW"))
        assertTrue(result.reason.contains("session_confidence=LOW"))
    }
}
