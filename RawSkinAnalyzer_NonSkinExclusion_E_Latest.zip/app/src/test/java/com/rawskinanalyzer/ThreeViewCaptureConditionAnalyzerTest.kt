package com.rawskinanalyzer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ThreeViewCaptureConditionAnalyzerTest {
    private fun profile(
        view: String,
        meanLuma: Double,
        colorCast: Double = 0.02,
        warnings: List<String> = emptyList()
    ) = CaptureConditionProfile(
        view = view,
        meanLuma = meanLuma,
        meanR = meanLuma,
        meanG = meanLuma,
        meanB = meanLuma,
        rgRatio = 1.0,
        bgRatio = 1.0,
        colorCastMagnitude = colorCast,
        dynamicRange = 30.0,
        illuminantEstimate = "NEUTRAL_ESTIMATE",
        suggestedExposureGain = (128.0 / meanLuma).coerceIn(0.75, 1.35),
        warnings = warnings
    )

    @Test fun consistentLightingProducesNoWarnings() {
        val f = profile("FRONT_FACE", 130.0)
        val l = profile("LEFT_CHEEK", 125.0)
        val r = profile("RIGHT_CHEEK", 128.0)
        val result = ThreeViewCaptureConditionAnalyzer.analyze(f, l, r)
        assertEquals("HIGH_CAPTURE_CONDITION_CONSISTENCY", result.consistency)
        assertTrue(result.crossViewWarnings.isEmpty())
    }

    @Test fun majorLumaSpreadIsFlaggedAsMajorInconsistency() {
        val f = profile("FRONT_FACE", 200.0)
        val l = profile("LEFT_CHEEK", 60.0, warnings = listOf("LOW_LIGHT"))
        val r = profile("RIGHT_CHEEK", 130.0)
        val result = ThreeViewCaptureConditionAnalyzer.analyze(f, l, r)
        assertEquals("MAJOR_CAPTURE_CONDITION_INCONSISTENCY", result.consistency)
        assertTrue("MAJOR_LIGHTING_MISMATCH_ACROSS_VIEWS" in result.crossViewWarnings)
    }

    @Test fun leftRightLumaMismatchIsFlaggedIndependently() {
        val f = profile("FRONT_FACE", 128.0)
        val l = profile("LEFT_CHEEK", 90.0)
        val r = profile("RIGHT_CHEEK", 150.0)
        val result = ThreeViewCaptureConditionAnalyzer.analyze(f, l, r)
        assertTrue("LEFT_RIGHT_LIGHTING_MISMATCH" in result.crossViewWarnings)
    }

    @Test fun strongColorCastAcrossViewsIsFlagged() {
        val f = profile("FRONT_FACE", 128.0, colorCast = 0.02)
        val l = profile("LEFT_CHEEK", 128.0, colorCast = 0.30, warnings = listOf("STRONG_COLOR_CAST"))
        val r = profile("RIGHT_CHEEK", 128.0, colorCast = 0.03)
        val result = ThreeViewCaptureConditionAnalyzer.analyze(f, l, r)
        assertTrue("MAJOR_COLOR_CAST_MISMATCH_ACROSS_VIEWS" in result.crossViewWarnings)
        assertTrue("SESSION_LIGHTING_RELIABILITY_REDUCED" in result.crossViewWarnings)
    }
}
