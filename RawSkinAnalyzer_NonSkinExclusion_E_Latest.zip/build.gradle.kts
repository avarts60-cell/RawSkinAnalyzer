plugins {
    id("com.android.application") version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    // UI-1A: Compose compiler plugin, must match the Kotlin version above exactly.
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
