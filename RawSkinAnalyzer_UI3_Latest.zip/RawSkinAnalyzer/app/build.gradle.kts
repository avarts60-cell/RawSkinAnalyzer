plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // UI-1A: required for Jetpack Compose with Kotlin 2.0+ (the Compose compiler is no
    // longer bundled into kotlin-android; it ships as its own Kotlin plugin as of Kotlin 2.0).
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.rawskinanalyzer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rawskinanalyzer"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.0-ui1a-core-ui"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    testOptions {
        unitTests {
            // Required for Robolectric: without this, android.jar's checked stubs
            // (e.g. Bitmap.createBitmap) throw "not mocked" at test runtime instead
            // of running real Robolectric shadows. Tests referencing android.graphics
            // types are non-functional without this + the Robolectric runner below.
            isIncludeAndroidResources = true
        }
    }
}

kotlin {
    jvmToolchain(17)
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    // Added: SkinRoiValidityTest exercises android.graphics.Bitmap/Color, which are
    // unmocked stubs under plain JUnit and throw RuntimeException("not mocked") for
    // every call. Without Robolectric these tests cannot pass; they were previously
    // present as source but not actually executable.
    testImplementation("org.robolectric:robolectric:4.13")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")

    // UI-1A: Compose core UI layer. Added on top of the existing Camera2/analysis
    // backend below — none of the dependencies above were removed or changed.
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.8.5")
}
