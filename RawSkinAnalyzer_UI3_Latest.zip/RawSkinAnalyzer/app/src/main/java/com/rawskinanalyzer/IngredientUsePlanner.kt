package com.rawskinanalyzer

data class IngredientUsePlan(
    val concern: SkinConcernCategory,
    val ingredientName: String,
    val concentrationGuidance: String,
    val frequencyGuidance: String,
    val routinePhase: String,
    val introductionRule: String,
    val caution: String?
)

object IngredientUsePlanner {
    fun plan(
        options: List<SpecificIngredientOption>,
        context: UserRoutineContext
    ): List<IngredientUsePlan> = options.map { option ->
        val cautious = context.tolerancePreference == TolerancePreference.CAUTIOUS
        val lowIntensity = context.activeIntensityPreference == ActiveIntensityPreference.LOW
        val (concentration, frequency) = guidanceFor(option, cautious || lowIntensity)

        IngredientUsePlan(
            concern = option.concern,
            ingredientName = option.ingredientName,
            concentrationGuidance = concentration,
            frequencyGuidance = frequency,
            routinePhase = option.routinePhase,
            introductionRule = if (cautious || lowIntensity)
                "START_CONSERVATIVELY_AND_REVIEW_TOLERANCE"
            else
                "INTRODUCE_GRADUALLY_AND_REVIEW_TOLERANCE",
            caution = option.caution
        )
    }

    private fun guidanceFor(
        option: SpecificIngredientOption,
        conservative: Boolean
    ): Pair<String, String> = when (option.ingredientName) {
        "Niacinamide" ->
            if (conservative) "LOWER_STRENGTH_OPTION" to "START_FEW_SESSIONS_PER_WEEK"
            else "STANDARD_COSMETIC_STRENGTH_OPTION" to "START_REGULARLY_AND_REVIEW"
        "Vitamin C" ->
            if (conservative) "LOWER_STRENGTH_OPTION" to "START_FEW_MORNING_SESSIONS_PER_WEEK"
            else "STANDARD_COSMETIC_STRENGTH_OPTION" to "START_REGULARLY_AND_REVIEW"
        "Azelaic acid" ->
            if (conservative) "LOWER_INTENSITY_OPTION" to "START_FEW_SESSIONS_PER_WEEK"
            else "PRODUCT_LABEL_COMPATIBLE_OPTION" to "INTRODUCE_GRADUALLY"
        "Salicylic acid" ->
            "PRODUCT_LABEL_COMPATIBLE_OPTION" to
                if (conservative) "START_INFREQUENTLY" else "START_FEW_SESSIONS_PER_WEEK"
        "Ceramides" ->
            "FORMULATION_DEPENDENT_SUPPORT_LEVEL" to "REGULAR_USE_AS_NEEDED"
        "Glycerin" ->
            "FORMULATION_DEPENDENT_SUPPORT_LEVEL" to "REGULAR_USE_AS_NEEDED"
        else ->
            "PRODUCT_SPECIFIC_REVIEW_REQUIRED" to "INTRODUCE_GRADUALLY"
    }
}