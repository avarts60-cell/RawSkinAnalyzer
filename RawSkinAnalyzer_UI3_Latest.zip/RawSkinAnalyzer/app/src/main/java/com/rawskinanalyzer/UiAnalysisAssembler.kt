package com.rawskinanalyzer

/**
 * UI-1B — UI-facing structured result bundle.
 *
 * Why this file exists: `FinalSkinAnalysisProfileAnalyzer.json()` already computes every
 * routine/progress/trend/adaptation object the UI needs, but it only returns a giant
 * pre-serialized JSON string — there was no structured Kotlin object a Compose screen could
 * bind to without re-parsing JSON inside a composable (which would violate the required
 * Compose -> ViewModel -> domain/repository flow). Rather than have the UI parse `json()`'s
 * output, or duplicate `json()` itself (which has real, one-time-only side effects —
 * `SkinSessionRepository.save(...)` persists this session, and `toleranceRepository.save(...)`
 * advances tolerance state), this file mirrors the exact same read side of that computation —
 * calling the exact same policy objects, in the exact same order, with the exact same
 * arguments — but stops short of any write. `MainActivity` calls this once per session,
 * strictly *before* the existing `json()` call, so both see identical "previous session" state;
 * `json()` remains completely unmodified and is still the single place persistence happens.
 *
 * Nothing here invents a score, confidence, recommendation, or historical session. Every field
 * below is a value some existing analyzer/policy already computed.
 */
data class FinalAnalysisBundle(
    val concerns: List<SkinConcern>,
    val objectives: List<SkinObjective>,
    val contextAdjustedSchedule: RoutineSchedule,
    val userRoutineContext: UserRoutineContext,
    val specificIngredients: List<SpecificIngredientOption>,
    val candidateSelections: List<CandidateSelectionDecision>,
    val selectedIngredients: List<SpecificIngredientOption>,
    val candidateCompatibility: List<CandidateCompatibilityDecision>,
    val toleranceRecords: List<IngredientToleranceRecord>,
    val routineIntensityDecisions: List<RoutineIntensityDecision>,
    val ingredientUsePlans: List<IngredientUsePlan>,
    val productRecommendations: List<ProductRecommendation>,
    val finalRoutineResult: FinalRoutineResult,
    val currentProgressSnapshot: SkinProgressSnapshot,
    val previousProgressSnapshot: SkinProgressSnapshot?,
    val progressResult: SkinProgressResult,
    val multiSessionTrend: MultiSessionTrendResult,
    val trendAwareAdaptation: TrendAwareAdaptationResult,
    val captureQualityReliability: CaptureQualityReliability,
    val generatedRoutineAdjustment: TrendAwareRoutineAdjustment,
    val controlledRoutineRevision: ControlledRoutineRevision,
    val routineExecution: RoutineAdaptationExecution,
    val analysisVersion: String
)

object UiAnalysisAssembler {
    /**
     * Read-only mirror of `FinalSkinAnalysisProfileAnalyzer.json()`'s computation chain.
     * `toleranceRepository` is only ever `.get()` here, never `.save()`d — this function must
     * not advance tolerance state, since `json()` (called separately by MainActivity) already
     * does that exactly once per session.
     */
    fun assemble(
        x: FinalSkinAnalysisProfile,
        toleranceRepository: ToleranceStateRepository,
        captureConditionConsistency: String?
    ): FinalAnalysisBundle {
        val concerns = SkinConcernInterpreter.fromFinalProfile(x)
        val objectives = SkinObjectivePlanner.plan(concerns, x.analysisConfidence)
        val strategy = RoutineStrategyPlanner.plan(objectives)
        val ingredientStrategy = IngredientStrategyPlanner.plan(strategy)
        val routineAssembly = RoutineCompatibilityPlanner.plan(ingredientStrategy)
        val routineSchedule = RoutineSchedulePlanner.plan(strategy, routineAssembly)
        val userRoutineContext = RoutineContextPlanner.defaultContext()
        val contextAdjustedSchedule = RoutineContextPlanner.apply(routineSchedule, userRoutineContext)
        val specificIngredients = SpecificIngredientMapper.map(ingredientStrategy, userRoutineContext)

        val candidateSelections = EvidenceAwareCandidateSelectionPolicy.select(specificIngredients, concerns)
        val candidateSelectionByKey = candidateSelections.associateBy {
            "${it.concern}:${it.ingredientName}:${it.role}"
        }
        val selectedIngredients = specificIngredients.filter { option ->
            candidateSelectionByKey["${option.concern}:${option.ingredientName}:${option.role}"]
                ?.selectionStatus == CandidateSelectionStatus.SELECTED
        }

        val candidateCompatibility = CandidateCompatibilityPolicy.plan(selectedIngredients)
        val compatibilityByName = candidateCompatibility.associateBy { it.ingredientName }

        // Read-only: reflects each ingredient's tolerance record as it stands going into this
        // session, without transitioning/saving it. json() performs the real transition+save.
        val toleranceSnapshot = selectedIngredients
            .map { it.ingredientName }
            .distinct()
            .associateWith { toleranceRepository.get(it) }

        val toleranceFilterDecisions = ToleranceAwareCandidateFilter.apply(selectedIngredients, toleranceSnapshot)
        val toleranceFilterByName = toleranceFilterDecisions.associateBy { it.ingredientName }
        val toleranceApprovedIngredients = selectedIngredients.filter {
            toleranceFilterByName[it.ingredientName]?.outcome != ToleranceFilterOutcome.EXCLUDED
        }

        val routineIntensityDecisions = toleranceApprovedIngredients.map { candidate ->
            val concernConfidence = concerns.firstOrNull { it.category == candidate.concern }?.confidence ?: "LOW"
            RoutineIntensityPolicy.calibrate(
                ingredientName = candidate.ingredientName,
                objectiveType = candidate.objectiveType,
                confidence = concernConfidence,
                compatibility = compatibilityByName[candidate.ingredientName]?.action ?: RoutineCompatibilityAction.REVIEW_REQUIRED,
                tolerance = toleranceSnapshot[candidate.ingredientName]?.state ?: ToleranceState.UNKNOWN
            )
        }

        val ingredientUsePlans = IngredientUsePlanner.plan(toleranceApprovedIngredients, userRoutineContext)
        val productRequirements = ProductSelectionPlanner.requirements(ingredientUsePlans)
        val productCatalogCandidates = ProductCatalogRepository.candidates()
        val productMatches = ProductSelectionPlanner.rank(productRequirements, productCatalogCandidates)
        val acceptedProductMatches = productMatches.filter { it.accepted }
        val productRecommendations = ProductRecommendationAssembler.assemble(
            productRequirements,
            acceptedProductMatches,
            ingredientUsePlans
        )
        val finalRoutineResult = FinalRoutineResultAssembler.assemble(
            x.primaryFinding,
            x.secondaryFinding,
            contextAdjustedSchedule,
            ingredientUsePlans,
            productRecommendations
        )

        val currentProgressSnapshot = SkinProgressSnapshot(
            pigmentationScore = x.pigmentationScore,
            darkMarkScore = x.darkMarkScore,
            blemishLikeScore = x.blemishLikeScore,
            rednessScore = x.rednessScore,
            poreLikeScore = x.poreLikeScore,
            shineScore = x.surfaceShineScore,
            textureScore = x.textureIrregularityScore,
            drynessScore = x.drynessRelatedScore,
            confidence = x.analysisConfidence
        )
        val analysisVersion = "final_skin_analysis_profile_v29"
        val previousProgressSnapshot = SkinSessionRepository.previousSnapshot(analysisVersion)
        val progressResult = SkinProgressTracker.compare(previousProgressSnapshot, currentProgressSnapshot)
        val trendHistory = SkinSessionRepository.compatibleHistory(analysisVersion) + currentProgressSnapshot
        val multiSessionTrend = MultiSessionTrendAnalyzer.analyze(trendHistory)
        val rawTrendAwareAdaptation = TrendAwareRoutineAdaptationPolicy.evaluate(progressResult, multiSessionTrend)
        val captureQualityReliability = CaptureQualityReliabilityGate.classify(captureConditionConsistency)
        val trendAwareAdaptation = CaptureQualityReliabilityGate.apply(rawTrendAwareAdaptation, captureQualityReliability)
        val generatedRoutineAdjustment = TrendAwareRoutineAdjustmentGenerator.generate(
            trendAwareAdaptation.decision,
            multiSessionTrend,
            ingredientUsePlans,
            finalRoutineResult
        )
        val controlledRoutineRevision = RoutineAdjustmentCandidateActivator.activate(
            generatedRoutineAdjustment,
            ingredientUsePlans,
            finalRoutineResult,
            toleranceByIngredient = toleranceSnapshot
        )
        val routineExecution = RoutineAdaptationExecutor.execute(trendAwareAdaptation.decision, finalRoutineResult)

        return FinalAnalysisBundle(
            concerns = concerns,
            objectives = objectives,
            contextAdjustedSchedule = contextAdjustedSchedule,
            userRoutineContext = userRoutineContext,
            specificIngredients = specificIngredients,
            candidateSelections = candidateSelections,
            selectedIngredients = selectedIngredients,
            candidateCompatibility = candidateCompatibility,
            toleranceRecords = toleranceSnapshot.values.toList(),
            routineIntensityDecisions = routineIntensityDecisions,
            ingredientUsePlans = ingredientUsePlans,
            productRecommendations = productRecommendations,
            finalRoutineResult = finalRoutineResult,
            currentProgressSnapshot = currentProgressSnapshot,
            previousProgressSnapshot = previousProgressSnapshot,
            progressResult = progressResult,
            multiSessionTrend = multiSessionTrend,
            trendAwareAdaptation = trendAwareAdaptation,
            captureQualityReliability = captureQualityReliability,
            generatedRoutineAdjustment = generatedRoutineAdjustment,
            controlledRoutineRevision = controlledRoutineRevision,
            routineExecution = routineExecution,
            analysisVersion = analysisVersion
        )
    }
}

/**
 * UI-1B — Skin Map structured result. Mirrors exactly what MainActivity's existing
 * runLocalizedPatternMapping()/runPatternHotspotDetection()/runCrossViewHotspotComparison()
 * stages already compute per view, bundled for the UI instead of only being written to
 * per-stage JSON files.
 */
data class SkinMapViewData(
    val cells: List<PatternMapCell>,
    val hotspots: List<PatternHotspot>
)

data class SkinMapBundle(
    val front: SkinMapViewData,
    val leftCheek: SkinMapViewData,
    val rightCheek: SkinMapViewData,
    val crossViewComparison: HotspotComparison
)

object SkinMapAssembler {
    fun assemble(
        frontCells: List<PatternMapCell>,
        leftCells: List<PatternMapCell>,
        rightCells: List<PatternMapCell>
    ): SkinMapBundle {
        val frontHotspots = PatternHotspotAnalyzer.analyze(frontCells)
        val leftHotspots = PatternHotspotAnalyzer.analyze(leftCells)
        val rightHotspots = PatternHotspotAnalyzer.analyze(rightCells)
        val comparison = CrossViewHotspotComparator.compare(frontHotspots, leftHotspots, rightHotspots)
        return SkinMapBundle(
            front = SkinMapViewData(frontCells, frontHotspots),
            leftCheek = SkinMapViewData(leftCells, leftHotspots),
            rightCheek = SkinMapViewData(rightCells, rightHotspots),
            crossViewComparison = comparison
        )
    }
}
