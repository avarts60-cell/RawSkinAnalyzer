package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.StoredSkinSession
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.components.SessionHistoryRow
import com.rawskinanalyzer.ui.components.SkinScoreCard
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class NamedScore(val name: String, val score: Double)

private fun StoredSkinSession.namedScores(): List<NamedScore> = listOf(
    NamedScore("REDNESS", snapshot.rednessScore),
    NamedScore("PIGMENTATION_OR_TONE_VARIATION", snapshot.pigmentationScore),
    NamedScore("DARK_MARK_SIGNAL", snapshot.darkMarkScore),
    NamedScore("BLEMISH_LIKE_FEATURES", snapshot.blemishLikeScore),
    NamedScore("TEXTURE_IRREGULARITY", snapshot.textureScore),
    NamedScore("PORE_LIKE_FEATURES", snapshot.poreLikeScore),
    NamedScore("SURFACE_SHINE_SIGNAL", snapshot.shineScore),
    NamedScore("DRYNESS_RELATED_SURFACE_SIGNAL", snapshot.drynessScore)
)

/**
 * UI-1B — History. Reads only `SkinSessionRepository.history()` (via the ViewModel), i.e. the
 * real per-session score snapshots `FinalSkinAnalysisProfileAnalyzer.json()` already persists
 * on every completed session. A session's "leading signal" here is the same computation
 * `FinalSkinAnalysisProfile.primaryFinding` itself uses (highest of the same 8 characteristic
 * scores) applied to the stored snapshot — not a new or fabricated figure. Only scores and
 * overall confidence are persisted per session (no per-characteristic confidence, capture
 * quality, or thumbnail is stored today), so this screen shows exactly that and no more.
 */
@Composable
fun HistoryScreen(
    state: RawSkinUiState,
    onBack: () -> Unit,
    onOpenSession: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "History", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (state.sessionHistory.isEmpty()) {
            EmptyState(
                title = "No sessions yet",
                message = "Completed analysis sessions will appear here."
            )
            return@Column
        }

        val currentAnalysisVersion = state.analysisBundle?.analysisVersion

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                SectionHeader(title = "${state.sessionHistory.size} recorded session(s)")
                Spacer(Modifier.height(12.dp))
            }
            items(state.sessionHistory.withIndex().toList()) { (index, session) ->
                val fmt = remember { SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US) }
                val leading = session.namedScores().maxByOrNull { it.score }
                SessionHistoryRow(
                    dateLabel = fmt.format(Date(session.createdAtEpochMillis)),
                    leadingSignal = leading?.name ?: "NO_SIGNAL",
                    confidence = session.snapshot.confidence,
                    compatible = currentAnalysisVersion == null || session.analysisVersion == currentAnalysisVersion,
                    onClick = { onOpenSession(index) }
                )
                Spacer(Modifier.height(10.dp))
            }
        }
    }
}

/** UI-1B — Session Details: the stored per-characteristic score snapshot for one past session. */
@Composable
fun SessionDetailScreen(
    session: StoredSkinSession?,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Session Details", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (session == null) {
            EmptyState(title = "Session not found", message = "This session is no longer available.")
            return@Column
        }

        val fmt = remember { SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US) }
        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                ClinicalCard {
                    Text(text = fmt.format(Date(session.createdAtEpochMillis)), style = MaterialTheme.typography.titleMedium, color = ClinicalTextPrimary)
                    Spacer(Modifier.height(4.dp))
                    Text(text = "Analysis version: ${session.analysisVersion}", style = MaterialTheme.typography.bodySmall, color = ClinicalTextSecondary)
                }
                Spacer(Modifier.height(16.dp))
                SectionHeader(title = "Stored Characteristic Scores")
                Spacer(Modifier.height(10.dp))
            }
            items(session.namedScores().sortedByDescending { it.score }) { s ->
                SkinScoreCard(
                    characteristic = s.name,
                    score = s.score,
                    level = "",
                    confidence = session.snapshot.confidence
                )
                Spacer(Modifier.height(10.dp))
            }
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Only characteristic scores and overall session confidence are persisted per session — per-characteristic evidence text and capture-quality detail are not stored historically, so they cannot be shown here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ClinicalTextSecondary
                )
            }
        }
    }
}
