package com.rawskinanalyzer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rawskinanalyzer.ui.components.AnalysisStatusCard
import com.rawskinanalyzer.ui.components.ClinicalCard
import com.rawskinanalyzer.ui.components.EmptyState
import com.rawskinanalyzer.ui.components.LoadingState
import com.rawskinanalyzer.ui.components.FeatureProgressRow
import com.rawskinanalyzer.ui.components.LimitationNote
import com.rawskinanalyzer.ui.components.PillTag
import com.rawskinanalyzer.ui.components.SectionHeader
import com.rawskinanalyzer.ui.components.TrendSparkline
import com.rawskinanalyzer.ui.state.RawSkinUiState
import com.rawskinanalyzer.ui.theme.ClinicalTextPrimary
import com.rawskinanalyzer.ui.theme.ClinicalTextSecondary
import com.rawskinanalyzer.ui.theme.ClinicalTextTertiary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * UI-1B — Progress. Every value shown comes from `SkinProgressTracker`/`MultiSessionTrendAnalyzer`
 * output (via `UiAnalysisAssembler`) or `SkinSessionRepository.history()` — no session, score,
 * or trend direction is invented, and a `INSUFFICIENT_COMPARISON_DATA`/`INSUFFICIENT_TREND_DATA`
 * result is shown as a limitation, never silently upgraded into a comparison.
 */
@Composable
fun ProgressScreen(
    state: RawSkinUiState,
    onBack: () -> Unit
) {
    val bundle = state.analysisBundle
    var selectedFeature by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(24.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ClinicalTextSecondary,
                modifier = Modifier.clickable { onBack() }
            )
            Spacer(Modifier.width(12.dp))
            Text(text = "Progress", style = MaterialTheme.typography.headlineMedium, color = ClinicalTextPrimary)
        }
        Spacer(Modifier.height(20.dp))

        if (bundle == null) {
            if (state.analysisRunning) {
                LoadingState(message = "Running analysis pipeline for this session…")
            } else {
                EmptyState(
                    title = "No progress data yet",
                    message = "Complete a session to see progress. A second compatible session is needed for a comparison."
                )
            }
            return@Column
        }

        LazyColumn(contentPadding = PaddingValues(bottom = 32.dp)) {
            item {
                SectionHeader(title = "Session Timeline")
                Spacer(Modifier.height(10.dp))
                if (state.sessionHistory.isEmpty()) {
                    ClinicalCard {
                        Text(
                            text = "No prior sessions recorded yet on this device.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ClinicalTextSecondary
                        )
                    }
                } else {
                    ClinicalCard {
                        val fmt = remember { SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.US) }
                        state.sessionHistory.take(6).forEach { session ->
                            Text(
                                text = fmt.format(Date(session.createdAtEpochMillis)),
                                style = MaterialTheme.typography.bodySmall,
                                color = ClinicalTextSecondary
                            )
                            Spacer(Modifier.height(4.dp))
                        }
                        if (state.sessionHistory.size > 6) {
                            Text(
                                text = "+${state.sessionHistory.size - 6} earlier session(s)",
                                style = MaterialTheme.typography.labelSmall,
                                color = ClinicalTextTertiary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Baseline Comparison")
                Spacer(Modifier.height(10.dp))
                if (bundle.previousProgressSnapshot == null) {
                    ClinicalCard {
                        Text(
                            text = "No previous compatible session available yet — this is the baseline session.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ClinicalTextSecondary
                        )
                    }
                } else {
                    AnalysisStatusCard(
                        title = "Overall direction: ${bundle.progressResult.overallDirection.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                        detail = "Comparison confidence: ${bundle.progressResult.comparisonConfidence.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}"
                    )
                }
                if (bundle.progressResult.overallDirection.name == "INSUFFICIENT_COMPARISON_DATA") {
                    Spacer(Modifier.height(10.dp))
                    LimitationNote("Not enough compatible session history yet for a reliable baseline comparison.")
                }
                if (bundle.captureQualityReliability.name != "RELIABLE") {
                    Spacer(Modifier.height(10.dp))
                    LimitationNote("This session's capture-condition reliability was ${bundle.captureQualityReliability.name.lowercase()} — comparisons and routine-adjustment confidence have been capped accordingly, not treated as a full-strength result.")
                }
                Spacer(Modifier.height(20.dp))

                SectionHeader(title = "Characteristic Selection")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    bundle.progressResult.features.take(4).forEach { f ->
                        PillTag(
                            text = f.feature.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() },
                            tint = if (selectedFeature == f.feature) ClinicalTextPrimary else ClinicalTextTertiary,
                            modifier = Modifier.clickable { selectedFeature = f.feature }
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            val features = if (selectedFeature != null)
                bundle.progressResult.features.filter { it.feature == selectedFeature }
            else bundle.progressResult.features

            items(features) { f ->
                FeatureProgressRow(
                    feature = f.feature,
                    previousScore = f.previousScore,
                    currentScore = f.currentScore,
                    delta = f.delta,
                    direction = f.direction.name
                )
                val trend = bundle.multiSessionTrend.features.firstOrNull { it.feature == f.feature }
                if (trend != null) {
                    Spacer(Modifier.height(6.dp))
                    ClinicalCard {
                        Text(
                            text = "Multi-session trend (${bundle.multiSessionTrend.sessionsUsed} sessions): ${trend.direction.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }}",
                            style = MaterialTheme.typography.labelMedium,
                            color = ClinicalTextSecondary
                        )
                        Spacer(Modifier.height(8.dp))
                        TrendSparkline(values = trend.values)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            item {
                if (bundle.multiSessionTrend.overallDirection.name == "INSUFFICIENT_TREND_DATA") {
                    LimitationNote("At least three compatible sessions are needed for a multi-session trend — only ${bundle.multiSessionTrend.sessionsUsed} available so far.")
                }
            }
        }
    }
}
